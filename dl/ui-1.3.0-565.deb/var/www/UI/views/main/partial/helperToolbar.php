<div id="help_toolbar" class="toolbar_item">
	<div class="toolbar_button_container">
		<a href="#" class="toolbar_button" id="help_link">
            <span class="icon"></span>
            <span class="down_arrow"></span>
        </a>
	</div>
	<div id="help_list_container" class="toolbar_button_list_container">
		<ul>
			<li>
                <div class="help_topic_container">
			        <a href="http://setup.wd2go.com" target="_blank" id="olc_link" class="help_link_image internet_required">
                        <span><?php echo _('GLOB_NAV_HELP_LINK_OLC')?></span>
                    </a>
                </div>
            </li>
            <li>
                <div class="help_topic_container">
			        <a href="http://setup.wd2go.com" target="_blank" id="help_topic_help" class="help_link_image">
                        <span><?php echo _('GLOB_NAV_HELP_LINK_HELP')?></span>
                    </a>
                </div>
            </li> 
			<li>
                <div class="help_topic_container" id="help_topic_about">
			        <a href="#" id="help_about_link" class="help_link_image">
                        <span><?php echo _('GLOB_NAV_HELP_LINK_ABOUT')?></span>
                    </a>
                </div>
            </li>
		</ul>
	</div>
</div>