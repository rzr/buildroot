<div id="<?php echo $identifier?>_container">
    <div id="<?php echo $identifier?>_header" class="main_content_header">
        <h1><?php echo _($title)?></h1>
        <?php if (isset($subtitle)):?>
        <a href="#" id="<?php echo $identifier?>_help"><?php echo _($subtitle)?></a>
        <?php endif?>
    </div>
    <div class="content_full_container">
        <div id="<?php echo $identifier?>_content" class="content_container">
        	<?php $view->LoadViews(); $view->LoadContents();?>
    	</div>
	</div>
</div>