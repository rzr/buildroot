<div id="update_progress" title="<?php echo _('PAGE_HEADER_UPDATING_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
			<div id="update_progress_idle" class="update_progress_label">
                <p><?php echo _('LABEL_DESCR_UPDATE_PROCESS_IDLE'); ?></p>
            </div>
			<div id="update_progress_downloading" class="update_progress_label">
                <?php echo _('LABEL_DESCR_DOWNLOADING'); ?><span id="update_progress_percentage_downloading" class="update_progress_percentage"></span>
            </div>
			<div id="update_progress_upgrading" class="update_progress_label">
                <p><?php echo _('LABEL_DESCR_UPDATING'); ?><span id="update_progress_percentage_upgrading" class="update_progress_percentage"></span></p>
            </div>
			<div id="update_progress_failed" class="update_progress_label">
                <p><?php echo _('LABEL_DESCR_UPDATE_PROCESS_FAILED'); ?></p>
            </div>
			<div id="update_progress_inprogress" class="update_progress_label">
                <table>
                    <tr>
                        <td><span class="spinnerSunIcon"></span></td>
                        <td><?php echo _('CONTENT_SETTINGS_STRING_FIRMWARE_UPGRADE_IN_PROGRESS'); ?></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <br />
                            <div id="firmware_upgrade_progressbar_elapsed_time_container">
                                <span><?php echo _('CONTENT_SETTINGS_STRING_ELAPSED_TIME'); ?></span>:&nbsp;<span id="firmware_upgrade_elapsed_time"></span>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
			<div id="update_progressbar"></div>
			<p><?php echo _('LABEL_DESCR_AVATAR_FIRMWARE_UPDATE_PROGRESS'); ?></p>
		</div>
	</div>
</div>