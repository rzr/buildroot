$(document).ready(function(){
	$('#battery_settings_power_profile').restForm({
		'refreshDataCallback':function(data){
			//reset form and close it
            if (data != null && data.power_profile != null) {
                if (data.power_profile.profile == 'max_life') {
                    $('#settings_battery_max_life_button').addClass('button-selected');
                    $('#settings_battery_media_performance_button').removeClass('button-selected');
                }else{
                    $('#settings_battery_media_performance_button').addClass('button-selected');
                    $('#settings_battery_max_life_button').removeClass('button-selected');
                }
            }
		},
		'processFormSuccessCallback':function(data){
			//reset form and close it
			if ($('#settings_battery_profile').val() == 'max_life') {
            	$('#settings_battery_max_life_button').addClass('button-selected');
            	$('#settings_battery_media_performance_button').removeClass('button-selected');
            }else{
            	$('#settings_battery_media_performance_button').addClass('button-selected');
            	$('#settings_battery_max_life_button').removeClass('button-selected');
            }
		}
	});
    $('#battery_status_form').restForm({
		'refreshDataCallback':function(data){
            var battery_state = 'unknown';
            var battery_percent = 0;

            if (data != null && data.battery_status != null) {
                battery_state = data.battery_status.state.toLowerCase();
                battery_percent = parseInt(data.battery_status.percent_remaining);

                $('#battery_settings_current_level_text').html(battery_percent + '%');
                if (battery_state == 'charging' || battery_state == 'discharging') {
                	$('#battery_settings_current_state_text').html(dictionaryList['battery_status_state_'+battery_state]);
                	
                	if (battery_state == 'charging') {
                		$('#dashboard_battery_information_available_image').removeClass('discharging');
                		$('#dashboard_battery_information_available_image').addClass('charging');
                    }
                    else {
                    	$('#dashboard_battery_information_available_image').removeClass('charging');
                    	$('#dashboard_battery_information_available_image').addClass('discharging');
                    }
                }
                else {
                 	$('#battery_settings_current_state_text').html(dictionaryList['_unknown']);
                }
            }
		}
	});
	$('#settings_battery_max_life_button').click(function(){
		$('#settings_battery_profile').val('max_life');
		$('#battery_settings_power_profile').submit();		
	});
	$('#settings_battery_media_performance_button').click(function(){
		$('#settings_battery_profile').val('max_system_performance');
		$('#battery_settings_power_profile').submit();
	});
	$("#dashboard_battery_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_battery',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#dashboard_battery_dialog').attr('title')+'</div>'
	});
	
    $('#dashboard_battery_close_button').click(function(e){
    	$("#power_profile_form").submit();
        $('#dashboard_battery_dialog').dialog('close');
    });
    
	$('#power_profile_form').restFormDialog({
    	'dialogName': 'create_user_wizard',
    	'useStubs': false
    });
});
