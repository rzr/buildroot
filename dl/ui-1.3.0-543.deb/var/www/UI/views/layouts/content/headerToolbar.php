<div id="header_toolbar_contents">
    <?php $view->LoadNavigation();$view->LoadViews();$view->LoadContents();?>
</div>