<div class="content_row">
    <label><?php echo _('CONTENT_SETTINGS_LABEL_CURRENT_VERSION')?></label>
    <span id="settingUpdateCurrentFirmwareVersion">&nbsp;</span>
    <form id="firmware_info_default_form" action="firmware_info"></form>
    <form id="firmware_info_form" method="PUT" action="firmware_info"><input type="hidden" id="firmware_image" name="image" /></form>
</div>
<div class="content_row">
    <label><?php echo _('CONTENT_SETTINGS_LABEL_LAST_UPDATE')?></label>
    <span id="settingUpdateLastUpdateTime">&nbsp;</span>
</div>
