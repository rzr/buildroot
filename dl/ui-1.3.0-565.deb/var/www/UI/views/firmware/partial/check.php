
<div id="check_update_content" class="edit_container_box">

    <!--
    <h2><?php echo _("CONTENT_SETTINGS_HEAD2_AUTOMATIC_UPDATE");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("TOOLTIP_SETTINGS_FIRMWARE_AUTOMATIC_UPDATE");?></div></div></div></h2>
    <div class="no_firmware_update_container">
        <div class="content_row">
            <label><?php echo _('LABEL_DESCR_NO_UPDATE_AVAILABLE')?></label>
            <button id="disabled_update_btn"><?php echo _('CONTENT_SETTINGS_BUTTON_INSTALL_UPDATE')?></button>
        </div>
    </div>
    -->
    <h2><?php echo _("LABEL_AVAILABLE_UPDATES");?></h2>

    <div class="check_for_update_container">
        <div class="content_row">
            <label><?php echo _('CONTENT_SETTINGS_LABEL_NEW_FIRMWARE')?></label>
            <button class="check_for_update_btn"><?php echo _('CONTENT_SETTINGS_BUTTON_CHECK_FOR_UPDATE')?></button>
            <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_UPDATE_TOOLTIP_CHECK_FOR_UPDATE");?></div></div></div>
        </div>
    </div>

    <div class="update_now_container">
        <div class="content_row">
            <label class="update_now_label"><?php echo _('CONTENT_SETTINGS_LABEL_NEW_FIRMWARE')?></label>
            <span class="settingUpdateFirmwareNewVersion"></span>
            <span class="extra_space_left"><a href="#" class="settingUpdateFirmwareNewReleaseNotes" target="_blank"><?php echo _('CONTENT_SETTINGS_LINK_RELEASE_NOTES')?></a></span>
        </div>
    
        <div class="content_row">
            <label>&nbsp;</label>
            <button class="begin_update_available_btn"><?php echo _('CONTENT_SETTINGS_BUTTON_INSTALL_UPDATE')?></button>
            <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_ALERTS_STRING_BEGIN_UPDATE')?></div></div></div>
            <span class="settingUpdateFirmwareNewImage"></span>
            <span class="settingUpdateFirmwareNewMessage"></span>
        </div>
    </div>

</div>


