<?php

class Language{
    private $language;
    private $host = 'http://127.0.0.1';
    private $apiPath = '/api/2.4.1/rest/';
    
    public function getLanguage(){
        if (!isset($this->language)){
            //default to en_US
            $this->language = 'en_US';
            $url = $this->host.$this->apiPath.'language_configuration';
            $ch = curl_init($url);
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    		$result = curl_exec($ch);
    		curl_close($ch);
    		$xml = simplexml_load_string($result);
    		if ($xml !== false){
    		    $language = $xml->language;
    		    if (isset($language) && !empty($language) && $language != 'DEFAULT'){
    		        $this->language = $language;
    		    }
    		}
        }
        return trim($this->language);
    }
}