<?php
class Firmware{
    private $firmware;
    private $host = 'http://127.0.0.1';
    private $apiPath = '/api/2.4.1/rest/';

    public function getFirmware(){
        if (!isset($this->firmware)){
            $this->firmware = '0';
            $url = $this->host.$this->apiPath.'version';
            $ch = curl_init($url);
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    		$result = curl_exec($ch);
    		curl_close($ch);
    		$xml = simplexml_load_string($result);
    		if ($xml !== false){
    		    $firmware = $xml->firmware;
    		    if (isset($firmware) && !empty($firmware)){
    		        $this->firmware = $firmware;
    		    }
    		}
        }
        return $this->firmware;
    }
}
?>
