<div class="content_row">
    <form id="settings_wireless_name_form" action="#" method="PUT">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_WIRELESS_NAME')?></label>
        <input id="settings_wireless_name" type="text" name="wireless_name" value="MyPassportWifi" />
        <span class="form_controls">
            <input type="submit" value="<?php echo _("BUTTON_SAVE");?>" />
        </span>
    </form>
</div>
<div class="content_row">
    <form id="settings_wireless_security_form" action="device_description" method="PUT">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_SECURITY')?></label>
        <input type="checkbox" id = "SettingWirelessToggleSecurity" class = "onoffswitch"/>
    </form>
</div>