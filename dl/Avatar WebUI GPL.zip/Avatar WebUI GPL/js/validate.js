 var isValid;
var errors;
var formName;
// JavaScript Document

function validate(FormName, returnErrors, showToolTip) {
	formName = FormName;
	isValid = true;
	errors = new Array();

	$(formName).find("input[class~='error']").removeClass('error');
	$(formName).find("input, textarea").each(function() {
	    $(this).removeClass('error');
	    if ($(this).hasClass('NOTEMPTY')) validateNotEmpty(this, showToolTip);
	    //if ($(this).hasClass('OWNER_OLD_PASSWORD')) validateOwnerPassword(this, showToolTip);
		//if ($(this).hasClass('OWNER_PASSWORD')) validateOwnerPassword(this, showToolTip);
	    if ($(this).hasClass('DESCRIPTION')) validateDescription(this, showToolTip);
	    if ($(this).hasClass('SHARENAME')) validateShareName(this, showToolTip);
	    if ($(this).hasClass('DEVICE_NAME')) validateDeviceName(this, showToolTip);
	    if ($(this).hasClass('DEVICE_DESCRIPTION')) validateDeviceDescription(this, showToolTip);
	    if ($(this).hasClass('PERSON_NAME')) validatePersonName(this, showToolTip);
	    if ($(this).hasClass('WORKGROUP')) validateWorkgroup(this, showToolTip);
	    if ($(this).hasClass('USERNAME')) validateUsername(this, showToolTip);
		if ($(this).hasClass('ADD_FIRST_NAME')) validateFirstname(this, showToolTip);
        if ($(this).hasClass('OLD_PASSWORD')) validatePassword(this, showToolTip);
	    if ($(this).hasClass('PASSWORD')) validatePassword(this, showToolTip);
        if ($(this).hasClass('WPA_NETWORK_PASSWORD')) validateWPANetworkPassword(this, showToolTip);
        if ($(this).hasClass('WEP_NETWORK_PASSWORD')) validateWEPNetworkPassword(this, showToolTip);
        if ($(this).hasClass('WPS_PIN')) validateWPSPin(this, showToolTip);
	    if ($(this).hasClass('CONFIRM_PASSWORD')) validateConfirmPassword(this, showToolTip);
		if ($(this).hasClass('CONFIRM_OWNER_PASSWORD')) validateConfirmOwnerPassword(this, showToolTip);
        if ($(this).hasClass('NETWORK_SSID')) validateNetworkSSID(this, showToolTip);
	    if ($(this).hasClass('EMAIL')) validateEmail(this, showToolTip);
	    if ($(this).hasClass('EMAILNOTREQ')) validateEmailNotRequired(this, showToolTip);
		if ($(this).hasClass('WEBACCOUNTEMAIL')) validateWebAccountEmail(this, showToolTip);
	    if ($(this).hasClass('CONFIRM_EMAIL')) validateConfirmEmail(this, showToolTip);
		if ($(this).hasClass('IPADDRESS')) validateIPAddress(this, showToolTip);
		if ($(this).hasClass('NTP_SERVER')) validateNTPServer(this, showToolTip);
		//if ($(this).hasClass('NETMASK')) validateNetMask(this);	// netmask validated as part of IPAddress
		if ($(this).hasClass('GATEWAY')) validateGateway(this, showToolTip);
	    if ($(this).hasClass('SHARE_USERNAME')) validateRemoteShareDeviceUsername(this, showToolTip);
	    //if ($(this).hasClass('SHARE_PASSWORD')) validateSharePassword(this);
	    if ($(this).hasClass('DEVICE_USERNAME')) validateRemoteShareDeviceUsername(this, showToolTip);
	    //if ($(this).hasClass('DEVICE_PASSWORD')) validateSharePassword(this);
	    if ($(this).hasClass('SAFEPOINTNAME')) validateSafepointName(this, showToolTip);
		if ($(this).hasClass('NETWORK_PORT')) validateCustomNetworkPort(this, showToolTip);
		if ($(this).hasClass('HTTPS_PORT')) validateDupHTTPSNetworkPort(this, showToolTip);
	});
	
	
	if (errors.length > 0) {
		if (typeof returnErrors == 'undefined' || returnErrors == false){
			showError(errors);
		}else{
			isValid = errors;
		}
	}


	return isValid;
}

function validateNotEmpty(obj, showToolTip) {

	objStyle = $(obj).attr('style');
	if ((typeof(objStyle) != 'undefined') &&
		(objStyle.toLowerCase().indexOf('none') != -1)) 
	{
        return;
	}
	if ($(obj).val() === "") {
		$(obj).addClass('error');
		isValid = false;
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
            if ($(obj).hasClass('WPA_NETWORK_PASSWORD')) {
                //errors.push($(obj).attr('id') + '_wpa');
                errors.push('wpa_password_error');

                if (($(obj).attr('id') == 'create_network_password') || 
                    ($(obj).attr('id') == 'create_network_password_show') ||
                    ($(obj).attr('id') == 'create_network_password_confirm')) 
                {
                    $('#create_network_password_tip').addClass('error');
                }
            }
            else if ($(obj).hasClass('WEP_NETWORK_PASSWORD')) {
                //errors.push($(obj).attr('id') + '_wep');
                errors.push('wep_password_error');
            }
            else {
                errors.push($(obj).attr('id'));
            }
		}
	}
}

/*
function validateOwnerPassword(obj, showToolTip) {
	if ($(obj).val() === '') return;
	if ($(obj).val().length > 32 || $(obj).val().indexOf('"') > -1  || $(obj).val().indexOf('$') > -1 ) {
        $(obj).addClass('error');
        isValid = false;
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
    }
}
*/

function validateDeviceName(obj, showToolTip){
    var myRegexp =  /^([a-zA-Z0-9\-]+)$/;
    var myRegexp2 = /^([0-9]+[a-zA-Z0-9\-]*)$/;
    var deviceNameValid = true;

    if ($(obj).val().length < 2 || $(obj).val().length > 15 || !myRegexp.test($(obj).val())) {
        deviceNameValid = false;
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
    }
    else { 
        if (($(obj).val().indexOf('-') == 0) || ($(obj).val().lastIndexOf('-') == $(obj).val().length -1)) {
            if (showToolTip){
    			displayToolTip(obj, $(obj).attr('id') + '_dash');
    		}
            else{
            	errors.push($(obj).attr('id') + '_dash');
    		}
            deviceNameValid = false;
        }
        if (myRegexp2.test($(obj).val())) {
            if (showToolTip){
    			displayToolTip(obj, $(obj).attr('id') + '_number');
    		}
            else{
            	errors.push($(obj).attr('id') + '_number');
    		}
            deviceNameValid = false;
        }
    }

    if (!deviceNameValid) {
        $(obj).addClass('error');
        isValid = false;
    }
}

function validateDeviceDescription(obj, showToolTip){
	if($(obj).val().length < 1){
		return;
	}
	var myRegexp = /^\w[\w\s]*$/i;
	if ($(obj).val().length > 42 || !myRegexp.test($(obj).val())) {
		$(obj).addClass('error');
		isValid = false;
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
	}
}

function validatePersonName(obj, showToolTip){
	if ($(obj).val().length > 20 || $(obj).val().length < 1) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateWorkgroup(obj, showToolTip){
	var myRegexp = /^[A-Za-z0-9][-\w!@#$%^&()_\-;:\',.]+$/i;	// letter or number followed by characters, must be at least two characters long
	var myRegexp2 = /^[A-Za-z0-9]+$/i;  // letters or numbers , can be one or more characters long	
	
	if ($(obj).val().length < 1 || $(obj).val().length > 16 || !(myRegexp.test($(obj).val()) || myRegexp2.test($(obj).val()))) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateDescription(obj, showToolTip){
	if($(obj).val().length < 1){
		return;
	}
	var myRegexp = /^\w[\w\s]*$/i;
	if ($(obj).val().length > 256 || !myRegexp.test($(obj).val())) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateShareName(obj, showToolTip) {
	if ($(obj).hasClass('READONLYSHARE')) {
		return;
	}
    var myRegexp = /^\w+$/i;
    var reservedLPTRegexp = /^lpt(\d|\d\d)$/i;
    var reservedCOMRegexp = /^com(\d|\d\d)$/i;
    var reserved = ['public','shares','backup','ntp','con','aux','prn','nul'];
	var sharename = $(obj).val();
    test = $.inArray(sharename.toLowerCase(), reserved);
    if ($(obj).val().length < 1 || $(obj).val().length > 32 || !myRegexp.test($(obj).val())) {
        $(obj).addClass('error');
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
        isValid = false;
    }
    else if ((test > -1) || (reservedLPTRegexp.test(sharename.toLowerCase())) || (reservedCOMRegexp.test(sharename.toLowerCase()))){
		$(obj).addClass('error');

        if (errorsList["reserved_sharename_orig"] == undefined) {
            errorsList["reserved_sharename_orig"] = errorsList["reserved_sharename"];
        }
        else {
            errorsList["reserved_sharename"] = errorsList["reserved_sharename_orig"];
        }

        var newmsg = errorsList["reserved_sharename"].replace('{0}',sharename);
        errorsList["reserved_sharename"] = newmsg;

		if (showToolTip){
			displayToolTip(obj, 'reserved_sharename');
		}
		else{
			errors.push('reserved_sharename');
		}
		
		isValid = false;
	}
}


function validateUsername(obj, error_id, showToolTip) {
	if (error_id == null) {
		error_id = 'reserved_username';
	}
    //var myRegexp = /^\w+$/i;
    var myRegexp =  /^([a-zA-Z0-9\-]+)$/;
	var reservedLPTRegexp = /^lpt(\d|\d\d)$/i;
	var reservedCOMRegexp = /^com(\d|\d\d)$/i;
	var reserved = ['root','daemon','bin','sys','sync','games','man','lp','mail','news','uucp','proxy','backup','list','irc','gnats','nobody','libuuid','sshd','ntp','con','aux','prn','nul'];
	var username = $(obj).val();
	test = $.inArray(username.toLowerCase(),reserved);
	if (username.length < 1 || username.length > 32 || !myRegexp.test(username)) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
    else if (username.indexOf('-') == 0) {
        if (showToolTip){
			displayToolTip(obj, $(obj).attr('id') + '_dash');
		}
        else{
        	errors.push($(obj).attr('id') + '_dash');
		}
        isValid = false;
    }
    else if ((test > -1) || (reservedLPTRegexp.test(username.toLowerCase())) || (reservedCOMRegexp.test(username.toLowerCase()))){
		$(obj).addClass('error');

        if (errorsList["reserved_username_orig"] == undefined) {
            errorsList["reserved_username_orig"] = errorsList["reserved_username"];
        }
        else {
            errorsList["reserved_username"] = errorsList["reserved_username_orig"];
        }

        var newmsg = errorsList["reserved_username"].replace('{0}',username);
        errorsList["reserved_username"] = newmsg;

        if (showToolTip){
			displayToolTip(obj, 'reserved_username');
		}
        else{
        	errors.push('reserved_username');
		}
        
		isValid = false;
	}
}

function validateFirstname(obj, showToolTip) {
	validateUsername(obj, 'reserved_first_name', showToolTip);
}

function validateShareUsername(obj, showToolTip) {
    var myRegexp = /^\w+$/i;
    var reserved = [''];
    test = $.inArray($(obj).val(), reserved);
    if ($(obj).val().length < 1 || $(obj).val().length > 32 || !myRegexp.test($(obj).val()) || test > -1) {
        $(obj).addClass('error');
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
        isValid = false;
    }
}

function validateRemoteShareDeviceUsername(obj, showToolTip) {
    var reserved = [''];
    test = $.inArray($(obj).val(), reserved);
    if (test > -1) {
        $(obj).addClass('error');
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
        isValid = false;
    }
}

function validateIPAddress(obj, showToolTip) {
	var ipaddress = $(obj).val();
	var bError = false;
    var ipaddressID = $(obj).attr('id');

	// Make sure IP Address is valid IP
	errCode = validateIP(ipaddress, 'IPADDRESS');
	if (errCode !== 0) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_IPADDRESS_'+errCode.toString());
		}
		else{
			errors.push('Setting_IPADDRESS_' + errCode.toString());
		}
		isValid = false;
		bError = true;
	}

	// Make sure Subnet mask is valid
	var netmask;
    var netmaskID;
    if (ipaddressID == 'SettingIp') {
        netmask = $("#SettingNetmask").val();
        netmaskID = "#SettingNetmask";
    }
    else if (ipaddressID == 'wifi_edit_config_form_ipaddress') {
        netmask = $("#wifi_edit_config_form_netmask").text();   // text because netmask is not settable in wifi_edit_config_form
        netmaskID = "#wifi_edit_config_form_netmask";
    }
    else if (ipaddressID == 'wifi_signin_SettingIp') {
        netmask = $("#wifi_signin_SettingNetmask").val();
        netmaskID = "#wifi_signin_SettingNetmask";
    }
    else if (ipaddressID == 'wifi_modify_SettingIp') {
        netmask = $("#wifi_modify_SettingNetmask").val();
        netmaskID = "#wifi_modify_SettingNetmask";
    }
    else if (ipaddressID == 'wifi_signin_to_other_SettingIp') {
        netmask = $("#wifi_signin_to_other_SettingNetmask").val();
        netmaskID = "#wifi_signin_to_other_SettingNetmask";
    }

	errCode = validateNetMask(netmask);
	if (errCode !== 0) {
		$(netmaskID).addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_NETMASK_'+errCode.toString());
		}
		else{
			errors.push('Setting_NETMASK_' + errCode.toString());
		}
		isValid = false;
		bError = true;
	}

	// don't process host validation if ipaddress or netmask are invalid IPs
	if (bError === true) {
		return;
	}
	
	var ipArray = ipaddress.split('.');
	var netmaskArray = netmask.split('.');

	var networkAddressArray = getNetworkAddressArray(ipArray, netmaskArray);
	var broadcastAddressArray = getBroadcastAddressArray(networkAddressArray, netmaskArray);

	var ipInt = ipArrayToInt(ipArray);
	var networkAddressInt = ipArrayToInt(networkAddressArray);
	var broadcastAddressInt = ipArrayToInt(broadcastAddressArray);
	if (ipInt <= networkAddressInt || ipInt >= broadcastAddressInt){
		if (showToolTip){
			displayToolTip(obj, 'SETTING_IPADDRESS_1009');
		}
		else{
			errors.push('Setting_IPADDRESS_1009');
		}
		isValid = false;
		bError = true;
	}
		 
	return;
}

function getNetworkAddressArray(ipArray, netmaskArray){
	var networkAddressArray = new Array();
	networkAddressArray[0] = ipArray[0]&netmaskArray[0];
	networkAddressArray[1] = ipArray[1]&netmaskArray[1];
	networkAddressArray[2] = ipArray[2]&netmaskArray[2];
	networkAddressArray[3] = ipArray[3]&netmaskArray[3];
	return networkAddressArray;
}

function getBroadcastAddressArray(networkAddressArray, netmaskArray){
	var broadcastAddressArray = new Array();
	for(var i = 0; i < 4; i++){
		broadcastAddressArray[i] = networkAddressArray[i] | (~netmaskArray[i] & 255);
	}
	return broadcastAddressArray;
}

function ipArrayToInt(ipArray){
	if (ipArray.length !== 4)
	{
		return null;
	}
	return ipArray[0] * 16777216  // 2^24
		+ ipArray[1] * 65536  // 2^16
		+ ipArray[2] * 256  // 2^8
		+ ipArray[3] * 1;  // 2^0
}

function validateNTPServer(obj, showToolTip) {
	var ntpserver = $(obj).val();
	var bError = false;

	$ntpserver_texbox_visible = $('#primary_ntp').is(':visible');

	if((ntpserver.length < 1) && ($ntpserver_texbox_visible === false)){
		return;
	}

	errCode = validateHostNameOrIP(ntpserver, 'NTP');
	if (errCode !== 0) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_NTP_' + errCode.toString());
		}
		else{
			errors.push('Setting_NTP_' + errCode.toString());
		}
		isValid = false;
		bError = true;
	}
}

function invertNetmask(netmask) {
	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var netmaskArray = netmask.match(ipPattern);

	var inverseNetmask = '';
	inverseNetmaskArray = new Array();

	for (i = 0; i < 4; i++) {
		// netmaskArray[0] = 'a.b.c.d'
		// netmaskArray[1] = 'a'
		// netmaskArray[2] = 'b'
		// netmaskArray[3] = 'c'
		// netmaskArray[4] = 'd'
		ipSegment = netmaskArray[i+1];  // we only want the octets starting at index 1
		inverseNetmaskArray[i] = (255 - ipSegment);
		inverseNetmask += inverseNetmaskArray[i].toString();
		if (i < 3) {
			inverseNetmask += '.';
		}
	}
	return inverseNetmask;
}

function validateNetMask(netmask) {
	// make sure netmask is a valid IP
	errCode = validateIP(netmask, 'NETMASK');
	if (errCode !== 0) {
		return errCode;
	}

    //m[0] can be 128, 192, 224, 240, 248, 252, 254, 255
	//m[1] can be 128, 192, 224, 240, 248, 252, 254, 255 if m[0] is 255, else m[1] must be 0
	//m[2] can be 128, 192, 224, 240, 248, 252, 254, 255 if m[1] is 255, else m[2] must be 0
	//m[3] can be 128, 192, 224, 240, 248, 252, 254, 255 if m[2] is 255, else m[3] must be 0

	var flag = '';
	var correct_range = {128:1,192:1,224:1,240:1,248:1,252:1,254:1,255:1,0:1};
	var m = netmask.split('.');
	var binRepresentation = parseInt(m[0]).toString(2) + "" + parseInt(m[1]).toString(2) + "" + parseInt(m[2]).toString(2) + "" + parseInt(m[3]).toString(2);
	if ((m[0] === "0") || (m[0] != "255" && m[1] !== "0") || (m[1] != "255" && m[2] !== "0") || (m[2] != "255" && m[3] !== "0") ||
			(binRepresentation.indexOf('01', 0) >= 0)) {
		return 1009;
	}

	return 0;
}

// This function will validate whether the gateway is in the same subnet
function validateGateway(obj, showToolTip) {
	var bError = false;
    var gatewayID = $(obj).attr('id');
	var gateway = $(obj).val();

	// gateway is optional field
	if (gateway === '') {
		return;
	}

	// make sure gateway is a valid IP
	errCode = validateIP($(obj).val(), 'GATEWAY', showToolTip);
	if (errCode !== 0) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_GATEWAY_' + errCode.toString());
		}
		else{
			errors.push('Setting_GATEWAY_' + errCode.toString());
		}
		isValid = false;
		bError = true;
	}

    var strIpAddress;
    var subnetMask;

    if (gatewayID == 'SettingGateway') {
        strIpAddress = $("#SettingIp").val();
        subnetMask = $("#SettingNetmask").val();
    }
    else if (gatewayID == 'wifi_signin_SettingGateway') {
        strIpAddress = $("#wifi_signin_SettingIp").val();
        subnetMask = $("#wifi_signin_SettingNetmask").val();
    }
    else if (gatewayID == 'wifi_modify_SettingGateway') {
        strIpAddress = $("#wifi_modify_SettingIp").val();
        subnetMask = $("#wifi_modify_SettingNetmask").val();
    }
    else if (gatewayID == 'wifi_signin_to_other_SettingGateway') {
        strIpAddress = $("#wifi_signin_to_other_SettingIp").val();
        subnetMask = $("#wifi_signin_to_other_SettingNetmask").val();
    }

	// Make sure IP Address is valid IP
	errCode = validateIP(strIpAddress, 'IPADDRESS', showToolTip);
	if (errCode !== 0) {
		$("#SettingIp").addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_IPADDRESS_'+errCode.toString());
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
		bError = true;
	}

	// Make sure Subnet mask is valid
	errCode = validateNetMask(subnetMask, showToolTip);
	if (errCode !== 0) {
		$("#SettingNetmask").addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_NETMASK_'+errCode.toString());
		}
		else{
			errors.push('Setting_NETMASK_' + errCode.toString());
		}
		isValid = false;
		bError = true;
	}

	// don't process gateway subnet validation if gateway, ipaddress, or netmask are invalid IPs
	if (bError === true) {
		return;
	}
	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var subnetAddress = "";
	var subnetGatewayAddress = ""; 
	var ipArray = strIpAddress.split('.');
	var netArray = subnetMask.split('.');
	var gatewayArray = gateway.split('.');
	
	var networkAddressArray = getNetworkAddressArray(ipArray, netArray);
	var broadcastAddressArray = getBroadcastAddressArray(networkAddressArray, netArray);

	var ipInt = ipArrayToInt(ipArray);
	var gatewayInt = ipArrayToInt(gatewayArray);
	var networkAddressInt = ipArrayToInt(networkAddressArray);
	var broadcastAddressInt = ipArrayToInt(broadcastAddressArray);
	if (gatewayInt <= networkAddressInt || gatewayInt >= broadcastAddressInt || ipInt === gatewayInt){
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj, 'Setting_GATEWAY_1009');
		}
		else{
			errors.push('Setting_GATEWAY_1009');
		}
		isValid = false;
	}
}

function validatePassword(obj, showToolTip){
	if ($(obj).val() === '') return;
	if ($(obj).val().length > 32 || $(obj).val().indexOf('"') > -1) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateWPANetworkPassword(obj, showToolTip){
	if ($(obj).val() === '') return;
	if ($(obj).val().length < 8 || $(obj).val().length > 63 || $(obj).val().indexOf('"') > -1) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
            //errors.push($(obj).attr('id')+'_wpa');
            errors.push('wpa_password_error');
		}

        if (($(obj).attr('id') == 'create_network_password') || 
            ($(obj).attr('id') == 'create_network_password_show') ||
            ($(obj).attr('id') == 'create_network_password_confirm')) 
        {
            $('#create_network_password_tip').addClass('error');
        }

		isValid = false;
	}
}

function validateWEPNetworkPassword(obj, showToolTip){
    if ($(obj).val() === '') return;

    var myRegexp =  /^([a-fA-F0-9]+)$/;
    var WEPPassword = $(obj).val();
    var WEPPasswordLength = WEPPassword.length;

    if (WEPPassword.indexOf('"') > -1) {
        // cannot contain double quote charater
        isValid = false;
    }
    else if (WEPPasswordLength == 5 || WEPPasswordLength == 13) {
        // length of 5 or 13, it must be ASCII characters
    }
    else if (WEPPasswordLength == 10 || WEPPasswordLength == 26) {
        // if length is 10 or 26, it must be HEX characters
        if (!myRegexp.test(WEPPassword)) {
            isValid = false;
        }
    }
    else {
        isValid = false;
    }

    if (!isValid) {
        $(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
            //errors.push($(obj).attr('id')+'_wep');
            errors.push('wep_password_error');
		}
    }
}

function validateWPSPin(obj, showToolTip){
    if ($(obj).val() === '') return;

    var myRegexp = /^([0-9]+)$/;
	if ($(obj).val().length != 8 || !myRegexp.test($(obj).val())) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
            errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateNetworkSSID(obj, showToolTip){
    if ($(obj).val() === '') return;

    var ssidName = $(obj).val();
    var ssidNameLength = ssidName.length;

    if ((ssidName.indexOf(' ') == 0) || (ssidName.indexOf(' ') == ssidNameLength-1)) {
        $(obj).addClass('error');
        if (showToolTip){
            displayToolTip('ssidname_begin_end_space');
        }
        else{
            errors.push('ssidname_begin_end_space');
        }
        isValid = false;
    }
}

function validateSharePassword(obj, showToolTip) {
    if ($(obj).val() === '') return;
    if ($(obj).val().length > 16 || $(obj).val().indexOf('"') > -1) {
        $(obj).addClass('error');
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
        isValid = false;
    }
}


function validateSafepointName(obj, showToolTip) {
    var myRegexp = /^\w+$/i;
    var reserved = [''];
    test = $.inArray($(obj).val(), reserved);
    if ($(obj).val().length < 1 || $(obj).val().length > 32 || !myRegexp.test($(obj).val()) || test > -1) {
        $(obj).addClass('error');
        if (showToolTip){
			displayToolTip(obj);
		}
        else{
			errors.push($(obj).attr('id'));
		}
        isValid = false;
    }
}

function validateConfirmPassword(obj, showToolTip){
    var passwordClass = "input.PASSWORD";
    if (($(obj).attr('id') == 'create_network_password_confirm') ||
        ($(obj).attr('id') == 'wifi_edit_config_form_password_confirm'))
    { 
        passwordClass = "input.NETWORK_PASSWORD";
    }

	mainPassword = $(formName).find(passwordClass).val();
	if ($(obj).val() != mainPassword) {
		$(obj).addClass('error');

        if (($(obj).attr('id') == 'edit_user_password_confirm') || 
            ($(obj).attr('id') == 'create_login_password_confirm') ||
            ($(obj).attr('id') == 'create_network_password_confirm') ||
            ($(obj).attr('id') == 'settings_admin_user_form_password_confirm') ||
            ($(obj).attr('id') == 'wifi_edit_config_form_password_confirm'))
        {
            if (showToolTip){
    			//displayToolTip(obj, $(obj).attr('id') + '_not_match');
                displayToolTip(obj, 'password_not_match');
    		}
            else{
            	//errors.push($(obj).attr('id')+'_not_match');
                errors.push('password_not_match');
    		}
        }
        else {
            if (showToolTip){
    			displayToolTip(obj);
    		}
            else{
            	errors.push($(obj).attr('id'));
    		}
        }

		isValid = false;
	}
}

function validateConfirmOwnerPassword(obj, showToolTip){
	// Owner has 3 password input box:
	// eq(0) - old password input box, 
	// eq(1) - new password input box, 
	// eq(2) - confirm password input box
	mainPassword = $(formName).find("input.PASSWORD").eq(1).val();
	if ($(obj).val() != mainPassword) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
        else{
        	errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateEmailNotRequired(obj, showToolTip){
	if($(obj).val().length < 1){
		return;
	}
	var myRegexp = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9\-]{2,4})+$/;
	if (!myRegexp.test($(obj).val())) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
        else{
        	errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateEmail(obj, showToolTip){
	var myRegexp = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9\-]{2,4})+$/;
	if (!myRegexp.test($(obj).val())) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
        else{
        	errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateWebAccountEmail(obj, showToolTip){

	var newWebAccountEmail = $(obj).val();
	var dupEmail = false;
	$('.webaccount_list_item').each(function(idx) {
		// skip template
		if (idx > 0) {
			idxWebAccountEmail = $(this).find('#account_email_id').html();
			if (newWebAccountEmail.toLowerCase() == idxWebAccountEmail.toLowerCase()) {
				$(obj).addClass('error');
				if (showToolTip){
					displayToolTip(obj, 'save_webaccount_duplicate');
				}
	            else{
	            	errors.push('save_webaccount_duplicate');
	    		}
				isValid = false;
				return;
			}
		}
    });
}

function validateConfirmEmail(obj, showToolTip){
	mainEmail = $(formName).find("input.EMAIL").val();
	if ($(obj).val() != mainEmail) {
		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateCustomNetworkPort(obj, showToolTip){
	if($(obj).val().length < 1){
		return;
	}
	var myRegexp = /^([0-9]+)$/;
	var portnum = parseInt($(obj).val(), 10);
	var isError = false;

	if ($(obj).val().length > 5 || !myRegexp.test($(obj).val())) {
		isError = true;
	}
	else if (portnum < 1024 || portnum > 65535) {

		// exception custom http=80 and https=443
		if ($(obj).hasClass('HTTP_PORT') && portnum == 80) {
			isError = false;
		}
		else if ($(obj).hasClass('HTTPS_PORT') && portnum == 443) {
			isError = false;
		}
		else {
			isError = true;
		}
	}

	if (isError) {
        var newmsg;
		if ($(obj).hasClass('HTTP_PORT')) {

            if (errorsList["remote_access_settings_manual_port1_orig"] == undefined) {
                errorsList["remote_access_settings_manual_port1_orig"] = errorsList["remote_access_settings_manual_port1"];
            }
            else {
                errorsList["remote_access_settings_manual_port1"] = errorsList["remote_access_settings_manual_port1_orig"];
            }

            newmsg = errorsList["remote_access_settings_manual_port1"].replace('{0}',portnum);
            errorsList["remote_access_settings_manual_port1"] = newmsg;
		}
		else if ($(obj).hasClass('HTTPS_PORT')) {

            if (errorsList["remote_access_settings_manual_port2_orig"] == undefined) {
                errorsList["remote_access_settings_manual_port2_orig"] = errorsList["remote_access_settings_manual_port2"];
            }
            else {
                errorsList["remote_access_settings_manual_port2"] = errorsList["remote_access_settings_manual_port2_orig"];
            }

            newmsg = errorsList["remote_access_settings_manual_port2"].replace('{0}',portnum);
            errorsList["remote_access_settings_manual_port2"] = newmsg;
		}

		$(obj).addClass('error');
		if (showToolTip){
			displayToolTip(obj);
		}
		else{
			errors.push($(obj).attr('id'));
		}
		isValid = false;
	}
}

function validateDupHTTPSNetworkPort(obj, showToolTip) {

	var https_port = $(obj).val();
	var http_port = $(formName).find("input.HTTP_PORT").val();
	
	if (https_port == http_port) {
		$(obj).addClass('error');
		isValid = false;
		bError = true;
		if (showToolTip){
			displayToolTip(obj, 'https_port_dup');
		}
		else{
			errors.push('https_port_dup');
		}
	}
}

function displayToolTip(obj, errorMsg){
    var tooltip_message;
	if (typeof errorMsg == 'undefined' || errorMsg == null){
		errorMsg = $(obj).attr('id');
	}
	var itemToAppend = $(obj);
	var inputBoxParent = $(obj).parent('.deleteicon');
	if (inputBoxParent.length > 0){
		itemToAppend = inputBoxParent[0];
	}
    if (errorsList[errorMsg] != undefined) {
        tooltip_message = errorsList[errorMsg];
    }
    else {
        tooltip_message = errorMsg;
    }
	$('<span class="error_tooltip_container"><span class="error_icon"></span><span class="tooltip_inner_container"><span class="tooltip">'+tooltip_message+'</span></span></span>')
		.insertAfter(itemToAppend)
		.find('.error_icon')
		.bind('mouseover touchstart click', function(){
			var tooltip = $(this).siblings('.tooltip_inner_container').find('.tooltip').first();
	    	if (!tooltip.is(':visible')){
		    	var timeToShow = 3000+tooltip.html().length*70;
		    	tooltip.show().oneTime(timeToShow, function(){
		    		$(this).fadeOut(200);
		    	});
	    	}})
	    .bind('mouseleave', function(){
	    	var tooltip = $(this).siblings('.tooltip_inner_container').find('.tooltip').first();
	    	tooltip.hide();
	    });
}



