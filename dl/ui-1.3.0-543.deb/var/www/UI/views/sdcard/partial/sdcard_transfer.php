<div id="sd_card_media_transfer" class="edit_container_box">
    <h2><?php echo _("CONTENT_SETTINGS_HEAD2_SD_CARD_TRANSFER");?></h2>

    <div class="content_row sdcard_transfer_location">
		<label><?php echo _('CONTENT_SETTINGS_LABEL_AFTER_TRANSFER_FILE_LOCATION')?></label>
        <span id="sdcard_transfer_location"><?php echo _("CONTENT_SETTINGS_STRING_AFTER_TRANSFER_FILE_LOCATION");?></span>
    </div>

    <div class="content_row">
    	<form id="sdcard_after_transfer_form" method="PUT" action="storage_transfer">
    		<label><?php echo _('CONTENT_SETTINGS_LABEL_AFTER_TRANSFER')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("TOOLTIP_SETTINGS_IMPORT_MODE");?></div></div></div></label>
            <button type="button" id="settings_sdcard_transfer_copy_mode_button" class="left-button"><?php echo _('BUTTON_LEAVE_ORIGINAL')?></button><button type="button" id="settings_sdcard_transfer_move_mode_button" class="right-button"><?php echo _('BUTTON_DELETE_ORIGINAL')?></button>
    	    <input type="hidden" id="settings_sdcard_transfer_mode" name="transfer_mode" value=""/>
        </form>
    </div>
    
    <div class="content_row">
    	<form id="sdcard_automatic_transfer_form" method="PUT" action="storage_transfer">
    		<label><?php echo _('CONTENT_SETTINGS_LABEL_AUTOMATIC_TRANSFER')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("TOOLTIP_SETTINGS_SD_CARD_AFTER_TRANSFER");?></div></div></div></label>
            <input type="checkbox" class="onoffswitch" id="sdcard_automatic_transfer_switch"/>
            <input type="hidden" id="scard_auto_transfer_field" name="auto_transfer" value=""/>
    	</form>
    </div>

    <div class="content_row" id="sdcard_transfer_now_button_container">
    	<form id="sdcard_transfer_now" method="POST" action="storage_active_transfer">
            <label><?php echo _('CONTENT_SETTINGS_LABEL_IMPORT_FILES')?></label>
            <input type="hidden" id="jobs_async" name="async" value="true" />
            <input type="submit" id="copy_move_now_button" value="<?php echo _('CONTENT_SETTINGS_STRING_COPY_NOW')?>" />
            <span class="extra_space_left" id="last_import_timestamp_container">
                <?php echo _('CONTENT_SETTINGS_STRING_LAST_IMPORT')?>&nbsp;
                <span id="last_import_date_value"></span>&nbsp;<span id="last_import_time_value"></span>
            </span>
    	</form>
    </div>

    <div class="content_row" id="sdcard_transfer_in_progress_container">
        <form id="sdcard_transfer_progress_default_form" method="GET" action="jobs"></form>
    	<form id="sdcard_transfer_progress_form" method="GET" action="jobs"></form>

		<label><?php echo _('CONTENT_SETTINGS_LABEL_IMPORT_FILES')?></label>

        <span id="sdcard_transfer_completed_container">
            <button type="button" id="sdcard_transfer_progressbar_completed"><?php echo _('CONTENT_SETTINGS_STRING_COMPLETE')?></button>
            <span class="extra_space_left" id="sdcard_transfer_progressbar_completed_result"></span>
        </span>
        <span id="sdcard_transfer_inprogress_container">
            <span id="sdcard_transfer_progressbar" class="generic_progressbar"></span>
            <span class="extra_space_left" id="sdcard_transfer_progress"></span>
            <!--<span class="extra_space_left" id="sdcard_transfer_progressbar_percentage"></span>-->
            <!--<span class="extra_space_left"></span><button id="cancel_sdcard_transfer_button"><?php echo _('BUTTON_CANCEL')?></button>-->
        </span>
    </div>

</div>
