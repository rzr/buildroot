<div id="shutting_down" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_SHUTTING_DOWN');?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <p><?php echo _('LABEL_DESCR_AVATAR_SHUTTING_DOWN');?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="shutting_down_close_button"  class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
