<div id="dashboard_devices_box" class="dashboard_medium_box dashboard_box">
	<div class="header"><h3><?php echo _('Devices')?></h3></div>
    <div id="dashboard_devices_count" class="dashboard_count">2</div>
    <div class="footer"><a href="#" id="dashboard_devices_link"></a></div>
</div>