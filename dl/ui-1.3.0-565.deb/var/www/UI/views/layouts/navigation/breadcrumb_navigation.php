<div id="<?php echo $identifier?>_breadcrumb_container" class="breadcrumb_container">
	<nav id="<?php echo $identifier?>_breadcrumb_nav" class="breadcrumb_nav">
        <ul id="<?php echo $identifier?>_breadcrumb_nav_ul" class="nav_ul">
        	<?php foreach($navigationItems as $navigationItemGroup): 
			    foreach($navigationItemGroup as $navigationItemList):
			    	foreach($navigationItemList as $navigationItem):?>
        	<li id="<?php echo $navigationItem->id?>" class="main_nav_li <?php if (isset($navigationItem->default) && $navigationItem->default === true):?>current <?php endif?> <?php if (isset($navigationItem->group)):?>group<?php echo $navigationItem->group?> <?php if ($navigationItemList == end($navigationItemGroup) && $navigationItem == end($navigationItemList)):?>last<?php endif?>"<?php endif?>><div><a href="<?php echo $navigationItem->link?>" id="<?php echo $navigationItem->id?>_link"><span class="main_nav_link_title"><?php echo _($navigationItem->title)?></span></a></div></li>
        		    <?php endforeach;
        		endforeach;
        	endforeach;?>
        </ul>
	</nav>
</div>