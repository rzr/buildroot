<div id="confirm_upgrade_firmware_dialog" title="<?php echo _('PAGE_HEADER_UPDATE_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
		<?php echo _('LABEL_DESCR_AVATAR_UPDATE_FROM_FILE_REBOOT'); ?>
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="confirm_upgrade_firmware_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="confirm_upgrade_firmware_ok_button" class="mochi_dialog_save_button"><?php echo _('CONTENT_SETTINGS_DIALOG_BUTTON_INSTALL_AND_REBOOT')?></button>
	</div>
</div>

<div id="confirm_upgrade_firmware_message_dialog" title="<?php echo _('PAGE_HEADER_UPDATE_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">

            <!-- display firmware package info -->
            <div id="confirm_upgrade_firmware_message_name"></div>
            <div><a href="#" target="_blank" id="confirm_upgrade_firmware_message_releasenotes"><?php echo _('CONTENT_SETTINGS_LINK_RELEASE_NOTES'); ?></a></div>

            <!-- firmware EULA message -->
            <div id="confirm_upgrade_firmware_message">
                <br />
                <iframe id="confirm_upgrade_firmware_message_iframe" frameborder="0" height="297px" width="100%"></iframe>  
            </div>

            <!-- checkbox for firmware EULA message -->
            <div id="confirm_upgrade_firmware_message_acceptance">
                <br />
                <form id="confirm_upgrade_firmware_message_acceptance_form">
                    <input type="checkbox" class="normal_checkbox" id="confirm_upgrade_firmware_message_acceptance_input" name="confirm_upgrade_firmware_message_acceptance" value=""/>
                    <label class="fw_eula_checkbox_label" for="confirm_upgrade_firmware_message_acceptance_input"><?php echo _('LABEL_FW_UPGRADE_EULA_ACCEPTANCE')?></label>
                </form>
            </div>

		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="confirm_upgrade_firmware_message_dialog_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
        <button type="button" id="confirm_upgrade_firmware_message_dialog_next_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_NEXT')?></button>
	</div>
</div>


