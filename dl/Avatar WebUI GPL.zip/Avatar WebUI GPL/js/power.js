$(document).ready(function(){
    $('#head_settings_nav_hardware_link').navItem({
        'contentId': 'hardware_container',
        'refreshDataCall': function(){

        	// Set Selection
        	resetNavigationSelection('#head_settings_nav_hardware_link');

        	pollingHandler.poll();
            refreshSettingsHardwareForms();
        }
    });
});