<div id="confirm_import_config" title="<?php echo _('PAGE_HEADER_IMPORT_CONFIGURATION_FILE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
	        <?php echo _('LABEL_DESCR_CONFIGURATION_UPDATE_REBOOT'); ?>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="confirm_import_config_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="confirm_import_config_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>