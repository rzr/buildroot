<div id="dashboard_wifi_box" class="dashboard_medium_box dashboard_box">
	<div class="header">
        <h3 class="network_mode network_default_title"><?php echo _('CONTENT_HOME_SMALL_BOX_TITLE_CONNECTION')?></h3>
        <h3 class="network_mode mode_direct_connection"><?php echo _('CONTENT_SETTINGS_TITLE_DIRECT_CONNECTION')?></h3>
        <h3 class="network_mode mode_trusted_network"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></h3>
        <h3 class="network_mode mode_network_hotspot"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></h3>
    </div>
    <div class="connection_diagram">
        <span class="me_text overflow_hidden_nowrap_ellipsis"></span>
        <span class="connection_text overflow_hidden_nowrap_ellipsis"></span>
        <span class="device_text overflow_hidden_nowrap_ellipsis"></span>
    </div>
</div>