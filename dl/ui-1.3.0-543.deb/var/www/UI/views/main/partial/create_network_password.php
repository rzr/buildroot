
<div id="create_network_security_container">
    <div id="create_network_password_content">
        <h2><?php echo _('GLOB_NAV_LOGIN_TITLE_SECURE_YOUR_AVATAR_NETWORK_CONNECTION')?></h2>
        <form id="create_network_password_form" action="wifi_ap" method="PUT">
            <div class="white_bg">

                <div class="create_network_password_static_content">
                    <span class="enabled"></span>
                    <span class="broadcast"></span>
                    <span class="security_mode"></span>
                </div>

                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_NAME'); ?></label>
                    <input type="text" id="create_network_ssid" name="ssid" class="NETWORK_SSID NOTEMPTY" maxlength="32" />
                    <span id="create_network_original_ssid" class="original_settings"></span>
                </div>
    
                <div class="content_row">
                    <label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_CREATE_PASSWORD')?></label>
                    <span id="create_network_password_container">
                        <input type="password" id="create_network_password" name="security_key" class="NETWORK_PASSWORD WPA_NETWORK_PASSWORD NOTEMPTY" maxlength="63" autocomplete="off" />
                    </span>
                    <span id="create_network_password_show_container">
                        <input type="text" id="create_network_password_show" name="security_key" maxlength="63" />
                    </span>
                </div>
        
                <div class="content_row" id="create_network_password_confirm_container">
                    <label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_CONFIRM_PASSWORD')?></label>
                    <input type="password" id="create_network_password_confirm" class="CONFIRM_PASSWORD" maxlength="63" autocomplete="off"/>
                </div>

                <div class="content_row" id="create_network_password_tip">
                    <?php echo _('CONTENT_LOGIN_GENERAL_WIFI_PASSWORD_TIP')?>
                </div>
        
                <div class="content_row">
                    <label>&nbsp;</label>
                    <input type="checkbox" class="normal_checkbox" id="create_network_password_show_password_checkbox" /> <?php echo _('CONTENT_SETTINGS_STRING_SHOW_PASSWORD')?>
                </div>
    
                <input type="hidden" name="enabled" />
                <input type="hidden" name="broadcast" />
                <input type="hidden" name="security_mode" />
                
            </div>
                
            <div class="content_row" id="create_network_password_buttons">
                <input type="button" id="create_network_password_skip_button"  value="<?php echo _('BUTTON_SKIP')?>" />
                <input type="button" id="create_network_password_ok_button" class="wizard_action" value="<?php echo _('BUTTON_NEXT')?>" />
            </div>
        </form>
    </div>
    <div class="pass_city"></div>
</div>


<div id="confirm_skip_network_password_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_WARNING')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_SKIP_NETWORK_PASSWORD_WARNING_1')?></p>
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_SKIP_NETWORK_PASSWORD_WARNING_2')?></p>
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_CONTINUE_WITHOUT_PASSWORD')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="confirm_skip_network_password_close_button" class="close"><?php echo _('GLOB_NAV_EULA_BUTTON_GO_BACK')?></button>
    	<button type="button" id="confirm_skip_network_password_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="confirm_network_no_password_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_WARNING')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_SKIP_NETWORK_PASSWORD_WARNING_1')?></p>
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_SKIP_NETWORK_PASSWORD_WARNING_2')?></p>
            <p><?php echo _('GLOB_NAV_DIALOG_STRING_CONTINUE_WITHOUT_PASSWORD')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="confirm_network_no_password_close_button" class="close"><?php echo _('GLOB_NAV_EULA_BUTTON_GO_BACK')?></button>
    	<button type="button" id="confirm_network_no_password_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
