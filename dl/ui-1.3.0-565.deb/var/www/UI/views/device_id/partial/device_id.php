<div class="dashboard_box dashboard_long_box" id="dashboard_device_id_box">
    <div id="footer_device_image"></div>
    <div id="footer_device_name"><?php echo _('DEVICE_NAME')?></div>
    <div id="footer_device_version"></div>
    <div id="footer_device_details">
        <span id="footer_device_capacity"></span>
        <span id="footer_device_datetime_container">
            <span id="footer_device_date_value"></span>&nbsp;
            <span id="footer_device_time_value"></span>
        </span>
        <form id="footer_device_timestamp_form" action="date_time_configuration" method="PUT">
            <input id="footer_device_timestamp_datetime" name="datetime" type="hidden"/>
            <input id="footer_device_timestamp_ntpservice" name="ntpservice" type="hidden"/>
            <input name="ntpsrv0" type="hidden"/>
            <input name="ntpsrv1" type="hidden"/>
            <input name="ntpsrv_user" type="hidden"/>
            <input name="time_zone_name" type="hidden"/>
        </form>
    </div>
</div>