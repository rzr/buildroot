<?php
$eula = 'eula/'.LANGUAGE_STR.'/EULA.html';

?>
<div id="eula_container">
    <div id="eula_content" class="eula_background">
        <div id="eulaView">
            <div id="eulaHead">
                <div class="eulaTitle"><?php echo _('PAGE_HEADER_WESTERN_DIGITAL_TECHNOLOGIES'); ?></div>
                <span class="eulaSubtext"><?php echo _('LABEL_AVATAR_DESCR_PLEASE_READ_LICENSE_AGREEMENT');  ?></span>
            </div>
            <div id="eulaTextWrap">
                <div id="eulaText">
                <iframe src="<?php echo $eula; ?>?_=<?php echo time(); ?>" id="eula_iframe"></iframe>
                    <?php //echo $this->renderElement($eula); ?>        
                </div>
            </div>
            <div id="eulaActions">
                <table width="100%">
                    <tr>
                        <td width="33%"><button id="eulaDeclineLink"><?php echo _('GENERIC_LABEL_DECLINE_EULA'); ?></button></td>
                        <td width="33%" align="middle"><a href="#" id="privacyPolicyLink"><?php echo _('CONTENT_SETTINGS_LINK_PRIVACY_POLICY')?></a></td>
                        <td width="33%"><button id="eulaAgreeLink"><?php echo _('AVATAR_GENERIC_LABEL_ACCEPT_EULA'); ?></button></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div id="eula_city"></div>
</div>
