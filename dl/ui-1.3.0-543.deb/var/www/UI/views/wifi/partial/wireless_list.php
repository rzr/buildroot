<div id="wifi_ap_container" class="wifi_network_outer_box">
    
    <div id="wifi_ap_list_container">
        <a href="#" class="wifi_ap_list_refresh"></a>
        <div id="wifi_ap_container_title" class="content_row wifi_box_title overflow_hidden_nowrap_ellipsis"><?php echo _('CONTENT_SETTINGS_LABEL_CHOOSE_INTERNET_CONNECTION')?></div>
        <div id="wifi_ap_list_content" class="wifi_network_inner_box">
            <div class="wifi_list_please_wait">
                <span class="spinnerSunIcon"></span><br >
                <?php echo _('LABEL_DESCR_PLEASE_WAIT'); ?>
            </div>
            <ul id="wifi_ap_list" class="mochi_list">
                <li id="ap_default" class="wifi_ap_list_item default">
                    <label class="wireless_ssid_label overflow_hidden_nowrap_ellipsis"><span class="wireless_label_text"></span></label>
                    <div class="wireless_info">
                        <div class="wireless_wps"></div>
                        <div class="wireless_lock"></div>
                        <div class="wireless_strength"></div>
                        <div class="wireless_ap_ssid"></div>
                        <div class="wireless_ap_mac"></div>
                        <div class="wireless_ap_security_mode"></div>
                    </div>
                    <div class="wireless_client_info">
                        <div class="wireless_client_ip"></div>
                        <div class="wireless_client_netmask"></div>
                        <div class="wireless_client_gateway"></div>
                        <div class="wireless_client_dns0"></div>
                        <div class="wireless_client_dns1"></div>
                        <div class="wireless_client_dns2"></div>
                    </div>
                </li>
            </ul>
        </div>
        <div id="wifi_client_ap_submit_container">
            <button id="wifi_client_ap_submit_btn"><?php echo _('BUTTON_JOIN')?></button>
        </div>
    </div>
    
    <div id="connected_wifi_network_container">
        <div class="content_row wifi_box_title">
            <span class="network_mode mode_direct_connection"><?php echo _('CONTENT_SETTINGS_TITLE_DIRECT_CONNECTION')?></span>
            <span class="network_mode mode_trusted_network"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></span>
            <span class="network_mode mode_network_hotspot"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></span>
        </div>
    
        <div id="selected_wireless_network_content" class="wifi_network_inner_box">
            <!--
            <div class="edit_settings_button">
                <div id="connected_wifi_network_settings" class="settings_cog"></div>
            </div>
            -->
            <div id="selected_wireless_network_image"></div>
            <div id="selected_wireless_network_ssid_container">
                <span class="selected_wireless_network_ssid"></span>
                <div class="tooltip_container">
                    <span class="tooltip_icon"></span>
                    <div class="tooltip_inner_container">
                        <div class="tooltip">
                            <ul>
                        	    <li><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_SSID')?>: <span class="selected_wireless_network_ssid"></span></li>
                        	    <!--<li><?php echo _('LABEL_HEADER_IP_ADDRESS')?> <span class="selected_wireless_network_ip_address"></span></li>-->
                                <li><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_ROUTER')?>: <span class="selected_wireless_network_gateway"></span></li>
                                <!--<li><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_DNS')?>: <span class="selected_wireless_network_dns"></span></li>-->
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="no_internet_access"><?php echo _('CONTENT_SETTINGS_NETWORK_STRING_NO_INTERNET_ACCESS')?></div>
            </div>
        </div>
    </div>

</div>

