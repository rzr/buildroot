<div class="content_row">
    <!--<label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_POWER')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_DIAGNOSTICS_TOOLTIP_REBOOT_SHUTDOWN')?></div></div></div></label>-->
    <button id="shutdown_btn"><?php echo _('AVATAR_LABEL_SHUTDOWN')?></button>
    <span class="extra_space_left"></span><button id="reboot_btn"><?php echo _('LABEL_REBOOT')?></button>
</div>