<?php

// DEPRECATED - moved to views/support/partial/popups

$lang = LANGUAGE_3CHAR;

$productDoc = 'http://products.wd.com/?id=wdfmycloud&type=um';
$faq = 'http://products.wdc.com/?id=wdfmycloud&amp;type=faq&amp;language='.$lang;
$forum = 'http://products.wdc.com/?id=wdfmycloud&amp;type=forum';
$contacts = 'http://products.wdc.com/?id=wdfmycloud&amp;type=contact';
$privacyPolicy = 'http://products.wdc.com/?id=wdfmycloud&amp;type=privacypolicy&amp;language='.$lang;
?>
<div id="support_dialog" title="<?php echo _('CONTENT_DIALOG_HELP_TITLE_SUPPORT')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div id="support_dialog_content" class="mochi_dialog_content">

            <div class="edit_container_box">
                <h2><?php echo _('CONTENT_DIALOG_HELP_HEAD2_REQUEST_AUTOMATED_SUPPORT')?></h2>
                <p><?php echo _('CONTENT_DIALOG_HELP_DESC_REQUEST_AUTOMATED_SUPPORT')?></p>

                <p><?php echo _('CONTENT_DIALOG_HELP_STRING_CHECK_AND_CLICK_REQUEST_SUPPORT_DESC1')?></p>
                <p><?php echo _('CONTENT_DIALOG_HELP_STRING_CHECK_AND_CLICK_REQUEST_SUPPORT_DESC2')?></p>

                <form id="request_automated_support_form" method="POST" action="system_log">
                    <div class="content_row">
                        <input type="checkbox" class="normal_checkbox" id="request_automated_support" name="request_support" value=""/>
                        <label class="help_checkbox_label" for="request_automated_support"><?php echo _('CONTENT_DIALOG_HELP_STRING_ATTACH_MY_DIAGNOSTIC_REPORT')?></label>
                    </div>

                    <div class="content_row">
                        <button id="support_run_request_support_button"><?php echo _('BUTTON_REQUEST_SUPPORT')?></button>&nbsp;&nbsp;&nbsp;<a href="<?php echo $privacyPolicy?>" target="_blank"><?php echo _('CONTENT_SETTINGS_LINK_PRIVACY_POLICY')?></a>
                    </div>
                </form>
            </div>

            <div class="edit_container_box">
                <h2><?php echo _('CONTENT_DIALOG_HELP_HEAD2_CREATE_AND_SAVE_SYSTEM_REPORT')?></h2>
                <p><?php echo _('CONTENT_DIALOG_HELP_DESC_CREATE_AND_SAVE_SYSTEM_REPORT')?></p>
                <button type="button" id="support_run_report_button"><?php echo _('CONTENT_SETTINGS_BUTTON_CREATE_AND_SAVE')?></button>
            </div>

            <div class="edit_container_box">
                <h2><?php echo _('CONTENT_DIALOG_HELP_HEAD2_SUPPORT_RESOURCES')?></h2>
                <div><a href="<?php echo $productDoc?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_PRODUCT_DOCUMENTATION')?></a></div>
                <div><a href="<?php echo $faq?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_FAQS')?></a></div>
                <div><a href="<?php echo $forum?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_FORUM')?></a></div>
                <div><a href="<?php echo $contacts?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_CONTACTS')?></a></div>
            </div>
        </div>
	</div>

	<div class="dialog_form_controls">
    	<button type="button" id="support_dialog_close_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>      
