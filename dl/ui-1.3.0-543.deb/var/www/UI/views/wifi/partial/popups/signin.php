<?php
    include(realpath(dirname(__FILE__))."/../../../../views/common/wifi_security_modes.php");
?>

<div id="wifi_signin_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_SIGN_IN_TO')?>" class="mochi_dialog_container">
    <div class="mochi_dialog_content_container">
    	<div class="mochi_dialog_content">
            <!--<form id="wifi_signin_form_default" action="current_wifi_client_connection" method="POST"></form>-->
            <form id="wifi_signin_form" action="current_wifi_client_connection" method="POST">
        
                <!--
                <div class="content_row" id="wifi_signin_trusted_container">
                    <label><?php echo _('CONTENT_SETTINGS_LABEL_TYPE_OF_SETUP')?></label>
                    <span id="wifi_signin_form_type"></span>
                </div>
                -->

                <div class="content_row" id="wifi_signin_trusted_toggle_container">
                	<label><?php echo _('CONTENT_SETTINGS_LABEL_TYPE_OF_SETUP')?></label>
                    <button type="button" id="wifi_signin_form_type_untrusted_button" class="left-button"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></button><button type="button" id="wifi_signin_form_type_trusted_button" class="right-button"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></button>
                    <div class="tooltip_container">
                        <span class="tooltip_icon"></span>
                        <div class="tooltip_inner_container">
                            <div class="tooltip">
                            	<?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOTSPOT')?><br /><br />
                                <?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOME_NETWORK')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content_row" id="wifi_signin_wps_toggle_container">
                	<label>&nbsp;</label>
                    <button type="button" id="wifi_signin_use_password_button" class="left-button"><?php echo _('BUTTON_USE_PASSWORD')?></button><button type="button" id="wifi_signin_use_wps_button" class="right-button"><?php echo _('BUTTON_USE_WPS')?></button>
                    <div class="tooltip_container">
                        <span class="tooltip_icon"></span>
                        <div class="tooltip_inner_container">
                            <div class="tooltip">
                            	<?php echo _('HELP_GET_CONNECT_TO_HOME_ITEM4_SUB1')?><br /><br />
                                <?php echo _('HELP_GET_CONNECT_TO_HOME_ITEM4_SUB2')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content_row" id="wifi_signin_wps_pin_container">
                    <label><?php echo _('CONTENT_SETTINGS_LABEL_WPS_PIN')?></label>
                    <input type="text" id="wifi_signin_wps_pin" name="wps_pin" maxlength="8" />
                </div>

                <div class="content_row display_ssid_password">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_PASSWORD')?></label>
                    <span id="wifi_signin_form_password_container"><input type="password" id="wifi_signin_form_password" name="security_key" maxlength="63" /></span>
                    <span id="wifi_signin_form_password_show_container"><input type="text" id="wifi_signin_form_password_show" name="security_key" maxlength="63" /></span>
               </div>

                <div class="content_row display_ssid_password">
                    <label>&nbsp;</label>
                    <input type="checkbox" class="normal_checkbox" id="wifi_signin_form_show_password_checkbox" /> <?php echo _('CONTENT_SETTINGS_STRING_SHOW_PASSWORD')?>
                </div>

                <!-- Auto-Join not supported
                <div class="content_row">
                    <label><?php echo _('CONTENT_SETTINGS_LABEL_AUTO_JOIN')?></label>
                    <input type="checkbox" id="wifi_signin_auto_join_toggle" class="onoffswitch"/>
		            <input type="hidden" id="wifi_signin_auto_join_value" name="auto_join" value="true"/>
                </div>
                -->

                <!--<input type="hidden" name="ssid" id="wifi_signin_form_ssid" value="" />-->
                <span id="wifi_signin_form_ssid"></span>
                <input type="hidden" name="mac_address" id="wifi_signin_form_mac_address" value="" />
		<input type="hidden" name="security_mode" id="wifi_signin_form_security_mode" value="" />
                <input type="hidden" name="trusted" id="wifi_signin_form_trusted" value="" />

                <!-- Client Network Settings -->
                <div class="content_row advanced_options_row">
                    <label class="show_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="right_arrow"></span>
                    </label>
                    <label class="hide_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="down_arrow"></span>
                    </label>
                </div>

                <div class="advanced_options_container">

                    <div class="content_row settings_mac_clone">
                        <label><?php echo _('CONTENT_SETTINGS_LABEL_MACADDRESS_CLONE')?></label>
		        <input type="hidden" class="mac_clone_value" name="mac_clone_enable" value="false"/>
		        <input type="checkbox" class="onoffswitch mac_clone_toggle"/>
                        <input type="hidden" class="cloned_mac_address" name="cloned_mac_address"/>
                        <div class="tooltip_container">
                            <span class="tooltip_icon"></span>
                            <div class="tooltip_inner_container">
                                <div class="tooltip">
                                    <?php echo _('CONTENT_SETTINGS_TOOLTIP_MACADDRESS_CLONE')?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_MAC_ADDRESS')?></label>
                        <span class="wifi_network_settings_mac_address"></span>
                    </div>
                    <div class="content_row">
                    	<label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?></label>
                        <span class="wifi_network_settings_device_name"></span>
                    </div>        	
                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_NETWORK_MODE')?></label>
                        <button type="button" class="wifi_settings_network_mode_dhcp_button left-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_DHCP')?></button><button type="button" class="wifi_settings_network_mode_static_button right-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_STATIC')?></button>
                        <input type="hidden" class="wifi_settings_dhcp_enabled" name="dhcp_enabled" value="true"/>
                    </div>
                    
                    <!--
                    <div class="wifi_client_network_settings_dhcp_container">
                        <div class="content_row">
                       	    <label><?php echo _('LABEL_HEADER_IP_ADDRESS')?></label>
                            <span class="wifi_network_settings_dhcp_ip_address"></span>
                        </div>
                    </div>
                    -->
                    <div class="wifi_client_network_settings_static_container">
               		<div class="content_row">
                            <div class="input text">
                		<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?><span class="required">&nbsp;*</span></label>
                		<input type="text" id="wifi_signin_SettingIp" class="IPADDRESS wifi_settings_ip wifi_static_network_settings" name="ip" />
                	    </div>
                	</div>
                	<div class="content_row">
            		<div class="input text">
            		    <label><?php echo _("LABEL_HEADER_NETMASK")?><span class="required">&nbsp;*</span></label>
            		    <input type="text" id="wifi_signin_SettingNetmask" class="NETMASK wifi_settings_netmask wifi_static_network_settings" name="netmask" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _("LABEL_HEADER_GATEWAY")?></label>
            		    <input type="text" id="wifi_signin_SettingGateway" class="GATEWAY wifi_settings_gateway wifi_static_network_settings" name="gateway" />
            		</div>
            	    </div>
                    <div class="content_row">
            		<div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_1')?></label>
            		    <input type="text" id="wifi_signin_SettingDns0" class="DNS wifi_settings_dns0 wifi_static_network_settings" name="dns0" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_2')?></label>
            		    <input type="text" id="wifi_signin_SettingDns1" class="DNS wifi_settings_dns1 wifi_static_network_settings" name="dns1" />
            		</div>
            	    </div>
                    <input type="hidden" id="wifi_signin_SettingDns2" class="wifi_settings_dns2 wifi_static_network_settings" name="dns2" />
                    <div class="content_row">
                            <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
                        </div>
                    </div>
                </div>
                <!-- Client Network Settings -->

            </form>
        </div>
    </div>
	<div class="dialog_form_controls">
    	<button type="button" id="wifi_signin_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
        <input type="submit" id="wifi_signin_save_button" class="mochi_dialog_save_button" value="<?php echo _('BUTTON_OK')?>" />
	</div>
</div>

<div id="wifi_modify_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_MODIFY')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
    	<div class="mochi_dialog_content">
            <form id="wifi_modify_form" action="wifi_client_access_points" method="PUT">
                <div class="content_row" id="wifi_modify_trusted_toggle_container">
                	<label><?php echo _('CONTENT_SETTINGS_LABEL_TYPE_OF_SETUP')?></label>
                    <button type="button" id="wifi_modify_form_type_untrusted_button" class="left-button"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></button><button type="button" id="wifi_modify_form_type_trusted_button" class="right-button"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></button>
                    <div class="tooltip_container">
                        <span class="tooltip_icon"></span>
                        <div class="tooltip_inner_container">
                            <div class="tooltip">
                            	<?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOTSPOT')?><br /><br />
                                <?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOME_NETWORK')?>
                            </div>
                        </div>
                    </div>
                </div>

                <input type="hidden" name="mac_address" id="wifi_modify_form_mac_address" value="" />
                <input type="hidden" name="trusted" id="wifi_modify_form_trusted" value="" />

                <!-- Client Network Settings -->
                <div class="content_row advanced_options_row">
                    <label class="show_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="right_arrow"></span>
                    </label>
                    <label class="hide_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="down_arrow"></span>
                    </label>
                </div>

                <div class="advanced_options_container">

                    <div class="content_row settings_mac_clone">
                        <label><?php echo _('CONTENT_SETTINGS_LABEL_MACADDRESS_CLONE')?></label>
        	        <input type="hidden" class="mac_clone_value" name="mac_clone_enable" value="false"/>
        	        <input type="checkbox" class="onoffswitch mac_clone_toggle"/>
                        <input type="hidden" class="cloned_mac_address" name="cloned_mac_address"/>
                        <div class="tooltip_container">
                            <span class="tooltip_icon"></span>
                            <div class="tooltip_inner_container">
                                <div class="tooltip">
                                    <?php echo _('CONTENT_SETTINGS_TOOLTIP_MACADDRESS_CLONE')?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_MAC_ADDRESS')?></label>
                        <span class="wifi_network_settings_mac_address"></span>
                    </div>
                    <div class="content_row">
                    	<label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?></label>
                        <span class="wifi_network_settings_device_name"></span>
                    </div>        	
                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_NETWORK_MODE')?></label>
                        <button type="button" class="wifi_settings_network_mode_dhcp_button left-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_DHCP')?></button><button type="button" class="wifi_settings_network_mode_static_button right-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_STATIC')?></button>
                        <input type="hidden" class="wifi_settings_dhcp_enabled" name="dhcp_enabled" value="true"/>
                    </div>
                    
                    <div class="wifi_client_network_settings_dhcp_container">
                        <div class="content_row">
                       	    <label><?php echo _('LABEL_HEADER_IP_ADDRESS')?></label>
                            <span class="wifi_network_settings_dhcp_ip_address"></span>
                        </div>
                    </div>
                    <div class="wifi_client_network_settings_static_container">
               		<div class="content_row">
                            <div class="input text">
                		<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?><span class="required">&nbsp;*</span></label>
                		<input type="text" id="wifi_modify_SettingIp" class="IPADDRESS wifi_settings_ip wifi_static_network_settings" name="ip" />
                	    </div>
                	</div>
                	<div class="content_row">
            		<div class="input text">
            		    <label><?php echo _("LABEL_HEADER_NETMASK")?><span class="required">&nbsp;*</span></label>
            		    <input type="text" id="wifi_modify_SettingNetmask" class="NETMASK wifi_settings_netmask wifi_static_network_settings" name="netmask" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _("LABEL_HEADER_GATEWAY")?></label>
            		    <input type="text" id="wifi_modify_SettingGateway" class="GATEWAY wifi_settings_gateway wifi_static_network_settings" name="gateway" />
            		</div>
            	    </div>
                    <div class="content_row">
            		<div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_1')?></label>
            		    <input type="text" id="wifi_modify_SettingDns0" class="DNS wifi_settings_dns0 wifi_static_network_settings" name="dns0" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_2')?></label>
            		    <input type="text" id="wifi_modify_SettingDns1" class="DNS wifi_settings_dns1 wifi_static_network_settings" name="dns1" />
            		</div>
            	    </div>
                    <input type="hidden" id="wifi_modify_SettingDns2" class="wifi_settings_dns2 wifi_static_network_settings" name="dns2" />
                    <div class="content_row">
                            <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
                        </div>
                    </div>
                </div>
                <!-- Client Network Settings -->
            </form>
        </div>
    </div>
	<div class="dialog_form_controls">
    	<button type="button" id="wifi_modify_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
        <!--<span class="extra_space_left"><button type="button" id="wifi_modify_disconnect_button" class="close"><?php echo _('BUTTON_DISCONNECT')?></button></span>-->
        <input type="submit" id="wifi_modify_save_button" class="mochi_dialog_save_button" value="<?php echo _('BUTTON_OK')?>" />
	</div>
</div>

<div id="wifi_signin_to_other_network_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_SIGN_IN_TO')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
    	<div class="mochi_dialog_content">
            <form id="wifi_signin_to_other_network_form" action="current_wifi_client_connection" method="POST">

                <div class="content_row" id="wifi_signin_to_other_network_trusted_container">
                    <label><?php echo _('CONTENT_SETTINGS_LABEL_TYPE_OF_SETUP')?></label>
                    <span id="wifi_signin_to_other_network_form_type"></span>
                </div>

                <div class="content_row" id="wifi_signin_to_other_network_trusted_toggle_container">
                	<label><?php echo _('CONTENT_SETTINGS_LABEL_TYPE_OF_SETUP')?></label>
                    <button type="button" id="wifi_signin_to_other_network_form_type_untrusted_button" class="left-button"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></button><button type="button" id="wifi_signin_to_other_network_form_type_trusted_button" class="right-button"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></button>
                    <div class="tooltip_container">
                        <span class="tooltip_icon"></span>
                        <div class="tooltip_inner_container">
                            <div class="tooltip">
                            	<?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOTSPOT')?><br /><br />
                                <?php echo _('CONTENT_SETTINGS_TOOLTIP_NETWORK_MODE_HOME_NETWORK')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content_row">
                	<label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_NAME')?></label>
                	<input id="wifi_signin_to_other_network_form_ssid" name="ssid" type="text" value="" class="NETWORK_SSID NOTEMPTY" />
                </div>

                <div class="content_row">
                    <label><?php echo _('CONTENT_SETTINGS_DIALOG_LABEL_WIFI_SECURITY')?></label>
                    <div class="selectBox defaultfont">
                        <select id="wifi_signin_to_other_network_form_security_mode_select"><?php foreach($client_security_modes as $index=>$security_mode):?>
                            <option value="<?php echo $index?>"><?php echo $security_mode?></option>
                        <?php endforeach;?></select>
                    </div>
                </div>

                <div class="content_row display_wifi_encryption">
                    <label><?php echo _('CONTENT_SETTINGS_DIALOG_LABEL_WIFI_ENCRYPTION')?></label>
                    <div class="selectBox defaultfont">
                        <select id="wifi_signin_to_other_network_form_encryption_select"><?php foreach($encryption_types as $index=>$encryption_type):?>
                            <option value="<?php echo $index?>"><?php echo $encryption_type?></option>
                        <?php endforeach;?></select>
                    </div>
                </div>

                <div class="content_row display_ssid_password">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_PASSWORD')?></label>
                    <span id="wifi_signin_to_other_network_form_password_container"><input type="password" id="wifi_signin_to_other_network_form_password" name="security_key" maxlength="63" /></span>
                    <span id="wifi_signin_to_other_network_form_password_show_container"><input type="text" id="wifi_signin_to_other_network_form_password_show" name="security_key" maxlength="63" /></span>
                </div>

                <div class="content_row display_ssid_password">
                    <label>&nbsp;</label><input type="checkbox" class="normal_checkbox" id="wifi_signin_to_other_network_form_show_password_checkbox" /> <?php echo _('CONTENT_SETTINGS_STRING_SHOW_PASSWORD')?>
                </div>

                <!--
                <div class="content_row">
                    <label><?php echo _('CONTENT_SETTINGS_LABEL_AUTO_JOIN')?></label>
                    <input type="checkbox" id="wifi_signin_to_other_network_auto_join_toggle" class="onoffswitch"/>
		            <input type="hidden" id="wifi_signin_to_other_network_join_value" name="auto_join" value="true"/>
                </div>
                -->

                <input type="hidden" name="security_mode" id="wifi_signin_to_other_network_form_security_mode" value="" />
                <input type="hidden" name="trusted" id="wifi_signin_to_other_network_form_trusted" value="" />

                <!-- Client Network Settings -->
                <div class="content_row advanced_options_row">
                    <label class="show_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="right_arrow"></span>
                    </label>
                    <label class="hide_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="down_arrow"></span>
                    </label>
                </div>

                <div class="advanced_options_container">

                    <div class="content_row settings_mac_clone">
                        <label><?php echo _('CONTENT_SETTINGS_LABEL_MACADDRESS_CLONE')?></label>
        	        <input type="hidden" class="mac_clone_value" name="mac_clone_enable" value="false"/>
        	        <input type="checkbox" class="onoffswitch mac_clone_toggle"/>
                        <input type="hidden" class="cloned_mac_address" name="cloned_mac_address"/>
                        <div class="tooltip_container">
                            <span class="tooltip_icon"></span>
                            <div class="tooltip_inner_container">
                                <div class="tooltip">
                                    <?php echo _('CONTENT_SETTINGS_TOOLTIP_MACADDRESS_CLONE')?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_MAC_ADDRESS')?></label>
                        <span class="wifi_network_settings_mac_address"></span>
                    </div>
                    <div class="content_row">
                    	<label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?></label>
                        <span class="wifi_network_settings_device_name"></span>
                    </div>        	
                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_NETWORK_MODE')?></label>
                        <button type="button" class="wifi_settings_network_mode_dhcp_button left-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_DHCP')?></button><button type="button" class="wifi_settings_network_mode_static_button right-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_STATIC')?></button>
                        <input type="hidden" class="wifi_settings_dhcp_enabled" name="dhcp_enabled" value="true"/>
                    </div>
                    
                    <!--
                    <div class="wifi_client_network_settings_dhcp_container">
                        <div class="content_row">
                       	    <label><?php echo _('LABEL_HEADER_IP_ADDRESS')?></label>
                            <span class="wifi_network_settings_dhcp_ip_address"></span>
                        </div>
                    </div>
                    -->
                    <div class="wifi_client_network_settings_static_container">
               		<div class="content_row">
                            <div class="input text">
                		<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?><span class="required">&nbsp;*</span></label>
                		<input type="text" id="wifi_signin_to_other_SettingIp" class="IPADDRESS wifi_settings_ip wifi_static_network_settings" name="ip" />
                	    </div>
                	</div>
                	<div class="content_row">
            		<div class="input text">
            		    <label><?php echo _("LABEL_HEADER_NETMASK")?><span class="required">&nbsp;*</span></label>
            		    <input type="text" id="wifi_signin_to_other_SettingNetmask" class="NETMASK wifi_settings_netmask wifi_static_network_settings" name="netmask" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _("LABEL_HEADER_GATEWAY")?></label>
            		    <input type="text" id="wifi_signin_to_other_SettingGateway" class="GATEWAY wifi_settings_gateway wifi_static_network_settings" name="gateway" />
            		</div>
            	    </div>
                    <div class="content_row">
            		<div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_1')?></label>
            		    <input type="text" id="wifi_signin_to_other_SettingDns0" class="DNS wifi_settings_dns0 wifi_static_network_settings" name="dns0" />
            		</div>
            	    </div>
            	    <div class="content_row">
            	        <div class="input text">
            		    <label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_2')?></label>
            		    <input type="text" id="wifi_signin_to_other_SettingDns1" class="DNS wifi_settings_dns1 wifi_static_network_settings" name="dns1" />
            		</div>
            	    </div>
                    <input type="hidden" id="wifi_signin_to_other_SettingDns2" class="wifi_settings_dns2 wifi_static_network_settings" name="dns2" />
                    <div class="content_row">
                            <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
                        </div>
                    </div>
                </div>
                <!-- Client Network Settings -->

            </form>
        </div>
    </div>
	<div class="dialog_form_controls">
    	<button type="button" id="wifi_signin_to_other_network_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
        <input type="submit" id="wifi_signin_to_other_network_save_button" class="mochi_dialog_save_button" value="<?php echo _('BUTTON_OK')?>" />
    </div>
</div>

<div id="wifi_signin_confirmation_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_AVATAR_NETWORK_CONNECTION_CHANGING')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <div id="connect_or_switch_to_home_mode">
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_DIRECT_CONNECTION_PARAGRAPH_1')?></p>
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_DIRECT_CONNECTION_PARAGRAPH_2')?></p>
            </div>
            <div id="switch_home_to_hotspot_or_home">
                <!--<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_1')?></p>-->
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_2')?></p>
            </div>
            <br />
            <p><?php echo _('CONTENT_DIALOG_ALERTS_STRING_WOULD_YOU_LIKE_TO_PROCEED_WITH_THIS_CHANGE')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="wifi_signin_confirmation_overlay_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="wifi_signin_confirmation_overlay_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="wifi_modify_confirmation_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_AVATAR_NETWORK_CONNECTION_CHANGING')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <div id="modify_wifi_to_home_mode">
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_DIRECT_CONNECTION_PARAGRAPH_1')?></p>
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_DIRECT_CONNECTION_PARAGRAPH_2')?></p>
            </div>
            <div id="modify_wifi_to_hotspot_mode">
                <!--<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_1')?></p>-->
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_2')?></p>
            </div>
            <br />
            <p><?php echo _('CONTENT_DIALOG_ALERTS_STRING_WOULD_YOU_LIKE_TO_PROCEED_WITH_THIS_CHANGE')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="wifi_modify_confirmation_overlay_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="wifi_modify_confirmation_overlay_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="wifi_disconnect_confirmation_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_AVATAR_NETWORK_CONNECTION_CHANGING')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
	    <div class="mochi_dialog_content">
            <!--<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_1')?></p>-->
            <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ABOUT_TO_LOSE_HOME_CONNECTION_PARAGRAPH_2')?></p>
            <br />
            <p><?php echo _('CONTENT_DIALOG_ALERTS_STRING_WOULD_YOU_LIKE_TO_PROCEED_WITH_THIS_CHANGE')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="wifi_disconnect_confirmation_overlay_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="wifi_disconnect_confirmation_overlay_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="wifi_signin_complete_message_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_NETWORK_CONNECTION_CHANGED')?>" class="mochi_dialog_container">
    <div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">

            <div id="signin_complete_message_to_home_mode">
                <p id="home_network_reconnect_intro"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_HOME_NETWORK')?></p>
                <span><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_TO_RECONNECT')?></span>
                <ul>
                    <li id="home_network_reconnect_tip_1"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIFFERENT_NETWORK_TO_RECONNECT_TIP_1')?></li>
                    <li id="home_network_reconnect_tip_2"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIFFERENT_NETWORK_TO_RECONNECT_TIP_2')?></li>
                </ul>
            </div>

            <div id="signin_complete_message_to_hotspot">
                <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_PARAGRAPH_1')?></p>
                <ul>
                    <li id="hotspot_connection_reconnect_tip_1"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_TO_RECONNECT_TIP_1')?></li>
                    <li id="hotspot_connection_reconnect_tip_2"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_TO_RECONNECT_TIP_2')?></li>
                </ul>
            </div>

            <!--<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_CAN_NOT_ACCESS_WEB_UI')?></p>-->

            <div class="connection_diagram_container">
                <div class="connection_diagram">
                    <span class="me_text overflow_hidden_nowrap_ellipsis"></span>
                    <span class="connection_text overflow_hidden_nowrap_ellipsis"></span>
                    <span class="device_text overflow_hidden_nowrap_ellipsis"></span>
                </div>
            </div>

		</div>
	</div>
</div>

<div id="wifi_disconnect_complete_message_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_NETWORK_CONNECTION_CHANGED')?>" class="mochi_dialog_container">
    <div class="mochi_dialog_content_container no_dialog_form_controls">
	<div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_PARAGRAPH_1')?></p>
            <ul>
                <li id="direct_connection_reconnect_tip_1"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_TO_RECONNECT_TIP_1')?></li>
                <li id="direct_connection_reconnect_tip_2"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_ON_DIRECT_CONNECTION_TO_RECONNECT_TIP_2')?></li>
            </ul>

            <div class="connection_diagram_container">
                <div class="connection_diagram">
                    <span class="me_text overflow_hidden_nowrap_ellipsis"></span>
                    <span class="connection_text overflow_hidden_nowrap_ellipsis"></span>
                    <span class="device_text overflow_hidden_nowrap_ellipsis"></span>
                </div>
            </div>

		</div>
	</div>
</div>

<div id="verify_wifi_signin_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_CONNECTING_TO')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
    	<div class="mochi_dialog_content">
            <div class="verify_wifi_signin_status connecting">
                <table>
                    <tr>
                        <td><span class="spinnerSunIcon"></span></td>
                        <td><?php echo _('LABEL_DESCR_PLEASE_WAIT'); ?></td>
                    </tr>
                </table>
            </div>
            <span class="verify_wifi_signin_status password_failed"><?php echo _('ERROR_CURRENT_WIFI_CLIENT_CONNECTION_ERROR')?></span>
            <span class="verify_wifi_signin_status wps_failed"><?php echo _('ERROR_CURRENT_WIFI_CLIENT_CONNECTION_WPS_ERROR')?></span>
        </div>
    </div>
	<div class="dialog_form_controls">
        <button type="button" class="close mochi_dialog_save_button" id="verify_wifi_signin_overlay_close_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

