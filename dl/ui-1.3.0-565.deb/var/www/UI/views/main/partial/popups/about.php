<?php
$gpl = 'GNU%20Public%20License/gpl-3.0.html';
$copyright = 'Copyright%20Info/Copyright%20Info.txt'; 
?>
<div id="about_dialog" class="mochi_dialog_container" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_ABOUT'); ?>">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <div id="about_device_image">
            	<div id="about_device_image_content">
                    <?php echo _('GLOB_NAV_HELP_STRING_FIRMWARE_VERSION')?>:&nbsp;<span id="about_firmware_version"></span>
                    <p><?php echo _('GLOB_NAV_HELP_STRING_COPYRIGHT')?>&nbsp;&copy;&nbsp;<?php echo _('GLOB_AVATAR_NAV_HELP_STRING_COPYRIGHT_2013_WD_ALL_RIGHT_RESERVED')?></p>
                    <p id="about_copyright_container">
                        <a href="<?php echo $copyright?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_COPYRIGHT_INFO')?></a><br />
                        <a href="<?php echo $gpl?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_GNU_PUBLIC_LICENSE')?></a>
                    </p>
                </div>
            </div>
        </div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="about_dialog_close_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>      
