$(document).ready(function () {
	$('#share_user_access_list_container').data('users', new Object());
	
	$('#share_delete').attr('disabled', true);
    $('#share_delete').addClass('ui-state-disabled');

	$('#edit_share_name').restForm({
		'relatedForms': ['edit_share_description', 'edit_share_media', 'edit_share_public_access'],
		'setDefaultFormDataCallback': function (data) {

			var originalShareName = $('#share_originalname').val();
        	var newName = $('#share_new_share_name').val();
        	
        	
        	var listData = $('#shares_list').data('shares').share;
        	var itemToRemove = null;
        	// remove old name from list data
            for (var i in listData){
            	if (listData[i].share_name == originalShareName){
            		itemToRemove = i;
            		break;
            	}
            }
            
            if (itemToRemove != null){
            	listData.splice(itemToRemove, 1);
            }
            
            var itemToAdd = {'share_name': $('#share_new_share_name').val(),
            		'sharename': $('#share_new_share_name').val(), 'description': $('#edit_share_name input[name=description]').val(), 
            		'media_serving': $('#edit_share_name input[name=media_serving]').val(),
            		'public_access': $('#edit_share_name input[name=public_access]').val(), 
            		'remote_access': $('#edit_share_name input[name=remote_access]').val()};

        	if (listData != null){
	        	listData.push(itemToAdd);	        	  
        	}

			$('#share_originalname').val(newName);
			$('#shares_list #share_' + originalShareName + ' .share_list_sharename').text(newName);
			$('#shares_list #share_' + originalShareName).attr('id', 'share_' + newName);
			$('#edit_share_description').find("input[name=share_name]").val(newName);
			$('#edit_share_media').find("input[name=share_name]").val(newName);
			$('#edit_share_public_access').find("input[name=share_name]").val(newName);
			
			$('#edit_share_name').restForm('_setDefaultFormData', data);
        	$('#delete_share_form #delete_share_name').val(newName);

        	//set share access share name
        	
            $('#shares_list #share_' + originalShareName + ' a').attr('href', function () {
                var splitUri = $(this).attr('href').split('/');
                for (var i = splitUri.length - 1; i >= 0; --i){
                	if (splitUri[i] == originalShareName){
                		splitUri[i] = newName;
                		break;
                	}
                }
                return splitUri.join('/');
            });
            $('#users_list #share_' + originalShareName).attr('id', 'share_' + newName);
            $('#edit_share_name').attr('action', $('#edit_share_default').attr('action')+'/'+newName);
            $('#edit_share_description').attr('action', $('#edit_share_default').attr('action')+'/'+newName);
            $('#edit_share_media').attr('action', $('#edit_share_default').attr('action')+'/'+newName);
            $('#edit_share_public_access').attr('action', $('#edit_share_default').attr('action')+'/'+newName);
        }
	});
	$('#edit_share_description').restForm({
		'relatedForms': ['edit_share_name', 'edit_share_media', 'edit_share_public_access']
	});
	$('#edit_share_media').restForm({
		'relatedForms': ['edit_share_name', 'edit_share_description', 'edit_share_public_access'],
        'refreshDataCallback': function (data) {
            if (data.media_serving != undefined) { 
                if (data.media_serving == "any"){
                    $('#edit_share_media').find('#share_media_sharing').attr('checked', true);
                }
                else {
                    $('#edit_share_media').find('#share_media_sharing').attr('checked', false);
                }
            }
            //$('#edit_share_media').restForm('_refreshData', data);
            $('#edit_share_media').find('input[name="share_name"]').val(data.share_name);
            $('#edit_share_media').find('input[name="description"]').val(data.description);
            $('#edit_share_media').find('input[name="public_access"]').val(data.public_access);
            $('#edit_share_media').find('input[name="remote_access"]').val(data.remote_access);
            
            $('#edit_share_media').find('input[name="share_name"]')[0].defaultValue = data.share_name;
            $('#edit_share_media').find('input[name="description"]')[0].defaultValue = data.description;
            $('#edit_share_media').find('input[name="public_access"]')[0].defaultValue = data.public_access;
            $('#edit_share_media').find('input[name="remote_access"]')[0].defaultValue = data.remote_access;
        },
		'inputRadioCheckboxChangeCallback':function(){
			if ($('#share_media_sharing').is(':checked')) {
                $('#share_media_sharing_value').val('any');                         
            }
            else {
                $('#share_media_sharing_value').val('none');
            }
			
			$('#edit_share_media').submit();
		},
		'setDefaultRelatedFormsDataCallback': function(){
			var relatedForms = $('#edit_share_media').data('restFormSettings').relatedForms; 
			if (relatedForms != null){
       			var data = {'media_serving': $('#share_media_sharing_value').val()};
            	for(var i in relatedForms){
            		$('#'+relatedForms[i]).restForm('refreshData', data, false);
        		}
            }
		}
	});
	
	$('#edit_share_public_access').restForm({
		'relatedForms': ['edit_share_name', 'edit_share_description', 'edit_share_media'],
		'refreshDataCallback': function(data){
			$('#edit_share_public_access').restForm('_refreshData', data);
		},
		'hideProcessingCallback': function(ignoreChildren, hideLoadingDisplay){
			if ($('#share_new_share_name').val() != 'Public'){
				$('#edit_share_public_access').restForm('_hideProcessing', ignoreChildren, hideLoadingDisplay);
			}
		},
		'setDefaultRelatedFormsDataCallback': function(data){
			var relatedForms = $('#edit_share_public_access').data('restFormSettings').relatedForms;
			if (relatedForms != null){
				if (typeof(data) == 'undefined'){
	    			var data = {};
	    		}
				if ($('#share_public_access_checkbox').is(':checked')){
					data['public_access'] = 'true';
				}
				else{
					data['public_access'] = 'false';
				}
				for(var i in relatedForms){
            		$('#'+relatedForms[i]).restForm('refreshData', data, false);
            	}
			}
		},
		'setDefaultFormDataCallback': function(data){
			$('#edit_share_public_access').restForm('_setDefaultFormData', data);
			$('#edit_share_name input[name=public_access]').val();
			$('#edit_share_description input[name=public_access]').val();
			$('#edit_share_media input[name=public_access]').val();
			
			$('#user_access_list li').each(function(){
				if ($('#share_public_access_checkbox').is(':checked')){
					$(this).addClass('ui-state-disabled');
					$(this).find('.access_link_container').find('.access_link').removeClass('selected');
					$(this).find('.share_access_description').text(dictionaryList['public']);
					$(this).find('button').attr('disabled', 'disabled').addClass('ui-state-disabled');
				}
				else{
					$(this).find('.access_link_container').css('display', 'inline-block');
					$(this).removeClass('ui-state-disabled');
					$(this).find('button').removeAttr('disabled').removeClass('ui-state-disabled');
					var accessButtonSelected = $(this).find('.access_link.selected');
					var accessType = 'no';
					if (accessButtonSelected.length > 0){
						if (accessButtonSelected.hasClass('share_rw_access')){
							accessType = 'rw';
						}else if(accessButtonSelected.hasClass('share_ro_access')){
							accessType = 'ro';
						}else if (accessButtonSelected.hasClass('share_no_access')){
							accessType = 'no';
						}
					}else{
						accessType = 'no';
						$(this).find('.share_no_access').addClass('selected');
					}
					$(this).find('.share_access_description').text(dictionaryList[accessType]);
				}
			});
		}
	});
	
	$('#share_public_access_checkbox').live("toggle", function (e) {
        e.preventDefault();

        $('#share_public_access_checkbox').submit();
    });
	
    $('#shares_list_navigation').listNavigation({
    	'containerName': 'shares',
        'prefix': 'share',
        'userAjaxCall': null,
        'beforeRetrieveData': function(){
			$('#edit_share_name').restForm("showProcessing", false, true);
		},
		'afterRetrieveData': function(){
			$('#edit_share_name').restForm("hideProcessing", false, true);
		},
        'prepareLinkCall': function(i,a,item){
        	return a+"/"+item;
		},
		'afterShowItem': function(itemData){
			//if usb, we need to disable the delete button
			if (typeof itemData.usb_handle != 'undefined'){
				$('#share_delete_button_container').addClass('ui-state-disabled');
				$('#share_delete').addClass('ui-state-disabled');
				$('#share_delete').attr('disabled', 'disabled');
			} 
			else{
				$('#share_delete').removeAttr('disabled');
				$('#share_delete').removeClass('ui-state-disabled');
				$('#share_delete_button_container').removeClass('ui-state-disabled');
			}
			
			
			//need to load user data
			if ($(this).data('listNavigationSettings').userAccessAjaxCall != null){
				$(this).data('listNavigationSettings').userAccessAjaxCall.abort();
			}
			$(this).data('listNavigationSettings').userAccessAjaxCall = $.ajaxAPI({
				"url": "users",
				"before": function(){
					$('#user_access_list li:first').siblings().each(function(){
                		$(this).remove();
                	});
				},
				"success": function(data) {
            	    //populate our share access list
					if (data != null && data.users != null && data.users.user != null){
                    	if( Object.prototype.toString.call( data.users.user ) != '[object Array]' ){
                    		data.users.user = $.makeArray(data.users.user);
                    	}
                    	var shares = $('#shares_list_navigation').data('listNavigationSettings').cache;
                    	var share = null;
						var i;
						var j;
                    	for (i in shares){
                    		if (shares[i].share_name == $('#share_originalname').val()){
                    			share = shares[i];
                    			break;
                    		}
                    	}
                    	share = itemData;
                    	var users = new Array();
                    	for (i in data.users.user){
                    		users.push(data.users.user[i]);
                    	}
                    	$.each(data.users.user, function(i, item){
                    		var shareAccess = "RW";
                			var shareAccessFound = false;
                			if( Object.prototype.toString.call( share.share_access ) != '[object Array]' ){   // only 1 volume
                				share.share_access = $.makeArray(share.share_access);
                			}
                    		for (j in share.share_access){
                    			if (share.share_access[j].username == item.username){
                    				shareAccessFound = true;
                    				shareAccess = share.share_access[j].access;
                    				break;
                    			}
                    		}
                    		if (!shareAccessFound){
                    			shareAccess = "NO";
                    		}
                    		AddToShareUserAccessList(item.username, shareAccess, share, users, item, share.public_access == 'true');
                    	});
                    }
				}
			});
		},
        'updateDetailForm': function (data) {
        	//need to adjust form actions to append the share name at the end
        	$('#edit_share_name').attr('action', $('#edit_share_default').attr('action')+'/'+data.share_name);
        	$('#edit_share_description').attr('action', $('#edit_share_default').attr('action')+'/'+data.share_name);
        	$('#edit_share_media').attr('action', $('#edit_share_default').attr('action')+'/'+data.share_name);
        	$('#edit_share_public_access').attr('action', $('#edit_share_default').attr('action')+'/'+data.share_name);
        	
        	$('#edit_share_name').restForm('refreshData', data);
        	$('#edit_share_name').restForm('refreshRelatedForms', data);

            totalSizeString = ByteSize(data.size);
            $('#share_details_size').html(totalSizeString);
            
        	$('#delete_share_form #delete_share_name').val(data.share_name);
        	$('#share_originalname').val(data.share_name);
        	$('#share_originalname')[0].defaultValue = data.share_name;
        	$('#share_new_share_name').val(data.share_name);
        	$('#share_new_share_name')[0].defaultValue = data.share_name;
        },
        'selectItem': function (data) {
            $('#shares_list ul.listNavigation li.selected').removeClass("selected");
            $('#shares_list ul.listNavigation li#share_' + data.share_name).addClass("selected");

        	$('#share_delete').attr('disabled', false);
            $('#share_delete').removeClass('ui-state-disabled');

            hideSharesBumper();
        }
    });
    $('#delete_share_form').restForm({
        'processFormSuccessCallback': function () {
            $('#shares_list_navigation').listNavigation("removeFromList", $('#delete_share_name').val());
            var listData = $('#shares_list').data('shares').share;
            var itemToRemove = null;
            for (var i in listData){
            	if (listData[i].share_name == $('#delete_share_name').val()){
            		itemToRemove = i;
            		break;
            	}
            }
            if (itemToRemove != null){
            	listData.splice(itemToRemove, 1);
            }
            $('#shares_list').ferrisWheelNav({
            	'nav_container_cls': 'listNavigation',
            	'nav_cls': 'leftmenu',
            	'nav_ul_cls': 'listNavigation'
            });
        }
    });
    
    $("#delete_share_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_share',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#delete_share_confirmation').attr('title')+'</div>'
    });
    
    $('#delete_share_close_button').click(function(){
    	$("#delete_share_confirmation").dialog("close");
    });
    
    $('#delete_share_ok_button').click(function(){
    	$("#delete_share_confirmation").dialog('close');
        $('#delete_share_form').submit();
    });
    
    $('#share_delete').live("click", function(event){
    	event.preventDefault();
    	$('#delete_share_confirmation').dialog('open');
    });
    
    
    
    $('.edit_share_user_access_form').each(function () {
        SetShareUserAccessListRestForm($(this));
    });
    $('#share_user_access_list_container .access_link').each(function () {
        if (typeof($(this).data("access_link_click_set")) == "undefined")
        {
            $(this).data("access_link_click_set", true);
            $(this).click(function (e) {
                e.preventDefault();
                $(this.form).find("input[name=type]").val($(this).val());
                $('#user_access_overlay_' + $(this.form).find("input[name=shareName]")).show();
                $(this.form).submit();
            });
        }
    });
    
    
    $("#create_share_btn").live("click", function (e) {
        e.preventDefault();
        $('#create_share_form').restForm('reset');
        $('#create_share_dialog').dialog("open");

        //hideSharesBumper();
    });
    
    
    $("#create_share_dialog").mochiDialog({
        autoOpen: false,
        resizable: false,
        width: 600,
        minHeight: 285,
        dialogClass: 'mochi_dialog mochi_dialog_share',
        modal: true,
        stack: false,
        title: '<div id="create_share_dialog_title" class="wizard_dialog_title">'+$('#create_share_dialog').attr('title')+'</div>'
    });

    $('#create_share_wizard_close_button').click(function () {
        $('#create_share_dialog').dialog('close');
    });

    $('#create_share_form').restFormDialog({
        'dialogName': 'create_share_dialog',
        'beforeProcessForm': function(){
            if ($('#create_share_media_sharing').is(':checked')) {
                $('#create_share_media_serving_default').val('any');                         
            }
            else {
                $('#create_share_media_serving_default').val('none');
            }
        },
    	'setDefaultFormDataCallback': function (data) {
        	//add to list navigation
    		if ($('#shares_list_navigation .listNavigation li').length > 1){ 
	        	var mediaServingValue = $('#create_share_media_serving_default').val();
	        	if ($('#create_share_media_sharing:checked').length > 0){
	        		mediaServingValue = $('#create_share_media_sharing').val();
	        	}
	        	var itemToAdd = {'share_name': $('#create_share_name').val(),
	            		'sharename': $('#create_share_name').val(), 'description': $('#create_share_description').val(), 'media_serving': mediaServingValue,
	            		'public_access': $('#create_share_public_access').val(), 'remote_access': $('create_share_remote_access').val()};
	        	$('#shares_list_navigation').listNavigation("addToList", $('#create_share_name').val(), false, null, itemToAdd);
	        	var listData = $('#shares_list').data('shares');
	        	if (listData != null){
		        	listData['share'].push(itemToAdd);
		        	$('#share_'+$('#create_share_name').val()+' a.share').click();
	        	}
	        	$('#shares_list').ferrisWheelNav({
	            	'nav_container_cls': 'listNavigation',
	            	'nav_cls': 'leftmenu',
	            	'nav_ul_cls': 'listNavigation'
	            });
    		}
        	var dashboardCount = parseInt($('#dashboard_shares_count').text());
        	if (!isNaN(dashboardCount)){
        		$('#dashboard_shares_count').text(dashboardCount + 1);
        	}
        	$('#create_share_dialog').dialog('close');
        }
    });
    
    
});

function AddToShareUserAccessList(userName, shareAccess, share, users, userData, isPublic)
{
    var cloneLi = $('#share_user_access_list_container .share_access_list li:first').clone();
	cloneLi.attr('id', 'user_access_item_'+userName);
    cloneLi.find('.user_access_overlay').attr('id', 'user_access_overlay_'+userName);
    cloneLi.find('.user_access_label_text').text(userName);
    if (userData.is_admin == 'true'){
    	cloneLi.find('.user_access_label').addClass("admin_user_access_label");
    }
    cloneLi.find('.access_link.selected').each(function(){
        $(this).removeClass('selected');
    });
    cloneLi.find('.share_access_description').attr('id', 'share_user_access_item_description_'+userName);
    switch(shareAccess){
        case "RW":
            cloneLi.find('.share_rw_access').addClass("selected");
            cloneLi.find('#share_user_access_item_description_'+userName).text(dictionaryList['rw']);
            break;
        case "RO":
            cloneLi.find('.share_ro_access').addClass("selected");
            cloneLi.find('#share_user_access_item_description_'+userName).text(dictionaryList['ro']);
            break;
        case "NO":
            cloneLi.find('.share_no_access').addClass("selected");
            cloneLi.find('#share_user_access_item_description_'+userName).text(dictionaryList['no']);
            break;
		default:
			break;
    }
    if (isPublic){
    	cloneLi.find('.access_link_container').find('.access_link').removeClass('selected');
    	cloneLi.find('button').attr('disabled', 'disabled').addClass('ui-state-disabled');
    	cloneLi.addClass('ui-state-disabled');
        cloneLi.find('#share_user_access_item_description_'+userName).text(dictionaryList['public']);
    }

    cloneLi.shareAccessHandler({
    	user: userName,
    	share: share,
    	users: users
    		
    });
	cloneLi.appendTo($('#share_user_access_list_container .share_access_list'));
    SetShareUserAccessListRestForm($('#edit_share_user_access_form_'+userName));
}

function SetShareUserAccessListRestForm(element){
    element.restForm({
        'setDefaultFormDataCallback': function (data) {
            $(this).find('.access_link').each(function(){
                $(this).removeClass('selected');
            });
            switch(data.Access)
            {
                case "RW":
                    $('#share_user_access_item_description_' + $(this).find("input[name=userName]").val()).text("Full Access");
                    break;
                case "RO":
                    $('#share_user_access_item_description_' + $(this).find("input[name=userName]").val()).text("Read Only");
                    break;
                case "NO":
                    $('#share_user_access_item_description_' + $(this).find("input[name=userName]").val()).text("No Access");
                    break;
				default:
					break;
            }
        },
        'showProcessingCallback': function () {
            $('#user_access_overlay_' + $(this).find("input[name=userName]").val()).animate(
                {
                    opacity: "show"
                },
                {
                    duration: 500
                }
            );
        },
        'hideProcessingCallback': function () {
            $('#user_access_overlay_' + $(this).find("input[name=userName]").val()).animate(
                {
                    opacity: "hide"
                },
                {
                    duration: 500
                }
            );
        }
    });
}

function hideSharesBumper() {
    $('#about_shares').hide();
    $('#shares_edit_container').show();
}
