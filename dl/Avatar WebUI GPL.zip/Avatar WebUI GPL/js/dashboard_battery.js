$(document).ready(function(){
	var batteryDashboardHandler = {
		updateInProgress:false,
		update: function(useQueue){
			var $this = this;
	    	if ($this.updateInProgress) {
	            return;
	        }
	    	var ajaxAPIOptions = {
				"url": "battery_status",
	            "timeout": ajaxTimeout,
				"success": function(data, textStatus, jqXHR) {
					if (data != null && data.battery_status != null) {
	                    if (data.battery_status.percent_remaining != '') {
                            
                            var $battery_img = $('#dashboard_battery_information_available_image'),
                                $battery_text = $('#dashboard_battery_information_available_text');
                            
                            $battery_text.children('.charge_value').text(data.battery_status.percent_remaining);
                            $battery_img.fadeIn();
                            $battery_text.fadeIn();
                            
	                    	$battery_img.removeClass('battery_full');
	                    	$battery_img.removeClass('battery_80');
	                    	$battery_img.removeClass('battery_60');
	                    	$battery_img.removeClass('battery_40');
	                    	$battery_img.removeClass('battery_20');
	                    	
	                    	percentage = parseInt(data.battery_status.percent_remaining);
	                    	
	                    	if (percentage <= 20){
	                    		$battery_img.addClass('battery_20');
	                    	}
	                    	else if (percentage <= 40){
	                    		$battery_img.addClass('battery_40');
	                    	}
	                    	else if (percentage <= 60){
	                    		$battery_img.addClass('battery_60');
	                    	}
	                    	else if (percentage <= 80){
	                    		$battery_img.addClass('battery_80');
	                    	}
	                    	else {
	                    		$battery_img.addClass('battery_full');
	                    	}
	                    }
	                    
	                    if (data.battery_status.state == 'charging') {
                            $battery_img.removeClass('discharging');
                            $battery_img.addClass('charging');
	                    }
	                    else {
                            $battery_img.removeClass('charging');
                            $battery_img.addClass('discharging');
	                    }
	                }
				},
	            "error": function (request, status, error) {
	                
	            },
				"complete": function(){
					$this.updateInProgress = false;
	        	    if ($this.updateCompleteHandler != null){
	        	    	$this.updateCompleteHandler();
	        	    }
				}
			};
	    	if (typeof useQueue != 'undefined' && useQueue == true){
	    		ajaxQueue.add(ajaxAPIOptions);	
	    	}
	    	else{
	    		$.ajaxAPI(ajaxAPIOptions);
	    	}
	    }
	};
	
	dashboardHandler.addUpdateHandle(batteryDashboardHandler, 'updateBatteryPercent');
});