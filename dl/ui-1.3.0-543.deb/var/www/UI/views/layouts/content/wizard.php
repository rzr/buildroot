<div id="<?php echo $identifier?>_wizard">
	<div class="mochi_dialog_content_container" style="">
		<div class="mochi_dialog_content" style="">
            <?php $view->LoadViews(); $view->LoadContents();?>
        </div>
    </div>
	<div class="navigation dialog_form_controls">
		<button type="button" class="backward"><?php echo _('BUTTON_BACK')?></button>
		<button type="button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
	    <button type="button" class="forward mochi_dialog_save_button"><?php echo _('BUTTON_NEXT')?></button>
        <button type="button" class="finish mochi_dialog_save_button"><?php echo _('BUTTON_FINISH')?></button>
	</div>
</div>