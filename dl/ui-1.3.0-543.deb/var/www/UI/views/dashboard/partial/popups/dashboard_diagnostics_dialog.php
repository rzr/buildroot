<div id="dashboard_diagnostics_dialog" title="<?php echo _('CONTENT_HOME_DIALOG_TITLE_DIAGNOSIS')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">						
			<p><?php echo _('CONTENT_HOME_DIALOG_STRING_DIAGNOSIS_DESC')?></p>
			<div class="dashboard_diagnostics_list_container">
				<ul class="dashboard_diagnostics_list">
					<li class="dashboard_diagnostics_list_item dashboard_diagnostics_temperature"><span class="dashboard_diagnostic_list_health_item"><?php echo _('CONTENT_HOME_DIALOG_LABEL_TEMPERATURE')?></span>
					<span class="dashboard_diagnostic_list_health_status" id="dashboard_diagnostics_temperature"><?php echo _('CONTENT_HOME_DIALOG_STRING_DIAGNOSIS_GOOD')?></span>
					<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_TEMPERATURE')?></div></div></div></li>
					<li class="dashboard_diagnostics_list_item dashboard_diagnostics_drive"><span class="dashboard_diagnostic_list_health_item"><?php echo _('CONTENT_HOME_DIALOG_LABEL_DRIVE_STATUS')?></span>
					<span class="dashboard_diagnostic_list_health_status" id="dashboard_diagnostics_smart_status"><?php echo _('CONTENT_HOME_DIALOG_STRING_DIAGNOSIS_GOOD')?></span>
					<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_DRIVE_STATUS')?></div></div></div></li>
					<li class="dashboard_diagnostics_list_item dashboard_diagnostics_share"><span class="dashboard_diagnostic_list_health_item"><?php echo _('CONTENT_HOME_DIALOG_LABEL_SHARE_STATUS')?></span>
					<span class="dashboard_diagnostic_list_health_status" id="dashboard_diagnostics_volume_status"><?php echo _('CONTENT_HOME_DIALOG_STRING_DIAGNOSIS_GOOD')?></span>
					<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_SHARE_STATUS')?></div></div></div></li>
					<li class="dashboard_diagnostics_list_item dashboard_diagnostics_free_space"><span class="dashboard_diagnostic_list_health_item"><?php echo _('CONTENT_HOME_DIALOG_LABEL_FREE_SPACE')?></span>
					<span class="dashboard_diagnostic_list_health_status" id="dashboard_diagnostics_free_space"><?php echo _('CONTENT_HOME_DIALOG_STRING_DIAGNOSIS_GOOD')?></span>
					<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_FREE_SPACE')?></div></div></div>
					</li>
				</ul>
			</div>

		</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="dashboard_diagnostics_close_button" class="close mochi_dialog_save_button"><?php echo _("BUTTON_OK")?></button>
	</div>

</div>

