<div id="view_single_alert_dialog" title="<?php echo _('GLOB_NAV_NOTIFICATIONS_TITLE_NOTIFICATION')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
        	<div>
                <p id="alert_details_title" class="notification_title single_alert_description" style="display:inline-block"></p><p id="alert_details_count_shown" class="notification_count_shown" style="display:inline-block;padding-left:5px"></p>

       			<p id="alert_details_description" class="single_alert_notification_description"></p> 
                <p id="single_alert_begin_update"><a href="#"><span id="alert_begin_update_link"><?php echo _('CONTENT_DIALOG_ALERTS_STRING_BEGIN_UPDATE')?></span></a></p>
                <br />
        		
        		<div>
        			<span id="alert_details_time" style="display:inline-block" class="notification_time"></span>
        			<span style="display:inline-block" class="single_alert_notitication_code_text"><?php echo _('GLOB_NAV_NOTIFICATIONS_LABEL_CODE')?>
        			    <span id="single_alert_details_code" class="notitication_code" style="display:inline-block"></span>
                    </span>
        
        			<!-- <a class="notification_single_alert_more_info" style="display:inline-block;margin-right:5px" href="#" >More Information</a> -->
        		</div>
        	</div>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="alerts_view_single_alert_cancel_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>      
