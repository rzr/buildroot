var ajaxTimeoutLong = 600000; // 10 minutes	(must greater than ajaxTimeout)
var ajaxTimeout =     300000; // 5 minutes
var ajaxTimeoutFast =  15000; // 15 seconds (for testing)
var ajaxTimeoutNetwork =  30000; // 30 seconds
var ajaxTimeoutPolling =  30000; // 30 seconds
var loaderTimer = 0;
var gCapacity_GB = 0;
var gUsage_GB = 0;
var gIsMobile = false;
var gInternetAccess = false;
var gDeviceName = "MyPassport";
var gSSIDName = "";
var gSSIDSecured = false;
var gSSIDBroadcasting = true;
var gWANSSIDName = "";
var gAvatarApIpAddress = "";
//var gAvatarApSecurity = "";
//var gDeviceDescription = "";
var gSerialNumber = "";
var gModelNumber = "";
var gModelName = "";
var gMacAddress = "";
//var gDeviceUsersCount = 0;
//var gDateTime = 0;
var gTimezoneName = "";
var BYTE_DIVISOR = 1000;
var deviceName = "";
//var redirectURL = SITE_BASE_URL;
var redirectURL = '/' + SITE_BASE_URL;
var systemStatepoll = 5000;
var apiUrlPrefix = "/api/2.4.1/rest/";
var stubApiUrlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';

var gTrustedNetwork = false;
var gConnectedNetwork = false;
var gConnectedDevices = false;
var gFoundMe = false;
var gWiFiEnabled = false;

var pollingFrequency =     60000;   // 60 seconds
var pollingMedFrequency =  30000;   // 30 seconds
var pollingFastFrequency = 10000;   // 10 seconds

var toolbarItems = {};
var loadingTop;
var $window;
var $stickyEl;

var gRedirect = false;
var gPopupBlocker = true;

var dialogWidth = 600,
    dialogMinHeight = 203;

$(document).ready(function () {

	//initDeviceTitle();
	initGlobalVariables();


    $('#overall_help_link').click(function (e) {
        e.preventDefault();
        $('#overall_help').dialog("open");
    });

    $('#help_link').click(function (e) {
        e.preventDefault();
        e.stopPropagation();
        checkOtherToolbarItems('help_link');
        $('#help_list_container').toggle();
        if ($('#help_link').hasClass('selected')){
        	$('#help_link').removeClass('selected');
        }
        else{
        	$('#help_link').addClass('selected');
        }
    });
    
    toolbarItems.help_link = function(){
    	$('#help_list_container').toggle();
    	$('#help_link').removeClass('selected');
    };
    
    $(document).click(function(event) { 
	    if($(event.target).parents().index($('#help_list_container')) == -1 && $('#help_link').hasClass('selected')) {
	    	$('#help_list_container').toggle();
	    	$('#help_link').removeClass('selected');
	    }        
	});
    
	$('#notification_link').click(function (e) {
        e.preventDefault();
        e.stopPropagation();
        
        // if there are notifications then do something, otherwise do nothing
        if (!$('#notification_link').hasClass('noAlerts')){
	        checkOtherToolbarItems('notification_link');
	        toggleNotificationListContainer();
	        if ($('#notification_link').hasClass('selected')){
	        	$('#notification_link').removeClass('selected');
	        }
	        else{
	        	$('#notification_link').addClass('selected');
	        }
        }
    });
    
    toolbarItems.notification_link = function(){
    	toggleNotificationListContainer();
		$('#notification_link').removeClass('selected');
    };
    
    $(document).click(function(event) { 
	    if($(event.target).parents().index($('#notification_list_container')) == -1 && $('#notification_link').hasClass('selected')) {
	    	toggleNotificationListContainer();
			$('#notification_link').removeClass('selected');
	    }        
	});
    
//    $('#logo').click(function (e){
//    	debug_ajax = true;
//    	ajaxWindow = window.open();
//    	var html = '<div id="easter_egg_area"></div>';
//    	$(ajaxWindow.document.body).html(html);
//    });
    
    
    $('.tooltip_icon').live('mouseover touchstart click', function(){
    	var tooltip = $(this).siblings('.tooltip_inner_container').find('.tooltip').first();
    	if (!tooltip.is(':visible')){
	    	var timeToShow = 3000+tooltip.html().length*70;
	    	tooltip.show().oneTime(timeToShow, function(){
	    		$(this).fadeOut(200);
	    	});
	    	var position = tooltip.offset().left - $(window).scrollLeft();
	    	var tooltipRightPosition = position + tooltip.width();
	    	if (tooltipRightPosition > $(window).width()){
	    		tooltip.css('left', -1 * tooltip.width());
	    	}
    	}
    });
    
    $('.tooltip_icon').live('mouseleave', function(){
    	var tooltip = $(this).siblings('.tooltip_inner_container').find('.tooltip').first();
    	tooltip.hide();
    });

    $("#device_initializing").dialog({
		autoOpen: false,
		resizable: false,
		position: 'center',
		width: 300,
		minHeight: 140,
		dialogClass:'mochi_dialog mochi_dialog_info',
		modal: true,
		stack: true,
		title: '<div class="wizard_dialog_title">'+$('#device_initializing').attr('title')+'</div>'
	});
    
    
    $window = $(window);
    $stickyEl = $('#loading');
    loadingTop = $stickyEl.offset().top;

    $window.scroll(function() {
    	$stickyEl.toggleClass('sticky', $window.scrollTop() > loadingTop);
    	if ($window.scrollTop() > loadingTop){
    		$stickyEl.css({top: '0'});
    	}
    	else{
    		$stickyEl.css({top: loadingTop+'px'});
    	}
    });
    
    $('#acknowledgement_down_controls_ok').click(function(e){
    	e.preventDefault();
    	$('#loading_back').hide();
    	$('#acknowledgement_down').hide();
    });
});

/*
function initFormElements(){
	$('input:checkbox.normal_checkbox').checkbox({cls:'jquery-checkbox2'});
	$.each($('select'), function () {
	       $(this).selectmenu({ style: 'dropdown', width : $(this).width() + 16});
	});
}
*/

function displayLoading(loadingText){
    if (typeof(loadingText) != 'undefined') {
        $('#loading').html(loadingText);
    }
    else {
        $('#loading').html( dictionaryList['loadingtxt'] );
    }

	$('#loading_back').show();
	var visibleDialogContent = $('.mochi_dialog_content_container:visible'); 
	if (visibleDialogContent.length > 0){
		loadingTop = visibleDialogContent.offset().top;
    	$('#loading').css('top', loadingTop+'px');
    	
    	var newLeft = visibleDialogContent.offset().left + visibleDialogContent.outerWidth()/2 - $('#loading').outerWidth()/2;
    	$('#loading').css('left', newLeft+'px');
    	$('#loading').css('margin-left', 0);
	}
	else if ($('#content:visible').length > 0){
		$('#loading').css({top: '0'});
		$('#loading').css({left: '50%'});
		$('#loading').css('margin-left', '-144px');
		loadingTop = 172;
	}
	else{
		$('#loading').css({top: '0'});
		$('#loading').css({left: '50%'});
		$('#loading').css('margin-left', '-144px');
		loadingTop = 61;
	}
	if ($window.scrollTop() > loadingTop){
		$('#loading').css({top: '0'});
	}
	$('#loading').slideDown("slow");
}

function displayLoadingWithText(loadingText) {
    $('#loading').html(loadingText);
    displayLoading();
}

// legacy wrapper for displayLoadingWithTimeout()
function openLoaderWithTimeout() {
	displayLoadingWithTimeout();
}

function displayLoadingWithTimeout(){

	clearTimeout(loaderTimer);

	displayLoading();

	loaderTimer = setTimeout(function(){
	    hideLoading();		
	}, ajaxTimeoutLong);
}

function hideLoading(){
	$('#loading').slideUp("slow");
	$('#loading_back').hide();
}

function get_storage_capacity() { 
    $.ajaxAPI({
        "url": "storage_usage",
        "success": function(data) {
            return parseInt(data.storage_usage.size);
        }
    });
}

function initGlobalVariables() {
    
    var ua = navigator.userAgent.toLowerCase();
    var platform = navigator.platform.toLowerCase();
    var isAndroid = ua.indexOf("android") > -1; 
    var isMobile = ua.indexOf("mobile") > -1; 
    
    gIsMobile = isAndroid || isMobile || (platform == "ipad") || (platform == "iphone");
    
    if ((platform == "ipad") || (platform == "iphone")) {
        $('#eulaText').addClass('iOSTextOverflow');
        $('#privacyPolicyText').addClass('iOSTextOverflow');
    }
}

function resetGlobalVariables() {
    gDeviceName = "MyPassport";
    gSSIDName = "MyPassport";
    gSSIDSecured = false;
    gSSIDBroadcasting = true;
}

function initDeviceTitle() {

    $.ajaxAPI({
        "url": "system_information",
        "success": function (data) {
            if (data != null && data.system_information != null) {
                gModelName = trimString(data.system_information.model_name);
                gModelNumber = trimString(data.system_information.model_number);
                gSerialNumber = data.system_information.serial_number;
                gMacAddress = data.system_information.mac_address;
                gDeviceName = trimString(data.system_information.host_name);
            }
        },
        "complete": function (jqXHR, textStatus) {
             // gDeviceName already in system_information
             //getDeviceDescription();

             // just update title since gDeviceName already defined in system_information
             updateDeviceTitle();
        }
    });
}

function getDeviceDescription(updateTitle) {
    if (typeof updateTitle == 'undefined'){
		updateTitle = false;
	}
    $.ajaxAPI({
        "url": "device_description",
        "success": function (data) {
            if (data != null && data.device_description != null) {
                gDeviceName = trimString(data.device_description.machine_name);
                gDeviceDescription = trimString(data.device_description.machine_desc);
            }
            if (updateTitle) {
                updateDeviceTitle();
            }
        }
    });
}

function updateDeviceTitle() {
    var deviceName = dictionaryList['model_number_' + gModelNumber];
    if (deviceName == undefined) {
        deviceName = gModelName;
    }

    if (gDeviceName == gModelName || gDeviceName == 'MyPassport') {
        document.title = deviceName;
    }
    else {
        document.title = gDeviceName + ' [' + deviceName + ']';
    }
}

function checkForDeviceReady(useQueue) {

    var ajaxAPIOptions = {
        "url": "system_state",
        "success": function (data) {
            if (data != null && data.system_state != null) {
                if (data.system_state.status == 'ready') {
                    $('#device_initializing').dialog('close');
                }
                else {
                    $('#device_initializing').dialog('open');
                    setTimeout("checkForDeviceReady();", systemStatepoll);
                }
            }
        }
    };
    if (typeof useQueue != 'undefined' && useQueue == true){
    	ajaxQueue.add(ajaxAPIOptions);
    }else{
    	$.ajaxAPI(ajaxAPIOptions);
    }
}

function displaySplash(){
	$('#splash_back').show();
	$('#splash').show();
}

function hideSplash(){
	$('#splash').fadeOut(100);
	$('#splash_back').hide();
}

function checkOtherToolbarItems(currentId){
	for (var i in toolbarItems){
		if (i != currentId && $('#'+i).hasClass("selected")){
			toolbarItems[i]();
		}
	}
}

function disableIdTag(id) {
    $(id).addClass("ui-state-disabled");
    $(id).attr('disabled', true);
}

function enableIdTag(id) {
    $(id).removeClass("ui-state-disabled");
    $(id).attr('disabled', false);
}

function displayElapsedTime(id, startTime) {
    var currentTime = new Date().getTime();
    var elapsedTime = ms2Time(currentTime - startTime);
    $(id).html(elapsedTime);
}

function tickElapsedTime(id, startTime) {
    displayElapsedTime(id, startTime);
    setTimeout("tickElapsedTime('"+id+"', "+startTime+");", 5000);
}

function getPollingErrorMessage(request) {
    var xotree = new XML.ObjTree();
    var data = xotree.parseXML( request.responseText );
    var errorKey = '';
    var errorMsg = dictionaryList['unknown'];
    var error_id = parseDataForErrors(data);
    if (error_id) {
        errorKey = 'error_id_' + error_id;
        if (errorsList[errorKey] != undefined) {
            errorMsg = errorsList[errorKey];
        }
    }
    else {
        var error_code = parseDataForErrors(data, 'error_code');
        if (error_code) {
            errorKey = 'http_'+ error_code;
            if (errorsList[errorKey] != undefined) {
                errorMsg = errorsList[errorKey];
            }
        }
    }
    return errorMsg;
}

function initDatetime() { 
    $.ajaxAPI({
        "url": "date_time_configuration",
        "success": function(data) {
            if (data != null && data.date_time_configuration != null) {
                gDateTime = parseInt(data.date_time_configuration.datetime);
                gTimezoneName = trimString(data.date_time_configuration.time_zone_name);
            }
        }
    });
}

