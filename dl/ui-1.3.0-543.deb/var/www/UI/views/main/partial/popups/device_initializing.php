<div id="device_initializing" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_DRIVE_INITIALIZING'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
            <table>
                <tr>
                    <td><span class="device_rebooting_status_icon spinnerSunIcon"></span></td>
                    <td><span><?php echo _('LABEL_DESCR_INTIALIZING_DRIVE'); ?></span></td>
                </tr>
            </table>
		</div>
	</div>
</div>
