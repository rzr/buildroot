<?php
$privacyPolicy = 'Privacy%20Policy/'.LANGUAGE_STR.'.html';
if (!file_exists($privacyPolicy)) {
    $privacyPolicy = 'Privacy%20Policy/en_US.html';
}
?>
<div id="support_dialog" title="<?php echo _('CONTENT_DIALOG_HELP_TITLE_SUPPORT')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div id="support_dialog_content" class="mochi_dialog_content">

            <div class="edit_container_box">
                <h2><?php echo _('CONTENT_DIALOG_HELP_HEAD2_REQUEST_AUTOMATED_SUPPORT')?></h2>
                <p><?php echo _('CONTENT_DIALOG_AVATAR_HELP_DESC_REQUEST_AUTOMATED_SUPPORT')?></p>

                <p><?php echo _('CONTENT_DIALOG_AVATAR_HELP_STRING_CHECK_AND_CLICK_REQUEST_SUPPORT_DESC1')?></p>
                <p><?php echo _('CONTENT_DIALOG_AVATAR_HELP_STRING_CHECK_AND_CLICK_REQUEST_SUPPORT_DESC2')?></p>

                <form id="request_automated_support_form" method="POST" action="system_log">
                    <div class="content_row">
                        <input type="checkbox" class="normal_checkbox" id="request_automated_support" name="request_support" value=""/>
                        <label class="help_checkbox_label" for="request_automated_support"><?php echo _('CONTENT_DIALOG_AVATAR_HELP_STRING_ATTACH_MY_DIAGNOSTIC_REPORT')?></label>
                    </div>

                    <div class="content_row">
                        <a href="<?php echo $privacyPolicy?>" target="_blank"><?php echo _('CONTENT_SETTINGS_LINK_PRIVACY_POLICY')?></a>
                    </div>
                </form>
            </div>
        </div>
	</div>

	<div class="dialog_form_controls">
    	<button type="button" id="support_run_request_support_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_REQUEST_SUPPORT')?></button>
    	<button type="button" id="support_dialog_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    </div>
</div>      
