<div id="wifi_ap_container" class="wifi_network_outer_box">
    
    <div id="wifi_ap_list_container">
        <span class="wifi_box_title_button">
            <form id="wifi_enabled_form" action="wifi_client_configuration" method="PUT">
                <input type="hidden" id="WifiEnableValue" name="enable" value="true"/>
                <input type="checkbox" id="WifiEnableToggle" class="onoffswitch"/>
            </form>
        </span>
        <div id="wifi_ap_container_title" class="content_row wifi_box_title overflow_hidden_nowrap_ellipsis"><?php echo _('CONTENT_SETTINGS_LABEL_CHOOSE_INTERNET_CONNECTION')?></div>
        <div id="wifi_ap_list_off" class="wifi_network_inner_box">
            <div id="wifi_ap_list_off_msg"><?php echo _('CONTENT_SETTINGS_STRING_TO_SEE_AVAILABLE_NETWORKS_TURN_WIFI_ON')?></div>
        </div>
        <div id="wifi_ap_list_content" class="wifi_network_inner_box">
            <div class="wifi_list_please_wait">
                <span class="spinnerSunIcon"></span><br >
                <?php echo _('LABEL_DESCR_PLEASE_WAIT'); ?>
            </div>
            <ul id="wifi_ap_list" class="mochi_list">
                <li id="ap_default" class="wifi_ap_list_item default">
                    <div class="wifi_ap_list_item_icon"></div>
                    <label class="wireless_ssid_label overflow_hidden_nowrap_ellipsis wireless_label_text"></label>
                    <div class="wireless_info">
                        <div class="wireless_wps"></div>
                        <div class="wireless_lock"></div>
                        <div class="wireless_strength"></div>
                        <div class="wireless_ap_ssid"></div>
                        <div class="wireless_ap_mac"></div>
                        <div class="wireless_ap_security_mode"></div>
                    </div>
                    <div class="wireless_client_info">
                        <div class="wireless_client_ip"></div>
                        <div class="wireless_client_netmask"></div>
                        <div class="wireless_client_gateway"></div>
                        <div class="wireless_client_dns0"></div>
                        <div class="wireless_client_dns1"></div>
                        <div class="wireless_client_dns2"></div>
                    </div>
                </li>
            </ul>
        </div>
        <div id="wifi_client_ap_submit_container">
            <button id="wifi_client_ap_submit_btn"><?php echo _('BUTTON_JOIN')?></button>
        </div>
    </div>
    
</div>

