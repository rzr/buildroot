<div id="settings_<?php echo $identifier?>_container" class="edit_container_box">
	<h2><?php echo _($title)?></h2>
	<?php $view->LoadContents();$view->LoadViews(); ?>
</div>