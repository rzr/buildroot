<div id="reboot_dialog" title="<?php echo _('PAGE_HEADER_REBOOT'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
            <!--<div id="reboot_zero" class="reboot_label"><?php echo _('LABEL_DESCR_FACTORY_RESTORE_SUCCESS'); ?></div>-->
            <div id="reboot_format" class="reboot_label"><?php echo _('LABEL_DESCR_PARTIAL_RESTORE_SUCCESS'); ?></div>
            <div id="reboot_systemOnly" class="reboot_label"><?php echo _('LABEL_DESCR_PARTIAL_RESTORE_SUCCESS'); ?></div>
            <!--<div id="reboot_112" class="reboot_label"><?php echo _('LABEL_DESCR_FIRMWARE_UPDATE_SUCCESS'); ?></div>-->
            <div id="reboot_update" class="reboot_label"><?php echo _('LABEL_DESCR_FIRMWARE_UPDATE_SUCCESS'); ?></div>
            <!--<div id="reboot_restore" class="reboot_label"><?php echo _('LABEL_DESCR_FACTORY_RESTORE_SWITCH_TO_QUICK_RESTORE'); ?></div>-->
            <!--<div id="reboot_safepoint" class="reboot_label"><?php echo _('LABEL_SAFEPOINT_RESTORE_COMPLETE'); ?></div>-->
            <!--<div id="reboot_generic" class="reboot_label"></p>-->

			<div>
                <table>
                    <tr>
                        <td>
                            <span class="device_rebooting_status_icon spinnerSunIcon"></span></td>
                        <td>
                            <span class="device_rebooting_text"><?php echo _('LABEL_DESCR_DRIVE_REBOOTING'); ?></span>
                            <span class="device_initializing_text"><?php echo _('LABEL_DESCR_INTIALIZING_DRIVE'); ?></span>
                        </td>
                    </tr>
                </table>
			</div>

			<br />
			<?php echo _('LABEL_DESCR_AVATAR_DO_NOT_UNPLUG_DEVICE_DURING_REBOOT'); ?>
			<br /> <br />
		</div>
	</div>
</div>
