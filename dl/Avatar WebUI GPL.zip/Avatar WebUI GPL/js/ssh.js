
$(document).ready(function(){

    $('#ssh_form').restForm({
	    'useStubs': false,	     
        'refreshDataCallback' : function(data) {
            if (data.ssh_configuration.enablessh.toLowerCase() == 'true') {
                $('#ssh_form').find('#SettingDiagnosticsSSHToggle').attr('checked', true);
                $('#SettingDiagnosticsSSHValue').val('true');
            }                   
            else {
                $('#ssh_form').find('#SettingDiagnosticsSSHToggle').attr('checked', false);
                $('#SettingDiagnosticsSSHValue').val('false');
            } 
        }
    });

    $("#ssh_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        open: function(event, ui){
            $('#SettingsSshIAgreeToggle').attr('checked', false);
            //$('.sshOkButton').hide();
            $('.sshOkButton').attr('disabled', true);
            $('.sshOkButton').addClass('ui-state-disabled');

        },
        title: '<div class="wizard_dialog_title">'+$('#ssh_confirmation').attr('title')+'</div>'
    });
    
    $('#ssh_confirmation').bind('dialogclose', function(e) {
        if(e.keyCode == 27){
            $('#SettingDiagnosticsSSHToggle').attr('checked',false);
            $('#SettingDiagnosticsSSHValue').val('false');
        }
    });

    $('#ssh_confirmation_close_button').click(function(){
    	$('#SettingDiagnosticsSSHToggle').attr('checked',false);
        $('#SettingDiagnosticsSSHValue').val('false');
        $('#ssh_confirmation').dialog('close');
    });
    
    $('#ssh_confirmation_ok_button').click(function(){
    	$('#ssh_confirmation').dialog('close');
        $('#SettingDiagnosticsSSHValue').val('true');
        $('#ssh_form').submit();
    });

});

