
<div id="product_improvement" class="edit_container_box">
    <div class="content_row">
        <form id="product_improvement_form" action="privacy_options" method="PUT">
            <label><?php echo _('CONTENT_DIALOG_HELP_STRING_PARTICIPATION')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_HELP_DESC_PRODUCT_IMPROVEMENT_PROGRAM')?></div></div></div></label>
			<input type="checkbox" id="PrivacyOptionToggle" class="onoffswitch"/>		
            <input id="PrivacyOptionValue" name="send_serial_number" value="true" type="hidden"/>
            <span class="extra_space_left"><a id="product_improvement_more_info" href="#"><?php echo _('CONTENT_DIALOG_ALERTS_STRING_MORE_INFO')?><span class="details_link_marker">&nbsp;&raquo;</span></a></span>
        </form>
    </div>
</div>
