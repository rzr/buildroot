<?php
    $ap_security_modes = array('NONE'=>_('GENERIC_WIFI_SECURITY_NONE'),
                            'WPA2PSK/TKIPAES'=>_('GENERIC_WIFI_SECURITY_WPA2_PERSONAL'),
                            'WPAPSK1WPAPSK2/TKIPAES'=>_('GENERIC_WIFI_SECURITY_WPA_WPA2_PERSONAL_MIXED_MODE')
    );

    $client_security_modes = array('NONE'=>_('GENERIC_WIFI_SECURITY_NONE'),
                                   'WEP'=>_('GENERIC_WIFI_SECURITY_WEP'),
                                   'WPAPSK'=>_('GENERIC_WIFI_SECURITY_WPA_PERSONAL'),
                                   'WPA2PSK'=>_('GENERIC_WIFI_SECURITY_WPA2_PERSONAL'),
                                   'WPAPSK1WPAPSK2'=>_('GENERIC_WIFI_SECURITY_WPA_WPA2_PERSONAL_MIXED_MODE')
    );

    $encryption_types = array('TKIPAES'=>_('GENERIC_WIFI_ENCRYPTION_TKIP_AES'),
                              'AES'=>_('GENERIC_WIFI_ENCRYPTION_AES'),
                              'TKIP'=>_('GENERIC_WIFI_ENCRYPTION_TKIP')
    );

    /*
    $network_modes = array('bgn'=>_('GENERIC_WIFI_NETWORK_MODE_BGN'),
                           'bg'=>_('GENERIC_WIFI_NETWORK_MODE_BG'),
                           'gn'=>_('GENERIC_WIFI_NETWORK_MODE_GN'),
                           'b'=>_('GENERIC_WIFI_NETWORK_MODE_B'),
                           'g'=>_('GENERIC_WIFI_NETWORK_MODE_G'),
                           'n'=>_('GENERIC_WIFI_NETWORK_MODE_N')
    );
    */

    $wifi_channels = array('0'=>_('CONTENT_SETTINGS_DIALOG_STRING_AUTO'),
                           '1'=>_('1'),
                           '2'=>_('2'),
                           '3'=>_('3'),
                           '4'=>_('4'),
                           '5'=>_('5'),
                           '6'=>_('6'),
                           '7'=>_('7'),
                           '8'=>_('8'),
                           '9'=>_('9'),
                           '10'=>_('10'),
                           '11'=>_('11')
    );
?>

