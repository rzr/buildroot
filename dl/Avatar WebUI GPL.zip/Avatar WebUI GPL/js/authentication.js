
var reconnectInProgress = false;
var reconnectTimeOutMax = 600000; // 10 minutes
var reconnectStartTimeStamp = 0;
var startReconnectDelay = 10000; // 10 seconds

var authenticationHandler = $.authentication({
	'showEula': function(){
        $('#eula_language_form').restForm("refreshForm");
        $("#eula_container").show(); 
        //$("#header_toolbar").hide(); 
        $("#page").show();
        $("#main_nav_container").hide();
        $("#dashboard_container").hide();
        
        // hide the header toolbar except for language selection
        $(".toolbar_item").hide(); 
        $("#language_toolbar").show(); 
	},
	'hideEula': function(){
        $("#eula_container").hide(); 
        //$("#header_toolbar").show(); 
        
        $("#header_language").hide(); 

        // show the header toolbar except for language selection
        $(".toolbar_item").show();
        $("#language_toolbar").hide(); 
	},
	'displayLoading': function(){
		displaySplash();
	},
	'hideLoading': function(){
		hideSplash();
	},
	'processEulaError': function(response, action, httpCode){
		processAndDisplayError(response, action, httpCode);
	},
	'processEulaAcceptanceError': function(){
		$("#eula_acceptance_error").show();
	},
	'showLogin': function(adminName){
		if (typeof adminName != 'undefined' && adminName !== null){
			$("#login_username").val(adminName);
		}
        $("#logout_toolbar").show();
        authenticationHandler.hideLoading();

        $('#login_form').restForm("refreshForm");
        $('#eula_language_form').restForm("refreshForm");
        
        $("#authentication_container").show().siblings().hide();
        $("#main_nav_container").hide();
        $("#page").show();

        // hide the header toolbar except for language selection
        $(".toolbar_item").hide(); 
        $("#language_toolbar").show();
        
        // focus password input
        window.setTimeout(function () {
            $("input#login_password").focus();
        }, 500); // 500 covers all browsers with as little delay as possible.
	},
	'hideLogin': function(logout){
        $("#login_password").removeClass("invalid_unauthorized");
		$("#invalid_unauthorized").hide();
        //$("#invalid_password").hide();
        /*
        $("#login_dialog").dialog('close');
        $("#page").show();
        */

        $("#authentication_container").hide();
        $("#dashboard_container").show();
        
		// Show Navigation Container after login
        $("#main_nav_container").show();

        // show the header toolbar except for language selection
        $(".toolbar_item").show();
        $("#language_toolbar").hide(); 

        if (gIsMobile) {
            $('#shortcut_toolbar').hide();
        }

        if (logout === true) {
            $("#nav_dashboard_link").click();
            // Set Selection
            resetNavigationSelection('#nav_dashboard');
        }
	},
	'showPublicMode': function(firstTime){
		if (firstTime){
			authenticationHandler.hideLoading();
		}
        $("#logout_toolbar").hide();
        authenticationHandler.authenticate('','',true);
	},
    /* not needed since Admin password creation removed
    'showCreateAdminPassword': function(){
         authenticationHandler.hideLoading();

         // hide the header toolbar (including language selection)
         $(".toolbar_item").hide(); 
         $("#language_toolbar").hide(); 

         $('#create_login_password_form').restForm("refreshForm");

         $("#create_login_password_container").show().siblings().hide();
         $("#main_nav_container").hide();
         $("#page").show();
    },
    */
    'showCreateNetworkPassword': function(login_username){
         authenticationHandler.hideLoading();

         // hide the header toolbar (including language selection)
         $(".toolbar_item").hide(); 
         $("#language_toolbar").hide(); 

         // pre-authenticate as admin without password so we could modify the admin password
        $.ajaxAPI({
            "url": "local_login",
            "data": {"username":login_username,"password":""},
            "complete": function () {
                $('#create_network_password_form').restForm("refreshForm");
                $("#create_network_security_container").show().siblings().hide();
                $("#main_nav_container").hide();
                $("#page").show();
                
                // focus password input
                window.setTimeout(function () {
                    $("input#create_network_password").focus();
                }, 400);
            }
        });
    },
    /* not needed since Admin password creation removed; already in create_network_password_ok_button()
    'createNetworkPassword': function(){
        $("#create_network_password_form").submit();
    }, 
    */ 
    'hideCreatePassword': function(){
        hideCreatePassword();
        $("#create_shortcut_dialog").dialog("open");
	},
	'showInvalidPasswordError': function(){
        $('#login_form').restForm('reset');

		//$("#invalid_password").show();
        $("#login_password").addClass("invalid_unauthorized");
        $("#invalid_unauthorized").show();
	},
    /* Legacy Sequoia only, no getting_started_wizard for Avatar
	'eulaAcceptanceCallback': function(){
		$('#getting_started_wizard').divWizard("enableForward", false, false);
		$('#getting_started_wizard_add_users_setup_title').hide();
		$('#getting_started_wizard_add_users_invite_title').hide();
		$('#getting_started_wizard_add_user_edit_admin_form_container').hide();
		$('#getting_started_wizard_add_users_user_list_container').hide();
		$('#getting_started_wizard_add_users_do_not_add').hide();
		$('#getting_started_wizard_add_user_edit_admin_form').restForm("reset");
		
		//SetGettingStartedUsers(true);
		
        $('#getting_started_wizard').divWizard("startOver");
		$("#getting_started_wizard").dialog("open"); 
    }, 
	*/ 
	'beforeCheckUsers': function(){
		$('#splash_content h2').text(dictionaryList['splashAuthenticate']);
	}
});

$(document).ready(function(){
	$("#login_form").restForm({
        'refreshDataCallback': function(data) {
            var login_username = 'admin';
            /* password hint not supported
            var password_hint = '';
            */

           // $('#login_form').restForm("_refreshData", data);
            if (data !== null && data.users !== null && data.users.user !== null){
                if ( Object.prototype.toString.call( data.users.user ) != '[object Array]' ) {
                    login_username = data.users.user.username;
                    /* password hint not supported
                    if (data.users.user.password_hint != null) {
                        password_hint = data.users.user.password_hint;
                    }
                    */
                }
                else {
                    for(var i in data.users.user){
                        if (data.users.user[i].is_admin == 'true') {
                            login_username = data.users.user[i].username;
                            /* password hint not supported
                            if (data.users.user[i].password_hint != null) {
                                password_hint = data.users.user[i].password_hint;
                            }
                            */
                            break;
                        }
                    }
                }
            }
            $('#login_username').val(login_username);
            $('#login_user_id').html(login_username);
            /* password hint not supported
            if (password_hint) {
                $('#password_hint_container').show();
                $('#password_hint').html(password_hint);
            }
            else {
                $('#password_hint_container').hide();
            }
            */
        }
    });

    /* not needed since Admin password creation removed
    $("#create_login_password_form").restForm({
        'refreshDataCallback': function(data) {
            var login_username;
            var login_user_id;
            var is_admin;
            var password_hint = '';

            $('#create_login_password_form').restForm("reset");

            $('#create_login_password_form').restForm("_refreshData", data);
            if (data != null && data.users != null && data.users.user != null){
                if( Object.prototype.toString.call( data.users.user ) != '[object Array]' ){
                    login_username = data.users.user.username;
                    login_user_id = data.users.user.user_id;
                    is_admin = data.users.user.is_admin;
                    if (data.users.user.password_hint != null) {
                        password_hint = data.users.user.password_hint;
                    }
                }
                else{
                    for(var i in data.users.user){
                        if (data.users.user[i].is_admin == 'true') {
                            login_username = data.users.user[i].username;
                            login_user_id = data.users.user[i].user_id;
                            is_admin = data.users.user[i].is_admin;
                            if (data.users.user[i].password_hint != null) {
                                password_hint = data.users.user[i].password_hint;
                            }
                            break;
                        }
                    }
                }
            }
            $('#login_username_display').html(login_username);
            $('#create_login_username').val(login_username);
            $('#create_login_user_id').val(login_user_id);
            $('#create_login_is_admin').val(is_admin);
            if (password_hint) {
                $('#create_password_hint_container').show();
                $('#create_password_hint').html(password_hint);
            }
            else {
                $('#create_password_hint_container').hide();
            }
        },
        'validateFormCallback': function(){
            $('#create_login_password_form').restForm('_validateForm');
            // Note: CONFIRM validation already done as part of class CONFIRM
            if ($('#create_login_password_form').data('validForm') == true){
                if ($('#create_login_password').val() != $('#create_login_password_confirm').val()){
                    $('#create_login_password_form').data('validForm', false);
                }
            }

    	},
    	'beforeProcessForm': function(){
            var password = $('#create_login_password').val();
    		$('#create_login_password_encoded').val($.base64.encode(password));
    	},
        'processFormSuccessCallback':function(data){
            var username = $('#create_login_username').val();
            var password = $('#create_login_password').val();
            authenticationHandler.authenticate(username, password);
        }
    });
    */

    $("#create_network_password_form").restForm({
        'refreshDataCallback': function(data) {
            var network_ssid = '_unknown';
            var security_mode = 'WPA2PSK/TKIPAES';  // default security mode
            var enabled = 'true';
            var broadcast = 'true';

            $('#create_network_password_form').restForm("reset");
            resetCreateNetworkPasswordForm();

            $('#create_network_password_form').restForm("_refreshData", data);
            if (data !== null && data.wifi_ap !== null && data.wifi_ap.ssid !== null){
                if (data.wifi_ap.ssid !== '') {
                    network_ssid = data.wifi_ap.ssid;
                    enabled = data.wifi_ap.enabled;
                    broadcast = data.wifi_ap.broadcast;
                }
            }

            /*$('#network_name_display').html(network_ssid);*/
            /*$('#network_security_mode').val(security_mode);*/
            $('#create_network_original_ssid').html(network_ssid);

            /* workaround IE8 issue with form reset*/
            $('#create_network_password_form').find('.security_mode').text( security_mode );
            $('#create_network_password_form').find('.enabled').text( enabled );
            $('#create_network_password_form').find('.broadcast').text( broadcast );
        },
        'validateFormCallback': function(){
            // workaround to disable the show password textbox not initially disabled
            if ($('#create_network_password_show_password_checkbox').is(":checked")) {
                disableIdTag('#create_network_password');
                enableIdTag('#create_network_password_show');
            }
            else {
                enableIdTag('#create_network_password');
                disableIdTag('#create_network_password_show');
            }

            $('#create_network_password_form').restForm('_validateForm');
            /* CONFIRM validation already done as part of class CONFIRM
            if ($('#create_network_password_form').data('validForm') == true){
                if ($('#create_network_password').val() != $('#create_network_password_confirm').val()){
                    $('#create_network_password_form').data('validForm', false);
                } 
            }
            */
        },
    	'beforeProcessForm': function(){
            //var password = $('#create_network_password').val();
    		//$('#create_network_password_encoded').val($.base64.encode(password));

            /* workaround IE8 issue with form reset*/
            $('#create_network_password_form').find('input[name="security_mode"]').val( $('#create_network_password_form').find('.security_mode').text() );
            $('#create_network_password_form').find('input[name="enabled"]').val( $('#create_network_password_form').find('.enabled').text() );
            $('#create_network_password_form').find('input[name="broadcast"]').val( $('#create_network_password_form').find('.broadcast').text() );
    	},
        'processFormSuccessCallback':function(data){
			//$('#create_network_password_form').restForm('reset');
            gSSIDName = $('#create_network_ssid').val();
            doReconnectNetwork();
        }
    });

    $('#create_network_password_show_password_checkbox').click(function() {
        if ($('#create_network_password_show_password_checkbox').is(":checked")) {
            $('#create_network_password').val( $('#create_network_password_show').val() );
            resetCreateNetworkPasswordForm();
        }
        else {
            $('#create_network_password_show').val( $('#create_network_password').val() );
            $('#create_network_password_container').hide();
            $('#create_network_password_show_container').show();
            $('#create_network_password_confirm_container').hide();

            $('#create_network_password').removeClass('NETWORK_PASSWORD').removeClass('WPA_NETWORK_PASSWORD').removeClass('NOTEMPTY');
            $('#create_network_password_confirm').removeClass('CONFIRM_PASSWORD');
            $('#create_network_password_show').addClass('NETWORK_PASSWORD').addClass('WPA_NETWORK_PASSWORD').addClass('NOTEMPTY');

            disableIdTag('#create_network_password');
            enableIdTag('#create_network_password_show');
        }
    });    

    /*
    $("#login_dialog").dialog({
        autoOpen: false,
        resizable: false,
        draggable: false,
        closeOnEscape: false,
        position: 'center',
        width:450,
        minHeight:300,
        zIndex:2000,
        dialogClass:'mochi_dialog mochi_dialog_logo',
        modal: true,
        stack: false
    });
    */
    
    $('#login_ok_button').click(function(e){
        e.preventDefault();
        var username = $("#login_username").val(),
            password = $('#login_password').val();

        if(validate('#login_form')){
            //$("#invalid_password").hide();
            $("#login_password").removeClass("invalid_unauthorized");
            $("#invalid_unauthorized").hide();
            authenticationHandler.authenticate(username, password);
        }
    });

    $('#login_password').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#login_ok_button").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#login_username').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#login_ok_button").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#logout_link').live('click', function(){
        authenticationHandler.logout();
    });

    /* not needed since Admin password creation removed
    $('#create_login_password_skip_button').live('click', function(){

        //var username = $('#create_login_username').val();
        //var password = "";

        // since the user wishes to skip setting a password login with no password
        authenticationHandler.authenticate('', '', true);
    });
    */

    $("#eula_language_form").restForm({
        'refreshDataCallback': function(data) {
            if (data !== null && data.language_configuration !== null) {
                if (data.language_configuration.language.toLowerCase() == 'default') {
                    data.language_configuration.language = 'en_US';
                }
            }
            $('#eula_language_form').restForm("_refreshData", data);
        },
        'processFormSuccessCallback': function(){
            gLanguage = $('#eula_language_select').val();
            window.location = redirectURL;
        }
    });
    $("#eula_agree_form").restForm();

    $('#eula_accept_btn').live('click', function(){
        $("#eula_not_accepted_error").hide();
        if( $("#eula_checked").is(":checked") ) {
            authenticationHandler.acceptEula();
            //$("#eula_language_form").submit();
        }
        else {
            $("#eula_not_accepted_error").show();
        }
    });
    
    $('#eulaShowLink').live('click', function(){
        $("#eula_forms_container").hide();
        $("#eula_forms_floater").hide();
        //$("#eula_content").css("padding-top","100px");
        //$("#eula_background").css("margin-top","100px");
        //$("#eula_background").css("margin-left","0");
        $("#eulaView").show();
    });

    $('#eulaAgreeLink').live('click', function(){
        authenticationHandler.acceptEula();
    });

    $('#eulaCancelLink').live('click', function(){
        $("#eulaView").hide();
        $("#eula_not_accepted_error").hide();
        //$("#eula_content").css("padding-top","190px");
        //$("#eula_background").css("margin-top","190px");
        //$("#eula_background").css("margin-left","17%");
        $("#eula_forms_floater").show();
        $("#eula_forms_container").show();
    });

    $("#eulaPrintLink").click(
        function(){
			var eula = frames[0];
			eula.focus();
			eula.print();
            return false;
        }
    );

    $("#eula_language_select").change(function() {
        var lang = $("#eula_language_select option:selected").html();
        $(this).submit();
    });

    $('#create_network_password_ok_button').live('click', function(){
        /* not needed since Admin password creation removed
        $('#create_network_password_form').restForm('_validateForm');
        if ($('#create_network_password_form').data('validForm') == true){ 
            // Note: CONFIRM validation already done as part of class CONFIRM 
            if ($('#create_network_password').val() != $('#create_network_password_confirm').val()){
                $('#create_nework_password_form').data('validForm', false);
            }
        }

        if ($('#create_network_password_form').data('validForm') == true) {
            authenticationHandler.flagCreateNetworkPassword();
            authenticationHandler.showCreateAdminPassword();
        }
        */

        var password;
        var showWarning = false;
        if ($('#create_network_password_show_container').is(':visible')){
            password = $('#create_network_password_show').val();
            if (password == '') {
                showWarning = true;
                $('#create_network_password_show').removeClass('NOTEMPTY');
                $('#create_network_password_form').find('.security_mode').text('NONE')
            }
            else {
                $('#create_network_password_show').addClass('NOTEMPTY');
                $('#create_network_password_form').find('.security_mode').text('WPA2PSK/TKIPAES')
            }
        }
        else {
            password = $('#create_network_password').val();
            var confirmPassword = $('#create_network_password_confirm').val();
            if (password == '' && confirmPassword == '') {
                showWarning = true;
                $('#create_network_password').removeClass('NOTEMPTY');
                $('#create_network_password_form').find('.security_mode').text('NONE')
            }
            else {
                $('#create_network_password').addClass('NOTEMPTY');
                $('#create_network_password_form').find('.security_mode').text('WPA2PSK/TKIPAES')
            }
        }

        if (showWarning) {
            $('#confirm_network_no_password_dialog').dialog('open');
        }
        else {
            $("#create_network_password_form").submit();
        }
    });

    $('#create_network_password_skip_button').live('click', function(){
        /* not needed since Admin password creation removed
        authenticationHandler.showCreateAdminPassword();
        */

        $('#confirm_skip_network_password_dialog').dialog('open');
    });

    $("#confirm_skip_network_password_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        modal: true,
        stack: true,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        title: '<div class="wizard_dialog_title">'+$('#confirm_skip_network_password_dialog').attr('title')+'</div>'
    });

    $('#confirm_skip_network_password_close_button').click(function(){
        $('#confirm_skip_network_password_dialog').dialog('close');
    });

    $('#confirm_skip_network_password_ok_button').click(function(){
        $('#confirm_skip_network_password_dialog').dialog('close');
        authenticationHandler.authenticate('','',true);
    });

    $("#confirm_network_no_password_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        modal: true,
        stack: true,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        title: '<div class="wizard_dialog_title">'+$('#confirm_network_no_password_dialog').attr('title')+'</div>'
    });

    $('#confirm_network_no_password_close_button').click(function(){
        $('#confirm_network_no_password_dialog').dialog('close');
    });

    $('#confirm_network_no_password_ok_button').click(function(){
        $('#confirm_network_no_password_dialog').dialog('close');

        var originalSSID = $('#create_network_original_ssid').html();
        var newSSID = $('#create_network_ssid').val();
        if (newSSID != originalSSID) {
            $("#create_network_password_form").submit();
        }
        else {
            authenticationHandler.authenticate('','',true);
        }
    });

    $("#onboarding_reconnect_network_dialog").dialog({
        autoOpen: false,
        resizable: false,
        closeOnEscape: false,
        position: 'center',
        width: 710,
        minHeight: dialogMinHeight,
        zIndex: 2000,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#onboarding_reconnect_network_dialog').attr('title')+'</div>',
        open: function(){
            var msg;
            var ssidname = '<b><i>'+gSSIDName+'</i></b>';
            msg = dictionaryList['find_wifi'].replace('{0}', ssidname);
            $('#onboarding_connect_msg_find_wifi_network').find('.connect_network_msg_title').html(msg);

            msg = dictionaryList['connect_wifi'].replace('{0}', ssidname);
            $('#onboarding_connect_msg_select_wifi_network').find('.connect_network_msg_title').html(msg);

            // browser is on Mac or iOS
            if ((navigator.appVersion.indexOf("Mac") != -1) || (navigator.platform.toLowerCase() == "ipad") || (navigator.platform.toLowerCase() == "iphone")) {
                $('#onboarding_connect_msg_find_wifi_network').find('.icon').removeClass('pc_icon');
                $('#onboarding_connect_msg_select_wifi_network').find('.icon').removeClass('pc_icon');
            } else {
                $('#onboarding_connect_msg_find_wifi_network').find('.icon').addClass('pc_icon');
                $('#onboarding_connect_msg_select_wifi_network').find('.icon').addClass('pc_icon');
            }
            
            msg = dictionaryList['select_avatar_wifi'].replace('{0}', ssidname);
            $('#onboarding_connect_msg_select_wifi_network').find('.connect_network_msg_details').html(msg);

            var deviceNameURL = getDeviceNameURL(gDeviceName);
            msg = dictionaryList['devicename_url'].replace('{0}', '<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
            $('#onboarding_connect_network_msg_refresh_browser').find('.connect_network_msg_details').html(msg);
        }
    });

    $('#onboarding_reconnect_network_form').restForm({
        'timeout': ajaxTimeoutPolling,
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
        },
        'setDefaultFormDataCallback': function (data) {
          
            reconnectInProgress = false;
            var username = $('#create_login_username').val();
            var password = $('#create_login_password').val();

            if (data.system_state.status == "ready") {
                $("#onboarding_reconnect_network_dialog").dialog('close');

                hideCreatePassword();
                authenticationHandler.authenticate(username, password);

                return;
            }

            // avoid infinitely calling reconnectNetwork() by checking timeout
            var reconnectCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((reconnectCurrentTimeStamp - reconnectStartTimeStamp) > reconnectTimeOutMax) {
                // if system is "ready", then just authenticate
                if (status == "ready") {
                    $("#onboarding_reconnect_network_dialog").dialog('close');

                    hideCreatePassword();
                    authenticationHandler.authenticate(username, password);
                }
                else {
                    showReconnectTimeout();
                }
                return;
            }
            setTimeout("reconnectNetwork();", pingInterval);
        },
        'processFormErrorCallback': function(){
            reconnectInProgress = false;

            // avoid infinitely calling reconnectNetwork() by checking timeout
            var reconnectCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((reconnectCurrentTimeStamp - reconnectStartTimeStamp) > reconnectTimeOutMax) {
                showReconnectTimeout();
                return;
            }
            setTimeout("reconnectNetwork();", pingInterval);
        
        },
        'processFormSuccessCallback':function(data){ 
            $("#onboarding_reconnect_network_dialog").dialog('close'); 
            authenticationHandler.authenticate('','',true);
        }
    });
});

function doReconnectNetwork() {
    reconnectStartTimeStamp = new Date().getTime(); // in milliseconds

    $("#onboarding_reconnect_network_dialog").dialog("open"); 
    setTimeout("reconnectNetwork();", startReconnectDelay);
}

function reconnectNetwork(){

    if(reconnectInProgress) {
        return;
    }
    reconnectInProgress = true;

    $('#onboarding_reconnect_network_form').submit();
}

// show the reconnect timeout message
function showReconnectTimeout() {
    $("#onboarding_reconnect_network_dialog").dialog('close');
    //gRedirect = true;
    //showError('reconnect_network_timeout');

    $("#reconnect_network_timeout_dialog").dialog('open');
}

function hideCreatePassword() {
    //$("#create_login_password_container").hide();
    $("#create_network_security_container").hide();
    $("#dashboard_container").show();
    $("#main_nav_container").show();
}

function resetCreateNetworkPasswordForm() {
    $('#create_network_password_container').show();
    $('#create_network_password_show_container').hide();
    $('#create_network_password_confirm_container').show();

    $('#create_network_password').addClass('NETWORK_PASSWORD').addClass('WPA_NETWORK_PASSWORD').addClass('NOTEMPTY');
    $('#create_network_password_confirm').addClass('CONFIRM_PASSWORD');
    $('#create_network_password_show').removeClass('NETWORK_PASSWORD').removeClass('WPA_NETWORK_PASSWORD').removeClass('NOTEMPTY');

    enableIdTag('#create_network_password');
    disableIdTag('#create_network_password_show');
}
