<div id="<?php echo $identifier?>_nav" class="leftmenu_container">
	<nav class="leftmenu">
		<ul>
			<?php foreach($navigationItems as $navigationItemGroup):
			    foreach($navigationItemGroup as $navigationItemList): 
			        foreach($navigationItemList as $navigationItem):?>
					<li><a href="<?php echo $navigationItem->link?>" id="<?php echo $navigationItem->id?>"><?php echo _($navigationItem->title)?></a><div class="right_arrow"></div></li>
				    <?php endforeach;
				endforeach;
			endforeach;?>
		</ul>
	</nav>
</div>