<div id="shortcut_toolbar" class="toolbar_item">
    <div class="toolbar_button_container">
        <button id="shortcut_link">
            <span class="icon"></span>
            <span class="text"><?php echo _('BUTTON_SHORTCUT')?></span>
        </button>
    </div>
</div>

