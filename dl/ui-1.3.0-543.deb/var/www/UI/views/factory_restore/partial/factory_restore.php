
<div id="factory_restore" class="edit_container_box">
    <h2><?php echo _('CONTENT_SETTINGS_HEAD2_RESTORE_FACTORY_SETTINGS')?><div class="tooltip_container">
    <span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip">
    <?php echo _('CONTENT_SETTINGS_FACTORY_RESTORE_TOOLTIP_PROLOGUE')?>
    <ul>
    	<li><?php echo _('CONTENT_SETTINGS_FACTORY_RESTORE_TOOLTIP_SYSTEM_ONLY')?></li>
        <li><?php echo _('CONTENT_SETTINGS_FACTORY_RESTORE_TOOLTIP_SYSTEM_AND_DISK')?></li>
    	<!--<li><?php echo _('CONTENT_SETTINGS_FACTORY_RESTORE_TOOLTIP_FULL_RESTORE')?></li>-->
    </ul>
    </div></div></div></h2>
    <div class="content_row content_row_wrappable">
    	<form id="factory_restore_form" style="display: inline-block" method="POST" action="system_factory_restore">
            <!--<label><?php echo _('CONTENT_SETTINGS_LABEL_FACTORY_RESTORE')?></label>-->
            <div class="settings_values_container">
                <button type="button" id="settings_factory_restore_system_button"><?php echo _('BUTTON_JUST_SETTINGS')?></button>
                <span class="extra_space_left"></span><button type="button" id="settings_factory_restore_quick_button"><?php echo _('CONTENT_SETTINGS_BUTTON_SYSTEM_AND_DISK')?></button>
                <!--<span class="extra_space_left"></span><button type="button" id="settings_factory_restore_full_button"><?php echo _('BUTTON_WIPE_DATA_AND_RESTORE_SETTINGS')?></button>-->

                <input id="FactoryRestoreValue" type="hidden" name="erase" value="systemOnly" />
            </div>
    	</form>
    
    	<form id="factory_restore_progress_form" method="GET" action="system_factory_restore"></form>
    </div>
</div>
