<div id="itunes_rescan_results" title="<?php echo _("CONTENT_SETTINGS_HEAD2_ITUNES");?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
			<div id="itunes_rescan_good" style="display:none"><?php echo _("AVATAR_CONTENT_SETTINGS_DIALOG_STRING_ITUNES_RESCAN_STARTED");?></div>
    		<div id="itunes_rescan_bad" style="display:none"><?php echo _("AVATAR_CONTENT_SETTINGS_DIALOG_STRING_ITUNES_RESCAN_ERROR");?></div>
    	</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="itunes_rescan_results_close_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

