var rebuildDLNAInProgress = false;
var rescanDLNAInProgress = false;
var checkDLNARescanInProgress = false;
var DLNAPoll = 10000;  // 10 seconds
var gMediaServerEnable = false;
var checkMediacrawlerRebuildInProgress = false;

$(document).ready(function(){

    pollingHandler.addPoll("media_server_database", ["media_container"], settingsDLNAPollSuccess, settingsMediaPollError);
    pollingHandler.addPoll("mediacrawler_status", ["media_container"], settingsMediacrawlerPollSuccess, settingsMediaPollError);

    //$('#dlna_media_player_list_item_form').restForm();

    //$('#settings_media_name_form').restForm();

    $('#head_settings_nav_media_link').navItem({
        'contentId': 'media_container',
        'refreshDataCall': function(){

        	// Set Selection
        	resetNavigationSelection('#head_settings_nav_media_link');
            initSDCardTransferProgress();
        
        	pollingHandler.poll();
        	$('#settings_media_toggle_dlna_service_form').restForm("refreshForm");
            //$('#settings_toggle_itunes_service_form').restForm("refreshForm");
            $('#settings_nav_media_link').parent('li').addClass('selected').siblings().removeClass('selected');
            $('#sdcard_automatic_transfer_form').restForm("refreshForm");
            $('#sdcard_after_transfer_form').restForm("refreshForm");

            /*
            $("#settings_media_crawler_videos").text(gMediaCountTotal["videos"]);
            $("#settings_media_crawler_music_tracks").text(gMediaCountTotal["music"]);
            $("#settings_media_crawler_pictures").text(gMediaCountTotal["photos"]);
            $("#settings_media_crawler_others").text(gMediaCountTotal["other"]);

            $("#mediaCrawler_MediaDB_activity").text( gMediaCrawlerScanningStateMsg );
            */
        }
    });

    $('#head_settings_nav_media_link').click(function(){
        $('#head_nav').hide();
        $('#head_nav_link').removeClass('selected');
    });

    $('#settings_media_toggle_dlna_service_form').restForm({
        'refreshDataCallback': function(data) {
            $('#settings_media_toggle_dlna_service_form').restForm("_refreshData", data);

            gMediaServerEnable = data.media_server_configuration.enable_media_server;
            if (gMediaServerEnable == 'false') {
                //$('#settings_dlna_form_advanced_options').hide();
                $('#settings_dlna_database_container').hide();
            }
            else {
                //$('#settings_dlna_form_advanced_options').show();
                $('#settings_dlna_database_container').show();
            }

            getMediaServerDatabase();
        },
        'processFormSuccessCallback': function(){
            $('#settings_media_toggle_dlna_service_form').restForm("processFormSuccess");

            getMediaServerDatabase();
        }
    });

    /* Legacy Sequoia
    $('#settings_toggle_itunes_service_form').restForm({
        'refreshDataCallback': function(data) {
            $('#settings_toggle_itunes_service_form').restForm("_refreshData", data);
            
            if (data.itunes_configuration.enable_itunes_server == 'true') {
                $('#settings_itunes_form_rescan').show();
            }
            else {
                $('#settings_itunes_form_rescan').hide();
            }
        }
    });

    $("#itunes_enabled").live('toggle', function(){
        // checked means iTunes=true
        if( $(this).is(":checked") ){
            $('#settings_itunes_form_rescan').show();
        }
        else {
            $('#settings_itunes_form_rescan').hide();
        }
        $(this).submit();
    });

    $('#settings_itunes_form_rescan_link').live('click', function(){
        displayLoading();
        $.ajaxAPI({
            "url": "itunes_scan",
            "type": "PUT",
            "data": {"scan":"now"},
            "error": function (request, status, error) {
                processAndDisplayError(request.responseText, 'put_itunes_scan', request.status);
            },
            "success": function (data) {
                $('#itunes_rescan_good').css('display', 'block');
                $("#itunes_rescan_results").dialog("open");
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
            }
        });
    });
    */

    /*
    $('#settings_dlna_form_advanced_options_link').live('click', function (e) {
    	e.preventDefault();

        $.ajaxAPI({
            "url": "media_server_connected_list",
            "type": "GET",
            "error": function (request, status, error) {
                processAndDisplayError(request.responseText, 'get_media_server_connected_list', request.status);
            },
            "success": function (data) {

                if (data != null && data.media_server_connected_list != null && data.media_server_connected_list.device != null) {

                    // delete all available items except template
                    $("#config_dlna_dialog_media_players ul li:first").siblings().each(function(){
                        $(this).remove();
                    });
                    if( Object.prototype.toString.call( data.media_server_connected_list.device ) != '[object Array]' ){  // only 1 device_user
                    	data.media_server_connected_list.device = $.makeArray(data.media_server_connected_list.device);
                    }
                    for(var i in data.media_server_connected_list.device){

                        var timestamp = new Date().getTime();
                        var ipaddress = data.media_server_connected_list.device[i].ip_address;
                        var device_enable = data.media_server_connected_list.device[i].device_enable;
                        var inputID = "dlna_media_player_toggle_" + ipaddress.replace(/\./g,'_') + '_' + timestamp;
                        var formID = "dlna_media_player_list_item_form_" + ipaddress.replace(/\./g,'_') + '_' + timestamp;
                        var friendly_name = data.media_server_connected_list.device[i].friendly_name;
                        var description = data.media_server_connected_list.device[i].device_description;
                        var mac_address = data.media_server_connected_list.device[i].mac_address;

                        if (friendly_name == '') {
                            friendly_name = dictionaryList['generic_media_receiver'];
                        }
                        if (description == '') {
                            description = dictionaryList['generic_media_receiver'];
                        }

                        newMediaPlayer = $('#config_dlna_dialog_media_players').find("ul.dlna_media_player_list li:first").clone();
                        newMediaPlayer.removeAttr('style');
                        newMediaPlayer.find('.dlna_media_player_name').html(friendly_name);
                        newMediaPlayer.find('.dlna_media_player_ipaddress').html(ipaddress);
                        newMediaPlayer.find('.dlna_media_player_mac_address').val(mac_address);

                        newMediaPlayer.find('#dlna_media_player_list_item_form').attr("id", formID);
                        newMediaPlayer.find('#dlna_media_player_toggle_template').attr("id", inputID);

                        if (device_enable == 'true') {
                            newMediaPlayer.find('#'+inputID).attr("checked","checked");
                            newMediaPlayer.find('#'+formID).find('input:checkbox').each(function(){
                                $(this)[0].defaultChecked = true;
                            });
                        }

                        newMediaPlayer.appendTo('.dlna_media_player_list');

                        $('#'+formID).restFormDialog({
                        	'dialogName': 'config_dlna_dialog'
                        });
                    }
                }

                $("#config_dlna_dialog").dialog("open");
            }
        });        
    });
    */

    $("#config_dlna_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_media',
        modal: true,
        stack: false,
        title: '<div id="config_dlna_dialog_title" class="wizard_dialog_title">'+$('#config_dlna_dialog').attr('title')+'</div>'
    });

    $('#config_dlna_dialog_done_button').click(function () {
        $("#config_dlna_dialog").dialog("close");
    }); 

    $("#itunes_rescan_results").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: 410,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_media',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#itunes_rescan_results').attr('title')+'</div>'
    });
    
    $('#itunes_rescan_results_close_button').click(function(){
    	$("#itunes_rescan_results").dialog('close');
    });

});

$(function(){

    /* Legacy Sequoia
    $('#config_dlna_dialog_media_players').find('.onoffswitch').live('toggle', function(){
        var mediaPlayerFormID = $(this).parent().parent().attr('id');
        var mac_address = $('#'+mediaPlayerFormID).find('.dlna_media_player_mac_address').val();
        var device_enable = 'false';

        if( $(this).is(":checked") ) {
            device_enable = 'true';
        }

        var parameterOptions = {'device': {'0': {'mac_address':mac_address, 'device_enable': device_enable}}};

        displayLoading();
        $.ajaxAPI({
            "url": "media_server_connected_list",
            "type": "PUT",
            "data": parameterOptions,
            "error": function (request, status, error) {
                processAndDisplayError(request.responseText, 'put_media_server_connected_list', request.status);

                if (device_enable == 'false') {
                    $('#'+mediaPlayerFormID).find('.onoffswitch').val('true');
                    $('#'+mediaPlayerFormID).find('.onoffswitch').attr("checked","checked");
                }
                else {
                    $('#'+mediaPlayerFormID).find('.onoffswitch').val('false');
                    $('#'+mediaPlayerFormID).find('.onoffswitch').removeAttr("checked");
                }
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
            }
        });
        
    });
    */

    $('#dlna_enabled').live('toggle', function(){
        // checked means dlna=false
        if( $(this).is(":checked") ){
            $(this).siblings('.false').attr('disabled', true).addClass("ui-state-disabled");
            gMediaServerEnable = true;
            //$("#settings_dlna_form_advanced_options").show();
            $('#settings_dlna_database_container').show();

            enableIdTag("#dlna_mediadb_rescan_button");
            enableIdTag("#dlna_mediadb_rebuild_button");
            //$('#dlna_mediadb_button_container').show();
        }
        else {
            gMediaServerEnable = false;
            //$("#settings_dlna_form_advanced_options").hide();
            $('#settings_dlna_database_container').hide();

            disableIdTag("#dlna_mediadb_rescan_button");
            disableIdTag("#dlna_mediadb_rebuild_button");
            //$('#dlna_mediadb_button_container').hide();
        }
        $(this.form).submit();
    });

    $("#dlna_mediadb_rescan_button").live('click', function(){
        showDLNAProgressMsg();
        doDLNARescan();
        return false;
    });

    $("#dlna_mediadb_rebuild_button").live('click', function(){
        showDLNAProgressMsg();
        doDLNARebuild();
        return false;
    });

    $("#mediaCrawler_mediadb_rebuild_button").live('click', function(){
        if (!$(this).hasClass('ui-state-disabled')) {
            doMediacrawlerRebuild();
        }
    });

});

function getMediaServerDatabase() {
    // call ajax to get dlna version status
    $.ajaxAPI({
        "url": "media_server_database",
        "type": "GET",
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'get_media_server_database', request.status);
        },
        "success": function (data) {
            updateDLNAInfo(data.media_server_database, true);
        }
    });
}

function doDLNARescan() {
    if (rescanDLNAInProgress === true) {
        //setTimeout("doDLNARescan();", DLNAPoll);
        return;
    }

    rescanDLNAInProgress = true;
    clearDLNAMediaServerLastUpdate();

    // call ajax to recan DLNA media server stats
    $.ajaxAPI({
        "url": "media_server_database",
        "type": "PUT",
        "data": {"database":"rescan"},
        "error": function (request, status, error) {
            rescanDLNAInProgress = false;

            processAndDisplayError(request.responseText, 'put_media_server_database');

            hideDLNAProgressMsg();
        },
        "success": function(data, status, XMLHttpRequest) {
             rescanDLNAInProgress = false;

             if (XMLHttpRequest.status == 200) {
                 setTimeout('checkDLNARescanStatus();', DLNAPoll);
             }
             else {
                 showError('rescan_dlna_' + XMLHttpRequest.status);
                 hideDLNAProgressMsg();
             }
        }
    });
}

function doDLNARebuild() {
    if (rebuildDLNAInProgress === true) {
        //setTimeout("doDLNARebuild();", DLNAPoll);
        return;
    }

    rebuildDLNAInProgress = true;
    clearDLNAMediaServerLastUpdate();

    //displayLoading();

    $.ajaxAPI({
        "url": "media_server_database",
        "type": "PUT",
        "data": {"database":"rebuild"},
        //"timeout": 10000,   // 10sec timeout to start the rebuild_dlna process (note: the actual rebuild can take several hours so we will force a timeout)
        "error": function (request, status, error) {
             // the rebuild can take several hours so we'll force timeout and start checkDLNARescanStatus()
             if (status == 'timeout' || status == 'abort') {
                   //showError('rebuild_dlna_timeout');
                   setTimeout('checkDLNARescanStatus();', DLNAPoll); 
             }
             else {
                   processAjaxError('rebuild_dlna', status);
                   hideDLNAProgressMsg();
             }
        },
        "success": function(data, status, XMLHttpRequest) {
             if(XMLHttpRequest.status == 200) {
                 clearDLNAMediaServerLastUpdate();
                 setTimeout('checkDLNARescanStatus();', DLNAPoll); 
             }
             else {
                 showError('rebuild_dlna_' + XMLHttpRequest.status);
                 hideDLNAProgressMsg();
             }
        },
        "complete": function (jqXHR, textStatus) {
            rebuildDLNAInProgress = false;
            //hideLoading();
        }
    });
}

function clearDLNAMediaServerLastUpdate() {
    $('#settings_media_dlna_update').text('');
    $('#settings_media_dlna_music_tracks').text('0');
    $('#settings_media_dlna_pictures').text('0');
    $('#settings_media_dlna_videos').text('0');
}

function hideDLNAProgressMsg() {
    enableIdTag("#dlna_mediadb_rescan_button");
    enableIdTag("#dlna_mediadb_rebuild_button");
    //$('#dlna_mediadb_button_container').show();

    $("#dlnaMediaDBProcessContainer").hide();
    $("#dlnaMediaDBProcessContainer").parent().removeClass('updating_database');

    $("#settings_media_dlna_update").show();
    $("#settings_media_dlna_last_update_string").show();
}

function showDLNAProgressMsg() {
    disableIdTag("#dlna_mediadb_rescan_button");
    disableIdTag("#dlna_mediadb_rebuild_button");
    //$('#dlna_mediadb_button_container').hide();

    $("#dlnaMediaDBProcessContainer").show();
    $("#dlnaMediaDBProcessContainer").parent().addClass('updating_database');

    $("#settings_media_dlna_update").hide();
    $("#settings_media_dlna_last_update_string").hide();
}

function checkDLNARescanStatus(){
    if (checkDLNARescanInProgress === true) {
        //setTimeout("checkDLNARescanStatus();", DLNAPoll);
        return;
    }

    /*
    // don't poll if not in media tab
    if (!$('#head_settings_nav_media_link').hasClass("current")) {
        setTimeout("checkDLNARescanStatus();", DLNAPoll);
        return;
    }
    */

    // only poll if on Media page
    if (!$('#dlna_content').is(':visible')){
        return;
    }

    checkDLNARescanInProgress = true;

    // call ajax to get DLNA rescan/rebuild status
    $.ajaxAPI({
        "url": "media_server_database",
        "error": function (request, status, error) {
            checkDLNARescanInProgress = false;

            processAndDisplayError(request.responseText, 'get_media_server_database');

            hideDLNAProgressMsg();
        },
        "success": function(data, status, XMLHttpRequest) {
             checkDLNARescanInProgress = false;

             if((XMLHttpRequest.status != 200) && (XMLHttpRequest.status != 503)){
                 showError('check_rescan_dlna_' + XMLHttpRequest.status);
                 return;
             }
             else {

                 if ('media_server_database' in data) {
                     updateDLNAInfo(data.media_server_database, 'true', false);   // can only rescan if DLNA status=enabled

                     if ((data.media_server_database.scan_in_progress == '') ||
                         (data.media_server_database.scan_in_progress == 'false'))
                     {
                         return;
                     }
                 }

                 if (XMLHttpRequest.status == 503) { // don't poll again if 503 is returned
                     hideDLNAProgressMsg();
                 }
                 else {
                     setTimeout('checkDLNARescanStatus();', DLNAPoll);
                 }
             }
        }
    });

}

function updateDLNAInfo(data, rescanDLNA){

    var music_tracks = dictionaryList['_unknown'];
    var pictures = dictionaryList['_unknown'];
    var videos = dictionaryList['_unknown'];
    var lastupdate = dictionaryList['_unknown'];
    var version = dictionaryList['_unknown'];

    if (data.music_tracks != '') {
        music_tracks = data.music_tracks;
    }
    if (data.pictures != '') {
        pictures = data.pictures;
    }
    if (data.videos != '') {
        videos = data.videos;
    }
    if (data.time_db_update != 0 && data.time_db_update != '') {
        lastupdate = getTimeStamp(data.time_db_update);
    }

    if (data.version != 'twonky.dat' && data.version != '') {
        version = data.version;
    }

    $('#settings_media_dlna_version').text(version);
    $('#settings_media_dlna_music_tracks').text(music_tracks);
    $('#settings_media_dlna_pictures').text(pictures);
    $('#settings_media_dlna_videos').text(videos);
    $('#settings_media_dlna_update').text(lastupdate);
    if (lastupdate != dictionaryList['_unknown']) {
        $('#settings_media_dlna_last_update_string').show();
        localizeTimeStamp('#settings_media_dlna_update');
    }
    else {
        $('#settings_media_dlna_last_update_string').hide();
    }

    $('#dlnaMediaDB_count').show();

    if(gMediaServerEnable == 'false'){
        //$('#settings_dlna_database_container').hide();
    }
    else if(data.scan_in_progress == 'true'){
        //$('#settings_dlna_database_container').show();

        showDLNAProgressMsg();
        if (rescanDLNA) {
            setTimeout('checkDLNARescanStatus();', DLNAPoll); 
        }
    }
    else{
        hideDLNAProgressMsg();
    }
}

function settingsDLNAPollSuccess(data) {
    if (data != null && data.media_server_database != null){
        updateDLNAInfo(data.media_server_database, false);
    }
}

function settingsMediaPollError() {
    // do nothing
}

function settingsMediacrawlerPollSuccess(data) {
	if (data != null && data.mediacrawler_status != null && data.mediacrawler_status.volumes != null){
        getMediaCrawlerStatus(data);

        $("#settings_media_crawler_videos").text(gMediaCountTotal["videos"]);
        $("#settings_media_crawler_music_tracks").text(gMediaCountTotal["music"]);
        $("#settings_media_crawler_pictures").text(gMediaCountTotal["photos"]);
        $("#settings_media_crawler_others").text(gMediaCountTotal["other"]);

        $("#mediaCrawler_MediaDB_activity").text( gMediaCrawlerScanningStateMsg );

        if (gMediaCrawlerScanningState == 'building' || gMediaCrawlerScanningState == 'scanning') {
            disableIdTag('#mediaCrawler_mediadb_rebuild_button');
            setTimeout('checkMediacrawlerRebuildStatus();', DLNAPoll); 
        }
        else {
            enableIdTag('#mediaCrawler_mediadb_rebuild_button');
        }
	}
}

function doMediacrawlerRebuild() {

    displayLoading();
    disableIdTag('#mediaCrawler_mediadb_rebuild_button');

    $.ajaxAPI({
        "url": "mediacrawler",
        "timeout": ajaxTimeout,
        "type": "put",
        "data": {'allshare': 'true'},
        "success": function(data, status, XMLHttpRequest) {
            checkMediacrawlerRebuildStatus();
            hideLoading();
        },
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'put_mediacrawler', request.status);
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });
}

function checkMediacrawlerRebuildStatus(){
    if (checkMediacrawlerRebuildInProgress === true) {
        return;
    }
    // only poll if on Media page
    if (!$('#media_crawler_content').is(':visible')){
        return;
    }

    checkMediacrawlerRebuildInProgress = true;
    $.ajaxAPI({
        "url": 'mediacrawler_status',
        "type": "GET",
        "success": function(data){
			if (data != null && data.mediacrawler_status != null && data.mediacrawler_status.volumes != null){
                settingsMediacrawlerPollSuccess(data);

                if (gMediaCrawlerScanningState == 'building' || gMediaCrawlerScanningState == 'scanning') {
                    setTimeout('checkMediacrawlerRebuildStatus();', DLNAPoll); 
                }
			}
        },
        "complete": function (jqXHR, textStatus) {
            checkMediacrawlerRebuildInProgress = false;
        }
    });
}

