<div id="reboot_confirmation" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_REBOOT')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
			<p>
			<?php echo _('LABEL_DESCR_REBOOT_DEVICE_AVATAR');?>
			</p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="reboot_confirmation_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="reboot_confirmation_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
