<div id="error_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_ERROR'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
            <div id="error_dialog_message">
                <ul id="error_dialog_message_list"></ul>
            </div>
            <div id="unknown_ids_message">
                <ul id="unknown_ids_message_list"></ul>
            </div>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="error_dialog_close_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
