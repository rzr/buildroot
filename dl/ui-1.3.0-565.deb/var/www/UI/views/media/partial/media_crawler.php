<div id="settings_mediacrawler_database_container">
    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_STRING_MEDIA')?></label>
        <span id="mediaCrawler_MediaDB_count">
            <?php echo _('LABEL_DESCR_MEDIA_SERVING_VIDEOS')?>:&nbsp;<span id="settings_media_crawler_videos"></span>&nbsp;&nbsp;&nbsp;
            <?php echo _('CONTENT_HOME_DIALOG_LABEL_MUSIC')?>:&nbsp;<span id="settings_media_crawler_music_tracks"></span>&nbsp;&nbsp;&nbsp;
            <?php echo _('LABEL_DESCR_MEDIA_SERVING_PHOTOS')?>:&nbsp;<span id="settings_media_crawler_pictures"></span>&nbsp;&nbsp;&nbsp;
            <?php echo _('CONTENT_HOME_DIALOG_LABEL_OTHER')?>:&nbsp;<span id="settings_media_crawler_others"></span>
        </span>
    </div>

    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_SCAN_ACTIVITY')?></label>
        <span id="mediaCrawler_MediaDB_activity"><?php echo _('CONTENT_HOME_STRING_IDLE')?></span>
    </div>

    <div class="content_row">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_MEDIA_DATABASE");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_MEDIA_TOOLTIP_DLNA_DATABASE");?></div></div></div></label>
        <span id="mediaCrawler_mediadb_button_container">
            <button id="mediaCrawler_mediadb_rebuild_button"><?php echo _('BUTTON_REBUILD')?></button>
        </span>
    </div>

</div>