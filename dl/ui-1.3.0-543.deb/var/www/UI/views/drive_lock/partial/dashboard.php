<div id="dashboard_drive_lock_box" class="dashboard_medium_box dashboard_box">
	<div class="header"><h3><?php echo _('CONTENT_SETTINGS_STRING_DRIVE_LOCKED')?></h3></div>
    <div id="dashboard_drive_lock_indicator" class="dashboard_count"></div>
</div>