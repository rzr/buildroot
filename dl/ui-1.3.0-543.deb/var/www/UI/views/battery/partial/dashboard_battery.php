<div class="dashboard_box dashboard_medium_box" id="dashboard_battery">
    <div class="header">
        <h3><?php echo _('CONTENT_HOME_SMALL_BOX_TITLE_BATTTERY')?></h3>
    </div>
    <div id="dashboard_battery_information_available_container">
        <div id="dashboard_battery_information_available_image" class="battery_80 charging">
            <span></span>
        </div>
        <div id="dashboard_battery_information_available_text_cont">
            <div id="dashboard_battery_information_available_text" style="display:none">
                <div class="charge_value"></div>
                <div class="charge_txt">
                    <span class="icn">%</span>
                    <span class="txt"><?php echo _('CONTENT_HOME_SMALL_BOX_STRING_CHARGE')?></span>
                </div>
            </div>
        </div>
    </div>
</div>