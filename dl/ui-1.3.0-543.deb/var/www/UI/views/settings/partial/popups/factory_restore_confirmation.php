<div id="factory_restore_confirmation_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_FACTORY_RESTORE')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content dialog_content_length_factory_restore">
            <div id="system_only_factory_restore_desc" class="factory_restore_desc"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_SYSTEM_ONLY_FACTORY_RESTORE_DESC')?></div>
            <div id="quick_factory_restore_desc" class="factory_restore_desc"><?php echo _('CONTENT_SETTINGS_FACTORY_RESTORE_TOOLTIP_SYSTEM_AND_DISK')?></div>
            <!--<div id="full_factory_restore_desc" class="factory_restore_desc"><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_FULL_FACTORY_RESTORE_DESC')?></div>-->
            <br />
			<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_FACTORY_RESTORE_CONFIRMATION')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="factory_restore_confirmation_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="factory_restore_confirmation_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
