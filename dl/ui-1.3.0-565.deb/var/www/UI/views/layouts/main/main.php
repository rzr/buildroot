<?php
    include_once('lib/firmware.php');
    $firmware = new Firmware();
    $firmwareVersion = $firmware->getFirmware();

    if (file_exists("./ui_version.txt")) {
        $UIVersion = trim(file_get_contents('ui_version.txt'));
    }
    else {
        $UIVersion = $firmwareVersion;
    }

?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" charset="utf-8">
        <?php echo "SITE_BASE_URL = \"".SITE_BASE_URL."\";\n"; ?>
        <?php echo "VERSION = \"".$firmwareVersion."\";\n"; ?>
        <?php echo "UI = \"".$UIVersion."\";\n"; ?>
    </script>
    <link href="img/mypassportwireless.ico" type="image/x-icon" rel="icon" />
    <!--[if lt IE 9]>
	<script src="js/html5.js?v=<?php echo $UIVersion ?>"></script>
	<![endif]-->
	<?php
	if (DEBUG_MODE === true):?>
    <link href="css/main.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/notifications.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />    
     <link href="css/dashboard.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/media.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/jquery/jquery-ui-1.8.18.custom.css" rel="stylesheet" type="text/css" />
    <link href="css/jquery/ui.progressbar.css" rel="stylesheet" type="text/css" />
    <link href="css/jquery/jquery.jqplot.min.css" rel="stylesheet" type="text/css" />
    <link href="css/wizard.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/settings.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/eula.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/authentication.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/language_styles/language_style_<?php echo LANGUAGE_STR ?>.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <?php $view->LoadStyles()?>
    <link href="css/wifi.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" /><?php if (isset($_GET['light']) && $_GET['light'] == 'true'):?>
    <?php
    endif;
    else:?>
    <link href="css/jquery/aggregate.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/aggregate.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <link href="css/language_styles/aggregate_<?php echo LANGUAGE_STR ?>.css?v=<?php echo $UIVersion ?>" rel="stylesheet" type="text/css" />
    <?php endif?>
</head>

<body>

    <noscript><div id="noscript"><h1><?php echo _('LABEL_DESCR_PLEASE_ENABLE_JAVASCRIPT')?></h1></div></noscript>
    <div id="cookies_message" align="center"><h1><?php echo _('LABEL_DESCR_PLEASE_ENABLE_COOKIES')?></h1></div>
    <!--[if lt IE 8]>
	<div id="ie7_message" align="center"><h1><?php echo _('LABEL_DESCR_IE7_NOT_SUPPORTED')?></h1></div>
	<![endif]-->
	<div id="fullpage_container">

        <header id="main_header_container">
        	<div id="main_header">
    		    <div id="header_left" class="branding_logo">

                </div>
                <div id="header_toolbar">
                    <?php $view->LoadHead();?>
    		    </div>
    		</div>
    	</header>

        <div id="page">
        	<div id="container">
            	<div id="content">
                    <?php //include("partial/navigation.php");?>
                    <?php $view->LoadNavigation();?>
            		<div id="main_content">
                		<?php $view->LoadViews();?>
                    </div>
                </div>
            </div>
        </div>

        <div id="loading"><?php echo _('LABEL_DESCR_LOADER_UPDATING')?></div>

        <div id="acknowledgement_down">
            <div id="acknowledgement_down_message">
            <ul></ul>
            </div>
                <div id="acknowledgement_down_controls">
                <button id="acknowledgement_down_controls_ok"><?php echo _('BUTTON_OK')?></button>
            </div>
        </div>

        <div id="splash">
            <div id="splash_header"></div>
                <div id="splash_content">
                    <div id="product_image" class="splash_city"></div>
                    <h1><?php echo _('CONTENT_SPLASH_STRING_ACCESSING_AVATAR')?></h1>
                </div>
            <div id="splash_footer"></div>
        </div>
        <div id="splash_back"></div>

        <div id="loading_back"></div>

<!--         <div style="clear:both"></div>
        <div id="footer"></div> -->

    </div>
    <script src="js/dictionary.php?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <?php
	if (DEBUG_MODE === true):?>
    <script src="js/jquery/jquery-1.7.2.min.js" type="text/javascript"></script>
    <script src="js/jquery/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.dropshadow.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.timers.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.checkbox.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.ui.selectmenu.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.touchwipe.min.js" type="text/javascript"></script>
    <script src="js/jquery/ajaxupload.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.actual.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.wizard.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.base64.min.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.jqplot.min.js" type="text/javascript"></script>
    <script src="js/jquery/jqplot.donutRenderer.min.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.ui.touch-punch.js" type="text/javascript"></script>
    <!--[if lt IE 9]><script src="js/jquery/excanvas.min.js" type="text/javascript"></script><![endif]-->
    <script src="js/jquery/jquery.tinysort.min.js" type="text/javascript"></script>
    <script src="js/lib/ajax.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/ajaxQueue.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/authentication.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/form.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/nav.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/utilities.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/polling.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/share_access.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/lib/dialog.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/eula.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/authentication.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/alerts.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/ObjTree.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/dashboard.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/nav.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/global.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/dashboard_storage.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/dashboard_wifi.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/dashboard_battery.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/power.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/errors.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/media.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/settings.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/settings_utilities.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/network.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/network_validation.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/updates.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/storage.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/validate.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/shares.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/home.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/help.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/cookies.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/battery.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/connected_devices.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/wireless.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <!--<script src="js/wifi.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>-->
    <script src="js/sdcard.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/admin_user.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/drive_lock.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/ssh.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/support.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <?php $view->LoadScripts()?>
    <script src="js/modernizr.js?v=<?php echo $UIVersion ?>"></script>
    <script src="js/iecompat.js?v=<?php echo $UIVersion ?>"></script>
    <script src="js/ui_initialization.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <script src="js/jquery/locale/date-<?php echo LANGUAGE_STR ?>.js" type="text/javascript"></script>
    <script src="js/jquery/jquery.timezone.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <?php else:?>
    <script src="js/aggregate.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <!--[if lt IE 9]><script src="js/jquery/excanvas.min.js" type="text/javascript"></script><![endif]-->
    <script src="js/jquery/locale/date-<?php echo LANGUAGE_STR ?>.js" type="text/javascript"></script>
    <script src="js/jquery/aggregate-timezone.js?v=<?php echo $UIVersion ?>" type="text/javascript"></script>
    <?php endif?>
</body>
</html>