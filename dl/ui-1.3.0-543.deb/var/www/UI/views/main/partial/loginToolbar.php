<div id="logout_toolbar" class="toolbar_item">
    <div class="toolbar_button_container">
        <button id="logout_link"><?php echo _('GLOB_NAV_LINK_LOGOUT_AVATAR')?></button>
    </div>
</div>
