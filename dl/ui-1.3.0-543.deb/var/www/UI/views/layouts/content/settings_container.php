<div id="<?php echo $identifier?>_container">
	<div id="settings_<?php echo $identifier?>">
		<div id="<?php echo $identifier?>_body">
		    <?php $view->LoadContents();$view->LoadViews();?>
        </div>
	</div>
</div>