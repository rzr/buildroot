<div id="product_improvement_dialog" title="<?php echo _('CONTENT_DIALOG_HELP_HEAD2_PRODUCT_IMPROVEMENT_PROGRAM'); ?>">
    <form method="PUT" id="product_improvement_dialog_form" action="privacy_options">
        <input type="hidden" name="send_serial_number" value="true"/>
    </form>
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_DIALOG_HELP_DESC_PRODUCT_IMPROVEMENT_PROGRAM')?></p>
            <ul>
                <li><?php echo _('CONTENT_DIALOG_HELP_STRING_PRODUCT_IMPROVEMENT_PROGRAM_DESC1')?></li>
                <li><?php echo _('CONTENT_DIALOG_HELP_STRING_PRODUCT_IMPROVEMENT_PROGRAM_DESC2')?></li>
                <li><?php echo _('CONTENT_DIALOG_HELP_STRING_PRODUCT_IMPROVEMENT_PROGRAM_DESC4')?></li>
            </ul>
            <br />
            <span id="product_improvement_dialog_participate"><?php echo _('CONTENT_DIALOG_ALERTS_STRING_WOULD_YOU_LIKE_TO_PARTICIPATE')?></span>
        </div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="product_improvement_dialog_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="product_improvement_dialog_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_YES_PARTICIPATE')?></button>
        <button type="button" id="product_improvement_dialog_close_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_CLOSE')?></button>
	</div>
</div>
