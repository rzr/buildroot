
$(document).ready(function(){
	$('#settings_drive_lock_form').restForm({
	    'useStubs': false,	     
        'refreshDataCallback' : function(data) {
            if (data.device_security.locked.toLowerCase() == 'true') {
                $('#settings_drive_lock_form').find('#DriveLockToggle').attr('checked', true);
                $('#DriveLockValue').val('true');
            }                   
            else {
                $('#settings_drive_lock_form').find('#DriveLockToggle').attr('checked', false);
                $('#DriveLockValue').val('false');
            } 
        }
    });
	
    $('#DriveLockToggle').live('toggle', function (e) {
        
    	if ($(this).is(':checked')) {
    		$('#DriveLockValue').val('true');           
        }
        else {
            $('#DriveLockValue').val('false');
        }
        $('#settings_drive_lock_form').submit();
    });
});

