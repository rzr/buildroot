<div id="create_shortcut_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_CREATE_A_SHORTCUT'); ?>">
	<div class="mochi_dialog_content_container">
		<div class="create_shortcut_dialog_content">
			<?php echo _('GLOB_NAV_DIALOG_STRING_CREATE_A_SHORTCUT_1')?>
			<p><?php echo _('GLOB_NAV_DIALOG_STRING_CREATE_A_SHORTCUT_2')?></p>
            <div id="shortcut_dialog_icon"></div>    
        </div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="create_shortcut_dialog_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
        <button type="button" id="create_shortcut_dialog_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE_SHORTCUT')?></button>
	</div>
</div>

