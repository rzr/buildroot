/**

 * 
 */
var currentIndex = 0;
var mainNavRightInterval;
var mainNavLeftInterval;
var settingsNavRightInterval;
var settingsNavLeftInterval;

$(document).ready(function () {
    $('#nav_dashboard_link').navItem({
        'contentId': 'dashboard_container',
        'refreshDataCall': function(){
        	//$('#nav_dashboard_link').navItem('_refreshData');

        	//$('#nav_settings').hide();
        	pollingHandler.poll();
        	dashboardHandler.updateAll();
        	/*$.updateDashboardHandler({
            	updateOnInit: true,
            	updateFinishCallback: function(){
            		hideLoading();
            	}
            });*/
        }
    });
    $('#nav_users_link').navItemListNavigationContent({
        'contentId': 'users_container',
        'listId': 'users_list',
        'listDataKey': 'users',
        'listDataId': 'user',
        'itemIdentifier': 'username',
        'navigationListId': 'users_list_navigation',
        'refreshDataSuccess': function (data) {
            var data2 = jQuery.extend(true, {}, data);
            $('#nav_users_link').navItemListNavigationContent("_refreshDataSuccess", data2, true);
            $('#users_list').ferrisWheelNav({
            	'nav_container_cls': 'listNavigation',
            	'nav_cls': 'leftmenu',
            	'nav_ul_cls': 'listNavigation'
            });

            /*
            if ($('#users_list_navigation .listNavigation .selected').length > 0){
                var dataKey = $('#users_list_navigation .listNavigation .selected span.listnavigation_item_name').text();
                var item = null;
                for (var i in data["users"]["user"]){
		    		if (data["users"]["user"][i]["username"] == dataKey){
		    			item = data["users"]["user"][i];
		    			break;
		    		}
		    	}
				if (item != null){
					$('#users_list_navigation').listNavigation("showItem",item);
				}
			}
			else{
				var first = null;
                var listData = $('#users_list').data('users');
				for (var i in listData['user']) {
					if (listData['user'].hasOwnProperty(i) && typeof(i) !== 'function') {
						first = listData['user'][i];
						break;
					}
				}
				if (first != null){
					$('#users_list_navigation').listNavigation("showItem",first);
				}
            }
    		*/
        }
    });

    $('#nav_shares_link').navItemListNavigationContent({
        'contentId': 'shares_container',
        'listId': 'shares_list',
        'listDataKey': 'shares',
        'listDataId': 'share',
        'itemIdentifier': 'share_name',
        'navigationListId': 'shares_list_navigation',
        'refreshDataSuccess': function (data) {
            $('#nav_shares_link').navItemListNavigationContent("_refreshDataSuccess", data, true);
            $('#shares_list').ferrisWheelNav({
            	'nav_container_cls': 'listNavigation',
            	'nav_cls': 'leftmenu',
            	'nav_ul_cls': 'listNavigation'
            });
        }
    });

    $('#nav_safepoints_link').navItemListNavigationContent({
        'useStubs': false,
        'contentId': 'safepoints_container',
        'listId': 'safepoints_list',
        'listDataKey': 'safepoints',
        'listDataId': 'safepoint',
        'itemIdentifier': 'handle',
        'navigationListId': 'safepoints_list_navigation',
        'displayLoadingCallback':function(){
            displayWaitingForSafepointData();
            
            // initially stop the safepoint process in progress polling, start it later
            //pollingHandler.stop("safepoint_getlist?option=inprogress");
        },
        'refreshDataSuccess': function(data){
            noSafepoints = false;
            if ('safepoints' in data.safepoint_getlist){
                if (data.safepoint_getlist.safepoints.safepoint == undefined) { 
                        noSafepoints = true;  
                }
                else if (data.safepoint_getlist.safepoints.length == 1 &&
                data.safepoint_getlist.safepoints.safepoint.name == undefined){
                        noSafepoints = true;                  
                }
            }
            else if ('status_code' in data.safepoint_getlist){
                noSafepoints = true;              
            }
            displaySafepointListDataLoaded();

        	$('#nav_safepoints_link').navItemListNavigationContent("_refreshDataSuccess", data.safepoint_getlist, false);
            
            // start the safepoint in progress polling on this page in a given amount of time
           // setTimeout("pollingHandler.poll();", 30000);
        },
        'addToListCall': function (item) {
           $('#safepoints_list_navigation').listNavigation("addToList", item['handle'], false, item['name']);
           updateSafepointListElementForm(item);
        }

    });
    
    /*$('#nav_settings_link').navItem({
        'contentId': 'settings_container',
        'refreshDataCall': function(){
        	//$('#device_content').multiRestForm("refreshForms");
            refreshSettingsGeneralForms();
            pollingHandler.poll();
        }
    });*/

    $('#settings_nav_utilities_link').navItem({
        'contentId': 'utilities_container'
    });
    $('#settings_nav_web_access_link').navItem({
        'contentId': 'web_access_container'
    });
    $('#nav_remoteaccess_link').navItemListNavigationContent({
        'contentId': 'remoteaccess_container',
        'listId': 'remoteaccess_list',
        'listDataKey': 'users',
        'listDataId': 'user',
        'itemIdentifier': 'username',
        'navigationListId': 'remoteaccess_list_navigation',
        'refreshDataSuccess': function (data) {
            var data2 = jQuery.extend(true, {}, data);
            $('#nav_remoteaccess_link').navItemListNavigationContent("_refreshDataSuccess", data2, false);
            $('#remoteaccess_list').ferrisWheelNav({
            	'nav_container_cls': 'listNavigation',
            	'nav_cls': 'leftmenu',
            	'nav_ul_cls': 'listNavigation'
            });

            var i;
            if ($('#remoteaccess_list_navigation .listNavigation .selected').length > 0){
                var dataKey = $('#remoteaccess_list_navigation .listNavigation .selected span.listnavigation_item_name').text();
                var item = null;
                for (i in data2["users"]["user"]){
		    		if (data2["users"]["user"][i]["username"] == dataKey){
		    			item = data2["users"]["user"][i];
		    			break;
		    		}
		    	}
				if (item != null){
					$('#remoteaccess_list_navigation').listNavigation("showItem",item);
				}
			}
			else{
				var first = null;
                var listData = $('#remoteaccess_list').data('users');
				for (i in listData['user']) {
					if (listData['user'].hasOwnProperty(i) && typeof(i) !== 'function') {
						first = listData['user'][i];
						break;
					}
				}
                /*
				if (first != null){
					$('#remoteaccess_list_navigation').listNavigation("showItem",first);
				}
                */
            }

            $('#remote_access_status_form').restForm("refreshForm");
        }
    });

    $('#settings_nav_storage_link').navItem({
        'contentId': 'storage_container'
    });

});