<div id="set_ntp_dialog" title="<?php echo _("CONTENT_SETTINGS_DIALOG_TITLE_NTP_SETTINGS");?>" class="mochi_dialog_container">
	<form id="update_ntp_form" method="PUT" action="date_time_configuration">
		<div class="mochi_dialog_content_container">
			<div class="mochi_dialog_content">
				<p><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_NTP_SERVICE_INTRO");?></p>
				<br />

				<div class="edit_container_box">

					<p><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_CURRENT_NTP_SERVERS");?></p>

					<div>

						<ul class="ntp_server_list">

							<li class="ntp_server_list_item" id="ntpsrv_user_entry_section" style="display: none;">
                                <span class="ntp_icon"></span>
                                <span class="ntp_server_name">
                                    <input type="text" id="update_ntp_form_ntpsrv_user" class="NTP_SERVER NOTEMPTY" name="ntpsrv_user_entry" value="" /> 
                                </span>
                                <span id="update_ntp_form_ntpsrv_user_desc" class="ntp_server_description"><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_USER_DEFINED_NTP_SERVER");?></span> 
                                <a href="#" id="delete_ntpsrv_user"></a>
                            </li>

							<li class="ntp_server_list_item">
                                <span class="ntp_icon"></span>
                                <span id="update_ntp_form_ntpsrv0" class="ntp_server_name"></span>
                                <span id="update_ntp_form_ntpsrv0_desc" class="ntp_server_description"><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_MICROSOFT_NTP_SERVICE");?></span>
                            </li>

							<li class="ntp_server_list_item">
                                <span class="ntp_icon"></span>
                                <span id="update_ntp_form_ntpsrv1" class="ntp_server_name"></span>
                                <span id="update_ntp_form_ntpsrv1_desc" class="ntp_server_description"><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_NTP_POOL_SERVICE");?></span>
                            </li>

						</ul>

						<div id="create_user_ntp_btn_section" style="display: none;">
							<button id="create_user_ntp_btn" class="save" type="button"><?php echo _("CONTENT_SETTINGS_DIALOG_BUTTON_ADD_USER_NTP");?></button>
						</div>

					</div>
				</div>
			</div>
		</div>
		<div class="dialog_form_controls">
			<button type="button" id="update_ntp_form_cancel_button"><?php echo _('BUTTON_CANCEL')?></button>
			<button type="button" id="update_ntp_form_save_button"  class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
		</div>
	</form>
</div>
