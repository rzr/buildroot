var automaticImport = false;
var jobPollInProgress = false;
var jobInProgress = false;
var jobCompletedFlag = false;
var jobID = null;

$(document).ready(function(){
	$('#sdcard_automatic_transfer_form').restForm({
		'useStubs': false,
		'beforeProcessForm': function(){
			if (!$('#sdcard_automatic_transfer_switch').is(':checked')){
				$('#scard_auto_transfer_field').val('true');
			}else{
				$('#scard_auto_transfer_field').val('false');
			}
		},
		'refreshDataCallback':function(data){
			//reset form and close it
			if (data.storage_transfer.auto_transfer == 'true') {
				$('#sdcard_automatic_transfer_switch').attr('checked', true);
				automaticImport = true;
            }else{
            	$('#sdcard_automatic_transfer_switch').attr('checked', false);
				automaticImport = false;
            }
		},
		'processFormSuccessCallback':function(data){
			//reset form and close it
			if ($('#sdcard_automatic_transfer_switch').is(':checked')) {
				automaticImport = true;
            }else{
				automaticImport = false;
            }
			showHideImportNowButton();
		}
	});
	$('#sdcard_after_transfer_form').restForm({
		'useStubs': false,
		'refreshDataCallback':function(data){
			//reset form and close it
			if (data.storage_transfer.transfer_mode == 'copy') {
            	$('#settings_sdcard_transfer_copy_mode_button').addClass('button-selected');
            	$('#settings_sdcard_transfer_move_mode_button').removeClass('button-selected');
				$('#copy_move_now_button').val(dictionaryList['copy_now']);
            }else{
            	$('#settings_sdcard_transfer_move_mode_button').addClass('button-selected');
            	$('#settings_sdcard_transfer_copy_mode_button').removeClass('button-selected');
				$('#copy_move_now_button').val(dictionaryList['move_now']);
            }
		},
		'processFormSuccessCallback':function(data){
			//reset form and close it
			if ($('#settings_sdcard_transfer_mode').val() == 'copy') {
				$('#settings_sdcard_transfer_copy_mode_button').addClass('button-selected');
            	$('#settings_sdcard_transfer_move_mode_button').removeClass('button-selected');
				$('#copy_move_now_button').val(dictionaryList['copy_now']);
            }else{
            	$('#settings_sdcard_transfer_move_mode_button').addClass('button-selected');
            	$('#settings_sdcard_transfer_copy_mode_button').removeClass('button-selected');
				$('#copy_move_now_button').val(dictionaryList['move_now']);
            }
		}
		
	});
	$('#settings_sdcard_transfer_copy_mode_button').click(function(){
		$('#settings_sdcard_transfer_mode').val('copy');
		$('#sdcard_after_transfer_form').submit();		
	});
	$('#settings_sdcard_transfer_move_mode_button').click(function(){
		$('#settings_sdcard_transfer_mode').val('move');
		$('#sdcard_after_transfer_form').submit();
	});
	$('#sdcard_transfer_now').restForm({
		'useStubs': false,
		//'timeout': 0,	// 0 for infinite
		'processFormSuccessCallback':function(data, textStatus, jqXHR){
			if (data != null && data.storage_active_transfer != null && data.storage_active_transfer.job_id != null) {
				jobID = data.storage_active_transfer.job_id;
				setTimeout("checkSDCardTransferStarted();", 1000);
			}
		},
		'processFormErrorCallback': function (request, status, error) {
			hideLoading();
			$('#copy_move_now_button').removeClass('ui-state-disabled');
			$('#sdcard_transfer_now').restForm('processFormError', request, status, error);
		},
		'hideProcessingCallback': function () {
			// don't hide until checkSDCardTransferStarted completes OR unless error
        }
	});
	$('#sdcard_automatic_transfer_switch').click(function(){
		$('#sdcard_automatic_transfer_form').submit();
	});

	$('#sdcard_transfer_progress_form').restForm({
        'useStubs': false,
		'beforeProcessForm': function(){
			jobPollInProgress = true;
			if (jobID != null) {
				$('#sdcard_transfer_progress_form').attr('action', $('#sdcard_transfer_progress_default_form').attr('action')+'/'+jobID);
			}
			else {
				$('#sdcard_transfer_progress_form').attr('action', $('#sdcard_transfer_progress_default_form').attr('action'));
			}
		},
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
        },
		'setDefaultFormDataCallback': function (data) {
			 if (data != null && data.jobs != null) {
				if( Object.prototype.toString.call( data.jobs.job ) != '[object Array]' ){  // only 1 device_user
					data.jobs.job = $.makeArray(data.jobs.job);
				}

				if (jobInProgress) {
					// expect only 1 job returned
					for(var i in data.jobs.job){
						var status = data.jobs.job[i].status.toLowerCase();

						if (status == 'running' || status == 'waiting') {
							updateSDCardTransferProgress(data.jobs.job[i]);
							if ($('#sd_card_media_transfer').is(':visible')){
								setTimeout("checkSDCardTransferProgress();", 5000);
							}
						}
						else if ((status == 'completed') && (!jobCompletedFlag)) {
							jobCompletedFlag = true;

							var complete_work = 0;
							if (data.jobs.job[i].complete_work != null && data.jobs.job[i].complete_work != '') {
								complete_work = parseInt(data.jobs.job[i].complete_work);
							}
							var msg = dictionaryList["successful_import_x_bytes"].replace('{0}', ByteSize(complete_work));
							$('#sdcard_transfer_progressbar_completed_result').text(msg);

							$('#sdcard_transfer_completed_container').show();
							$('#sdcard_transfer_inprogress_container').hide();

							if ($('#sd_card_media_transfer').is(':visible')){
								setTimeout("checkSDCardTransferProgress();", 10000);	// display Completed for 10 seconds
							}
						}
						else {
							$('#sdcard_transfer_in_progress_container').hide();
							jobInProgress = false;
							jobCompletedFlag = false;
							jobID = null;
							if (status == 'failed') {
								showSDCardTransferFailed(data.jobs.job[i]);
							}
							showHideImportNowButton();
						}
					}
				}
				else {
					var last_complete_time = 0;
					var complete_time = 0;
	
					for(var i in data.jobs.job){
						var status = data.jobs.job[i].status.toLowerCase();

						// found a job running
						if (status == 'running' || status == 'waiting') {
							jobID = data.jobs.job[i].job_id;
						}
						else {
							if (data.jobs.job[i].complete_time != null && data.jobs.job[i].complete_time != '') {
								complete_time = parseInt(data.jobs.job[i].complete_time);
							}
							if (complete_time > last_complete_time) {
								last_complete_time = complete_time;
							}
						}
					}
	
					// if no job in progress, display last complete time
					if (jobID == null) {
						$('#sdcard_transfer_in_progress_container').hide();
						if (last_complete_time != 0) {
							$('#last_import_timestamp_container').show();
	
							var timestamp = getTimeStamp(last_complete_time);
							$('#last_import_date_value').text(timestamp);
							$('#last_import_time_value').text(timestamp);
	
							localizeTimeStamp('#last_import_date_value', 'd');
							localizeTimeStamp('#last_import_time_value', 't');
						}
						else {
							$('#last_import_timestamp_container').hide();
						}
					}
					// if job in progress, show progress container
					else {
						jobInProgress = true;
						$('#sdcard_transfer_in_progress_container').show();

						updateSDCardTransferProgress(data.jobs.job[i]);
						if ($('#sd_card_media_transfer').is(':visible')){
							setTimeout("checkSDCardTransferProgress();", 5000);
						}
					}
					showHideImportNowButton();
				}
			}
		},
		'processFormCompleteCallback': function(jqXHR, textStatus){
			jobPollInProgress = false;
            $('#sdcard_transfer_progress_form').restForm('processFormComplete', jqXHR, textStatus);
        }
    });

	$("#importing_sdcard_content_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width:530,
        minHeight:240,
        dialogClass:'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#importing_sdcard_content_dialog').attr('title')+'</div>'
    });
	$('#importing_sdcard_content_dialog_ok_button').click(function () { 
		$("#importing_sdcard_content_dialog").dialog("close");
	});

	var sd_card_location = dictionaryList['sd_card_location'].replace('{0}', '<b><i>SD Card Imports</i></b>');
	$('#sdcard_transfer_location').html(sd_card_location.replace());

});

function checkSDCardTransferProgress() {
	if (jobPollInProgress) {
		return;
	}
	$('#sdcard_transfer_progress_form').submit();
}

function checkSDCardTransferStarted() {
	var status;
	$.ajaxAPI({
		"url": 'jobs'+'/'+jobID,
		"success": function(data){
		    if (data != null && data.jobs != null) {

			    if( Object.prototype.toString.call( data.jobs.job ) != '[object Array]' ){  // only 1 device_user
					data.jobs.job = $.makeArray(data.jobs.job);
				}

				for(var i in data.jobs.job){
					status = data.jobs.job[i].status.toLowerCase();
					if (status == 'running') {
						jobInProgress = true;
						$("#importing_sdcard_content_dialog").dialog("open"); 
						setTimeout("checkSDCardTransferProgress();", 1000);
					}
					else if (status == 'waiting') {
						setTimeout("checkSDCardTransferStarted();", 1000);
					}
					else if (status == 'completed') {
						jobID = null;
						showHideImportNowButton();
					}
					else if (status == 'failed') {
						jobID = null;
						showSDCardTransferFailed(data.jobs.job[i]);
						showHideImportNowButton();
					}
					return;
				}
			}
		},
		"complete": function (jqXHR, textStatus) {
			if (status != 'waiting') {
				hideLoading();
				$('#copy_move_now_button').removeClass('ui-state-disabled');
			}
		}
	});
}

function showSDCardTransferFailed(data) {
	if (data.error_code != null && data.error_code != '') {
		showError('get_jobs_'+ data.error_code);
	}
	else if (data.error_message != null && data.error_message != '') {
		showError('', data.error_message);
	}
	else {
		showError('get_jobs_unk');
	}
}

function initSDCardTransferProgress() {
	jobID = null;
	jobInProgress = false;
	jobCompletedFlag = false;
	$('#sdcard_transfer_in_progress_container').hide();
	$('#sdcard_transfer_now_button_container').hide();

    $("#sdcard_transfer_progressbar").progressbar({value: 0});

	var progressTxt = dictionaryList['importing_x_of_y'].replace('{0}', '0');
	progressTxt = progressTxt.replace('{1}', '0');
	$("#sdcard_transfer_progress").html(progressTxt);
	//$("#sdcard_transfer_progressbar_percentage").html('(0%)');
		
	checkSDCardTransferProgress();
}

function updateSDCardTransferProgress(data) {
	$('#sdcard_transfer_now_button_container').hide();
	$('#sdcard_transfer_in_progress_container').show();

	$('#sdcard_transfer_completed_container').hide();
	$('#sdcard_transfer_inprogress_container').show();

	var complete_work = 0;
	var total_work = 0;
	var progressPercent = 0;

	if (data.complete_work != null && data.complete_work != '') {
		complete_work = parseInt(data.complete_work);
	}
	if (data.total_work != null && data.total_work != '') {
		total_work = parseInt(data.total_work);
	}

	if (total_work > 0) {
		progressPercent = Math.round(complete_work / total_work * 100);
	}
    $("#sdcard_transfer_progressbar").progressbar('value', progressPercent);

	var progressTxt = dictionaryList['importing_x_of_y'].replace('{0}', ByteSize(complete_work));
	progressTxt = progressTxt.replace('{1}', ByteSize(total_work));
	$("#sdcard_transfer_progress").html(progressTxt);
	//$("#sdcard_transfer_progressbar_percentage").html('('+progressPercent+'%)');
}

function showHideImportNowButton() {
	if (automaticImport == false && jobInProgress == false) {
		$('#sdcard_transfer_now_button_container').show();
	}
	else {
		$('#sdcard_transfer_now_button_container').hide();
	}
}
