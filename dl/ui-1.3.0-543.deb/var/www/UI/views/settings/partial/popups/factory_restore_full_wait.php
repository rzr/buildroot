<div id="factory_restore_full_wait_dialog" title="<?php echo _('LABEL_DESCR_FULL_FACTORY_RESTORE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
			<div>
                <table>
                    <tr>
                        <td><span class="spinnerSunIcon"></span></td>
                        <td><?php echo _('CONTENT_SETTINGS_STRING_FACTORY_RESTORE_IN_PROGRESS'); ?></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <br />

                            <div id="factory_restore_progressbar_container">
                                <div class="factory_restore_progressbar generic_progressbar"></div>
                                <div class="format_restore_progressbar_percentage"></div>
                            </div>
                            <div id="factory_restore_progressbar_elapsed_time_container">
                                <span><?php echo _('CONTENT_SETTINGS_STRING_ELAPSED_TIME'); ?></span>:&nbsp;<span id="factory_restore_elapsed_time"></span>
                            </div>
                        </td>
                    </tr>
                </table>
			</div>
        </div>
    </div>
    
</div>