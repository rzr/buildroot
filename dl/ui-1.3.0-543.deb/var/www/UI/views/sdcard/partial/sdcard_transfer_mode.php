<div id="sd_card_transfer" class="content_row">
	<form id="sdcard_after_transfer_form" method="PUT" action="storage_transfer">
		<label><?php echo _('CONTENT_SETTINGS_LABEL_AFTER_TRANSFER')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("TOOLTIP_SETTINGS_SD_CARD_AFTER_TRANSFER");?></div></div></div></label>
        <button type="button" id="settings_sdcard_transfer_copy_mode_button" class="left-button"><?php echo _('BUTTON_LEAVE_ORIGINAL')?></button><button type="button" id="settings_sdcard_transfer_move_mode_button" class="right-button"><?php echo _('BUTTON_DELETE_ORIGINAL')?></button>
	    <input type="hidden" id="settings_sdcard_transfer_mode" name="transfer_mode" value=""/>
    </form>
</div>
