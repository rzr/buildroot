<div class="content_row">				
	<form id="network_ftp_form" method="PUT" action="network_services_configuration">
		<label><?php echo _('LABEL_FTP_ACCESS')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_NETWORK_TOOLTIP_FTP')?></div></div></div></label>
		<input type="hidden" id="network_enable_ftp_value" name="enable_ftp" value="true"/>
		<input type="checkbox" id="SettingNetworkFtpToggle" class="onoffswitch"/>
	</form>
</div> 								

