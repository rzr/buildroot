<?php
$lang = LANGUAGE_3CHAR;

$productDoc = 'http://products.wd.com/?id=wdfmycloud&type=um';
$faq = 'http://products.wdc.com/?id=wdfmycloud&amp;type=faq&amp;language='.$lang;
$forum = 'http://products.wdc.com/?id=wdfmycloud&amp;type=forum';
$contacts = 'http://products.wdc.com/?id=wdfmycloud&amp;type=contact';
?>

<div>
    <div><a href="<?php echo $productDoc?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_PRODUCT_DOCUMENTATION')?></a></div>
    <div><a href="<?php echo $faq?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_FAQS')?></a></div>
    <div><a href="<?php echo $forum?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_FORUM')?></a></div>
    <div><a href="<?php echo $contacts?>" target="_blank"><?php echo _('GLOB_NAV_HELP_LINK_CONTACTS')?></a></div>
</div>
