<?php
    // NOTE: deprecated; use the one in src/views/factory_restore directory
?>
<div class="content_row content_row_wrappable">

	<form id="factory_restore_form" style="display: inline-block" method="POST" action="system_factory_restore">
        <table>
            <tr>
                <td><label><?php echo _('CONTENT_SETTINGS_LABEL_FACTORY_RESTORE')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('AVATAR_CONTENT_SETTINGS_DIAGNOSTICS_TOOLTIP_FACTORY_RESTORE')?></div></div></div></label></td>
                <td class="settings_values_container">
                    <span class="extra_space_left"></span><button type="button" id="settings_factory_restore_quick_button"><?php echo _('CONTENT_SETTINGS_BUTTON_QUICK_RESTORE')?></button>
                    <span class="extra_space_left"></span><button type="button" id="settings_factory_restore_full_button"><?php echo _('CONTENT_SETTINGS_BUTTON_FULL_RESTORE')?></button>
                
                    <input id="FactoryRestoreValue" type="hidden" name="erase" value="format" />
                </td>
            </tr>
        </table>
	</form>

	<form id="factory_restore_progress_form" method="GET" action="system_factory_restore"></form>
</div>