<?php
    include(realpath(dirname(__FILE__))."/../../../views/common/wifi_security_modes.php");
?>

<div class="edit_container_box">
    <h2>
        <span class="network_mode mode_direct_connection"><?php echo _('CONTENT_SETTINGS_HEAD2_CONNECTION_STATUS')?> <?php echo _('CONTENT_SETTINGS_TITLE_DIRECT_CONNECTION')?></span>
        <span class="network_mode mode_trusted_network"><?php echo _('CONTENT_SETTINGS_HEAD2_CONNECTION_STATUS')?> <?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></span>
        <span class="network_mode mode_network_hotspot"><?php echo _('CONTENT_SETTINGS_HEAD2_CONNECTION_STATUS')?> <?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></span>
        <span class="network_mode setup_network"><?php echo _('BUTTON_SETUP_CONNECTION')?>: <?php echo _('CONTENT_SETTINGS_TITLE_SETTING_UP')?></span>

        <!--
        <span class="network_mode_help">
            <?php echo _('CONTENT_GENERIC_BUMPER_TITLE_HELP_TOPICS')?><br />
            <a href="#" id="link_help_direct_connection"><?php echo _('CONTENT_SETTINGS_TITLE_DIRECT_CONNECTION')?></a><br />
            <a href="#" id="link_help_home_network"><?php echo _('CONTENT_SETTINGS_TITLE_HOME_NETWORK')?></a><br />
            <a href="#" id="link_help_hotspot"><?php echo _('CONTENT_SETTINGS_TITLE_NETWORK_HOTSPOT')?></a>
        </span>
        -->
    </h2>

    <div class="content_row">
        
        <span class="wifi_buttons wifi_access_point_setting_up_buttons">
            <button id="wifi_access_point_setup_connection"><?php echo _('BUTTON_SETUP_CONNECTION')?></button><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_TOOLTIP_SETUP_CONNECTION");?></div></div></div>
        </span>

        <span class="wifi_buttons wifi_access_point_profile_list_buttons">
            <span class="network_button_spacer"></span>
            <button id="wifi_ap_profile_list_btn"><?php echo _('BUTTON_REMOVE_CONNECTIONS')?></button><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_TOOLTIP_REMOVE_CONNECTIONS");?></div></div></div>
        </span>

        <span class="wifi_buttons wifi_access_point_cancel_buttons">
            <button id="wifi_setup_connection_cancel_btn"><?php echo _('BUTTON_CANCEL')?></button>
        </span>

        <form id="wifi_access_point_default_form" action="current_wifi_client_connection"></form>
        <form id="wifi_access_point_forget_default_form" action="wifi_client_access_points"></form>

        <form method="PUT" id="wifi_access_point_forget_network_form" action="wifi_client_access_points">
            <input type="hidden" name="remember_network" value="false"/>
        </form>
    </div>

</div>
