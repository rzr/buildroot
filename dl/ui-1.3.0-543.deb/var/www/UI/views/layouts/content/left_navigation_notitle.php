<div id="<?php echo $identifier?>_container">
    <div class="content_full_container">
        <?php $view->LoadNavigation();?>    
        <div id="<?php echo $identifier?>_content" class="content_container">
        	<?php $view->LoadViews(); $view->LoadContents();?>
    	</div>
	</div>
</div>