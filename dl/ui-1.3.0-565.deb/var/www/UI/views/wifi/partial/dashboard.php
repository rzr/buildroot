<div id="dashboard_wifi_box" class="dashboard_medium_box dashboard_box">
	<div class="header">
        <h3><?php echo _('NAV_WIFI')?></h3>
    </div>
    <div class="connection_diagram">
        <span class="me_text overflow_hidden_nowrap_ellipsis"></span>
        <span class="connection_text overflow_hidden_nowrap_ellipsis"></span>
        <span class="device_text overflow_hidden_nowrap_ellipsis"></span>
    </div>
</div>