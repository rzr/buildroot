var smartTestCanceled = false;
var pingInProgress = false;
var pingInterval = 10000; // 10 seconds
var previous_reboot_state = '';
var switching_to_quick = false;
var factoryRestoreType = '';
var factoryRestoreInProgress = false;
var startPingDelay = 10000; // 10 seconds

var rebootTimeOutMax =      600000; // 10 minutes
var rebootTimeOutLongMax = 1200000; // 20 minutes
var rebootStartTimeStamp = 0;
var rebootTimeout = rebootTimeOutMax;
var rebootInitHere = false;

var factoryRestoreStartTime = 0;
var factoryRestoreProgressCount = 0;
var factoryRestorePollInterval = 10000; // 10 seconds

var smartTestPollInProgress = false;

//var pingFactoryRestoreInProgress = false;

var rebootReconnectTime = 120000; // 2 minutes

$(document).ready(function(){
    
// #########################################################
//                nav Items 
// #########################################################    
    $('#settings_nav_diagnostics').navItem({
	    'containerId': 'settings_content',
	    'contentId': 'diagnostics_container',
	    'selectedClass': 'selected',
	    'refreshDataCall': function(){
	    
	        
	        // default to quick restore for factory restore
//            $('#FactoryRestoreDropDown option[value=quick]').each(function(){
//			    $(this)[0].defaultSelected = true;
//			    $('#FactoryRestoreDropDown').selectmenu("value", $(this).val())
//		    });

            /* Legacy Sequoia
            if(gIsMobile) {
                $('#settings_system_configuration_export_button').attr('disabled', true);
                $('#settings_system_configuration_export_button').addClass('ui-state-disabled');
                $('#settings_system_configuration_import_button').attr('disabled', true);
                $('#settings_system_configuration_import_button').addClass('ui-state-disabled');
            } 
            */ 

	        //$('#diagnostics_tests_form').restForm("refreshForm");

	        //$('#factory_restore_form').restForm("refreshForm");

        }
        
    }); 
       
// #########################################################
//                forms 
// #########################################################
	
	$('#diagnostics_tests_form').restForm({
	     'useStubs': false,
	     'onOffCheckboxOptions': {
            checkedLabel: 'Short',
            uncheckedLabel: 'Full'
        },   
        'hideProcessingCallback': function () {                     
            // hide processing overlay if the smart test is not being canceled
            if ($('#diagnostics_tests_form').find('#SettingDiagnosticsTestsValue').val() != 'stop') {
            	$('#diagnostics_tests_form').restForm('_hideProcessing', false, true);
            }
        },     
        'beforeProcessForm' : function(){
            
            // if the user is not trying to cancel the smart test then identify the type of test to start
            if (!smartTestCanceled) {

                smartTestCanceled = false;
                showSmartTestProgress(true);
            }            
        },
        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
            
            // if there is a smart test in progress, process the data
            if (data.smart_test.status.toLowerCase() == 'inprogress') {                
		         showSmartTestProgress();
            }
            // else set the quick test (checked value) to the default value and set the corresponding text
            else
            {
                $('#diagnostic_test_in_progress').css('display', 'none');
                $('#diagnostic_test_not_in_progress').css('display', 'block');
                $("#settings_diagnostic_test_short_button").removeClass("button-selected");
                $("#settings_diagnostic_test_long_button").removeClass("button-selected");

                // SLEE - workaround to enable the Quick Test and Full Test button if disabled after a Cancel
                enableIdTag("#settings_diagnostic_test_short_button");
                enableIdTag("#settings_diagnostic_test_long_button");
                enableIdTag("#SettingDiagnosticsTestsValue");
               
              //  $('#full_smart_test_text').css('display', 'none');
              //  $('#quick_smart_test_text').css('display', 'inline-block');
            }  
        }

	});
	
	$('#diagnostic_test_progress_form').restForm({
        'useStubs': false,
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
             
        },
        'setDefaultFormDataCallback': function (data) {

            if (data.smart_test.status.toLowerCase() != 'inprogress') {

                finishSmartTest(data);
            }
            else {
                progressPercent = parseFloat(data.smart_test.percent_complete);
                $("#diagnostics_tests_progressbar").progressbar('value', progressPercent);
                $("#diagnostics_tests_progressbar_percentage").html(progressPercent+'%');
                setTimeout("processSmartTest();", 5000);                        
            }  
        },
        'beforeProcessForm': function(){
            smartTestPollInProgress = true;
        },
        'processFormCompleteCallback': function(jqXHR, textStatus){
			smartTestPollInProgress = false;
            $('#diagnostic_test_progress_form').restForm('processFormComplete', jqXHR, textStatus);
        }
    });
    
    
    // this form is used when the smart tests reports a status of bad. This form
    // is used to discover which drive is bad
    $('#diagnostic_test_results2_form').restForm({
        'useStubs': false,
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {            
        },
        'setDefaultFormDataCallback': function (data) {
          
            displaySmartTestBadDrive(data);
        },
        'beforeProcessForm': function(){
        }              
    });
    
	$('#factory_restore_form').restForm({
	     'useStubs' : false,
//	     'onOffCheckboxOptions': {
//            checkedLabel: 'Quick',
//            uncheckedLabel: 'Full'
//        },
        'beforeProcessForm' : function(){
            $('#factory_restore_form').find('#FactoryRestoreValue').val(factoryRestoreType);                    
            factoryRestoreStartTime = new Date().getTime();

            /* Full factory restore not supported
            if (factoryRestoreType == 'zero') {
                $("#factory_restore_full_wait_dialog").dialog('open');
                enableIdTag('#factory_restore_full_wait_switch');
                $('.factory_restore_progressbar').progressbar({value: 0});
                $('#factory_restore_progressbar_container').show();
                $('#factory_restore_progressbar_elapsed_time_container').hide();
            } 
            */ 
            //else { 
        	    $("#factory_restore_quick_wait_dialog").dialog('open');           
            //} 

            factoryRestoreProgressCount = 0;
            switching_to_quick = false;
            factoryRestoreInProgress = true;
        },
        'processFormSuccessCallback': function () {
            $('#factory_restore_form').restForm("processFormSuccess");

            resetGlobalVariables();

            stopPolling();
            
            /* Full factory restore not supported
            if (factoryRestoreType == 'zero') { // only poll for restore progress if performing full factory restore
                setTimeout("processFactoryRestore();", factoryRestorePollInterval);
            } 
            */ 
            //else {
                finishFactoryRestore();
            //} 
        },
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {                     
        },
        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
            
            /* Full factory restore not supported so no progress
            // if there is a factory restore in progress, process the data
            if (data.system_factory_restore.status.toLowerCase() == 'inprogress') {
                $("#factory_restore_full_wait_dialog").dialog('open');    
                enableIdTag('#factory_restore_full_wait_switch');        
                $('.factory_restore_progressbar').progressbar({value: 0});
                $('#factory_restore_progressbar_container').show();
                $('#factory_restore_progressbar_elapsed_time_container').hide();
                switching_to_quick = false;
                processFactoryRestore();            
            }
            */

        },
        'processFormErrorCallback': function(request, status, error) {
            factoryRestoreInProgress = false;
            $("#factory_restore_quick_wait_dialog").dialog('close');
            $("#settings_factory_restore_system_button").removeClass("button-selected");
            $("#settings_factory_restore_quick_button").removeClass("button-selected");
            $('#factory_restore_form').restForm('processFormError', request, status, error);
        }
	});
	
	
	$('#factory_restore_progress_form').restForm({
        'useStubs': false,
        'timeout': ajaxTimeoutPolling,
        
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
             
        },
        'setDefaultFormDataCallback': function (data) {
          
            if (switching_to_quick) {
                return;
            }

            var progressPercent = 0;
            if (data != null && data.system_factory_restore != null) {

                if (data.system_factory_restore.status.toLowerCase() == 'complete') {
                    factoryRestoreInProgress = false;
                    finishFactoryRestore();
                    return;
                }

                if (data.system_factory_restore.percent != '') {
                    progressPercent = parseInt(data.system_factory_restore.percent);
                }
            }

            $('.factory_restore_progressbar').progressbar('value', progressPercent);
            $('.format_restore_progressbar_percentage').text(progressPercent + '%');
            setTimeout("processFactoryRestore();", factoryRestorePollInterval);

        },
        'beforeProcessForm': function(){
            if (factoryRestoreStartTime == 0) {
                factoryRestoreStartTime = new Date().getTime();
            }
        },
        'processFormErrorCallback': function(request, status, error) {

            // workaround to device hanging resulting in aborts
            if (status == 'timeout' || status == 'error' || status == 'abort') {

                factoryRestoreProgressCount++;
                if (factoryRestoreProgressCount < 3) {
                    setTimeout("processFactoryRestore();", factoryRestorePollInterval);
                }
                /*
                else {
                    factoryRestoreProgressCount = 0;
                    $("#factory_restore_full_wait_dialog").dialog('close');
                    $('#factory_restore_progress_form').restForm('processFormError', request, status, error);
                }
                */
                else {
                    $('#factory_restore_progressbar_container').hide();
                    $('#factory_restore_progressbar_elapsed_time_container').show();
                    tickElapsedTime('#factory_restore_elapsed_time', factoryRestoreStartTime);
                    disableIdTag('#factory_restore_full_wait_switch');
                    factoryRestorePingServer();
                }
            }
            else {
                if (factoryRestoreInProgress) {
                    factoryRestoreInProgress = false;
                    finishFactoryRestore();
                }
            }
        }

    });
	
    /*
	$('#ssh_form').restForm({
	     'useStubs': false,	     
        'refreshDataCallback' : function(data) {
            if (data.ssh_configuration.enablessh.toLowerCase() == 'true') {

                $('#ssh_form').find('#SettingDiagnosticsSSHToggle').attr('checked', true);
                $('#SettingDiagnosticsSSHValue').val('true');
            }                   
            else
            {
                $('#ssh_form').find('#SettingDiagnosticsSSHToggle').attr('checked', false);
                $('#SettingDiagnosticsSSHValue').val('false');

            }  
        }

	});
    */
     
    $('#ping_device_form').restForm({
        'useStubs': false,
        'timeout': ajaxTimeoutPolling,
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
        },
        'processFormCompleteCallback': function(jqXHR, textStatus){
            pingInProgress = false;
        },
        'setDefaultFormDataCallback': function (data) {
            var status = data.system_state.status;
	        if ((status == "ready") &&
                ((previous_reboot_state == 'initializing') || (previous_reboot_state == 'rebooting')))
            {
                //disabledPolling = false;
                previous_reboot_state = '';
                window.location = redirectURL;
                return;
	        }
	        else if (status == "initializing") {

                previous_reboot_state = 'initializing';

                $('.device_rebooting_text').hide();
                $('.device_initializing_text').show();
	        }

            // avoid infinitely calling pingServer() by checking timeout
            var rebootCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((rebootCurrentTimeStamp - rebootStartTimeStamp) > rebootTimeout) {
                // if system is "ready", then just redirect
                if (status == "ready") {
                    previous_reboot_state = '';
                    window.location = redirectURL;
                }
                else {
                    showRebootTimeout();
                }
                return;
            }
	        setTimeout("pingServer();", pingInterval);
	    },
        'beforeProcessForm': function(){
        },
        'processFormErrorCallback': function(){
            previous_reboot_state = 'rebooting';    // error means the device is rebooting

            // avoid infinitely calling pingServer() by checking timeout
            var rebootCurrentTimeStamp = new Date().getTime(); // in milliseconds
	        if ((rebootCurrentTimeStamp - rebootStartTimeStamp) > rebootTimeout) {
                showRebootTimeout();
	            return;
	        }

            // display Reconnect Network message after elapsed timer
            if ((rebootCurrentTimeStamp - rebootStartTimeStamp) > rebootReconnectTime) {
                showRebootReconnectNetwork();
	        }

	        setTimeout("pingServer();", pingInterval);
        }              
    });

	$('#system_configuration_form').restForm();

// #########################################################
//                dialogs 
// #########################################################
    
    /*
    $("#factory_restore_full_wait_dialog").dialog({
        autoOpen: false,
        resizable: false,
        closeOnEscape:false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        modal: true,
        stack: false,
        dialogClass: 'mochi_dialog mochi_dialog_factory_restore',
        title: '<div class="wizard_dialog_title">'+$('#factory_restore_full_wait_dialog').attr('title')+'</div>'
    });
    
    $('#factory_restore_full_wait_switch').click(function(){
    	switchToQuickRestore();
    });
    */
    
    $("#factory_restore_quick_wait_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        modal: true,
        stack: false,
        dialogClass: 'mochi_dialog mochi_dialog_factory_restore',
        title: '<div class="wizard_dialog_title">'+$('#factory_restore_quick_wait_dialog').attr('title')+'</div>'
    });
    
    $("#reboot_dialog").dialog({
	    autoOpen: false,
	    resizable: false,
	    position: 'center',
	    width: dialogWidth,
	    minHeight: dialogMinHeight,
	    modal: true,
	    stack: true,
	    dialogClass: 'mochi_dialog mochi_dialog_info',
	    title: '<div class="wizard_dialog_title">'+$('#reboot_dialog').attr('title')+'</div>'
    });
    
    $("#factory_restore_confirmation_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: 600,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_factory_restore',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#factory_restore_confirmation_dialog').attr('title')+'</div>'
    });
    
    $('#factory_restore_confirmation_close_button').click(function(){
        //$("#settings_factory_restore_full_button").removeClass("button-selected");
        $("#settings_factory_restore_system_button").removeClass("button-selected");
        $("#settings_factory_restore_quick_button").removeClass("button-selected");
        $('#factory_restore_confirmation_dialog').dialog('close');
    });
    
    $('#factory_restore_confirmation_ok_button').click(function(){
        $('#factory_restore_confirmation_dialog').dialog('close');
        $('#factory_restore_form').submit();
    });
    
    $("#reboot_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_info',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#reboot_confirmation').attr('title')+'</div>'
    });
    
    $('#reboot_confirmation_close_button').click(function(){
    	$('#reboot_confirmation').dialog('close');
    });
    
    $('#reboot_confirmation_ok_button').click(function(){
        $('#reboot_confirmation').dialog('close');
        rebootInitHere = true;
        doReboot('generic');
    });
    
    $("#shutdown_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_info',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#shutdown_confirmation').attr('title')+'</div>'
    });
    
    $('#shutdown_confirmation_close_button').click(function(){
    	$('#shutdown_confirmation').dialog('close');
    });
    
    $('#shutdown_confirmation_ok_button').click(function(){
    	$('#shutdown_confirmation').dialog('close');
        doShutdown();
    });
    
    $("#shutting_down").dialog({
		autoOpen: false,
		resizable: false,
		position: 'center',
		width: dialogWidth,
		minHeight: dialogMinHeight,
		dialogClass:'mochi_dialog mochi_dialog_info',
		modal: true,
		stack: true,
		title: '<div class="wizard_dialog_title">'+$('#shutting_down').attr('title')+'</div>'
	});
    
    $('#shutting_down_close_button').click(function(){
    	$('#shutting_down').dialog('close');
    });
	
	$("#diagnostic_results").dialog({
			autoOpen: false,
			resizable: false,
			position: 'center',
			width: dialogWidth,
			minHeight: dialogMinHeight,
			dialogClass:'mochi_dialog mochi_dialog_info',
			modal: true,
			stack: true,
			title: '<div class="wizard_dialog_title">'+$('#diagnostic_results').attr('title')+'</div>'
		});
	
	$('#diagnostic_results_close_button').click(function(){
		$('#diagnostic_results').dialog('close');
	});

    /* Legacy Sequoia
	$("#confirm_import_config").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_info',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#confirm_import_config').attr('title')+'</div>'
	});
	
	$('#confirm_import_config_close_button').click(function(){
        $('#confirm_import_config').dialog('close');
    });
    
    $('#confirm_import_config_ok_button').click(function(){
		configFileUploader.submit();
		$('#confirm_import_config').dialog('close');
    }); 
    */ 

    /* Legacy Sequoia
	$("#upload_config_file").dialog({
		autoOpen: false,
		resizable: false,
		position: 'center',
		width: dialogWidth,
		minHeight: dialogMinHeight,
		modal: true,
		stack: true,
		dialogClass: 'mochi_dialog mochi_dialog_info',
		title: '<div class="wizard_dialog_title">'+$('#upload_config_file').attr('title')+'</div>' 
	});
    */

    $('#supportLink').live('click', function() {
        $('#diagnostic_results').dialog('close');
        //$("#help_support_link").click();
    });

});


// ###############################################################
//
//              functions
//
// ###############################################################
$(function(){
    
	$('#reboot_btn').live('click', function() { 
	    $('#reboot_confirmation').dialog('open');     
	});

	$('#shutdown_btn').live('click', function() { 
	    $('#shutdown_confirmation').dialog('open'); 
	});


	$('#settings_factory_restore_system_button').click(function () {
        $('#factory_restore_confirmation_dialog').dialog('option', 'title', '<div class="wizard_dialog_title">'+dictionaryList['system_only_factory_restore_title']+'</div>');
        $(".factory_restore_desc").hide();
        $("#system_only_factory_restore_desc").show();

        //$("#settings_factory_restore_full_button").removeClass("button-selected");
        $("#settings_factory_restore_quick_button").removeClass("button-selected");
        $(this).addClass("button-selected");  
        factoryRestoreType = "systemOnly";      
        $("#factory_restore_confirmation_dialog").dialog('open');            
    });
    
    $('#settings_factory_restore_quick_button').click(function () {	
        $('#factory_restore_confirmation_dialog').dialog('option', 'title', '<div class="wizard_dialog_title">'+dictionaryList['quick_factory_restore_title']+'</div>');
        $(".factory_restore_desc").hide();
        $("#quick_factory_restore_desc").show();

        //$("#settings_factory_restore_full_button").removeClass("button-selected");
        $("#settings_factory_restore_system_button").removeClass("button-selected");
        $(this).addClass("button-selected");        
        factoryRestoreType = "format";
        $("#factory_restore_confirmation_dialog").dialog('open');            

    });
    
    /* Full factory restore not supported
    $('#settings_factory_restore_full_button').click(function () {	
        $('#factory_restore_confirmation_dialog').dialog('option', 'title', '<div class="wizard_dialog_title">'+dictionaryList['full_factory_restore_title']+'</div>');
        $(".factory_restore_desc").hide();
        $("#full_factory_restore_desc").show();

        $("#settings_factory_restore_quick_button").removeClass("button-selected");
        $("#settings_factory_restore_system_button").removeClass("button-selected");
        $(this).addClass("button-selected");        
        factoryRestoreType = "zero";      
        $("#factory_restore_confirmation_dialog").dialog('open');            
    });
    */

	$('#cancel_diagnostics_tests_button').live('click', function () {

        $('#diagnostics_tests_form').find('#SettingDiagnosticsTestsValue').val('stop');
        smartTestCanceled = true;

        $('#diagnostics_tests_form').submit();
    });
 
    /*
    $('#SettingDiagnosticsTestsToggle').live('toggle', function (e) {
        if ($(this).is(':checked')) {
            //$('#full_smart_test_text').css('display', 'none');
           // $('#quick_smart_test_text').css('display', 'inline-block');
        }
        else {
          //  $('#full_smart_test_text').css('display', 'inline-block');
           // $('#quick_smart_test_text').css('display', 'none');
        }
    });
    */

    $('#settings_diagnostic_test_short_button').click(function () {	
        $("#settings_diagnostic_test_long_button").removeClass("button-selected");
        $(this).addClass("button-selected");        
        $('#diagnostics_tests_form').find('#SettingDiagnosticsTestsValue').val('start_short');
        $("#diagnostics_tests_form").submit();            
    });
    
    $('#settings_diagnostic_test_long_button').click(function () {	
        $("#settings_diagnostic_test_short_button").removeClass("button-selected");
        $(this).addClass("button-selected");        
        $('#diagnostics_tests_form').find('#SettingDiagnosticsTestsValue').val('start_long');        
        $("#diagnostics_tests_form").submit();            
    });
    
                   
     $('#SettingDiagnosticsSSHToggle').live('toggle', function (e) {
        if ($(this).is(':checked')) {
            $("#ssh_confirmation").dialog('open');
            return;            
        }
        else {
            $('#SettingDiagnosticsSSHValue').val('false');
        }
        $('#ssh_form').submit();
    });

    /* Legacy Sequoia
    $('#settings_system_configuration_export_button').click(function () {	

        var url = apiUrlPrefix + "system_configuration?attach_file=true";
        displayLoading();
        downloadInIframe(url);
    });
    */
    
    $('#view_resource').live('click', function() { 
        var resourcelink = $('#support_resources_select option:selected').val();
        window.open(resourcelink, "_target");
        return false;
    });

}); 
  
function showSmartTestProgress(startTest) {

    if (startTest) {
        $('#diagnostic_test_in_progress').css('display', 'block');
        $('#diagnostic_test_not_in_progress').css('display', 'none');
        $("#diagnostics_tests_progressbar").progressbar({value: 0});
        $("#diagnostics_tests_progressbar_percentage").html('0%');
    }
    
    setTimeout("processSmartTest();", 5000);
}

function processFactoryRestore() {
    $('#factory_restore_progress_form').submit();
}

function processSmartTest() {
    if (smartTestPollInProgress) {
        return;
    }
    $('#diagnostic_test_progress_form').submit();
}

function finishSmartTest(data) {

    $('#diagnostic_test_in_progress').css('display', 'none');
    $('#diagnostic_test_not_in_progress').css('display', 'block');
    $("#settings_diagnostic_test_short_button").removeClass("button-selected");
    $("#settings_diagnostic_test_long_button").removeClass("button-selected");
  
    $('#diagnostic_good').css('display', 'none');
    $('#diagnostic_not_complete').css('display', 'none');
    $('#diagnostic_aborted').css('display', 'none');
    $('#diagnostic_unknown').css('display', 'none');
    $('#diagnostic_bad').css('display', 'none');

    hideLoading();
    
    var status = data.smart_test.status.toLowerCase();

    // if the status is bad then get additional information to dispay and display it
    if (status == 'bad') {
        $('#diagnostic_test_results2_form').submit();
    }
    else {
    
        $('#diagnostic_' + status).css('display', 'block');
        $("#diagnostic_results").dialog('open');
    }
    smartTestCanceled = false;

    // SLEE - workaround to enable the Quick Test and Full Test button if disabled after a Cancel
    enableIdTag("#settings_diagnostic_test_short_button");
    enableIdTag("#settings_diagnostic_test_long_button");
    enableIdTag("#SettingDiagnosticsTestsValue");

}

//##################################################
//
// this will have to be refined and tested at integration time
//
//##################################################
function displaySmartTestBadDrive(data) {

    diagnostic_bad_msg = '';
    for (var idx = 0; idx < data.smart_test2.internal_drive.length; idx++) {
        if (data.smart_test2.internal_drive[idx].status == 'bad') {

            // MyBookLive (Apollo 3G) reports location as "UNDEFINED"
            if (data.smart_test2.internal_drive[idx].location == 'UNDEFINED') {
                diagnostic_bad_msg = dictionaryList['labeldrivetxt'];
            }
            else {
                if (diagnostic_bad_msg != '') {
                    diagnostic_bad_msg += ', ';
                }
                diagnostic_bad_msg += dictionaryList['labeldrivetxt'] + ' ' + data.smart_test2.internal_drive[idx].location;
            }
        }
    }
    diagnostic_bad_msg += ' ' + dictionaryList['labelfaileddiagtesttxt'];
    $('#diagnostic_bad_msg').html(diagnostic_bad_msg);
                        
    $('#diagnostic_bad').css('display', 'block');
    $("#diagnostic_results").dialog('open');
}
        
function finishFactoryRestore() {

	$("#factory_restore_quick_wait_dialog").dialog('close');
	//$("#factory_restore_full_wait_dialog").dialog('close');

    redirectAfterFactoryRestore();

    doReboot(factoryRestoreType);
}

/* Full factory restore not supported
function factoryRestorePingServer() {
    if(pingFactoryRestoreInProgress) {
        return;
    }
    pingFactoryRestoreInProgress = true;

    $.ajaxAPI({
        "url": "system_state",
        "timeout": ajaxTimeoutPolling,
        "error": function (request, status, error) {
            // avoid infinitely calling factoryRestorePingServer() by checking timeout
            var rebootCurrentTimeStamp = new Date().getTime(); // in milliseconds
	        if ((rebootCurrentTimeStamp - rebootStartTimeStamp) > rebootTimeout) {
                showRebootTimeout();
	            return;
	        }

	        setTimeout("factoryRestorePingServer();", pingInterval);
        },
        "success": function (data) {
            if (data != null && data.system_state != null) {
                if (data.system_state.status == 'initializing') {
                    $("#factory_restore_quick_wait_dialog").dialog('close');
                    //$("#factory_restore_full_wait_dialog").dialog('close');
                    redirectAfterFactoryRestore();
                    doReboot(factoryRestoreType);
                }
                else {
                    processFactoryRestore();
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            pingFactoryRestoreInProgress = false;
            //hideLoading();
        }
    });
}
*/

/* Legacy Sequoia
function switchToQuickRestore(){ 
	
	$("#factory_restore_quick_wait_dialog").dialog('close');
	$("#factory_restore_full_wait_dialog").dialog('close');
	
	redirectAfterFactoryRestore();
	
    switching_to_quick = true;
    rebootInitHere = true;

	doReboot('restore');
}
*/

//
// this function gets device status to see what state the device is in
//
function pingServer(){

    if(pingInProgress) {
        return;
    }
    pingInProgress = true;

    $('#ping_device_form').submit();
}

// set up the values for the reboot display
function setRebootValues(label_code) {

	$('.device_initializing_text').hide();
	$('.device_rebooting_text').show();
	$('.reboot_label').hide();
    $('#reboot_'+label_code).show();

	suppressErrors = true;
	dateStamp = new Date();
	rebootStartTimeStamp = dateStamp.getTime(); // in milliseconds
	previous_reboot_state = '';

    stopPolling();
}

// show the rebooting message
function showRebootTimeout() {
    $('#reconnect_network_dialog').dialog('close');
    suppressErrors = false;

    if (errorsList["avatar_reboot_no_return_orig"] == undefined) {
        errorsList["avatar_reboot_no_return_orig"] = errorsList["avatar_reboot_no_return"];
    }
    else {
        errorsList["avatar_reboot_no_return"] = errorsList["avatar_reboot_no_return_orig"];
    }

    var deviceNameURL = getDeviceNameURL(gDeviceName);
    var newmsg = errorsList["avatar_reboot_no_return"].replace('{0}','<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
    errorsList["avatar_reboot_no_return"] = newmsg;

    //gRedirect = true;
    showError('avatar_reboot_no_return');
    //window.location = redirectURL;
}

function showRebootReconnectNetwork() {
    if ($('#reconnect_network_dialog').dialog('isOpen') == false) {
        $('.device_initializing_text').hide();
        $('.device_rebooting_text').hide();
        $('#reboot_dialog').dialog('close');
    
        $('#reconnect_network_dialog').dialog('open');
    }
}

function disableLoader() {
	hideLoading();
}

function downloadInIframe(url){
	var downloadToken = Math.floor(Math.random()*1000);
    //url += downloadToken;
    createCookie("download_system_report_token", downloadToken);
	var iframe = '<iframe src="' + url +'" style="display:none;" />';
	$('body').append(iframe);
	fileDownloadCheckTimer = window.setInterval(function () {
		var cookieValue = readCookie('download_system_report_token');
		if (cookieValue == downloadToken){
			disableLoader();
			eraseCookie('download_system_report_token');
			window.clearInterval(fileDownloadCheckTimer);
		}
	}, 500);
}

/* Legacy Sequoia
function openUploadConfigFileWithTimeout(){

	clearTimeout(uploadConfigTimer);

	$("#upload_config_file").dialog('open');

	uploadConfigTimer = setTimeout(function(){
		if ($('#upload_config_file').dialog('isOpen')) {
			$('#upload_config_file').dialog('close');
			showError('config_file_timeout');
		}
	}, ajaxTimeoutLong);
}
*/

/* Legacy Sequoia
// Config File Upload
function init_configFileUpload(){

    var button = $("#settings_system_configuration_import_button");

    var url = apiUrlPrefix + "system_configuration?format=json";

    importUserCanceledOut = false;
    configFileUploader = new AjaxUpload(button, {
        action: url,
        name: 'file',
        responseType: 'json',
        autoSubmit: false,
        onSubmit: function(file, ext) {

            // if the user canceled out
            if (importUserCanceledOut) {
                importUserCanceledOut = false;
                return false;
            }
            var regex = /^(conf)$/i;
            if (!(ext && regex.test(ext))) {
                showError('invalid_config_file_type');
                return false;
            }
            openUploadConfigFileWithTimeout();
            this.disable();
            return true;
        },
        onChange: function(file, ext) {
            $("#confirm_import_config").dialog('open');
        },
        onComplete: function(file, response) {
            //alert(debug(response));
            this.enable();

            setTimeout(function(){
                $("#upload_config_file").dialog('close');
                if (response != null && response.system_configuration != null) {
    
                    if (response.system_configuration.status != null && response.system_configuration.status.toLowerCase() == "success") {
                        
                        if (response.system_configuration.status_code != null) {
    
                            if (response.system_configuration.status_code != 112) {
                                rebootInitHere = true;
                                doReboot(response.system_configuration.status_code);
                            }
                            else {
                                showError("post_system_configuration_"+response.system_configuration.status_code);
                            }
                        }
                        else {
                            // default is doReboot(110) which is "successful full restore) until we can proces the response code
                            rebootInitHere = true;
                            doReboot(110);
                        }
                    }
                    else if (response.system_configuration.status_code != null) {
                        // legacy API returns "status_code" only
                        if (response.system_configuration.status_code != 112) {
                            rebootInitHere = true;
                            doReboot(response.restore_status.status_code);
                        }
                        else {
                            showError("system_configuration "+response.system_configuration.status_code+" "+response.system_configuration.status_description);
                        }
                    }
                    else if (response.system_configuration.error_id != null) {
                        showError('post_system_configuration_'+response.system_configuration.error_id);
                    }
                    else if (response.system_configuration.error_code != null) {
                        showError('post_system_configuration_'+response.system_configuration.error_code);
                    }
                    else {
                        showError('post_system_configuration_error');
                    }
                }
                else {
                    // Legacy API doesn't return anything, we'll just assume it's successful
                    //SLEE - temporarily doReboot(110) which is "successful full restore) until we can proces the response code
                    rebootInitHere = true;
                    doReboot(110);
                }
            }, 5000);
        }
    });
    $("#settings_system_configuration_import_button").hover(
        function(){
            $(this).css('cursor','pointer !important');
        },
        function(){
            $(this).css('cursor','default');
        }
    );
}  
// End Config File Upload
*/

/*
function redirectAfterNetworkChangeReboot() {
    redirectAfterFactoryRestore();
}
*/

function redirectAfterFactoryRestore() {

    var DeviceUrl;
    switch (gModelNumber) {
        /*
        case 'sq': 
            DeviceUrl = 'http://WDMyCloud';
            break;
        case 'sqwifi': 
            DeviceUrl = 'http://WDMyCloudWiFi';
            break;
        case 'AP2NC':
            DeviceUrl = 'http://MyBookLiveDuo';
            break;
        case 'AP1NC':
            DeviceUrl = 'http://MyBookLive';
            break;
        */
        case 'AV1W':
        case 'WDBLJT':
        case 'WDBK8Z':
        case 'WDBDAF':
        default:
            DeviceUrl = 'http://MyPassport';
            break;
    }

	if (navigator.appVersion.indexOf("Mac") != -1) {
		redirectURL = DeviceUrl+'.local';
	} else {
		redirectURL = DeviceUrl;
	}
}

function getDeviceNameURL(deviceName) {
	if (navigator.appVersion.indexOf("Mac") != -1) {
		return 'http://'+deviceName+'.local';
	} else {
		return 'http://'+deviceName;
	}
}
 
function doReboot(label_code) {
    rebootStartTimeStamp = new Date().getTime(); // in milliseconds
    /*
    if ((label_code == 'restore') ||    // switch to quick restore
        (label_code == 'format') ||     // quick factory restore
        (label_code == 'systemOnly') || // system only factory restore
        (label_code == 'zero') ||       // full factory restore
        (label_code == 'safepoint'))    // safepoint restore
    {
        // factory restore and safepoint restore use longer reboot timeout
        rebootTimeout = rebootTimeOutLongMax;
    }
    else if ((label_code == 'update') || (label_code == '112')) {
        // firmware upgrade takes normal timeout (10 minutes) and reboot will always initiate from the server side
        rebootInitHere = false;
    }
    */
    $('.reboot_reconnect_msg').hide();
    switch (label_code) {
        case 'systemOnly':
        //case 'zero':
        case 'format':
            /* SLEE - OLD
            // factory restore use longer reboot timeout
            //rebootTimeout = rebootTimeOutLongMax;

            var reboot_msg = dictionaryList['reboot_reconnect_factory_restore_msg'].replace('{0}', '<b>'+dictionaryList['default_ssid']+'</b>');
            reboot_msg = reboot_msg.replace('{1}', '<a href="'+redirectURL+'">'+redirectURL+'</a>');

            $('#reboot_reconnect_factory_restore_msg').html(reboot_msg);
            $('#reboot_reconnect_factory_restore_msg').show()
            */
            break;
        case 'update':
            // firmware upgrade takes normal timeout (10 minutes) and reboot will always initiate from the server side
            rebootInitHere = false;
        case 'generic':
            /* SLEE - OLD
            if (gTrustedNetwork) {
                $('#reboot_message_separator').hide();
            }
            else {
                var reboot_msg = dictionaryList['reconnect_wireless_network_msg'].replace('{0}', '<b>'+gSSIDName+'</b>');
                reboot_msg = reboot_msg.replace('{1}', '<a href="'+redirectURL+'">'+redirectURL+'</a>');

                $('#reboot_reconnect_direct_connection_msg').html(reboot_msg);
                $('#reboot_reconnect_direct_connection_msg').show();
            }
            */
            break;
        default:
            break;
    }
    
    setRebootValues(label_code);

    // call reboot only if function requiring reboot was initiated on this browser?
    if (rebootInitHere == true) {

        displayLoading();
        $.ajaxAPI({
            "url": "shutdown",
            "type": "PUT",
            "data": {'state': 'reboot'},
            "timeout": ajaxTimeout,
            "error": function (request, status, error) {
                $('#reboot_dialog').dialog('open');
                suppressErrors = false;
                /* switch to quick factory restore not supported
                if (label_code == 'restore') {
                    processAndDisplayError(request.responseText, 'restore_put_shutdown_reboot', request.status);
                }
                */
                //else {
                    processAndDisplayError(request.responseText, 'put_shutdown_reboot', request.status);
                //}
                setTimeout("pingServer();", startPingDelay);
            },
            "success": function (data) {
                $('#reboot_dialog').dialog('open');
                stopPolling();
                setTimeout("pingServer();", startPingDelay);
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
            }
        });
        rebootInitHere = false;
    }
    else {
        $('#reboot_dialog').dialog('open');

        setTimeout("pingServer();", startPingDelay); 
    }
}

function doShutdown() {
    displayLoading();
    $.ajaxAPI({
        "url": "shutdown",
        "type": "PUT",
        "timeout": ajaxTimeout,
        "data": {'state': 'halt'},
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'put_shutdown_halt', request.status);
        },
        "success": function (data) {
            $('#shutting_down').dialog('open');
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });
}

/* Full factory restore not supported so no need to check if there is a restore in progress
function checkForFactoryRestore(useQueue) {

    var ajaxAPIOptions = {
        "url": 'system_factory_restore',
        "type": "GET",
        "timeout": ajaxTimeout,
        "success": function (data) {
            if ((data != null) && (data.system_factory_restore != null)) {

                // if there is a factory restore in progress, process the data
                if (data.system_factory_restore.status.toLowerCase() == 'inprogress') {

                    enableIdTag('#factory_restore_full_wait_switch');
                    $("#factory_restore_full_wait_dialog").dialog('open');           
                    $('.factory_restore_progressbar').progressbar({value: 0});
                    $('#factory_restore_progressbar_container').show();
                    $('#factory_restore_progressbar_elapsed_time_container').hide();
                    switching_to_quick = false;
                    processFactoryRestore();            
                }
            }
        }
    };
    if (typeof useQueue != 'undefined' && useQueue == true){
    	ajaxQueue.add(ajaxAPIOptions);
    }
    else{
    	$.ajaxAPI(ajaxAPIOptions);
    }
}
*/
