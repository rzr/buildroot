<form action="http://websupport.wdc.com/rn/nassupport.asp" method="post" target="_blank" id="quick_support_form">
    <input type="hidden" id="devlang" value="" name="devlang">
    <input type="hidden" id="devsn" value="" name="devsn">
    <input type="hidden" id="devmodel" value="" name="devmodel">
    <input type="hidden" id="devnastype" value="" name="devnastype">
    <input type="hidden" id="devfw" value="" name="devfw">
    <input type="hidden" id="devhash" value="" name="devhash">
</form>