<div id="config_dlna_dialog" title="<?php echo _("CONTENT_SETTINGS_DIALOG_TITLE_MEDIA_STREAMING_OPTIONS");?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
			<p><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_MEDIA_STREAMING_OPTIONS_INTRO");?></p>
			<br />

			<div class="edit_container_box">

				<p><?php echo _("CONTENT_SETTINGS_STRING_MEDIA_PLAYERS");?></p>

				<div id="config_dlna_dialog_media_players">

					<ul class="dlna_media_player_list">

						<li class="dlna_media_player_list_item" style="display: none;">
							<form id="dlna_media_player_list_item_form" method="PUT" action="media_server_connected_list">
                                <span class="dlna_media_player_icon"></span> 
                                <span class="dlna_media_player_name overflow_hidden_nowrap_ellipsis"></span> 
                                
                                <span class="dlna_media_player_ipaddress"></span>
								<!--<span class="dlna_media_player_block">Block</span>-->

                                <input class="dlna_media_player_mac_address" name="mac_address" value="" type="hidden">

                                <span class="dlna_media_player_toggle">
                                    <input id="dlna_media_player_toggle_template" class="onoffswitch" name="device_enable" value="true" type="checkbox">
                                </span>
							</form>
                        </li>

					</ul>

				</div>
			</div>
		</div>
	</div>

	<div class="dialog_form_controls">
		<button type="button" id="config_dlna_dialog_done_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>

</div>

