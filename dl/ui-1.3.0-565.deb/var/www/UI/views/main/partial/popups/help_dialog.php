<div id="help_dialog" title="<?php echo _('GLOB_NAV_HELP_LINK_HELP')?>" class="mochi_dialog_container">
	

	<div id="help_container">
   		<div id="help_getting_started" class="toggleLeftArrow up">
	    	<div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_GET_STARTED_DESC_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">	
				<ol>
					<li><?php echo _('HELP_GET_STARTED_DESC_LIST_ITEM1'); ?> <a href="#" class="help_load_content"><?php echo _('HELP_GET_STARTED_DESC_HOW_TO'); ?></a></li>
					<li><?php echo _('HELP_GET_STARTED_DESC_LIST_ITEM2_CONNECT_TO_INTERNET'); ?> <a href="#" class="help_connect_to_internet"><?php echo _('HELP_GET_STARTED_DESC_HOW_TO'); ?></a></li>
				</ol>
				<div id="help_getting_started_more_info"><?php echo _('HELP_GET_STARTED_DESC_MORE_INFO_LINE1'); ?></div>
			</div>
        </div>

 		<div id="help_load_content" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_LOAD_CONTENT_DESC_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<br>
				<div><?php echo _('HELP_LOAD_CONTENT_DESC_PROLOGUE'); ?> <?php echo _('HELP_GET_STARTED_DESC_SEE'); ?> <a href="#" class="help_first_connect_status"><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_HEADER'); ?></a></div>
				<br>
				<div><?php echo _('HELP_LOAD_CONTENT_DESC_COPY_FILES'); ?></div>
				<ol>
					<li><?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM1'); ?></li>
					<li>
						<?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM2'); ?>
						<ul>
							<li>
								<?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM2_SUB1_LINE1'); ?>
								<br>
								<?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM2_SUB1_LINE2'); ?>
							</li>
							<li>
								<?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM2_SUB2_LINE1'); ?>
								<br>
								<?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM2_SUB2_LINE2'); ?>
							</li>
						</ul>
					</li>
					<li><?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ITEM3'); ?></li>
				</ol>			
				<div><?php echo _('HELP_LOAD_CONTENT_DESC_LIST_ADDITIONAL_NOTE'); ?></div>
				<br>
				<div><?php echo _('HELP_LOAD_CONTENT_DESC_COPY_LOT_OF_FILES'); ?> <?php echo _('HELP_GET_STARTED_DESC_SEE'); ?> <a href="#" class="help_copy_with_usb"><?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_HEADER'); ?></a></div>
			</div>
        </div>
        
        <div id="help_first_connect_status" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<br>
				<div><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_PROLOGUE_LINE1'); ?></div>
				<br>
				<div><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_PROLOGUE_LINE2'); ?></div>
			
				<ul>
					<li id="help_first_connect_status_for_pc"><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_ITEM1'); ?></li>
					<li id="help_first_connect_status_for_mac"><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_ITEM2'); ?></li>				
				</ul>
				<div><?php echo _('HELP_FIRST_CONNECT_STATUS_DESC_NO_MEDIA'); ?> <?php echo _('HELP_GET_STARTED_DESC_SEE'); ?> <a href="#" class="help_load_content"><?php echo _('HELP_LOAD_CONTENT_DESC_HEADER'); ?></a></div>
			</div>
        </div>
        
        <div id="help_copy_with_usb" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<div> 
					<ol>
						<li>
							<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM1_LINE1'); ?>
							<br>
							<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM1_LINE2'); ?>
						</li>
						<li><?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM2'); ?></li>
						<li><?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM3'); ?>
							<ul>
								<li>
									<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM3_SUB1_LINE1'); ?>
									<br>
									<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM3_SUB1_LINE2'); ?>
								</li>
								<li>
									<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM3_SUB2_LINE1'); ?>
									<br>
									<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM3_SUB2_LINE2'); ?>
								</li>
							</ul>
						</li>
						<li>
							<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM4_LINE1'); ?>
							<br>
							<?php echo _('HELP_FIRST_COPY_WITH_USB_DESC_ITEM4_LINE2'); ?>
						</li>
					</ol>
				</div>
			</div>
        </div>
        
		<div id="help_get_led_meaning" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_GET_LED_MEANING_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<br>
				<div><?php echo _('HELP_GET_LED_MEANING_PROLOGUE'); ?></div>
				<br>
				<div><?php echo _('HELP_GET_LED_MEANING_TOP_LED'); ?></div>
				<br>
				<div>				
					<table class="help_led_table">
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLUE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLUE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_GREEN'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_GREEN_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_ORANGE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_ORANGE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_RED'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_RED_MEANING'); ?></td> 
						</tr>
						<!--
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_NO_LED'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_NO_LED_MEANING'); ?></td> 
						</tr>
						-->
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE'); ?></td>
						  <td>
						  	<?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_MEANING_PROLOGUE'); ?>
						  	<ul>
						  		<li>
						  			<?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_MEANING_STATE1'); ?>
						  			<br>
						  			<?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_MEANING_STATE1_LINE2'); ?>						  		
						  		</li>
						  		<li><?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_MEANING_STATE2'); ?></li>
						  		<li><?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_MEANING_STATE3'); ?></li>
						  	</ul>
						  </td> 
						</tr>
					</table>									
				</div>
				<br>
				<div><?php echo _('HELP_GET_LED_MEANING_SECOND_LED'); ?></div>
				<br>
				<div>				
					<table  class="help_led_table">
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SECOND_NO_LED'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SECOND_NO_LED_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_BLUE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_BLUE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_ORANGE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_ORANGE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_RED'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_RED_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_BLUE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_BLUE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_WHITE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_WHITE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_WHITE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SOLID_WHITE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_OFF_WITH_POWER_LED_BLINKING_WHITE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_OFF_WITH_POWER_LED_BLINKING_WHITE_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_WHITE'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_PULSE_WHITE_MEANING_STATE2'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_RED_WITH_RED'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_RED_WITH_RED_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_RED_ONE_LONG'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_BLINK_RED_ONE_LONG_MEANING'); ?></td> 
						</tr>
						<tr>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SECOND_NO_LED_AND_BLINK'); ?></td>
						  <td><?php echo _('HELP_GET_LED_MEANING_TABLE_SECOND_NO_LED_AND_BLINK_MEANING'); ?></td> 
						</tr>
					</table>											
				</div>				
			</div>
        </div>

        <div id="help_connect_to_internet" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_GET_CONNECT_TO_INTERNET'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<div>
					<ol>
						<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM1'); ?></li>
						<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM2'); ?></li>
						<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM3'); ?></li>
						<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM4'); ?>
							<ul>
								<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM4_SUB1'); ?></li>
								<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM4_SUB2'); ?></li>
								<li><?php echo _('HELP_GET_CONNECT_TO_INTERNET_ITEM4_SUB3'); ?></li>
							</ul>
						</li>
					</ol>
				</div>
			</div>
        </div>
        
        <div id="help_connect_with_usb" class="toggleLeftArrow up">
	        <div class="mochiLightTaskListHeader disclosureTitle">
				<div>
                    <div class="back_to_list">
                        <span class="back_to_list_text"><?php echo _('HELP_BACK_TO_LIST'); ?></span>
                        <span class="back_to_list_arrow"></span>
                    </div>
                    <?php echo _('HELP_GET_CONNECT_WITH_USB_HEADER'); ?>
                </div>
			</div>
			<div class="mochiLightTaskListBody disclosureContent">
				<br>
				<div>
					<?php echo _('HELP_GET_CONNECT_WITH_USB_PROLOGUE'); ?>
					<br>
					<?php echo _('HELP_GET_CONNECT_WITH_USB_TO_CONNECT'); ?>
					<ol>
						<li>
							<span><?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM1'); ?> </span><span><a href="#" class="help_get_led_meaning"><?php echo _('HELP_GET_LED_MEANING_HEADER'); ?></a></span>
							<br>
							<?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM1_NOTE'); ?>
						</li>
						<li><?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM2'); ?></li>
						<li><?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM3'); ?></li>
						<li><?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM4'); ?>
							<ul>
								<li>
									<?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM4_SUB1_LINE1'); ?>
									<br>
									<?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM4_SUB1_LINE2'); ?>
								</li>
								<li>
									<?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM4_SUB2_LINE1'); ?>
									<br>
									<?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM4_SUB2_LINE2'); ?>
								</li>
							</ul>
						</li>
						<li><?php echo _('HELP_GET_CONNECT_WITH_USB_ITEM5'); ?></li>						
					</ol>
					<div id="help_connect_with_usb_more_info"><?php echo _('HELP_GET_CONNECT_WITH_USB_GET_MORE_INFO'); ?></div>
				</div>
			</div>
        </div>                  
    </div>

	<div class="dialog_form_controls">
    	<button type="button" id="help_close_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>      


