<div id="<?php echo $identifier?>_container">    
    <div id="<?php echo $identifier?>_header" class="main_content_header">
        <h1><?php echo _($title)?></h1>
    </div>
    <div class="wifi_content_full_container">
        <div id="<?php echo $identifier?>_list_navigation">
            <?php $view->LoadContents(0)?>
            <div id="<?php echo $identifier?>_edit_container" class="edit_container">
                <?php $view->LoadContents(1)?>
            </div>
        </div>
        <?php $view->LoadViews()?>
    </div>
</div>