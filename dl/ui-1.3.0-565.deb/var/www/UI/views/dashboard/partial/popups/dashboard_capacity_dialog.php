<div id="dashboard_capacity_dialog" title="<?php echo _('CONTENT_HOME_DIALOG_TITLE_CAPACITY_USAGE')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_HOME_DIALOG_STRING_CAPACITY_USAGE_DESC')?></p>
            <div id="dashboard_usage_chart"></div>
		</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="dashboard_capacity_close_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>

</div>

