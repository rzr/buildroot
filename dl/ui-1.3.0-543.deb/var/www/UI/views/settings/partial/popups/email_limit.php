<div id="alert_email_limit_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_ALERT_EMAIL_LIMIT_MET')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
			<p><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_EMAIL_LIMIT')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="alert_email_limit_close_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>