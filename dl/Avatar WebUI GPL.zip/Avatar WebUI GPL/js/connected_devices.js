$(document).ready(function(){
	$("#dashboard_connected_devices_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_connected_devices',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#dashboard_connected_devices_dialog').attr('title')+'</div>'
  });
	
	$('#dashboard_devices_link').click(function(e){
        e.preventDefault();
        $("#dashboard_connected_devices_dialog").dialog("open");
    });
	
    $('#dashboard_connected_devices_close_button').click(function(){
        $('#dashboard_connected_devices_dialog').dialog('close');
    });

    $('#connected_devices_list_refresh').live('click', function() {
        if (!$(this).hasClass('ui-state-disabled') && !$(this).parent().hasClass('ui-state-disabled')) {
            updateConnectedDevices();
        }
    });

    $('.connected_device_delete').live('click', function() {
        if (!$(this).hasClass('ui-state-disabled')) {
            var mac_address = $(this).attr("rel");
            //var mac_address = $(this).parent().find('.connected_device_macaddress').text();
            $('#wifi_ap_client_delete_form').attr('action', $('#wifi_ap_client_default_form').attr('action')+'?mac_address='+mac_address);
            $('#wifi_ap_client_delete_form').submit();
        }
    });

    $('#wifi_ap_client_delete_form').restForm({
		'processFormSuccessCallback': function(){
            updateConnectedDevices(true);
		}
	});
    
});

function updateConnectedDevices(updateNetworkMode){
    if (updateNetworkMode == undefined) {
        updateDiagrams = false;
    }

    $('.connected_devices_item.default').siblings().remove();
    disableIdTag('#connected_devices_list_refresh');
    var connected_device_count = 0;
    var currentTime = new Date().getTime();

	$.ajaxAPI({
		"url": "wifi_ap_clients",
        "timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
			if (data != null && data.wifi_ap_clients != null && data.wifi_ap_clients.wifi_ap_client != null) {
                // only 1 ap client
				if( Object.prototype.toString.call( data.wifi_ap_clients.wifi_ap_client ) != '[object Array]' ){
					data.wifi_ap_clients.wifi_ap_client = $.makeArray(data.wifi_ap_clients.wifi_ap_client);
				}
                for(var i in data.wifi_ap_clients.wifi_ap_client){

                    if (data.wifi_ap_clients.wifi_ap_client[i].name == '' && data.wifi_ap_clients.wifi_ap_client[i].ip == '') {
                        return;
                    }

                    connected_device_count++;
                    var newItem = $('.connected_devices_item.default').clone();
                    newItem.removeClass('default');
                    newItem.find('.connected_device_delete').attr("rel", data.wifi_ap_clients.wifi_ap_client[i].mac);

                    if (data.wifi_ap_clients.wifi_ap_client[i].ip == gRemoteAddr) {
                        newItem.find('.connected_device_image').addClass('connected_device_me_image');
                        //newItem.find('.connected_device_delete').addClass("ui-state-disabled").attr('disabled', true);
                        newItem.find('.connected_device_delete').remove();
                        newItem.find('.connected_device_delete_container').find('.tooltip_inner_container').hide();
                        newItem.find('.wireless_label_text').text( dictionaryList['Me'] );
                        gFoundMe = true;
                    }
                    else if (data.wifi_ap_clients.wifi_ap_client[i].name != '') {
                        newItem.find('.wireless_label_text').text(data.wifi_ap_clients.wifi_ap_client[i].name);
                    }
                    else {
                        newItem.find('.wireless_label_text').text(data.wifi_ap_clients.wifi_ap_client[i].ip);
                    }

                    var connectionUpTime = ms2Time(currentTime - data.wifi_ap_clients.wifi_ap_client[i].connected_time * 1000); 

                    newItem.find('.connected_device_name').text(data.wifi_ap_clients.wifi_ap_client[i].name);
                    newItem.find('.connected_device_ipaddress').text(data.wifi_ap_clients.wifi_ap_client[i].ip);
                    newItem.find('.connected_device_macaddress').text(data.wifi_ap_clients.wifi_ap_client[i].mac);
                    newItem.find('.connected_device_uptime').text(connectionUpTime);

                	$('#connected_devices_list').append(newItem);
                }
			}
		},
        "error": function (request, status, error) {
        },
        "complete": function(){
            enableIdTag('#connected_devices_list_refresh');

            if (connected_device_count) {
                gConnectedDevices = true;
            }
            else {
                gConnectedDevices = false;
            }

            if (!gFoundMe) {
                updateConnectedDevicesWithMe();
            }

            if (updateNetworkMode) {
                checkCurrentWifiClientConnection();
            }

            $('.connected_devices_item').each(function (i) {
                if (i == 0) { return; }
                if (i % 2 === 0) {
                    $(this).addClass('alt_row_bg');
                }
            });
        }
	});
}

function updateConnectedDevicesWithMe(){

    if (gTrustedNetwork && gConnectedDevices) {
        return;
    }

    var newItem = $('.connected_devices_item.default').clone();
    newItem.removeClass('default');
    newItem.find('.connected_device_image').remove();
    newItem.find('.connected_device_delete_container').remove();
    newItem.find('.wireless_label_text').addClass('no_devices_found').text( dictionaryList['no_devices_found'] );

    var newLabel = newItem.find('.connected_device_label').clone();
    newItem.find('.connected_device_label_container').remove();
    newItem.append(newLabel);

	$('#connected_devices_list').append(newItem);
}

