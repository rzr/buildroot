
<div id="diagnostic_test_not_in_progress" style="display: block">
    <form id="diagnostics_tests_form" method="PUT" action="smart_test">
        <input type="hidden" id="SettingDiagnosticsTestsValue" name="test" value="start_short" />

	    <div class="content_row">
            <!--<label><?php echo _('CONTENT_SETTINGS_LABEL_DIAGNOSTICS_TEST')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_DIAGNOSTICS_TOOLTIP_DIAGNOSTICS_TEST')?></div></div></div></label>-->
			<button type="button" id="settings_diagnostic_test_short_button"><?php echo _('CONTENT_SETTINGS_BUTTON_QUICK_TEST')?></button>
            <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_DIAGNOSTICS_TOOLTIP_QUICK_DIAGNOSTICS_TEST')?></div></div></div>
        </div>

        <div class="content_row">
            <button type="button" id="settings_diagnostic_test_long_button"><?php echo _('CONTENT_SETTINGS_BUTTON_FULL_TEST')?></button>
            <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_DIAGNOSTICS_TOOLTIP_FULL_DIAGNOSTICS_TEST')?></div></div></div>
	    </div>

    </form>
</div>

<div id="diagnostic_test_in_progress" style="display: none">
	<div class="content_row">

		<label><?php echo _('CONTENT_SETTINGS_LABEL_TEST_IN_PROGRESS')?></label>
		<div id="diagnostics_tests_progressbar" style="display: inline-block;" class="generic_progressbar"></div>
        <span class="extra_space_left" id="diagnostics_tests_progressbar_percentage"></span>
		<span class="extra_space_left"></span><button id="cancel_diagnostics_tests_button"><?php echo _('BUTTON_CANCEL')?></button>

	</div>
	<form id="diagnostic_test_progress_form" method="GET" action="smart_test"></form>
	<form id="diagnostic_test_results2_form" method="GET" action="smart_test2"></form>
</div>

<form id="ping_device_form" method="GET" action="system_state"></form>

