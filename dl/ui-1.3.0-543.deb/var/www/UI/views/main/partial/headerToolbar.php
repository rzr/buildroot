<?php 
    $headerToolbars = array(100=>realpath(dirname(__FILE__))."/helperToolbar.php");
    $componentHeaderToolbars = $componentLoader->getToolbars('header');
    $headerToolbars = $headerToolbars + $componentHeaderToolbars;
    ksort($headerToolbars);
?>

<div id="header_toolbar">
<?php foreach($headerToolbars as $headerToolbar){
    include_once($headerToolbar);
}?>    
</div>