<span class="form_controls">
    <input type="submit" value="<?php echo _('BUTTON_SUBMIT')?>" />
    <input type="button" class="reset_form" value="<?php echo _('BUTTON_CANCEL')?>" />     
</span>