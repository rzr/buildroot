<div id="<?php echo $identifier?>_toolbar" class="toolbar_item">
    <div class="toolbar_button_container">
        <a href="#" id="<?php echo $identifier?>_nav_link" class="toolbar_button">
            <span class="icon"></span>
            <span class="down_arrow"></span>
        </a>
    </div>
    <div id="<?php echo $identifier?>_nav" class="toolbar_button_list_container">
    	<nav>
    		<ul>
    			<?php foreach($navigationItems as $navigationItemGroup):
    			    foreach($navigationItemGroup as $navigationItemList): 
    			        foreach($navigationItemList as $navigationItem):?>
    					<li class="help_topic_container"><a href="<?php echo $navigationItem->link?>" id="<?php echo $navigationItem->id?>"><?php echo _($navigationItem->title)?></a><div class="right_arrow"></div></li>
    				    <?php endforeach;
    				endforeach;
    			endforeach;?>
    		</ul>
    	</nav>
    </div>
</div>