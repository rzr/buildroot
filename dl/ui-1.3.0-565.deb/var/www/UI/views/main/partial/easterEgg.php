<div id="easter_egg_area" style="height:100px; overflow: auto; display: none;"></div>
