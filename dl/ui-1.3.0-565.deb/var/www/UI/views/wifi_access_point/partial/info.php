<div id="avatar_device_container" class="wifi_network_outer_box">
    <span class="wifi_box_title_button">
        <button id="wifi_network_settings_edit"><?php echo _('CONTENT_SETTINGS_LINK_EDIT')?></button>
        <button id="wifi_access_point_edit"><?php echo _('CONTENT_SETTINGS_LINK_EDIT')?></button>
    </span>
    <div class="content_row wifi_box_title overflow_hidden_nowrap_ellipsis"><?php echo _('AVATAR_PRODUCT_NAME')?></div>
    <div id="wifi_access_point_ssid_form_container" class="wifi_network_inner_box">
    	
        <div class="iconTooltip_container">
            <div class="tooltip_icon">
                <div id="wifi_access_point_image"></div>
            </div>
            <div id="avatar_icon_tooltip" class="tooltip_inner_container">
                <div class="tooltip">
                    <ul id="wifi_access_point_tooltip">
                	    <li><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?>: <span class="wifi_avatar_device_name"></span></li>
                	    <li><?php echo _('LABEL_HEADER_IP_ADDRESS')?>: <span class="wifi_avatar_device_ip_address"></span></li>
                        <li><?php echo _('LABEL_HEADER_NETMASK')?>: <span class="wifi_avatar_device_netmask"></span></li>
                        <li><?php echo _('LABEL_HEADER_GATEWAY')?>: <span class="wifi_avatar_device_gateway"></span></li>
                        <li><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_DNS')?>: <span class="wifi_avatar_device_dns"></span></li>
                    </ul>
                    <ul id="wifi_connected_tooltip">
                        <li><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_SSID')?>: <span class="wifi_avatar_ssid_name"></span></li>
                        <!--<li><?php echo _('GLOB_NAV_LOGIN_LABEL_SECURITY_TYPE')?>: <span class="wifi_avatar_security"></span></li>-->
                        <li><?php echo _('LABEL_HEADER_IP_ADDRESS')?>: <span class="wifi_avatar_ip_address"></span></li>
                    </ul>
                </div>
            </div>
        </div>

        <div id="wifi_avatar_access_point_name_container">
            <div id="wifi_access_point_name_container">
                <span id="wifi_access_point_name" class="overflow_hidden_nowrap_ellipsis"></span>
                <span id="wifi_access_point_ssid_lock"></span>
            </div>
            <div id="no_internet_access"><?php echo _('CONTENT_SETTINGS_NETWORK_STRING_NO_INTERNET_ACCESS')?></div>
        </div>
    </div>
</div>

