<div id="ssh_confirmation" title="<?php echo _('CONTENT_DIALOG_SETTINGS_SSH_TITLE_SSH_CONFIRMATION')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_SSH_MESSAGE')?></p>  
            <p>
                <label><?php echo _('LABEL_USER_NAME')?></label>
                <span>root</span>
            </p>
            <p>
                <label><?php echo _('LABEL_PASSWORD')?></label>
                <span>welc0me</span>
            </p>
            <form id="SettingsSshIAgreeToggle_form">
                <input type="checkbox" class="normal_checkbox" id="SettingsSshIAgreeToggle"/>
                <label class="ssh_checkbox_label" for="SettingsSshIAgreeToggle"><?php echo _('AVATAR_CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_SSH_I_ACCEPT')?></label>
            </form>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="ssh_confirmation_close_button"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="ssh_confirmation_ok_button" class="sshOkButton mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>