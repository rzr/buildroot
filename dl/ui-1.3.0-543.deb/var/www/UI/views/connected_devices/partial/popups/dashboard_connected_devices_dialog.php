<div id="dashboard_connected_devices_dialog" title="<?php echo _('CONTENT_SETTINGS_LABEL_CONNECTED_DEVICES')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">						
			<p><?php echo _('CONTENT_DIALOG_HELP_STRING_VIEW_DEVICES_CONNECTED')?></p>
			<div class="dashboard_connected_devices_list_container">
				<ul class="dashboard_connected_devices_list">
					<li class="dashboard_connected_devices_list_item connected_devices_iphone_icon"><span class="dashboard_connected_devices_item"><?php echo _('Mom\'s iPhone')?></span><span class="dashboard_connected_devices_time"><?php echo _('24 mins')?></span><a href="#" class="dashboard_connected_devices_kick"><?php echo _('Kick')?></a></li>
					<li class="dashboard_connected_devices_list_item connected_devices_ipad_icon"><span class="dashboard_connected_devices_item"><?php echo _('Charlie\'s iPad')?></span><span class="dashboard_connected_devices_time"><?php echo _('1.5 hours')?></span><a href="#" class="dashboard_connected_devices_kick"><?php echo _('Kick')?></a></li>
				</ul>
			</div>

		</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="dashboard_connected_devices_close_button" class="close mochi_dialog_save_button"><?php echo _("BUTTON_OK")?></button>
	</div>

</div>

