<div id="no_internet_access_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_INTERNET_ACCESS_REQUIRED')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
        <div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_SUPPORT_DIALOG_STRING_NO_INTERNET')?></p>
        </div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="no_internet_access_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="popup_blocked_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_POPUP_BLOCKER')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
        <div class="mochi_dialog_content">
            <p><?php echo _('CONTENT_SUPPORT_DIALOG_STRING_POPUP_BLOCKED')?></p>
        </div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="popup_blocked_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
