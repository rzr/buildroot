$(document).ready(function(){

    $('#eulaDeclineLink').live('click', function(){
       
        $("#eula_not_accepted").dialog('open');
       
    });
    
    $('#eula_go_back_button').live('click', function(){
        
        $("#eula_not_accepted").dialog('close');
       
    });

    $('#eula_exit_application_button').live('click', function(){
        
    	window.location = "http://wd.com";
       
    });

    $('#privacyPolicyLink').live('click', function(){
       
        $("#privacy_policy_overlay").dialog('open');
       
    });

    $('#privacy_policy_overlay_close').live('click', function(){

        $("#privacy_policy_overlay").dialog('close');

    });


//#########################################################
//dialogs 
//#########################################################

    $("#eula_not_accepted").dialog({
		autoOpen: false,
		resizable: false,
		position: 'center',
		width: dialogWidth,
		minHeight: dialogMinHeight,
		dialogClass:'mochi_dialog mochi_dialog_info',
		modal: true,
		stack: true,
		title: '<div class="wizard_dialog_title">'+$('#eula_not_accepted').attr('title')+'</div>'
	});
    
    $("#privacy_policy_overlay").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_info',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#privacy_policy_overlay').attr('title')+'</div>'
    });
        
});