
<div id="onboarding_reconnect_network_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_RECONNECT_TO_THE_AVATAR_NETWORK')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
        <form id="onboarding_reconnect_network_form" action="system_state" method="get"></form>
		<div class="reconnect_network_content">
            <div id="onboarding_connect_msg_find_wifi_network" class="reconnect_network_item">
                <div class="icon"></div>
                <div class="connect_network_msg">
                    <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_FIND_AVATAR_WIFI_NETWORK')?></div>
                    <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_GOTO_YOUR_COMPUTER_WIFI_SETTINGS')?></div>
                    <div><?php echo _('GLOB_NAV_DIALOG_STRING_THIS_MAY_TAKE_UP_TO_ONE_MINUTE')?></div>
                </div>
            </div>

            <div id="onboarding_connect_msg_select_wifi_network" class="reconnect_network_item">
                <div class="icon"></div>
                <div class="connect_network_msg">
                    <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_CONNECT_TO_AVATAR_WIFI_NETWORK')?></div>
                    <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_SELECT_AVATAR_FROM_THE_WIFI_LIST')?></div>
                </div>
            </div>

            <div id="onboarding_connect_network_msg_refresh_browser" class="reconnect_network_item">
                <div class="icon"></div>
                <div class="connect_network_msg">
                    <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_REFRESH_BROWSER')?></div>
                    <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_AVATAR_DEVICENAME_URL')?></div>

                    <!--
                    <div class="waiting_for_network_connection">
                        <span class="spinnerSunIcon"></span>
                        <span class="extra_space_left"><?php echo _('GLOB_NAV_DIALOG_STRING_WIFI_RECONNECT_WAITING_FOR_NETWORK_CONNECTION')?></span>
                    </div>
                    -->
                </div>
            </div>

            <!--
            <div>
                <ul>
                    <li><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_AVATAR_WIFI_SECURED')?></li>
                </ul>
            </div>
            -->

		</div>
	</div>

</div>

<div id="reconnect_network_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_RECONNECT_TO_THE_AVATAR_NETWORK')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
        <form id="reconnect_network_form" action="system_state" method="get"></form>
		<div class="reconnect_network_content">

            <div id="connect_msg_find_wifi_network" class="reconnect_network_item">
                <div class="icon"></div>
                <div class="connect_network_msg">
                    <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_FIND_AVATAR_WIFI_NETWORK')?></div>
                    <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_GOTO_YOUR_COMPUTER_WIFI_SETTINGS')?></div>
                    <div><?php echo _('GLOB_NAV_DIALOG_STRING_THIS_MAY_TAKE_UP_TO_ONE_MINUTE')?></div>
                </div>
            </div>

            <div id="ssid_broadcasting">
                <div id="connect_msg_select_wifi_network" class="reconnect_network_item">
                    <div class="icon"></div>
                    <div class="connect_network_msg">
                        <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_CONNECT_TO_AVATAR_WIFI_NETWORK')?></div>
                        <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_SELECT_AVATAR_FROM_THE_WIFI_LIST')?></div>
                    </div>
                </div>
            </div>
            <div id="ssid_not_broadcasting">
                <div id="connect_msg_select_other_network" class="reconnect_network_item">
                    <div class="icon"></div>
                    <div class="connect_network_msg">
                        <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_CONNECT_TO_AVATAR_WIFI_NETWORK')?></div>
                        <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_SELECT_OTHER_NETWORK_FROM_THE_WIFI_LIST_AND_ENTER_AVATAR')?></div>
                    </div>
                </div>
            </div>

            <div id="connect_network_msg_refresh_browser" class="reconnect_network_item">
                <div class="icon"></div>
                <div class="connect_network_msg">
                    <div class="connect_network_msg_title"><?php echo _('GLOB_NAV_DIALOG_STRING_REFRESH_BROWSER')?></div>
                    <div class="connect_network_msg_details"><?php echo _('GLOB_NAV_DIALOG_STRING_AVATAR_DEVICENAME_URL')?></div>

                    <!--
                    <div class="waiting_for_network_connection">
                        <span class="spinnerSunIcon"></span>
                        <span class="extra_space_left"><?php echo _('GLOB_NAV_DIALOG_STRING_WIFI_RECONNECT_WAITING_FOR_NETWORK_CONNECTION')?></span>
                    </div>
                    -->
                </div>
            </div>

            <!--
            <div id="reconnect_wireless_network_msg_container">
                <ul>
                    <li id="reconnect_wireless_network_security_msg"></li>
                    <li id="reconnect_wireless_network_dhcp_msg"></li>
                    <li id="reconnect_wireless_network_ssid_broadcast_msg"></li>
                    <li id="reconnect_wireless_network_ipaddress_msg"></li>
                </ul>
            </div>
            -->

		</div>
	</div>
</div>

<div id="reconnect_network_timeout_dialog" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_UNABLE_TO_FIND_NETWORK')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
            <p><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_PARAGRAPH_1')?></p>
            <span><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_TROUBLE_SHOOT')?></span>
            <ul>
                <li class="trouble_shooting_hints"><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_TROUBLE_SHOOT_1')?></li>
                <li class="trouble_shooting_hints"><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_TROUBLE_SHOOT_2')?></li>
                <li class="trouble_shooting_hints"><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_TROUBLE_SHOOT_3')?></li>
            </ul>
            <p><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_PARAGRAPH_2')?></p>
            <!--<p><?php echo _('ERROR_RECONNECT_NETWORK_TIMEOUT_PARAGRAPH_3')?></p>-->
		</div>
	</div>
</div>

