$(document).ready(function(){
	authenticationHandler.addItemToProcessAfterAuth(function(){
		hideSplash();
		$("#page").fadeIn();
	    checkForDeviceReady();
	    initDashboard();
	    
	    var useQueue = new Array(true);
	    
	    
	    //dashboardHandler.updateMobileDeviceCount(true);
	    dashboardHandler.callHandler('updateMobileDeviceCount', useQueue);
	    checkForFirmwareUpdate(true);
        //checkForFactoryRestore(true);
	    //dashboardHandler.updateFirmwareVersion(true);
	    //dashboardHandler.callHandler('updateFirmware', useQueue);
	    //dashboardHandler.callHandler('updateMediaCount', useQueue);
	    dashboardHandler.callHandler('updateStorage', useQueue);
	    //dashboardHandler.updateStorage(true);
        //dashboardHandler.updateHealthy(true);
	    //dashboardHandler.callHandler('updateHealth', useQueue);
	    //initUSB(true);
	    //dashboardHandler.updateUserCount(true);
	    //dashboardHandler.callHandler('updateUserCount', useQueue);
	    //dashboardHandler.updateShareCount(true);
	    //dashboardHandler.callHandler('updateShareCount', useQueue);
	    dashboardHandler.callHandler('wifiNameAndSignal', useQueue);
	    dashboardHandler.callHandler('updateBatteryPercent', useQueue);
	    initAlerts(true);
        //initSettings();
	    
	    //dashboardHandler.updateAll();
	    
	    //initSafepoints();

	    ajaxQueue.process();
	    /*
	    initAlerts();
	    initUSB();
	    initDashboard();
	    initUpdates();
	    initSettings();
	    ajaxQueue.process();
	    */
	    
        initPolling();
        initDeviceTitle();
        //initDatetime();

	});
	
	$('#splash_content h2').text(dictionaryList['splashConfiguration']);
	authenticationHandler.checkEula();
});
