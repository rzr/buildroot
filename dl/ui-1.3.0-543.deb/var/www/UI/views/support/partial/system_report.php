<div class="content_row">
    <!--<label><?php echo _('CONTENT_SETTINGS_LABEL_DOWNLOAD_LOGS')?></label>-->
    <button id="create_and_save_btn"><?php echo _('CONTENT_SETTINGS_LABEL_DOWNLOAD_LOGS')?></button>
    <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_HELP_DESC_AVATAR_CREATE_AND_SAVE_SYSTEM_REPORT')?></div></div></div>
</div>
