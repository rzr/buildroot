<div id="dashboard_media_scan_box" class="dashboard_medium_box dashboard_box">
	<div class="header"><h3><span id="dashboard_media_scan_box_title"><?php echo _('CONTENT_HOME_MEDIUM_BOX_TITLE_MEDIA_SCAN')?></span></h3></div>
    <div id="dashboard_content_scan" class="dashboard_count dashboard_content_status_text overflow_hidden_nowrap_ellipsis"></div>
    <div class="footer"><a href="#" id="dashboard_media_info_link"></a></div>
</div>