<div id="login_dialog" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <form id="login_dialog_form" action="users" method="get">
                <p><?php echo _('GLOB_NAV_LOGIN_STRING_LOGIN_INTRO'); ?></p>
                <br />
        
                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_USERNAME'); ?></label>
                    <input class="NOTEMPTY" type="text" id="login_username_dialog" name="username" value="" />
                </div>
        
                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_PASSWORD'); ?></label>
                    <input type="password" id="login_password_dialog" name="password" value="" autocomplete="off" />
                </div>
        
            </form>
        
            <div class="content_row">
                <!--<div class="error" id="invalid_password" style="display:none;"><?php echo _('GLOB_NAV_LOGIN_STRING_INVALID_USERNAME_PASSWORD'); ?></div>-->
                <div class="error" id="invalid_unauthorized" style="display:none;"><?php echo _('GLOB_NAV_LOGIN_STRING_UNAUTHORIZED'); ?></div>
            </div>
        
        </div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="login_dialog_ok_button" class="mochi_dialog_save_button"><?php echo _('GLOB_NAV_LINK_LOGIN_AVATAR')?></button>
	</div>
</div>