
<div id="create_login_password_container">
    <h3 class="create_password_intro"><?php echo _('GLOB_NAV_LOGIN_TITLE_SECURE_YOUR_AVATAR_ADMIN_PAGE'); ?></h3>
    <div id="create_login_password_content">
        <form id="create_login_password_form" action="users" method="PUT">
    
            <div class="content_row">
                <label><?php echo _('GLOB_NAV_LOGIN_LABEL_USERNAME'); ?></label>
                <span id="login_username_display"></span>
            </div>

            <div class="content_row">
            	<label><?php echo _('LABEL_PASSWORD')?></label>
                <input type="password" id="create_login_password" class="PASSWORD NOTEMPTY" maxlength="32" autocomplete="off" />
            </div>
            <div class="content_row">
            	<label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_CONFIRM_PASSWORD')?></label>
                <input type="password" id="create_login_password_confirm" class="CONFIRM_PASSWORD" maxlength="32" autocomplete="off" />
            </div>

            <div class="content_row" id="create_password_hint_container">
                <label><?php echo _('GLOB_NAV_LOGIN_LABEL_PASSWORD_HINT'); ?></label>
                <span id="create_password_hint"></span>
            </div>

            <br>
            
            <div class="content_row" id="create_login_password_buttons">
                <input type="button" id="create_login_password_skip_button"  value="<?php echo _('BUTTON_SKIP')?>" />            
                <span class="extra_space_left"></span>
            	<input type="submit" id="create_login_password_ok_button"  value="<?php echo _('BUTTON_NEXT')?>" />
            </div>

        	<input type="hidden" name="new_password" id="create_login_password_encoded" /> 
            <input type="hidden" id="create_login_is_admin" name="is_admin" />
            <input type="hidden" id="create_login_username" name="username" />
            <input type="hidden" id="create_login_user_id" name="user_id" />

        </form>

    </div>
</div>
