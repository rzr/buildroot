<?php
class DeviceDescription{
    private $device_description;
    private $host = 'http://127.0.0.1';
    private $apiPath = '/api/2.4.1/rest/';

    private function initDeviceDescription(){
        $this->device_description = array();
        $url = $this->host.$this->apiPath.'device_description';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $xml = simplexml_load_string($result);
        if ($xml !== false){
            $this->device_description = $xml;
        }
    }

    public function getDeviceName(){
        if (!isset($this->device_description)){
            $this->initDeviceDescription();
        }
        $machine_name = trim($this->device_description->machine_name);
        return $machine_name;
    }

    public function getDeviceDescription(){
        if (!isset($this->device_description)){
            $this->initDeviceDescription();
        }
        $machine_desc = trim($this->device_description->machine_desc);
        return $machine_desc;
    }
}
?>
