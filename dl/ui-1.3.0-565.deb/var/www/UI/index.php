<?php
    header('X-UA-Compatible: IE=edge,chrome=1');
    //build cached file if it doesn't exist
    $cacheFile = 'cache/fullpage.html';
    define ('DEBUG_MODE', false);
    define ('SITE_BASE_URL', 'UI');
    if (DEBUG_MODE){
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        include_once('lib/language.php');
        $language = new Language();
        $languageStr = $language->getLanguage();
        define('LANGUAGE_STR', $languageStr);
        setlocale(LC_ALL, $languageStr.".UTF-8");
        bindtextdomain("default", "./locale");
        textdomain("default");

        include_once('views/common/languages.php');
        if(isset($langMap[$languageStr])){
            $Language3Letter = $langMap[$languageStr];
        }
        else{
            $Language3Letter = 'eng';
        }
        define('LANGUAGE_3CHAR', $Language3Letter);
        
        include_once('lib/pageLoader.php');
        $pageLoader = new PageLoader();
        $pageLoader->LoadPage();
    }
    else{
        //if (!file_exists($cacheFile))
        if (true)
        {
            include_once('lib/language.php');
            $language = new Language();
            $languageStr = $language->getLanguage();
            define('LANGUAGE_STR', $languageStr);
            ob_start();
            setlocale(LC_ALL, $languageStr.".UTF-8");
            bindtextdomain("default", "./locale");
            textdomain("default");
            
            include_once('views/common/languages.php');
            if(isset($langMap[$languageStr])){
                $Language3Letter = $langMap[$languageStr];
            }
            else{
                $Language3Letter = 'eng';
            }
            define('LANGUAGE_3CHAR', $Language3Letter);

            include_once('lib/pageLoader.php');
            $pageLoader = new PageLoader();
            $pageLoader->LoadPage();
            /* let's not cache yet
            $fp = fopen($cacheFile, 'w'); 
    	    fwrite($fp, ob_get_contents());
            fclose($fp);
            ob_end_flush();
            */ 
        }
        else
        {
            include_once($cacheFile);
        }
    }