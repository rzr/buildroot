<div id="user_password_overlay" title="<?php echo _('CONTENT_USERS_DIALOG_TITLE_EDIT_ADMIN_PASSWORD')?>"  class="mochi_dialog_container">    
    <form id="edit_admin_user_password_form" action="users" method="PUT">
    	<div class="mochi_dialog_content_container">
    	    <div class="mochi_dialog_content">
            	<!--<p><?php echo _('CONTENT_USERS_DIALOG_STRING_EDIT_PASSWORD_DESC')?></p>-->
                <!--
                <div class="content_row" id="old_password_container">
                	<label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_OLD_PASSWORD')?></label><input type="password" id="edit_old_user_password" class="OLD_PASSWORD" maxlength="32"/>
                </div>
                -->

                <div class="edit_admin_user_static_content">
                    <span class="username"></span>
                    <span class="user_id"></span>
                    <span class="is_admin"></span>
                    <span class="fullname"></span>
                </div>

                <div class="content_row">
                    <label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_NEW_PASSWORD')?></label>
                    <span id="edit_user_password_form_password_container">
                        <input type="password" id="edit_user_password" class="PASSWORD NOTEMPTY" maxlength="32" autocomplete="off" />
                    </span>
                    <span id="edit_user_password_form_password_show_container">
                        <input type="text" id="edit_user_password_show" maxlength="32" />
                    </span>
                </div>
    
                <div class="content_row" id="edit_user_password_form_password_confirm_container">
                    <label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_CONFIRM_PASSWORD')?></label>
                    <input type="password" id="edit_user_password_confirm" class="CONFIRM_PASSWORD" maxlength="32" autocomplete="off"/>
                </div>
    
                <div class="content_row" id="edit_user_password_form_show_password_checkbox_container">
                    <label>&nbsp;</label>
                    <input type="checkbox" class="normal_checkbox" id="edit_user_password_form_show_password_checkbox" /> <?php echo _('CONTENT_SETTINGS_STRING_SHOW_PASSWORD')?>
                </div>

                <!--
                <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
                <br />
                -->

            </div>
        </div>
        <div class="dialog_form_controls">
            <input type="hidden" name="new_password" id="edit_admin_user_password_encoded" /> 
            <!--<input type="hidden" name="old_password" id="edit_old_password_encoded" />-->
            <input type="hidden" name="username" />
            <input type="hidden" name="user_id" />
            <input type="hidden" name="is_admin" />
            <input type="hidden" name="fullname" />
            <button type="button" id="edit_user_password_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
            <input type="submit" id="edit_user_password_save_button" class="mochi_dialog_save_button" value="<?php echo _('BUTTON_SAVE')?>" />
    	</div>
    </form>

</div>
