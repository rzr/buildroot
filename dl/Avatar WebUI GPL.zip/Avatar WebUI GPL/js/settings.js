var gTime_machine_size_limit_MB = 0;
var pingErrorCount = 0;
var timeZonesName;
var timeZonesAbbr;
//var MonthArray;
//var DayofWeekArray;
var timeTicking = false;

$(document).ready(function(){

    /* Legacy Sequoia - no Internet connectivity, no remote access status; DLNA polling moved to media.js
    pollingHandler.addPoll("device", ["settings_container"], settingsRemoteAccessPollSuccess, settingsPollError, pollingFastFrequency);
    pollingHandler.addPoll("media_server_database", ["settings_container"], settingsDLNAPollSuccess, settingsPollError);
    pollingHandler.addPoll("internet_access", ["settings_container"], settingsInternetPollSuccess, settingsPollError, pollingMedFrequency); 
    */ 

    init_updateUploadFromFile();

    /* Legacy Sequoia - configuration import/export not supported in Avatar
    init_configFileUpload();
    */

    /* Legacy Sequoia
	//general settings
	$('#settings_nav_device_link').navItem({
	    'containerId': 'settings_content',
	    'contentId': 'device_container',
	    'selectedClass': 'selected',
	    'refreshDataCall': function(){
            refreshSettingsGeneralForms();
        }
    });
    */

    /* Legacy Sequoia
    $('#settings_nav_media_link').navItem({
        'containerId': 'settings_content',
        'contentId': 'media_container',
        'selectedClass': 'selected',
	    'refreshDataCall': function(){
        	//$('#settings_media_name_form').restForm("refreshForm");
            $('#settings_media_toggle_dlna_service_form').restForm("refreshForm");
            //$('#settings_toggle_itunes_service_form').restForm("refreshForm");
        }
    }); 
    */ 

    $('#settings_device_name_form').restForm({
        /*'relatedForms': ['settings_device_description_form'],*/
        'timeout': ajaxTimeout,
        'beforeProcessForm': function(){
            pingErrorCount = 0;
        },
        'processFormSuccessCallback': function(){
            $('#settings_device_name_form').restForm("processFormSuccess");
            //$('#settings_device_description_form').restForm("refreshForm");

            finishDevicenameDescriptionChange("settings_device_name_form");
        },
        'processFormErrorCallback': function(request, status, error) {

            // workaround to account for network restart causing API to abort
            if (status == 'error') {
                finishDevicenameDescriptionChange("settings_device_name_form");
            }
            else {
                $('#settings_device_name_form').restForm('processFormError', request, status, error);
            }
        },
        'setDefaultFormDataCallback': function(data){
            $('#settings_device_name_form_machine_name')[0].defaultValue = $('#settings_device_name_form_machine_name').val();
            
            //$('#settings_device_name_form_machine_desc')[0].defaultValue = $('#settings_device_name_form_machine_desc').val();
            //$('#settings_device_description_form_machine_name')[0].defaultValue = $('#settings_device_description_form_machine_name').val();
            //$('#settings_device_description_form_machine_desc')[0].defaultValue = $('#settings_device_description_form_machine_desc').val();

        },
        /*
        'hideProcessingCallback': function() {                     
            // delay hiding until finishDevicenameDescriptionChange() or refreshDataCallback
        }*/
    });

    /* Legacy Sequoia
	$('#settings_device_description_form').restForm({
        'relatedForms': ['settings_device_name_form'],
        'timeout': ajaxTimeout,
        'beforeProcessForm': function(){
            pingErrorCount = 0;
        },
        'processFormSuccessCallback': function(){
            $('#settings_device_description_form').restForm("processFormSuccess");
            //$('#settings_device_name_form').restForm("refreshForm");
            gDeviceDescription = $('#settings_device_name_form_machine_desc').val();

            finishDevicenameDescriptionChange("settings_device_description_form");
        },
        'processFormErrorCallback': function(request, status, error) {

            // workaround to account for network restart causing API to abort
            if (status == 'error') {
                finishDevicenameDescriptionChange("settings_device_description_form");
            }
            else {
                $('#settings_device_description_form').restForm('processFormError', request, status, error);
            }
        },
        'setDefaultFormDataCallback': function(data){
            //$('#settings_device_name_form_machine_name')[0].defaultValue = $('#settings_device_name_form_machine_name').val();
            //$('#settings_device_name_form_machine_desc')[0].defaultValue = $('#settings_device_name_form_machine_desc').val();
            //$('#settings_device_description_form_machine_name')[0].defaultValue = $('#settings_device_description_form_machine_name').val();

            $('#settings_device_description_form_machine_desc')[0].defaultValue = $('#settings_device_description_form_machine_desc').val();
        },
        'hideProcessingCallback': function() {                     
            // delay hiding until finishDevicenameDescriptionChange() or refreshDataCallback
        }
    });
    */

    /*
    $('#settings_device_serialnum_form').restForm({
        'refreshDataCallback': function(data) {
            //$('#settings_device_serialnum_form').restForm("_refreshData", data);
            gSerialNumber = data.system_information.serial_number;
            gModelNumber = data.system_information.model_number;
            $('#device_serial_number').html(gSerialNumber);
        }
    });
    */

	$('#settings_device_language_form').restForm({
        'refreshDataCallback': function(data) {
            if (data !== null && data.language_configuration !== null) {
                if (data.language_configuration.language.toLowerCase() == 'default') {
                    data.language_configuration.language = 'en_US';
                }
            }
            $('#settings_device_language_form').restForm("_refreshData", data);
        },
	    'processFormSuccessCallback': function(){
            gLanguage = $('#languageSelect').val();
            window.location = redirectURL;
            displayLoading();
        }
	});
	
    /* Legacy Sequoia
	$('#settings_device_timezone_form').restForm({
        'relatedForms': ['settings_device_ntp_form'],
        'refreshDataCallback': function(data) {
            $('#settings_device_timezone_form').restForm("_refreshData", data);
            $('#settings_device_timezone_form').find(".ui-selectmenu").removeAttr("style");
            gTimezoneName = $("#time_zone_name_id").val();
        },
        'processFormSuccessCallback': function(){
            $('#settings_device_timezone_form').restForm("processFormSuccess");
            $('#settings_device_ntp_form').restForm("refreshForm");
            
            //$('#settings_device_timezone_container').find('.selectBox').removeClass('timeZoneMaxWidth_container');
            //$('#settings_device_timezone_container').find('.ui-selectmenu').removeClass('timeZoneMaxWidth_container');
            //$('#settings_device_timezone_container').find('.ui-selectmenu-status').removeClass('overflow_hidden_nowrap_ellipsis').removeClass('timeZoneMaxWidth');
            
        }
    });
    $('#settings_device_ntp_form').restForm({
        'relatedForms': ['settings_device_timezone_form'],
        'refreshDataCallback': function(data) {
            $('#settings_device_ntp_form').restForm("_refreshData", data);
            
            gDateTime = parseInt(data.date_time_configuration.datetime);
            //updateTimezone('#current_dateTime_value');

            var ntpEnabled = $('#SettingNtpServiceToggle').is(":checked");
            if (ntpEnabled){
                $('#dateTime_edit_icon').hide();
                $('#ntp_primary_server_section').show();
                $('#ntp_configure_section').show();

                if (data.date_time_configuration.ntpsrv_user != "") {
                    $('#primary_ntp_server').html(data.date_time_configuration.ntpsrv_user);
                }
                else {
                    $('#primary_ntp_server').html(data.date_time_configuration.ntpsrv0);
                }
            }
            else {
                $('#dateTime_edit_icon').show();
                $('#ntp_primary_server_section').hide();
                $('#ntp_configure_section').hide();
            }
        },
        'processFormSuccessCallback': function(data){
            $('#settings_device_ntp_form').restForm("processFormSuccess");
            $('#settings_device_timezone_form').restForm("refreshForm");
            
            if ($('#SettingNtpServiceToggle').is(":checked")) {
                setTimeout('getNTPTime(0);', 5000);
            }
        }
    });

    $('#update_ntp_form').restFormDialog({
    	'dialogName':'set_ntp_dialog'
    });

    $('#settings_device_led_form').restForm();

    $('#settings_hdd_standby_time_form').restForm();

    $('#settings_time_machine_form').restForm({
        'refreshDataCallback': function(data) {
            $('#settings_time_machine_form').restForm("_refreshData", data);
            
            if ((data != null) && (data.time_machine != null) && (data.time_machine.backup_size_limit != null) ) {
                gTime_machine_size_limit_MB = data.time_machine.backup_size_limit;

                // default new TimeMachine share is Public if user deleted last known TimeMachine share
                if (data.time_machine.backup_share == null || data.time_machine.backup_share == '') {
                    $("#settings_time_machine_form_backup_share").val("Public");
                    $("#settings_time_machine_form_backup_size_limit").val("0");
                }
            }

            if ( (data.time_machine.backup_enabled == 'false') || (data.time_machine.backup_enabled == '') ) {
                $('#settings_time_machine_form_configure').hide();
            }
            else {
                $('#settings_time_machine_form_configure').show();
            }
        }
    });

    $('#settings_nav_addins').navItem({
	    'containerId': 'settings_content',
	    'contentId': 'addins_container',
	    'selectedClass': 'selected',
	    'refreshDataCall': function(){

    		$.ajaxAPI({
				"url": "TBD",
				"success": function(xmlData) {

				}
			});
	    }
    });    

    $("#set_time_machine_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: 800,
        minHeight: 400,
        dialogClass: 'mochi_dialog mochi_dialog_timemachine',
        modal: true,
        stack: false,
        title: '<div id="set_time_machine_dialog_title" class="wizard_dialog_title">'+$('#set_time_machine_dialog').attr('title')+'</div>'
    });


    
    $('#settings_time_machine_configure_link').live('click', function (e) {
    	e.preventDefault();
        $("#time_machine_backup_enabled").val( $("#SettingTimeMachineToggle").is(":checked") );
        $("#time_machine_backup_size_limit").val( $("#settings_time_machine_form_backup_size_limit").val() );
        $("#set_time_machine_dialog").dialog("open");

        var current_share_max_capacity_GB = gCapacity_GB;

        // get shares list
        $.ajaxAPI({
            "url": "shares",
            "error": function (request, status, error) {
                processAndDisplayError(request.responseText, 'get_shares', request.status);
            },
            "success": function(data) {
                
                if (data != null && data.shares != null && data.shares.share != null) {

                    var currentExist = false;

                    // delete all available items except 1st which will be use as template
                    $("#SettingsTimeMachineShareSelect").find("option:first").siblings().each(function(){
                        $(this).remove();
                    });

                    if( Object.prototype.toString.call( data.shares.share ) != '[object Array]' ){  // only 1 share
                        currentExist = addShareToTimemachineSharelist(data.shares.share, currentExist);
                    }
                    else {  // multiple shares
                        for(var i in data.shares.share){
                            currentExist = addShareToTimemachineSharelist(data.shares.share[i], currentExist);
                        }
                    }

                    if (currentExist == true) {
                        $("#SettingsTimeMachineShareCurrent").attr("style", "display:none;");
                    }
                    else {
                        $("#SettingsTimeMachineShareCurrent").attr("style", "display:block;");
                        $("#SettingsTimeMachineShareCurrentName").html( $("#settings_time_machine_form_backup_share").val() );
                    }

                    // delete 1st option because it's a template
                    $("#SettingsTimeMachineShareSelect").find("option:first").remove();
                }

                var selectMenuOptions = {
                    style: 'dropdown',
                    width: 195,
                    wrapperElement: "<div class='selectMenuBlack'/>"
                };
                $("#SettingsTimeMachineShareSelect").selectmenu(selectMenuOptions);

                //SLEE - workaround since the width remains at 40px
                $("#update_time_machine_form").find("#SettingsTimeMachineShareSelect-button").attr("style","width:195px");

                //SLEE - workaround since the dropdown box doesn't display the current value
                $("#update_time_machine_form").find("#ui-selectmenu-status").html( $("#settings_time_machine_form_backup_share").val() );

                current_share_max_capacity_GB = parseInt( $("#SettingsTimeMachineShareSelect option:selected").attr("rel") );
            },
            "complete": function (jqXHR, textStatus) {
                setTimeMachineSlider(current_share_max_capacity_GB);   
            }
        });     

    });

    $('#update_time_machine_form_cancel_button').click(function () {
        //$("#update_time_machine_form").restForm("reset");
        $("#set_time_machine_dialog").dialog("close");
    });

    $('#update_time_machine_form_save_button').click(function () {
        
        var formMethod = $(this.form).attr('method').toLowerCase();
        var formAction = $(this.form).attr('action').toLowerCase();                

        var backup_enabled = $('#update_time_machine_form').find('input[name=backup_enabled]').val();
        var backup_share = $('#update_time_machine_form').find('.ui-selectmenu-status').html();
        var backup_size_limit = $('#time_machine_backup_size_limit').val();

        displayLoading();
        $.ajaxAPI({
            "url": formAction,
            "type": formMethod,
            "data": {'backup_enabled': backup_enabled, 'backup_share': backup_share, 'backup_size_limit': backup_size_limit},
            "error": function (request, status, error) {
                processAndDisplayError(request.responseText, formMethod + '_' + formAction, request.status);
            },
            "success": function () {
                 $('#settings_time_machine_form').restForm("refreshForm");
                 //$('#update_time_machine_form').restForm("refreshForm");
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
                $("#set_time_machine_dialog").dialog("close");
            }
        });        
        
    });

    $("#SettingsTimeMachineShareSelect").change(function() {
        current_share_max_capacity_GB = parseInt( $("#SettingsTimeMachineShareSelect option:selected").attr("rel") );
        setTimeMachineSlider(current_share_max_capacity_GB);
    });    

    $("#set_ntp_dialog").mochiDialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: 400,
        dialogClass: 'mochi_dialog mochi_dialog_ntp',
        modal: true,
        stack: false,
        title: '<div id="set_ntp_dialog_dialog_title" class="wizard_dialog_title">'+$('#set_ntp_dialog').attr('title')+'</div>'
    });

    $("#set_datetime_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: 300,
        dialogClass: 'mochi_dialog mochi_dialog_info',
        modal: true,
        stack: false,
        title: '<div id="set_datetimedialog_dialog_title" class="wizard_dialog_title">'+$('#set_datetime_dialog').attr('title')+'</div>'
    });

    $('#languageclock_setprimary_link').live('click', function (e) {
    	e.preventDefault();
        $("#update_ntp_form_ntpsrv0").html( $('#settings_device_ntp_form').find('input[name=ntpsrv0]').val() );
        //$("#update_ntp_form_ntpsrv0_desc").html("Microsoft NTP service");
        
        $("#update_ntp_form_ntpsrv1").html( $('#settings_device_ntp_form').find('input[name=ntpsrv1]').val() );
        //$("#update_ntp_form_ntpsrv1_desc").html("NTP pool service");

        $("#update_ntp_form_ntpsrv_user").val( $('#settings_device_ntp_form').find('input[name=ntpsrv_user]').val() );
        $('#update_ntp_form_ntpsrv_user')[0].defaultValue = $('#update_ntp_form_ntpsrv_user').val();
        //$("#update_ntp_form_ntpsrv_user_desc").html("User defined NTP server");

        $("#create_user_ntp_btn_section").hide();
        $("#ntpsrv_user_entry_section").hide();

        if ($('#settings_device_ntp_form').find('input[name=ntpsrv_user]').val() == "") {
            $("#create_user_ntp_btn_section").show();
        } 
        else {
            $("#ntpsrv_user_entry_section").show();
            $("#ntpsrv_user_entry_section").find(".deletebutton").attr("style", "display: none;");
        }

        $("#set_ntp_dialog").dialog("open");
    });

    $('#update_ntp_form_cancel_button').click(function () {
        $("#set_ntp_dialog").dialog("close");
    });

    $('#update_ntp_form_save_button').click(function () {

        if( ($('#ntpsrv_user_entry_section').is(':visible') == false) || (validate('#update_ntp_form')) ){

            $("#set_ntp_dialog").dialog("close");

            var formMethod = $(this.form).attr('method').toLowerCase();
            var formAction = $(this.form).attr('action').toLowerCase();

            var ntpsrv0 = $('#settings_device_ntp_form').find('input[name=ntpsrv0]').val();
            var ntpsrv1 = $('#settings_device_ntp_form').find('input[name=ntpsrv1]').val();
            var time_zone_name = $('#settings_device_ntp_form').find('input[name=time_zone_name]').val();
            var ntpsrv_user = '';
            if (($("#ntpsrv_user_entry_section").attr("style") != "display: none;")) {
                ntpsrv_user = $('#update_ntp_form_ntpsrv_user').val();
            }

            displayLoading();
            $.ajaxAPI({
                "url": $(this.form).attr('action'),
                "type": $(this.form).attr('method'),
                "data": {'datetime': gDateTime, 'ntpservice': 'true', 'ntpsrv0': ntpsrv0, 'ntpsrv1': ntpsrv1, 'ntpsrv_user': ntpsrv_user, 'time_zone_name': time_zone_name},
                "error": function (request, status, error) {
                    processAndDisplayError(request.responseText, formMethod + '_' + formAction, request.status);
                },
                "complete": function (jqXHR, textStatus) {
                    $('#settings_device_ntp_form').restForm("refreshForm");
                    hideLoading();
                }
            });
        }

    });

    $("#create_user_ntp_btn").live("click", function (e) {
        e.preventDefault();
        $("#update_ntp_form_ntpsrv_user").attr('disabled', false);
        $("#ntpsrv_user_entry_section").show();
        $("#create_user_ntp_btn_section").hide();
    });

    $("#delete_ntpsrv_user").live("click", function (e) {
        e.preventDefault();
        $("#update_ntp_form_ntpsrv_user").attr('disabled', true);
        $("#ntpsrv_user_entry_section").hide();
        $("#update_ntp_form_ntpsrv_user").val('');
        $("#create_user_ntp_btn_section").show();
    });

    $('#update_ntp_form_ntpsrv_user').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#update_ntp_form_save_button").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#remote_access_settings_manual_port1').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#update_remote_access_form_save_button").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#remote_access_settings_manual_port2').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#update_remote_access_form_save_button").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#dateTime_calender').live('keydown', function(event){
        if (event.keyCode == 13) {
            $("#settings_dateTime_date_submit_form").click();
            event.preventDefault();
            event.stopPropagation();
        }
    });
    
    $("#dateTime_calender").datepicker({
        gotoCurrent: true,
        showOn: "button",
        firstDay: 0,
        buttonText: dictionaryList['CalendarTxt'],
        showAnim: "slideDown"
    });

    $('#settings_dateTime_date_form').restForm();

    $('#settings_dateTime_edit_link').live('click', function (e) {
        e.preventDefault();

        $('#set_datetime_dialog').dialog("open");

        // display date in calender entry box
        var timestamp = getTimeStamp(gDateTime);
        $('#dateTime_calender_datestamp').html(timestamp);
        localizeTimeStamp('#dateTime_calender_datestamp', 'd');
        $('#dateTime_calender').val( $('#dateTime_calender_datestamp').html() );
        $('#settings_dateTime_date_form').find('.deletebutton').removeClass('deletebutton');

        $('#dateTime_calender_timestamp').html(timestamp);
        localizeTimeStamp('#dateTime_calender_timestamp', 's');

        var localTime = $('#dateTime_calender_timestamp').html();
        var hour = localTime.substr(11,2);
        var minutes = localTime.substr(14,2);

        // display current time in time entry box
        var ampm = "AM";
        if (hour >= 12) {
            ampm = "PM";
            hour -= 12;
        }

        $('#SettingsLanguageClockHour option').each(function(){
            $(this)[0].defaultSelected = false;
        });
        $('#SettingsLanguageClockHour option[value='+hour+']').each(function(){
            $(this)[0].defaultSelected = true;
            $('#SettingsLanguageClockHour').selectmenu("value", $(this).val());
        });

        $('#SettingsLanguageClockMinute option').each(function(){
            $(this)[0].defaultSelected = false;
        });
        $('#SettingsLanguageClockMinute option[value='+minutes+']').each(function(){
            $(this)[0].defaultSelected = true;
            $('#SettingsLanguageClockMinute').selectmenu("value", $(this).val());
        });

        $('#SettingsLanguageClockAMPM option').each(function(){
            $(this)[0].defaultSelected = false;
        });
        $('#SettingsLanguageClockAMPM option[value='+ampm+']').each(function(){
            $(this)[0].defaultSelected = true;
            $('#SettingsLanguageClockAMPM').selectmenu("value", $(this).val());
        });

    });

    $('#settings_dateTime_date_submit_form').live('click', function () {
        $("#set_datetime_dialog").dialog("close");

        //calculate the date time
        var hour = parseInt($('#SettingsLanguageClockHour').val());
        var minutes = parseInt($('#SettingsLanguageClockMinute').val());
        //add 12 for PM times that aren't noon
        if ($('#SettingsLanguageClockAMPM').val() == "PM"){
            hour += 12;
        }

        var currentDate = $("#dateTime_calender").datepicker( "getDate" );
        var month = currentDate.getUTCMonth();
        var day = currentDate.getUTCDate();
        var year = currentDate.getUTCFullYear();

        var newdate = new Date(year, month, day, hour, minutes, 0);
        var datetime = Math.round(newdate.getTime() / 1000);

        var formMethod = $(this.form).attr('method').toLowerCase();
        var formAction = $(this.form).attr('action').toLowerCase();
        
        var ntpservice = $('#settings_device_ntp_form').find('input[name=ntpservice]').val();
        var ntpsrv0 = $('#settings_device_ntp_form').find('input[name=ntpsrv0]').val();
        var ntpsrv1 = $('#settings_device_ntp_form').find('input[name=ntpsrv1]').val();
        var ntpsrv_user = $('#settings_device_ntp_form').find('input[name=ntpsrv_user]').val();
        var time_zone_name= $('#settings_device_ntp_form').find('input[name=time_zone_name]').val();

        displayLoading();
        $.ajaxAPI({
            "url": formAction,
            "type": formMethod,
            "data": {'datetime': datetime, 'ntpservice': ntpservice, 'ntpsrv0': ntpsrv0, 'ntpsrv1': ntpsrv1, 'ntpsrv_user': ntpsrv_user, 'time_zone_name': time_zone_name},
            "error": function (request, status, error) {
                //$('#update_time_machine_form').restForm("refreshForm");
                processAndDisplayError(request.responseText, formMethod + '_' + formAction, request.status);
            },
            "success": function () {
                $('#settings_device_ntp_form').restForm("refreshForm");
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
            }
        });

    });
    
    $('#settings_dateTime_date_cancel_form').live('click', function () {
        $("#set_datetime_dialog").dialog("close");
    });

    $("#SettingsTimezoneSelect").change(function() {
    
        //$('#settings_device_timezone_container').find('.selectBox').addClass('timeZoneMaxWidth_container');
        //$('#settings_device_timezone_container').find('.ui-selectmenu').addClass('timeZoneMaxWidth_container');
        //$('#settings_device_timezone_container').find('.ui-selectmenu-status').addClass('overflow_hidden_nowrap_ellipsis').addClass('timeZoneMaxWidth');

    }); 
    */

    if (are_cookies_enabled() == false) {
        $("#cookies_message").show();
    }

    timeZonesName = new Array();
    $('#SettingsTimezoneSelect option').each(function(i){
        var tzname = $(this).attr('value');
        timeZonesName.push(tzname);
    });

    // Note: when changing order of the timeZonesName (in commong/timezones.php), update these too.
    timeZonesAbbr = new Array();
    timeZonesAbbr = ['SST','HAST','AKST','PST','PST','MST (Arizona)','MST (Chihuahua)','MST','CST (Guatemala)','CST',
                     'CST (Mexico City)','CST (Saskatchewan)','COT','EST','EST','VET','AST','BOT','CLT','AMT (Manaus)',
                     'NST','BRT','ART','WGST','UYT','FNT','AZOT','CVT','WET','BST',
                     'CET','CET','CET','CET','WAT','EET','EET','EET','EET (Cairo)',
                     'CAT','EET','IST (Israel)','EET (Minsk)','AST (Arabia)','AST (Arabia)','EAT','IRST','MSK','GST','AZT',
                     'AMT (Armenia)','AFT','PKT','UZT','IST (India)','NPT','YEKT','ALMT','BST (Bangladesh)','MMT',
                     'ICT','KRAT','CST (China)','SGT','AWST','CST (China)','IRKT','JST','KST',
                     'ACST','ACST (Darwin)','YAKT','AEST (Brisbane)','AEST','ChST','AEST','VLAT','MAGT','NZST','FJT'];

});



var configFileUploader;
var uploadConfigTimer = 0;
var importUserCanceledOut = false;
var firstNetworkConnectivity_Poll = true;
var networkconnectivity_InProgress = false;

$(function(){

    /* Legacy Sequoia
    $("#SettingNtpServiceToggle").live('toggle', function(){
        // checked means ntpservice=true
        $(this).submit();
    });

    $("#SettingDeviceLEDToggle").live('toggle', function(){
        // checked means Device LED=true
        $(this).submit();
    });

    $("#SettingHDDStandbyToggle").live('toggle', function(){
        // checked means HDD Stand By=true
        $(this).submit();
    });

    $("#SettingTimeMachineToggle").live('toggle', function(){
        // checked means Time Machine=true (enabled)
        if( $(this).is(":checked") ){
            $('#settings_time_machine_form_configure').show();
        }
        else {
            $('#settings_time_machine_form_configure').hide();
        }
        $(this).submit();
        //$('#update_time_machine_form').restForm("refreshForm");
    }); 
    */ 

	/* TODO
	$(".element_duper").live('click',
	   function(event){
		  hidden = $(this).parent().find('.float_left_wrap:hidden');
		  hid_len = hidden.length;
		  if(hid_len){
			 $(hidden).eq(0).show();
			 hid_len--;
		  }
		  if(!hid_len){ $(this).hide(); }
	
	   }
	);
	
	$(".removeField").live('click',
	   function(event){ 
		  $(this).parent().css('display','none').find('input').val('');
		  $("#dns_server_duper").show();
	   }
	);
	

	
	$("#NetworkModeDhcpClient").live('click',
	   function(){
		  $('#hidden_network_mode').val('dhcp_client');
		  $('.hide_for_dynamic').hide();
	   }
	);
	
	$('#navigate_to_device_name').bind('click', function() { navigateToDisplayName(); });

	*/

});

function initSettings() {
    //init_updateUploadFromFile(data);  // init in dashboard.js
    //init_configFileUpload();
}

/* Legacy Sequoia - no remote access status polling in Avatar
function settingsRemoteAccessPollSuccess(data) {
    if (data != null && data.device != null){
        gDefault_ports_only = data.device.default_ports_only;
        gManual_port_forward = data.device.manual_port_forward;

        updateRemoteAccessConnectionStatus(data.device);
    }
} 
*/
 
/* SLEE - TODO DLNA polling in Avatar 
function settingsDLNAPollSuccess(data) {
    if (data != null && data.media_server_database != null){
        updateDLNAInfo(data.media_server_database, false);
    }
}
*/

/* Legacy Sequoia - no Internet connectivity polling in Avatar
function settingsInternetPollSuccess(data) {
    if (data != null && data.internet_access != null){
        updateInternetAccess(data.internet_access);
    }
}
*/

/* Legacy Sequoia
function settingsPollError() {
    // do nothing
}
*/

function navigateToDisplayName(){
	suppressErrors = true;
	url = 'http://'+deviceName;
	window.location = url;
}

/* Legacy Sequoia
function doUpdateDateTime(data) {

	$('#primary_ntp').attr('readonly', true);

    $('#server_date_time').html(data.datetimeformated);
}
*/

$(function() {
    /* Legacy Sequoia
    $('#add_primary_ntp').live('click', function() { showAddPrimaryNTP(); });
    $('#remove_primary_ntp').live('click', function() { removePrimaryNTP(); });


    $('.add_dns_server').live('click', function(event) { saveDnsServer($(this)); });
    $('.remove_dns_server').live('click', function(event) { removeDnsServer($(this)); }); 
    
    $('#register_btn').live('click', function() { $('#register_device').dialog('open'); });
    */ 
});

/* Legacy Sequoia
function showAddPrimaryNTP() {

    var giveFocus = false;
	$('#add_primary_ntp').hide();
	$('#remove_primary_ntp').show();

	if($('#primary_ntp').val() === ''){
		$('#primary_ntp').attr('readonly', false);
		giveFocus = true;
	} else {
		$('#primary_ntp').attr('readonly', true);
	}

	$('#primary_ntp').show();
	if (giveFocus){
		$('#primary_ntp').focus();
	}
}

function removePrimaryNTP(){
	$('#add_primary_ntp').show();
	$('#remove_primary_ntp').hide();
	$('#primary_ntp').hide();
	$('#primary_ntp').val('');
	$('#add_primary_ntp').focus();
	showSaveButtons('system_date_time');
}
*/

/* Legacy Sequoia
function updateTimeTick(incrementTime) {
    if (incrementTime) {
        gDateTime = gDateTime + 5;
    }

    var timestamp = getTimeStamp(gDateTime);
    $('#current_dateTime_value').html( timestamp );
    $('#current_dateTime_value_timestamp').html( timestamp );
    localizeTimeStamp('#current_dateTime_value');

    setTimeout("updateTimeTick(1);", 5000); // 5 seconds
}

function refreshSettingsGeneralForms() {

    // only highlight "General" if no other tabs highlighted.
    if (!$("#settings_nav").find(".leftmenu ul li").hasClass("selected")) {
        $("#settings_nav").find(".leftmenu ul li:first").addClass("selected");
    }

    if (timeTicking == false) {
        updateTimeTick(0);
        timeTicking = true;
    }

    if ( $("#settings_nav_device_link").parent().hasClass('selected') ) {

        if (gDeviceName != '') {
            $("#settings_device_name_form_machine_name").val(gDeviceName);
            $('#settings_device_name_form_machine_name')[0].defaultValue = $('#settings_device_name_form_machine_name').val();
    
//            $("#settings_device_name_form_machine_desc").val(gDeviceDescription);
//            $('#settings_device_name_form_machine_desc')[0].defaultValue = $('#settings_device_name_form_machine_desc').val();
    
//            $("#settings_device_description_form_machine_name").val(gDeviceName);
//            $('#settings_device_description_form_machine_name')[0].defaultValue = $('#settings_device_description_form_machine_name').val();
    
//            $("#settings_device_description_form_machine_desc").val(gDeviceDescription);
//            $('#settings_device_description_form_machine_desc')[0].defaultValue = $('#settings_device_description_form_machine_desc').val();
        }
        else {
            $('#settings_device_name_form').restForm("refreshForm");
            $('#settings_device_name_form').restForm("refreshRelatedForms");
        }
    
        if (gSerialNumber != '') {
            $("#device_serial_number").text(gSerialNumber);
        }
        else {
            $('#settings_device_serialnum_form').restForm("refreshForm");
        }
    
       // $('#settings_device_language_form').restForm("refreshForm");
             
        $('#languageSelect option[value=' + gLanguage + ']').each(function(){
		    $(this)[0].defaultSelected = true;
		    $('#languageSelect').selectmenu("value", $(this).val())
	    });
    
        $('#settings_device_timezone_form').restForm("refreshForm");
        //$('#settings_device_timezone_form').restForm("refreshRelatedForms");
        $('#settings_device_ntp_form').restForm("refreshForm");
    
        $('#settings_remote_access_settings_toggle_form').restForm("refreshForm");
        //$('#settings_remote_access_settings_connectivity_form').restForm("refreshForm");
    
        $('#settings_device_led_form').restForm("refreshForm");
        $('#settings_hdd_standby_time_form').restForm("refreshForm");
        $('#settings_time_machine_form').restForm("refreshForm");
    
        //$('#update_time_machine_form').restForm("refreshForm");
    
        //gCapacity_GB = get_storage_capacity();

    }

}
*/

/* Legacy Sequoia
function setTimeMachineSlider(current_share_max_capacity_GB) {

    // remove old slider if applicable
    $("#time_machine_slider").slider("destroy");

    // create new slider using default settings
    $("#time_machine_slider").slider({
        max: 100,   // 100%
        min: 1,     // 1%   (don't use 0%)
        value: 100,   // default at 100%
        slide: function(event, ui) {
            //var percent_value = $( "#time_machine_slider" ).slider( "option", "value" );

            var percent_value = ui.value;

            value = Math.round (percent_value * current_share_max_capacity_GB);
            if (value > 0) {
                value = Math.round(value / 100);
            }

            valueTxt = ByteSize(value * BYTE_DIVISOR * BYTE_DIVISOR * BYTE_DIVISOR);
            $("#time_machine_slider_value").html(valueTxt + ' (' + percent_value + '%)');
            $("#time_machine_backup_size_limit").val(value * BYTE_DIVISOR);
        }
    });

    // update slider with selected values

    backup_size_limit = parseInt( $("#time_machine_backup_size_limit").val() ); // backup_size_limit is in MB

    // backup_size_limit=0 means max capacity
    if (backup_size_limit == 0) {
        backup_size_limit_GB = current_share_max_capacity_GB;
    }
    else {
        backup_size_limit_GB = Math.round(backup_size_limit / BYTE_DIVISOR);

        if (backup_size_limit_GB > current_share_max_capacity_GB) {
            backup_size_limit_GB = current_share_max_capacity_GB;
        }
    }

    // storage degraded will have current_share_max_capacity_GB=0
    var backup_size_limit_percent = 0;
    if (current_share_max_capacity_GB > 0) {
        backup_size_limit_percent = Math.round((backup_size_limit_GB / current_share_max_capacity_GB) * 100);
        
        if (backup_size_limit_percent == 0) {
            backup_size_limit_percent = 1;  // minimum 1%
            backup_size_limit_GB = Math.round((backup_size_limit_percent * current_share_max_capacity_GB) / 100);
        }
    }
    else {
        // time machine size limit of 0 means 100%
        backup_size_limit_percent = 100;
    }

    // calculate slider display value in ByteSize()
    valueTxt = ByteSize(backup_size_limit_GB * BYTE_DIVISOR * BYTE_DIVISOR * BYTE_DIVISOR);
    $("#time_machine_slider").slider("option", "value", backup_size_limit_percent);  // slider scale is 1-100
    $("#time_machine_slider_value").html(valueTxt + ' (' + backup_size_limit_percent + '%)');

    // calculate new time_machine_backup_size_limit
    $("#time_machine_backup_size_limit").val( Math.round(backup_size_limit_GB * BYTE_DIVISOR) );
} 
*/
 
/* Legacy Sequoia 
function addShareToTimemachineSharelist(data, currentExist) {

    share_name = data.share_name;
    
    newOption = $('#SettingsTimeMachineShareSelect').find("option:first").clone();
    newOption.val(share_name);
    newOption.html(share_name);
    newOption.attr("rel", gCapacity_GB);

    if (data.capacity != null) {
        var share_max_capacity_GB = 0;
        if (data.capacity > 0) {    // share capacity is in MB
            share_max_capacity_GB = Math.round ( parseInt(data.capacity) / BYTE_DIVISOR );
        }
        newOption.attr("rel", share_max_capacity_GB);
    }

    // which one is currently selected
    if (share_name == $("#settings_time_machine_form_backup_share").val()) {
        currentExist = true;
        newOption.attr("selected","selected");

        if (data.capacity != null) {
            if (data.capacity > 0) {    // share capacity is in MB
                current_share_max_capacity_GB = Math.round ( parseInt(data.capacity) / BYTE_DIVISOR );
            }
        }
    }
    else {
        newOption.removeAttr("selected");
    }

    newOption.appendTo('#SettingsTimeMachineShareSelect');

    return currentExist;
}
*/

function finishDevicenameDescriptionChange(formName) {

    // make sure we can ping the server before finishing devicename change
    $.ajaxAPI({
        /*"url": "update_counts?ping",*/
        "url": "system_state",
        "error": function (request, status, error) {

            pingErrorCount++;
            if ((status == 'error') && (pingErrorCount < 5)) {
                setTimeout('finishDevicenameDescriptionChange("'+formName+'");', 5000);
            }
            else {
                showError(formName + '_error');
            }
        },
        "success": function (data) {

            // redirect to ipaddress if browsing via hostname
            url = getURLLocation(location);
            if (isHostname(url)) {
                window.location = 'http://'+gIPAddress;
            }
            else if (formName == 'settings_device_name_form') {
                gDeviceName = $('#settings_device_name_form_machine_name').val();
                updateDeviceTitle();
            }

            $('#'+formName).restForm("processFormSuccess");
            var relatedForms = $('#'+formName).data('restFormSettings').relatedForms;
            for(var i in relatedForms){
        		$('#'+relatedForms[i]).restForm('_hideProcessing', true, false);
        	}
            $('#'+formName).restForm('_hideProcessing', true, true);

        }
    });
}

/* Legacy Sequoia
function getNTPTime(i) {
    if (i <= 3) {
        i++;
        $.ajaxAPI({
            "url": "date_time_configuration",
            "success": function(data) {
                if (data != null && data.date_time_configuration != null) {
                    gDateTime = parseInt(data.date_time_configuration.datetime);
                }
            },
            "complete": function (jqXHR, textStatus) {
                 setTimeout('getNTPTime("'+i+'");', 5000);
            }
        });
    }
}
*/
 
function refreshSettingsHardwareForms() {

    //if ( $("#head_settings_nav_hardware_link").parent().hasClass('selected') ) {

        $('#battery_status_form').restForm("refreshForm");
        $('#battery_settings_power_profile').restForm("refreshForm");

        $('#settings_drive_lock_form').restForm("refreshForm");

        // commented out diagnostics and factory restore, they are no longer part of hardware
        //     $('#diagnostics_tests_form').restForm("refreshForm");
        //     $('#factory_restore_form').restForm("refreshForm");

    //}
}

function resetNavigationSelection(id) {
	$(".nav_ul li").removeClass("current");
	$(id).addClass('current');
}


$(document).ready(function(){
	$('#head_nav_link').click(function(e){
		e.preventDefault();
		e.stopPropagation();
		$('#head_nav').toggle();
		checkOtherToolbarItems('head_nav_link');
		if ($('#head_nav_link').hasClass('selected')){
        	$('#head_nav_link').removeClass('selected');
        }
        else{
        	$('#head_nav_link').addClass('selected');
        }
	});
	
	toolbarItems.head_nav_link = function(){
    	$('#head_nav').toggle();
    	$('#head_nav_link').removeClass('selected');
    };
    
    $(document).click(function(event) { 
	    if($(event.target).parents().index($('#head_nav')) == -1 && $('#head_nav_link').hasClass('selected')) {
	    	$('#head_nav').toggle();
	    	$('#head_nav_link').removeClass('selected');
	    }        
	});
	
    $('#head_settings_nav_device_link').navItem({
        'contentId': 'settings_container',
        'childContent': 'device_container',
        'refreshDataCall': function(){
        	pollingHandler.poll();
        },
        'childContentDisplayCall': function(){
        	refreshSettingsGeneralForms();
        	$('#settings_nav_device_link').parent('li').addClass('selected').siblings().removeClass('selected');
        }
    });
    
    $('#head_settings_nav_device_link').click(function(){
    	$('#head_nav').hide();
    	$('#head_nav_link').removeClass('selected');
    	//$('#nav_settings').css('display','inline-block');
    });

});