

var RAIDConversionInProgress = false;
var RAIDConversionGetInProgress = false;
var raidStatusPoll = 30000; // 30 seconds

var raidConversionErrorCount = 0;
var elapsedTime = '';

var autoUpdateRAIDStatusFailCount = 0;

$(function() {

    $('#NewRaidLINEAR').live('click', function(event) {
        $('#mode_spanning_help').show();
        $('#mode_raid_help').hide();
        $('#raid_buttons').show();
    });

    $('#NewRaidRAID1').live('click', function(event) {
        $('#mode_raid_help').show();
        $('#mode_spanning_help').hide();
        $('#raid_buttons').show();
    });

    /* TODO
    $('#NewRaidLINEAR').live('click', function() {
        $('#NewRAID').val('LINEAR');
        $('#confirm_linear_id').css('display', '');
        $('#confirm_raid1_id').css('display', 'none');
        $('#linear_help_container').css('display', '');
        $('#raid1_help_container').css('display', 'none');

        if ($('#CurrentRAID').val() == 'LINEAR') {
            $('#convert_raid_btn').addClass('ui-state-disabled').attr('disabled', true);
            $('#convert_raid_btn').attr('rel', 'disabled');
        }
        else {
            $('#convert_raid_btn').removeClass('ui-state-disabled').attr('disabled', false);
            $('#convert_raid_btn').attr('rel', 'enabled');
        }

    });

    $('#NewRaidRAID1').live('click', function() {
        $('#NewRAID').val('RAID1');
        $('#confirm_linear_id').css('display', 'none');
        $('#confirm_raid1_id').css('display', '');
        $('#linear_help_container').css('display', 'none');
        $('#raid1_help_container').css('display', '');

        if ($('#CurrentRAID').val() == 'RAID1') {
            $('#convert_raid_btn').addClass('ui-state-disabled').attr('disabled', true);
            $('#convert_raid_btn').attr('rel', 'disabled');
        }
        else {
            $('#convert_raid_btn').removeClass('ui-state-disabled').attr('disabled', false);
            $('#convert_raid_btn').attr('rel', 'enabled');
        }

    });

    $('#edit_raid_config_btn').live('click', function(){
        if (!$('#edit_raid_config_btn').hasClass('ui-state-disabled')) {
            showEditRAIDPanel();
        }
    });

    $('#cancel_convert_raid_btn').live('click', function() {
        hideEditRAIDPanel();
    });

    $('#convert_raid_btn').live('click', function() {
        if ($('#convert_raid_btn').attr('rel') == 'enabled') {
            $('#confirm_raid_conversion').dialog('open');
        }
    });

    $('#safepointLink').live('click', function() {
        $('#confirm_raid_conversion').dialog('close');
        openTab = 1;
        $("#backups_nav").click();
    });

    $('.raid_drive_list_item').live('click', function() {
        doSelectRaidDrive($(this));
    });
    
    $('.raid_drive_list_item').live('keydown', function(event) {
    	if (event.keyCode == 13) {
    		$(this).click();
        }
    });
    */

});

function doSelectRaidDrive(selected){
	$('.raid_drive_list_item').removeClass('selected');
	selected.addClass('selected');
    selected_drivenum = selected.attr('rel');

    openLoaderWithTimeout();

    $.ajax({
        type: 'post',
        url: 'settings/get_raid_details',
        dataType: "json",
        timeout: ajaxTimeout,
        success: function(data) {
            $('#loader').dialog('close');
            if('redirect' in data){
				if('redirect_url' in data){
					window.location = data.redirect_url;
					return;
				}
				else{
					window.location = SITE_BASE_URL+'start_over';
					return;
				}
			}
            else if ('http_code' in data) {

                if (data.http_code == 200) {

                    // clear out old values
                    $('#details_manufacturer').html('');
                    $('#details_drive_model').html('');
                    $('#details_serial_number').html('');
                    $('#details_size').html('');
                    $('#details_smart').html('');

                    $('#details_raid_drive_number').html(selected_drivenum);
                    $('#raid_drive_details').slideDown('slow', function() {
                        resizeObject($('div.auto_resize:visible'));
                    });

                    if (('internal_drive' in data)) {

                        // which drive is selected to display details?
                        var driveselected;
                        for (var i = 0; i < 2; i++) {
                            drive = $('#raid_drive_location_' + i);
                            if (drive.filter(".selected").length) {
                                driveselected = drive.attr('rel');
                                break;
                            }
                        }

                        for (var idx in data.internal_drive) {

                            if (data.internal_drive[idx].location == driveselected) {
                                $('#details_manufacturer').html(data.internal_drive[idx]['manufacture']);
                                $('#details_drive_model').html(data.internal_drive[idx]['model']);
                                $('#details_serial_number').html(data.internal_drive[idx]['serial_number']);
                                $('#details_size').html(data.internal_drive[idx]['drive_size']);

                                // drive smart status
                                smart_status = data.internal_drive[idx]['smart_status'];
                                driveSmart = $('#raidstatus' + smart_status.toUpperCase()).html();
                                if ((typeof(driveSmart) == 'undefined') || (driveSmart === null)){
                                    driveSmart = ucwords(smart_status.toLowerCase());
                                }
                                $('#details_smart').html(driveSmart);
                                
                                // drive start status class
                                driveSmartClass = '';
                                switch (smart_status.toLowerCase()) {
                                    case 'pass': 
                                    case 'good': 
                                        break;
                                    case 'failed':
                                        driveSmartClass = 'raid_status_error';
                                        break;
                                    case 'unknown':
                                    default:
                                        driveSmartClass = 'raid_status_warning';
                                        break;
                                }
                                $('#details_smart').removeClass();
                                if (driveSmartClass !== '') {
                                    $('#details_smart').addClass(driveSmartClass);
                                }

                                break;
                            }
                        }
                    }
                }
                else {
                    showError('get_raid_details_' + data.http_code);
                }
            }
            else {
                showError('get_raid_details_unk');
            }
        },
        error: function(request, status, error) {
            if (status == 'timeout') {
            	showError('get_raid_details_timeout');
            }
            else {
                showError('get_raid_details_unk_error');
            }
            $('#loader').dialog('close');
        }
    });
}

function showEditRAIDPanel() {
    $('#edit_raid_panel').slideDown('slow', function() {
        resizeObject($('div.auto_resize:visible'));
        showRAIDRightPanelDefault();
        focusFirstInput($(this));
    });
    $('#edit_raid_panel').siblings().hide();
}

function showRAIDRightPanelDefault(){
    $('.raid_right_interior_panel .default').siblings().fadeOut();
    $('.raid_right_interior_panel .default').fadeIn('fast');
    $('.raid_drive_list_item').removeClass('selected');
}

function hideEditRAIDPanel() {
	$('#edit_raid_panel').siblings().show();
    //$('#edit_raid_panel_form')[0].reset();
    if ($('#CurrentRAID').val() == 'LINEAR') {
        $('#confirm_linear_id').css('display', 'none');
        $('#confirm_raid1_id').css('display', '');
        $('#linear_help_container').css('display', 'none');
        $('#raid1_help_container').css('display', '');

        $('#NewRaidLINEAR').click();
    }
    else {
        $('#confirm_linear_id').css('display', '');
        $('#confirm_raid1_id').css('display', 'none');
        $('#linear_help_container').css('display', '');
        $('#raid1_help_container').css('display', 'none');

        $('#NewRaidRAID1').click();
    }

    $('#convert_raid_btn').addClass('ui-state-disabled').attr('disabled', true);
    $('#edit_raid_panel').fadeOut();
    $('.right_interior_panel').fadeIn();
}

function doEditRaidFromPanel() {
    alert('doEditRaidFromPanel');
}

function doRAIDConversion() {
    $('#confirm_raid_conversion').dialog('close');

    openLoaderWithTimeout();
    $.ajax({
        type: 'post',
        url: 'settings/start_raid_conversion',
        data: $('#edit_raid_panel_form').serialize(),
        dataType: "json",
        timeout: ajaxTimeout,
        success: function(data) {
            $('#loader').dialog('close');
            if('redirect' in data){
				if('redirect_url' in data){
					window.location = data.redirect_url;
					return;
				}
				else{
					window.location = SITE_BASE_URL+'start_over';
					return;
				}
			}
            else if ('http_code' in data) {

                if (data.http_code == 200) {
                    progressTxt = $('#categoryretrievingstatustxt').html();
                    $("#raid_conversion_progresstxt").html(progressTxt);
                    $("#raid_conversion_progress_steptxt").html('');
                    $("#raid_conversion_percentage").html('');
                    $("#raid_conversion_elapsed_time").html('');
                    $('#raid_conversion_progress').dialog('open');

                    RAIDConversionInProgress = true;
                    processRaidConversion();
                    return;
                }
                else if ((data.http_code == 500) && ('remove_nbytes_size' in data)) {
                    $("#remove_nbytes_size").html(data.remove_nbytes_size + '&nbsp;');
                    showError('start_raid_conversion_space_limitation');
                }
                else {
                    showError('start_raid_conversion_' + data.http_code);
                }
            }
            else {
                showError('start_raid_conversion_unk');
            }
        },
        error: function(request, status, error) {
            if (status == 'timeout') {
            	showError('start_raid_conversion_timeout');
            }
            else {
                showError('start_raid_conversion_unk_error');
            }
            $('#loader').dialog('close');
        }
    });
}

function processRaidConversion() {

    // don't processRaidConversion if RAID Conversion is not in progress
    if (RAIDConversionInProgress === false) {
        return;
    }

    // don't get_raidconversion_status another get is in progress
    if (RAIDConversionGetInProgress === true) {
        setTimeout("processRaidConversion();", raidStatusPoll);
        return;
    }

    RAIDConversionGetInProgress = true;

    $.ajax({
        type: 'post',
        url: 'settings/get_raidconversion_status',
        dataType: "json",
        timeout: ajaxTimeout,
        success: function(data) {

            RAIDConversionGetInProgress = false;

            if('redirect' in data){
				if('redirect_url' in data){
					window.location = data.redirect_url;
				}
				else{
					window.location = SITE_BASE_URL+'start_over';
				}
			}
            else if ('http_code' in data) {

                if (data.http_code == 200)  {

                    if (!('status' in data)) {
                        showError('raid_conversion_unk');
                    }
                    else if (data.status.toLowerCase() == 'converting') {

                        RAIDConversionInProgress = true;
                        raidConversionErrorCount = 0;
    
                        elapsedTime = data.elapsed_time.toString();
                        stepTxt = $('#conversionsteptxt').html() + ' ' + data.step.toString();
    
                        switch(data.category.toLowerCase()){
                        case 'preparing_system' :
                            progressTxt = $('#categorypreparingsystemtxt').html();
                    		break; 
                        case 'converting':
                            progressTxt = $('#categoryconvertingtxt').html();
                    		break; 
                        case 'restoring_system':
                            progressTxt = $('#categoryrestoringsystemtxt').html();
                            break; 
                        default:
                    		//progressTxt = $('#categoryunknowntxt').html();
                            progressTxt = data.category.toString() + '...';
                    		break; 
                        }
                        
                        $("#raid_conversion_progresstxt").html(progressTxt);
                        $("#raid_conversion_progress_steptxt").html(stepTxt);
                        $("#raid_conversion_percentage").html('(' + data.progress + '%)');
                        $("#raid_conversion_elapsed_time").html(elapsedTime);
    
                        setTimeout("processRaidConversion();", 5000);
                        return;
                    }
                    else if (data.status.toLowerCase() == 'conversion_failure') {
                        showError('raid_conversion_failed');
                    }
                    else if (data.status.toLowerCase() == 'conversion_success') {
                        // success
                        $("#raid_conversion_progresstxt").html('');
                        $("#raid_conversion_progress_steptxt").html('');
                        $("#raid_conversion_percentage").html('(100%)');
                        $("#raid_conversion_elapsed_time").html('');
    
                        newRAID = $('#NewRAID').val();
                        $('#CurrentRAID').val( newRAID );
                        $('#edit_raid_panel').siblings().show();
                        $('#convert_raid_btn').addClass('ui-state-disabled').attr('disabled', true);
                        $('#edit_raid_panel').fadeOut();
                        $('.right_interior_panel').fadeIn();
    
                        if (newRAID == 'RAID1') {
                            successmsg = $('#convertraid1successtxt').html();
                        }
                        else {
                            successmsg = $('#convertspansuccesstxt').html();
                        }
                        $("#conversion_success_msg").html(successmsg);
                        $("#total_raid_conversion_elapsed_time").html(elapsedTime);
                        $('#raid_conversion_completed').dialog('open');
                        setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
                       // setTimeout("checkForRAIDConversion();", raid_poll);
                    }
                    else {
                        showError('raid_conversion_unk');
                    }
                }
                else if ('status_code' in data) {
                    raidConversionErrorCount++;
                    if (raidConversionErrorCount <= 5) {
                        setTimeout("processRaidConversion();", 5000);
                        return;
                    }
                    showError('get_raidconversion_' + data.status_code);
                }
                else {
                    raidConversionErrorCount++;
                    if (raidConversionErrorCount <= 5) {
                        setTimeout("processRaidConversion();", 5000);
                        return;
                    }
                    showError('get_raidconversion_' + data.http_code);
                }
            }
            else {
                raidConversionErrorCount++;
                if (raidConversionErrorCount <= 5) {
                    setTimeout("processRaidConversion();", 5000);
                    return;
                }
                showError('get_raidconversion_unk');
            }

            $('#raid_conversion_progress').dialog('close');
            RAIDConversionInProgress = false;
        },
        error: function(request, status, error) {
            if (status == 'timeout') {
            	showError('get_raidconversion_timeout');
            }
            else {
                showError('get_raidconversion_unk_error');
            }
            $('#raid_conversion_progress').dialog('close');
            RAIDConversionInProgress = false;
            RAIDConversionGetInProgress = false;
        }
    });
}

function autoUpdateRAIDStatus(forceUpdate) {

    if (typeof(newCounter) != 'undefined') {
        fastPollCounter = newCounter;
    }

    // don't autoUpdate if RAID Conversion is in progress
    if (RAIDConversionInProgress === true) {
        setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
        return;
    }

    if (typeof(forceUpdate) == 'undefined') {
        // don't autoUpdate if not in the Storage tab
        storage_tab_id = $('#storage_tab').attr('href');
        storage_tab_class = ( $(storage_tab_id).attr('class') );
        if (storage_tab_class == undefined) {
            setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
            return;
        }
        else {
            class_list = storage_tab_class.split(' ');
            for (var idx in class_list) {
                if (class_list[idx] == 'ui-tabs-hide') {
                    setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
                    return;
                }
            }
        }
    }
    
    $.ajax({
        type: 'post',
        url: 'settings/update_raid_status',
        dataType: "json",
        timeout: ajaxTimeout,
        success: function(data) {
            //alert(debug(data));
            if('redirect' in data){

                autoUpdateRAIDStatusFailCount++;
                if (autoUpdateRAIDStatusFailCount <= maxRedirectFailCount) {
                    // ignore redirect failures 3 times for automatic polling
                    setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
                    return;
                }
                else {
                    autoUpdateRAIDStatusFailCount = 0;
                    if('redirect_url' in data){
                        window.location = data.redirect_url;
                        return;
                    }
                    else{
                        window.location = SITE_BASE_URL+'start_over';
                        return;
                    }
                }
            }
            else {
                autoUpdateRAIDStatusFailCount = 0;
            }

            if ('http_code' in data){

                if(data.http_code == 200 || data.http_code == 500){

                    disableEditButton = false;

                    if ('config' in data) {
                        if ('raid_configuration' in data.config) {
                            if (data.config.raid_configuration.toLowerCase() == 'linear') {
                                raidtype = $('#raidtypemaxcapacitytxt').html();
                            }
                            else if (data.config.raid_configuration.toLowerCase() == 'raid1') {
                                raidtype = $('#raidtypemaxprotectiontxt').html();
                            }
                            else {
                                raidtype = $('#raidstatusUNKNOWN').html();
                                disableEditButton = true;
                            }
                        }
                        $('#raid_type_id').html(raidtype);
                    }

                    if ('status' in data) {
                        raidStatus = $('#raidstatusUNKNOWN').html();
                        raidStatusClass = '';
                        raidRebuildingProgress = '';
                        statusErrorDisplayText = '';
                        if ('raid_status' in data.status) {
                            switch (data.status.raid_status.toLowerCase()) {
                                case 'good': 
                                    break;
                                case 'rebuilding':
                                    raidStatusClass = 'raid_status_inprogress';
                                    raidRebuildingProgress = data.status.raid_rebuilding_progress.toString();
                                    statusErrorDisplayText = $('#raidstatusREBUILDINGstatustxt').html();
                                    break;
                                case 'failed_drive':
                                    raidStatusClass = 'raid_status_error';
                                    statusErrorDisplayText = $('#raidstatusFAILED_DRIVEerrortxt').html();
                                    disableEditButton = true;
                                    break;
                                case 'stopped':
                                case 'failed':
                                    raidStatusClass = 'raid_status_error';
                                    statusErrorDisplayText = $('#raidstatusFAILEDerrortxt').html();
                                    disableEditButton = true;
                                    break;
                                case 'unknown':
                                default:
                                    raidStatusClass = 'raid_status_warning';
                                    break;
                            }
    
                            raidStatus = $('#raidstatus' + data.status.raid_status.toUpperCase()).html();
                            if ((typeof(raidStatus) == 'undefined') || (raidStatus === null)){
                                raidStatus = ucwords(data.status.raid_status.toLowerCase());
                            }

                            if (raidRebuildingProgress !== '') {
                                $("#raid_rebuilding_progressbar_container").removeAttr('style');
                                $("#raid_rebuilding_progresstxt_container").removeAttr('style');
                                $("#raid_rebuilding_progressbar").progressbar('value', raidRebuildingProgress);
                                $("#raid_rebuilding_progresstxt").html(raidRebuildingProgress + '%');
                            }
                            else {
                                $("#raid_rebuilding_progressbar_container").attr('style','display:none;');
                                $("#raid_rebuilding_progresstxt_container").attr('style','display:none;');
                            }
                            if (statusErrorDisplayText !== '') {
                                $("#raid_status_error_text_container").removeAttr('style');
                                $("#raid_status_error_text").html(statusErrorDisplayText);
                            }
                            else {
                                $("#raid_status_error_text_container").attr('style','display:none;');
                            }
                        }
                        $('#raid_status_id').html(raidStatus);

                        $('#raid_status_id').removeClass();
                        if (raidStatusClass !== '') {
                            $('#raid_status_id').addClass(raidStatusClass);
                        }
                    }

                    if ('raid_partition' in data) {

                        driveLabelTxt = $('#raiddrivetxt').html();

                        if ('user_raid_partition' in data.raid_partition) {
                            updateRAIDDriveList(data.raid_partition.user_raid_partition);
                        }
                        else {
                            driveStatus = $('#raidstatusUNKNOWN').html();

                            for (var i=0;i<2;i++) {
                                // default drive location is 1 and 2
                                $('#raid_img_location_' + i).html('');
    
                                // mark drives unknown
                                drive = $('#raid_drive_location_' + i);
                                drive.attr('rel', '');
                                drive.find('.raid_diskname').html(driveLabelTxt + ' ' + (i+1));
                                drive.find('#raid_drive_volume_status').html(driveStatus);
                                drive.find('#raid_drive_volume_status').removeClass();
                                drive.find('#raid_drive_volume_status').addClass('raid_status_warning');
                            }
                        }
                    }

                    if (disableEditButton === true) {
                        $('#edit_raid_config_btn').addClass('ui-state-disabled');
                    }
                    else {
                        $('#edit_raid_config_btn').removeClass('ui-state-disabled');
                    }
                }
            }
            setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
        },
        error: function(request, status, error) {
            /* don't display error pop-up when retrieving update status, just quietly continue
            if (status == 'timeout') {
                showError('update_raid_timeout');
            }
            */
            setTimeout("autoUpdateRAIDStatus();", raidStatusPoll);
        }
    });

}
function checkForRAIDConversion(){

//    if(disabledPolling) {
//        setTimeout("checkForRAIDConversion();", raid_poll);
//        return;
//    }

    $.ajax({
        type: 'post',
        url: 'settings/raid_status',
        dataType: "json",
        timeout: ajaxTimeout,
        success: function(data) {
            if('redirect' in data){
                if('redirect_url' in data){
                    window.location = data.redirect_url;
                    return;
                }
                else{
                    window.location = SITE_BASE_URL+'start_over';
                    return;
                }
            }
            if ('status' in data) {
                if (data.status.toLowerCase() != 'converting') {
                //    setTimeout("checkForRAIDConversion();", raid_poll);
                    return;
                }

                progressTxt = $('#categoryretrievingstatustxt').html();
                $("#raid_conversion_progresstxt").html(progressTxt);
                $("#raid_conversion_progress_steptxt").html('');
                $("#raid_conversion_percentage").html('');
                $('#raid_conversion_progress').dialog('open');
                RAIDConversionInProgress = true;
                processRaidConversion();
            }
            /*
            else {
                // ignore error and check again later
               // setTimeout("checkForRAIDConversion();", raid_poll);
            }
            */
        },
        error: function(request, status, error) {
            /* don't display error pop-up when retrieving progress status, just quietly continue
            if (status == 'timeout') {
                showError('get_raidconversion_status_timeout');
            }
            */
          //  setTimeout("checkForRAIDConversion();", raid_poll);
        }
    });
}

function updateRAIDDriveList(raid_partition) {

    for (var idx in raid_partition) {

        drive_location = raid_partition[idx].location;

        $('#raid_img_location_'+idx).html(drive_location);

        // drive volume status class
        drive_status = raid_partition[idx].status;

        driveStatusClass = '';
        switch (drive_status.toLowerCase()) {
            case 'good': 
                break;
            case 'failed':
                driveStatusClass = 'raid_status_error';
                break;
            case 'unknown':
            default:
                driveStatusClass = 'raid_status_warning';
                break;
        }

        $('#raid_img_location_'+idx).html(drive_location);
        $('#raid_img_location_'+idx).removeClass();
        if (driveStatusClass !== '') {
            $('#raid_img_location_'+idx).addClass(driveStatusClass);
        }

        // drive volume status
        driveStatus = $('#raidstatus' + drive_status.toUpperCase()).html();
        if ((typeof(driveStatus) == 'undefined') || (driveStatus === null)){
            driveStatus = ucwords(drive_status.toLowerCase());
        }

        drive = $('#raid_drive_location_' + idx);
        drive.attr('rel', drive_location);
        drive.find('.raid_diskname').html(driveLabelTxt + ' ' + drive_location);
        drive.find('#raid_drive_volume_status').html(driveStatus);
        drive.find('#raid_drive_volume_status').removeClass();
        if (driveStatusClass !== '') {
            drive.find('#raid_drive_volume_status').addClass(driveStatusClass);
        }
    }
}

