<div id="diagnostic_results" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_SELF_TEST_RESULTS')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
			<div id="diagnostic_good" style="display: none">
                <p><?php echo _('LABEL_DESCR_SELF_TEST_PASSED'); ?></p>
            </div>
			<div id="diagnostic_not_complete" style="display: none">
				<ul>
					<li><?php echo _('LABEL_DESCR_SELF_TEST_DID_NOT_COMPLETE'); ?></li>
				</ul>
			</div>
			<div id="diagnostic_aborted" style="display: none">
                <p><?php echo _('LABEL_DESCR_SELF_TEST_CANCELLED'); ?></p>
            </div>
			<div id="diagnostic_unknown" style="display: none">
                <p><?php echo _('ERROR_INTERNAL_SERVER_ERROR'); ?></p>
            </div>
			<div id="diagnostic_bad" style="display: none">
				<ul>
					<li><span id="diagnostic_bad_msg"></span></li>
					<li><?php echo _('ERROR_AVATAR_DIAGNOSTIC_TEST_FAILED_SUPPORT'); ?></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="diagnostic_results_close_button"  class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>