<?php
//get hostname
$hostName = '';
if (function_exists(gethostname)){
	$hostName = gethostname();
}else{
	$hostName = php_uname('n');
}
//get host address user input. we seem to have an issue where the icon url needs to be the same as where the user came from (i.e. if user used ip address, we need to use ip address)
$userEnteredHostName = $_SERVER['HTTP_HOST'];
//$iconFileUrl = 'http://'.strtolower($hostName).'/UI/img/favicon.ico';
$iconFileUrl = 'http://'.$userEnteredHostName.'/UI/img/mypassportwireless.ico';
//determine os, to see if we can use file://// or smb://
$user_agent = getenv("HTTP_USER_AGENT");

$url = '';
if(strpos($user_agent, "Win") !== FALSE){
	$url = 'file:////'.$hostName;
}
else{
	$url = 'smb://'.$hostName;
}

$outputString = '[{000214A0-0000-0000-C000-000000000046}]'."\n".
'Prop4=31,'.$hostName."\n".
'Prop3=19,11'."\n".
'[{A7AF692E-098D-4C08-A225-D433CA835ED0}]'."\n".
'Prop5=3,0'."\n".
'Prop9=19,0'."\n".
'[InternetShortcut]'."\n".
'URL='.$url.'/Public'."\n".
'IDList='."\n".
'IconFile='.$iconFileUrl."\n".
'IconIndex=0'."\n".
'[{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}]'."\n".
'Prop5=8,Microsoft.Website.9CB8E698.C9795A8C';




// headers to send your file
header("Content-Type: text/url");
header("Content-Length: " . strlen($outputString));
header('Content-Disposition: attachment; filename="' . $hostName . '.url"');

echo $outputString;
