<div id="<?php echo $identifier?>_content" class="edit_container_box">
	<h2><?php echo _($title)?></h2>
    <?php $view->LoadViews();$view->LoadContents();?>
</div>