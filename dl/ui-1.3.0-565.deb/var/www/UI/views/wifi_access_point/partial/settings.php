<!--
<div id="wifi_settings" class="edit_container_box">
    <h2><?php echo _("Connection Settings");?></h2>
    <div class="content_row">
        <form id="wifi_settings_form">
            <label><?php echo _('Connection Type')?></label>
            <div class="selectBox defaultfont">
                <select id="wifi_connection_mode" name="connection_mode">
                    <option value="direct">Direct Connection</option>
                    <option value="hotspot">Home Network</option>
                    <option value="hotspot">Hotspot</option>
                </select>
                <span id="wifi_settings_wifi_connection_mode" class="original_settings"></span>
            </div>
        </form>
    </div>
</div>

<div id="remembered_connection_settings" class="edit_container_box">
    <h2><?php echo _("Remembered Connection");?></h2>
    <div class="content_row">
        <label><?php echo _('Remembered Networks')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('TOOLTIP_SETTINGS_BATTERY_PRIORITY')?></div></div></div></label>
        <button id="wifi_ap_profile_list_btn"><?php echo _('BUTTON_REMOVE_CONNECTIONS')?></button><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_TOOLTIP_REMOVE_CONNECTIONS");?></div></div></div>
    </div>
</div>
-->
