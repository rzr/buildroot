var capacity_jqplot;
var jqplotData = [];
var gMediaCountTotal = [];

$(document).ready(function(){

	var storageUpdateHandler = {
			updateInProgress:false,
			update: function(useQueue){
				var $this = this;
		    	if ($this.updateInProgress) {
		            return;
		        }
		        $this.updateInProgress = true;
		    	var ajaxAPIOptions = {
					"url": "storage_usage",
		            "timeout": ajaxTimeout,
					"success": function(data, textStatus, jqXHR) {

		                var totalFree = 0;
		                var size = 0;
		                var usage = 0;
		                var photos = 0;
		                var music = 0;
		                var video = 0;
		                var other = 0;

		                if (data != null && data.storage_usage != null) {
		                    if (data.storage_usage.size != '') {
		                        size = data.storage_usage.size;
		                        gCapacity = size;
		                    }
		                    if (data.storage_usage.usage != '') {
		                        usage = data.storage_usage.usage;
		                        gUsage = usage;
		                    }
		                    if (data.storage_usage.photos != '') {
		                        photos = data.storage_usage.photos;
		                    }
		                    if (data.storage_usage.music != '') {
		                        music = data.storage_usage.music;
		                    }
		                    if (data.storage_usage.video != '') {
		                        video = data.storage_usage.video;
		                    }
		                    if (data.storage_usage.other != '') {
		                        other = data.storage_usage.other;
		                    }
		                }

		                var totalFreeTxt;
		                if (size - usage > 0) {
		                    totalFreeTxt = ByteSize(size - usage);
		                }
		                else {
		                    totalFreeTxt = ByteSize(0);
		                }
		                    
		                totalFree_parts = totalFreeTxt.split(' ');
		                totalFree = totalFree_parts[0];
		                totalFreeByteType = totalFree_parts[1];

		        	    $('#dashboard_storage_information_space_available_total_text').text(totalFree);
		        	    $('#dashboard_storage_information_space_type').text(totalFreeByteType);

		                $('#dashboard_storage_information_space_type').show();
		                $("#dashboard_storage_information_text_free").show();

		                adjustStorageInformationStorageGraph({
		                    photos: photos, 
		                    music: music, 
		                    videos: video,
		                    /*backup: 0,*/
		                    other: other,
		                    capacity: size,
		                    usage: usage
		                });
		                if (size > 0) {
		                    // data.storage_usage.size is Bytes
		                    gCapacity_GB = parseInt(size / BYTE_DIVISOR / BYTE_DIVISOR / BYTE_DIVISOR);

		                    percentFree = Math.round((size - usage) / gCapacity * 1000) / 10;
		                    deviceFreeSpace = percentFree + '% ';

		                    if (gFreeSpaceBad == true) {
		                        deviceFreeSpace += '('+ dictionaryList['lowFreeSpace'] + ')';
		                        $('#dashboard_diagnostics_free_space').addClass('warning');
		                    }

		                    $('#dashboard_diagnostics_free_space').html(deviceFreeSpace);
		                }
		                if (usage > 0) {
		                    // data.storage_usage.usage is Bytes
		                    gUsage_GB = parseInt(usage / BYTE_DIVISOR / BYTE_DIVISOR / BYTE_DIVISOR);
		                }

		                //init_updateUploadFromFile(data);
					},
		            "error": function (request, status, error) {
		                //processAndDisplayError(request.responseText, 'get_storage_usage', request.status);
		                /*
		                if (status == 'error') {
		                    $('#dashboard_storage_information_space_available_total_text').text(dictionaryList['error']);
		                }
		                else {
		                    $('#dashboard_storage_information_space_available_total_text').text(dictionaryList['_unknown']);
		                }
		                */
		                $('#dashboard_storage_information_space_available_total_text').text(dictionaryList['_unknown']);

		                $('#dashboard_storage_information_space_type').hide();
		                $("#dashboard_storage_information_text_free").hide();
		            },
					"complete": function(){
		                $this.updateInProgress = false;
		        	    if ($this.updateCompleteHandler != null){
		        	    	$this.updateCompleteHandler();
		        	    }

						if (gCapacity_GB != 0) {
							var capacityTxt = ByteSize(gCapacity_GB * BYTE_DIVISOR * BYTE_DIVISOR * BYTE_DIVISOR);
							$('#footer_device_capacity').text(capacityTxt + ' ' + dictionaryList['capacity_txt']);
						}
					}
				};
		    	if (typeof useQueue != 'undefined' && useQueue == true){
		    		ajaxQueue.add(ajaxAPIOptions);	
		    	}
		    	else{
		    		$.ajaxAPI(ajaxAPIOptions);
		    	}
			}
	    };
	    
	    dashboardHandler.addUpdateHandle(storageUpdateHandler, 'updateStorage');	


    $('#dashboard_usage_chart').live('click', function(e) { 
        e.preventDefault();

		if ($('.dashboard_capacity_size').is(':visible')) {
			$('.dashboard_capacity_size').hide();
			$('.dashboard_capacity_count').show();
		}
		else {
			$('.dashboard_capacity_size').show();
			$('.dashboard_capacity_count').hide();
		}
    });

});

function adjustStorageInformationStorageGraph(sizes) {
	gMediaCountTotal["videos"] = dictionaryList['_unknown'];
	gMediaCountTotal["music"] = dictionaryList['_unknown'];
	gMediaCountTotal["photos"] = dictionaryList['_unknown'];
	gMediaCountTotal["other"] = dictionaryList['_unknown'];

	$.ajaxAPI({
        "url": 'mediacrawler_status',
        "type": "GET",
        "success": function(data){
			if (data != null && data.mediacrawler_status != null && data.mediacrawler_status.volumes != null){
				getMediaCrawlerStatus(data);
			}
        },
        "complete": function (jqXHR, textStatus) {
            adjustCapacityStorageGraph(sizes);
        }
    });
}

function adjustCapacityStorageGraph(sizes) {
	$("#dashboard_usage_chart").fadeIn();
    jqplotData['free'] = 0;
    jqplotData['videos'] = 0;
    jqplotData['music'] = 0;
    jqplotData['photos'] = 0;
    jqplotData['other'] = 0;

    jqplotData['free_bytes'] = '';
    jqplotData['videos_bytes'] = '';
    jqplotData['music_bytes'] = '';
    jqplotData['photos_bytes'] = '';
    jqplotData['other_bytes'] = '';
    
	//get total size
    var totalSize = 0;
    var firstSizeKey, lastSizeKey;
    var key;
    for (key in sizes) {
        if (sizes.hasOwnProperty(key)) {
            totalSize += parseInt(sizes[key]);
            if (firstSizeKey == null) {
                firstSizeKey = key;
            }
            lastSizeKey = key;
        }
    }
    //assign percentages
    var capacity = parseInt(sizes['capacity']);
    var usage = parseInt(sizes['usage']);
    if (capacity > 0) {

    	jqplotData['free'] = Math.round((capacity - usage) / capacity * 10000) / 100;
        jqplotData['free_bytes'] = ByteSize(capacity - usage);

        for (key in sizes) {
            if (sizes.hasOwnProperty(key)) {
                // skip capacity and usage key
                if (key == 'capacity' || key == 'usage') {
                    continue;
                }
                
                var size = parseInt(sizes[key]);
                var percent = Math.round(size / capacity * 10000) / 100;
                var sizeBytes = ByteSize(size);

                if (size > 0 && percent <= 0.1) {
                    jqplotData[key] = 0.1;
                }
                else {
                    jqplotData[key] = percent;
                }

                jqplotData[key+'_bytes'] = sizeBytes;
            }
        }

		//set up capacity chart
	    var Data = [
            ['<span class="dashboard_capacity_icon dashboard_capacity_icon_videos"/>' + dictionaryList['VideosTxt'] + '</span>&nbsp;&nbsp;&nbsp;<span class="dashboard_capacity_size capacity_light_txt">' + jqplotData['videos_bytes'] + '</span><span class="dashboard_capacity_count capacity_light_txt">' + gMediaCountTotal['videos'] + ' ' + dictionaryList['totalTxt'] + '</span>', jqplotData['videos']],
            ['<span class="dashboard_capacity_icon dashboard_capacity_icon_music"/>' + dictionaryList['MusicTxt'] + '</span>&nbsp;&nbsp;&nbsp;<span class="dashboard_capacity_size capacity_light_txt">' + jqplotData['music_bytes'] + '</span><span class="dashboard_capacity_count capacity_light_txt">' + gMediaCountTotal['music'] + ' ' + dictionaryList['totalTxt'] + '</span>', jqplotData['music']],
            ['<span class="dashboard_capacity_icon dashboard_capacity_icon_photos"/>' + dictionaryList['PhotosTxt'] + '</span>&nbsp;&nbsp;&nbsp;<span class="dashboard_capacity_size capacity_light_txt">' + jqplotData['photos_bytes'] + '</span><span class="dashboard_capacity_count capacity_light_txt">' + gMediaCountTotal['photos'] + ' ' + dictionaryList['totalTxt'] + '</span>', jqplotData['photos']],
            ['<span class="dashboard_capacity_icon dashboard_capacity_icon_other"/>' + dictionaryList['OtherTxt'] + '</span>&nbsp;&nbsp;&nbsp;<span class="dashboard_capacity_size capacity_light_txt">' + jqplotData['other_bytes'] + '</span><span class="dashboard_capacity_count capacity_light_txt">' + gMediaCountTotal['other'] + ' ' + dictionaryList['totalTxt'] + '</span>', jqplotData['other']],
            ['<span class="dashboard_capacity_icon dashboard_capacity_icon_free_space"/>' + dictionaryList['FreeSpaceTxt'] + '&nbsp;&nbsp;&nbsp;<span class="capacity_light_txt">' + jqplotData['free_bytes'] + '</span>', jqplotData['free']],
	    ];
	    
	    capacity_jqplot = $.jqplot ('dashboard_usage_chart', [Data], { 
	        seriesDefaults: {
	            shadow: false, 
	            // Make this a donut chart.
	            renderer: $.jqplot.DonutRenderer,
	            rendererOptions: { 
	                sliceMargin: 0, 
	                showDataLabels: false,
	                highlightMouseOver: false,
					startAngle: -90
	            }
	        }, 
            seriesColors: [ "#CC505F", "#3CA570", "#EDD058", "#599DC6", "#A7AFAE"  ],
            legend: { 
                show: true,
                fontFamily: "Arial, Verdana, Helvetica",
                fontSize: "16px",
                location: 'e',
                background: 'none',
                border: 'none',
                showSwatch: false       // not working, override in main.css
            },
	        grid: { drawBorder: false }
	    });
        capacity_jqplot.redraw();
    
        $('.jqplot-table-legend .capacity_light_txt').html(function(i, v){
            return v.replace(/(\d)/g, '<span class="number">$1</span>');
        });
        
		$("#dashboard_storage_information_text").fadeIn();
    }
}

function getMediaCrawlerStatus(data) {
    var mediaProcessed = 0;
    var mediaTotal = 0;
    var i;
    var mediacrawler_state = '';

	if (data != null && data.mediacrawler_status != null && data.mediacrawler_status.volumes != null){	
		
		if( Object.prototype.toString.call( data.mediacrawler_status.volumes.volume ) != '[object Array]' ){   // only 1 volume
	
			if (data.mediacrawler_status.volumes.volume != null) {

				mediacrawler_state = data.mediacrawler_status.volumes.volume.volume_state;
				
				for(i in data.mediacrawler_status.volumes.volume.categories.category){
					media_transcoded_count = parseInt(data.mediacrawler_status.volumes.volume.categories.category[i].transcoded_count);
					media_total = parseInt(data.mediacrawler_status.volumes.volume.categories.category[i].total);

					mediaProcessed += media_transcoded_count;
					mediaTotal += media_total;

					mediaType = data.mediacrawler_status.volumes.volume.categories.category[i].category_type;
					gMediaCountTotal[mediaType] = media_total;
				}
			}
		}
		else {
	
			var mediaCount = new Array();
			var mediaCountTotal = new Array();
			var media = ["videos", "music", "photos", "other"]; // don't use dictionary, these are API returned values prefix
	
			for(i in media){
				mediaType = media[i];
				mediaCount[ mediaType ] = 0;
				mediaCountTotal[ mediaType ] = 0;
			}
	
			for(i in data.mediacrawler_status.volumes.volume){

				var current_volume_mediacrawler_state = data.mediacrawler_status.volumes.volume[i].volume_state.toLowerCase();
                switch (current_volume_mediacrawler_state) {
                case "error":
                    mediacrawler_state = 'error';
                    break;
                case "extracting":
                case "transcoding":
                case "running":
                    if ((mediacrawler_state != 'error') && (mediacrawler_state != 'unknown')) {
                        mediacrawler_state = 'building';
                    }
                    break;
                case "scanning":
                    if ((mediacrawler_state != 'error') && (mediacrawler_state != 'unknown') && (mediacrawler_state != 'building')) {
                        mediacrawler_state = 'scanning';
                    }
                    break;
                case "paused":
                case "idle":
                case "complete":
                    if ((mediacrawler_state != 'error') && (mediacrawler_state != 'unknown')&& (mediacrawler_state = 'building') && (mediacrawler_state != 'scanning')) {
                        mediacrawler_state = 'idle';
                    }
                    break;
                default:
                    if (mediacrawler_state != 'error') {
                        mediacrawler_state = 'unknown';
                    }
                    break;
                }

				for(var j in data.mediacrawler_status.volumes.volume[i].categories.category){
					media_transcoded_count = parseInt(data.mediacrawler_status.volumes.volume[i].categories.category[j].transcoded_count);
					media_total = parseInt(data.mediacrawler_status.volumes.volume[i].categories.category[j].total);

					mediaProcessed += media_transcoded_count;
					mediaTotal += media_total;

					mediaCount[ data.mediacrawler_status.volumes.volume[i].categories.category[j].category_type ] += media_transcoded_count;
					mediaCountTotal[ data.mediacrawler_status.volumes.volume[i].categories.category[j].category_type ] += media_total;
				}
			}
	
			for(i in media){
				mediaType = media[i];
				gMediaCountTotal[mediaType] = mediaCountTotal[ mediaType ];
			}
		}

		//$('#mediacrawler_progress').hide();
        switch (mediacrawler_state) {
        case "error":
            gMediaCrawlerScanningState = 'error';
			gMediaCrawlerScanningStateMsg = dictionaryList['error'];
            break;
        case "running":
        case "building":
        case "extracting":
        case "transcoding":
            gMediaCrawlerScanningState = 'building';
            if ((mediaTotal == 0) || (mediaProcessed >= mediaTotal)) {
                //$('#mediacrawler_progress').text(dictionaryList['additional_transcoding_inprogress']);
				gMediaCrawlerScanningStateMsg = dictionaryList['building_preview_images'];
            }
            else {
                //$('#mediacrawler_progress').text(dictionaryList['building_inprogress']);
				gMediaCrawlerScanningStateMsg = dictionaryList['building_inprogress'];
            }
            //$('#mediacrawler_progress').show();
            break;
        case "scanning":
            gMediaCrawlerScanningState = 'scanning';
            //$('#mediacrawler_progress').text(dictionaryList['scanning_inprogress']);
            //$('#mediacrawler_progress').show();
			gMediaCrawlerScanningStateMsg = dictionaryList['scanning_inprogress'];
            break;
        case "paused":
        case "idle":
        case "complete":
            gMediaCrawlerScanningState = 'idle';
			gMediaCrawlerScanningStateMsg = dictionaryList['idle'];
            break;
        case "unknown":
        default:
            gMediaCrawlerScanningState = 'unknown';
			gMediaCrawlerScanningStateMsg = dictionaryList['_unknown'];
            break;
        }
	}
}
