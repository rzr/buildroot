<div class="content_row">
    <!--<label><?php echo _('CONTENT_SETTINGS_LABEL_SEND_LOGS_TO_SUPPORT')?>-->
    <button id="request_support_btn"><?php echo _('CONTENT_SETTINGS_LABEL_SEND_LOGS_TO_SUPPORT')?></button>
    <div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('TOOLTIP_SETTINGS_SYSTEM_LOGS')?></div></div></div>
    <!--</label>-->
</div>

