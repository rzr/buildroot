<div id="dashboard_information_count_container">
    <div id="dashboard_mobile_devices_box" class="dashboard_medium_box dashboard_box">
    	<div class="header"><h3><?php echo _('CONTENT_HOME_MEDIUM_BOX_TITLE_CLOUD_DEVICES')?></h3></div>
        <div id="dashboard_mobile_devices_count" class="dashboard_count"></div>
        <div class="footer"><a href="#" id="dashboard_create_mobile_device_link"></a></div>
    </div>
    <div id="dashboard_users_box" class="dashboard_medium_box dashboard_box">
        <div class="header"><h3><?php echo _('CONTENT_HOME_MEDIUM_BOX_TITLE_USERS')?></h3></div>
        <div id="dashboard_users_count" class="dashboard_count"></div>
        <div class="footer"><a href="#" id="dashboard_create_user_link"></a></div>
    </div>
    <div id="dashboard_shares_box" class="dashboard_medium_box dashboard_box">
    	<div class="header"><h3><?php echo _('CONTENT_HOME_MEDIUM_BOX_TITLE_SHARES')?></h3></div>
        <div id="dashboard_shares_count" class="dashboard_count"></div>
        <div class="footer"><a href="#" id="dashboard_create_share_link"></a></div>
    </div>
	<div id="dashboard_media_scan_box" class="dashboard_medium_box dashboard_box">
		<div class="header"><h3><span id="dashboard_media_scan_box_title"><?php echo _('CONTENT_HOME_MEDIUM_BOX_TITLE_MEDIA_SCAN')?></span></h3></div>
        <div id="dashboard_content_scan" class="dashboard_count dashboard_content_status_text overflow_hidden_nowrap_ellipsis"></div>
        <div class="footer"><a href="#" id="dashboard_media_info_link"></a></div>
    </div>
</div>
