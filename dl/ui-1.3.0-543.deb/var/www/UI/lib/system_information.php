<?php
class SystemInformation{
    private $system_information;
    private $host = 'http://127.0.0.1';
    private $apiPath = '/api/2.1/rest/';

    private function initSystemInformation(){
        $this->system_information = array();
        $url = $this->host.$this->apiPath.'system_information';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $xml = simplexml_load_string($result);
        if ($xml !== false){
            $this->system_information = $xml;
        }
    }

    public function getModelName(){
        if (!isset($this->system_information)){
            $this->initSystemInformation();
        }
        $model_name = trim($this->system_information->model_name);
        return $model_name;
    }

    public function getModelNumber(){
        if (!isset($this->system_information)){
            $this->initSystemInformation();
        }
        $model_number = trim($this->system_information->model_number);
        return $model_number;
    }

    public function getSerialNumber(){
        if (!isset($this->system_information)){
            $this->initSystemInformation();
        }
        $serial_number = trim($this->system_information->serial_number);
        return $serial_number;
    }

    public function getMACAddress(){
        if (!isset($this->system_information)){
            $this->initSystemInformation();
        }
        $mac_address = trim($this->system_information->mac_address);
        return $mac_address;
    }

}
?>
