
var reconnectWirelessInProgress = false;
var reconnectWirelessTimeOutMax = 600000; // 10 minutes
var reconnectWirelessStartTimeStamp = 0;
var startReconnectWirelessDelay = 10000; // 10 seconds
var signInToOtherNetwork = false;

var wifi_signin_ap_remembered = false;
var wifi_signin_ap_trusted = false;
var wifi_signin_with_wps_pin = false;
var wifi_signin_password_required = false;
var wifi_signin_other_password_required = false;
var wifi_edit_config_password_required = false;

var signInWifiInProgress = false;
var signInWifiTimeOutMax = 120000; // 120 seconds
var signInWifiStartTimeStamp = 0;
var signInWifiDelay = 5000; // 5 seconds

var wifi_client_access_points_inprogress = false;
var connectToNewNetwork = false;
var current_ap_connected = false;
var wifiApListAutoClickFlag = true;
var modifyCurrentNetwork = false;

var checkInternetConnectivityCount = 0;
var maxCheckInternetConnectivityCount = 3;

$(document).ready(function(){

    /* Polling for Internet Access not supported
    pollingHandler.addPoll("internet_access", ["wifi_container"], internetAccessPollSuccess, InternetAccessPollError, pollingFrequency); 
    */ 

    $('#head_settings_nav_network_link').navItem({
        'contentId': 'wifi_container',
        'refreshDataCall': function(){

            // Set Selection
            resetNavigationSelection('#head_settings_nav_network_link');

            pollingHandler.poll();
            updateConnectedDevices();
            //checkCurrentWifiClientConnection();
            //showWifiClientAccessPointListContainer();

            checkWiFiEnabled();

            if (gSSIDName == '') {
                getSSIDName();
            }
        }
    });

    $('#wifi_client_ap_submit_btn').live('click', function(){
        if (!$(this).hasClass('ui-state-disabled')) {
            var dialogTitle = dictionaryList['sign_in_title'];
            var ssidName = $('#wifi_signin_form_ssid').text();
            if (signInToOtherNetwork || wifi_signin_password_required || connectToNewNetwork) {
                if (signInToOtherNetwork) {
                    dialogTitle = dialogTitle.replace('{0}',dictionaryList['other_network']);
                    $('#wifi_signin_to_other_network_overlay_title').text(dialogTitle);
                    $('#wifi_signin_to_other_network_overlay').dialog("open");
                }
                else {
                    if ((connectToNewNetwork) && (ssidName == gWANSSIDName)) {
                        dialogTitle = dictionaryList['modify_wifi_network_title'];
                        dialogTitle = dialogTitle.replace('{0}', ssidName);
                        $('#wifi_modify_overlay_title').text(dialogTitle);
                        $('#wifi_modify_overlay').dialog("open");
                    }
                    else {
                        dialogTitle = dialogTitle.replace('{0}', ssidName);
                        $('#wifi_signin_overlay_title').text(dialogTitle);
                        $('#wifi_signin_overlay').dialog("open");
                    }
                }
            }
            else {
                // if selecting an unsecured AP, just show the Connect To dialog
                dialogTitle = dialogTitle.replace('{0}', ssidName);
                $('#wifi_signin_overlay_title').text(dialogTitle);
                $('#wifi_signin_overlay').dialog("open");
            }
        }
    });

    /*
    $('#wifi_setup_connection_cancel_btn').live('click', function(){

        $('.wifi_ap_list_item').removeClass('selected');
        //disableIdTag('#wifi_client_ap_submit_btn');

        resetNetworkPage();
    });
    */

    $('#wifi_signin_close_button').live('click', function(e){
        e.preventDefault();

        $('#wifi_signin_form').restForm('reset');

        wifiApListAutoClickFlag = false;
        $('.wifi_ap_list_item.selected').click();
        wifiApListAutoClickFlag = true;

        $('.wifi_ap_list_item').removeClass('selected');

		$('#wifi_signin_overlay').dialog('close');
	});

    $('#wifi_signin_save_button').live('click', function(e){

        e.preventDefault();

        // just mark remembered=false for the given network
        if (!$('#wifi_signin_form_remember_network').hasClass('ui-state-disabled')) {
            if ($('#wifi_signin_form_remember_network').val() == 'false') {
                $('#wifi_signin_overlay').dialog('close');
                var mac_address = $('#wifi_signin_form_mac_address').val();
                forgetThisRememberedNetwork(mac_address);
                return;
            }
        }

        // validate form so error message is displayed before warning message
        before_wifi_signin_form_submit();

        if (!gFoundMe) {
            // connect Avatar to new Home from Computer on home router
            if ($('#wifi_signin_form_trusted').val() == 'true') {
                if(validate('#wifi_signin_form')){
                    $('#wifi_signin_overlay').dialog('close');
                    if ((connectToNewNetwork) && (gTrustedNetwork)) {
                        $('#switch_home_to_hotspot_or_home').show();
                        $('#connect_or_switch_to_home_mode').hide();
                    }
                    else {
                        $('#switch_home_to_hotspot_or_home').hide();
                        $('#connect_or_switch_to_home_mode').show();
                    }

                    $('#wifi_signin_confirmation_overlay').dialog('open');
                }
                else {
                    enableIdTag('#wifi_signin_form_password');
                    enableIdTag('#wifi_signin_form_password_show');
                }
            }
            // connect Avatar to new Hotspot from Computer on home router
            else {
                $('#wifi_signin_overlay').dialog('close');
                if ((connectToNewNetwork) && (gTrustedNetwork)) {
                    $('#switch_home_to_hotspot_or_home').show();
                    $('#connect_or_switch_to_home_mode').hide();
                    $('#wifi_signin_confirmation_overlay').dialog('open');
                }
                else {
                    $('#wifi_signin_form').submit();
                }
            }
        }
        else {
            // Direct Connect -> Home or Hotspot the same now
            if(validate('#wifi_signin_form')){
                $('#wifi_signin_overlay').dialog('close');
                $('#wifi_signin_form').submit();
            }
            else {
                enableIdTag('#wifi_signin_form_password');
                enableIdTag('#wifi_signin_form_password_show');
            }
        }
    });

    $('#wifi_modify_close_button').live('click', function(e){
        e.preventDefault();
        $('.wifi_ap_list_item').removeClass('selected');

		$('#wifi_modify_overlay').dialog('close');
	});

    // these are used in Connect To dialogs
    $('.wifi_settings_network_mode_static_button').live('click', function(e){
        e.preventDefault();
        if (!$('.wifi_settings_network_mode_static_button').hasClass("button-selected")) {
            $(".wifi_settings_network_mode_dhcp_button").removeClass("button-selected");
            $(this).addClass("button-selected");

            $(".wifi_settings_dhcp_enabled").val('false');

            enableIdTag('.wifi_static_network_settings');

            $('.wifi_client_network_settings_dhcp_container').hide();
            $('.wifi_client_network_settings_static_container').show();
        }
    });
    $('.wifi_settings_network_mode_dhcp_button').live('click', function(e){
        e.preventDefault();
        if (!$('.wifi_settings_network_mode_dhcp_button').hasClass("button-selected")) {
            $(".wifi_settings_network_mode_static_button").removeClass("button-selected");
            $(this).addClass("button-selected");

            $(".wifi_settings_dhcp_enabled").val('true');

            disableIdTag('.wifi_static_network_settings');

            $('.wifi_client_network_settings_dhcp_container').show();
            $('.wifi_client_network_settings_static_container').hide();
        }
    });

    $('#wifi_modify_save_button').live('click', function(e){
        e.preventDefault();

        $('#wifi_modify_overlay').dialog('close');

        // just delete the current_wifi_client_connection if forgetting this network
        if ($('#wifi_modify_form_remember_network').val() == 'false') {
            if (!gFoundMe && gTrustedNetwork) {
                $('#wifi_disconnect_confirmation_overlay').dialog('open');
            }
            else {
                var mac_address = $('#wifi_modify_form_mac_address').val();
                forgetThisCurrentConnection(mac_address);
            }
            return;
        }

        var newTrusted = ($('#wifi_modify_form_trusted').val() == 'true');

        if ($('.wifi_settings_network_mode_dhcp_button').hasClass('button-selected')) {
            $('#wifi_modify_SettingIp').removeClass('IPADDRESS');
            $('#wifi_modify_SettingNetmask').removeClass('NETMASK');
    
            $('.wifi_settings_dhcp_enabled').val('true');

            disableIdTag('.wifi_static_network_settings');
        }
        else {
            $('#wifi_modify_SettingIp').addClass('IPADDRESS');
            $('#wifi_modify_SettingNetmask').addClass('NETMASK');
    
            $('.wifi_settings_dhcp_enabled').val('false');
    
            enableIdTag('.wifi_static_network_settings');
        }

        if ($('#wifi_modify_form_trusted').val() == 'false') {
            enableIdTag('.mac_clone_value');

            var clone_mac_enable = $('.mac_clone_value').val();
            if (clone_mac_enable == 'true') {
                $('.cloned_mac_address').val(gMacAddress);
                enableIdTag('.cloned_mac_address');
            }
            else {
                disableIdTag('.cloned_mac_address');
            }
        }
        else {
            disableIdTag('.mac_clone_value');
            disableIdTag('.cloned_mac_address');
        }

        if (!gFoundMe) {
      
            if ((gTrustedNetwork && newTrusted) || (gTrustedNetwork == false && newTrusted == false)) {
                // do nothing
            }
            else if ((gTrustedNetwork) && (newTrusted == false)) {
                $('#modify_wifi_to_home_mode').hide();
                $('#modify_wifi_to_hotspot_mode').show();
                $("#wifi_modify_confirmation_overlay").dialog("open"); 
            }
            else {
                $('#modify_wifi_to_home_mode').show();
                $('#modify_wifi_to_hotspot_mode').hide();
                $("#wifi_modify_confirmation_overlay").dialog("open"); 
            }
        }
        else {
            // Modify Home or Hotspot the same now
            $('#wifi_modify_form').submit();
        }
    });

    $('#wifi_signin_to_other_network_close_button').live('click', function(e){
        e.preventDefault();

        $('#wifi_signin_to_other_network_form').restForm('reset');

        wifiApListAutoClickFlag = false;
        $('.wifi_ap_list_item.selected').click();
        wifiApListAutoClickFlag = true;

        $('.wifi_ap_list_item').removeClass('selected');

        $('#wifi_signin_to_other_network_overlay').dialog('close');
    });

    $('#wifi_signin_to_other_network_save_button').live('click', function(e){

        e.preventDefault();

        before_wifi_signin_to_other_network_form_submit();

        if (!gFoundMe) {
            // connect Avatar to new Home from Computer on home router
            if ($('#wifi_signin_to_other_network_form_trusted').val() == 'true') {
                if(validate('#wifi_signin_to_other_network_form')){
                    //$('#wifi_signin_to_other_network_overlay').dialog('close');
                    if ((connectToNewNetwork) && (gTrustedNetwork)) {
                        $('#connect_or_switch_to_home_mode').hide();
                        $('#switch_home_to_hotspot_or_home').show();
                    }
                    else {
                        $('#connect_or_switch_to_home_mode').show();
                        $('#switch_home_to_hotspot_or_home').hide();
                    }

                    $('#wifi_signin_confirmation_overlay').dialog('open');
                }
                else {
                    enableIdTag('#wifi_signin_to_other_network_form_password');
                    enableIdTag('#wifi_signin_to_other_network_form_password_show');
                }
            }
            // connect Avatar to new Hotspot from Computer on home router
            else {
                //$('#wifi_signin_to_other_network_overlay').dialog('close');
                if ((connectToNewNetwork) && (gTrustedNetwork)) {
                    $('#switch_home_to_hotspot_or_home').show();
                    $('#connect_or_switch_to_home_mode').hide();
                    $('#wifi_signin_confirmation_overlay').dialog('open');
                }
                else {
                    $('#wifi_signin_to_other_network_form').submit();
                }
            }
        }
        else {
            //$('#wifi_signin_to_other_network_overlay').dialog('close');
            //$('#wifi_signin_to_other_network_form').submit();

            // Direct Connect -> Home or Hotspot the same now
            if(validate('#wifi_signin_to_other_network_form')){
                //$('#wifi_signin_to_other_network_overlay').dialog('close');
                $('#wifi_signin_to_other_network_form').submit();
            }
            else {
                enableIdTag('#wifi_signin_to_other_network_form_password');
                enableIdTag('#wifi_signin_to_other_network_form_password_show');
            }
        }
    });

	$('#wifi_edit_config_cancel_button').click(function(){
		$('#wifi_edit_config_overlay').dialog('close');
	});
    
    $('#wifi_edit_config_form_password, #wifi_edit_config_form_password_confirm, #wifi_edit_config_form_password_show').keyup(function (e) {
        if(e.keyCode == 13) {
            $('#wifi_edit_config_save_button').click();
        }
    });
	
    $('#wifi_edit_config_save_button').click(function(){
        before_wifi_edit_config_form_submit();
        $('#wifi_edit_config_form').submit();
    });
    	
	
	$('#settings_wireless_name_form').restForm();
	$('#settings_wireless_security_form').restForm();

	$("#wifi_edit_config_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: "auto",
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_edit_config_overlay_title" class="wizard_dialog_title">'+$('#wifi_edit_config_overlay').attr('title')+'</div>',
        open: function(){
            enableIdTag('#wifi_edit_config_form_password');
            enableIdTag('#wifi_edit_config_form_password_confirm');
            $('#wifi_edit_config_form').find('.display_ssid_password').hide();
            wifi_edit_config_password_required = false;

            // channel and channel_mode are exclusive of each other; enable both for now and will process beforeFormSubmit
            enableIdTag('#wifi_edit_config_form_channel_select');
            enableIdTag('#wifi_edit_config_form_channel_mode');

            $('.show_advanced_options').show();
            $('.hide_advanced_options').hide();
            $('.advanced_options_container').hide();

            $('#wifi_edit_config_form').restForm("refreshForm");
        }
    });
	
    $("#wifi_edit_network_settings_config_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_edit_network_settings_config_overlay_title" class="wizard_dialog_title">'+$('#wifi_edit_network_settings_config_overlay').attr('title')+'</div>',
        open: function(){
            $("#wifi_edit_settings_network_mode_dhcp_button").removeClass("button-selected");
            $('#wifi_edit_settings_network_mode_static_button').removeClass("button-selected");
            $('#wifi_network_settings_dhcp_container').hide();
            $('#wifi_network_settings_static_container').hide();
            
            $('#wifi_edit_network_settings_config_form').restForm("refreshForm");
            $('#network_workgroup_form').restForm("refreshForm");
        }
    });
    $('#wifi_edit_network_settings_config_cancel_button').click(function(){
        if (!$(this).hasClass('ui-state-disabled')) {
            $('#wifi_edit_network_settings_config_overlay').dialog('close');
        }
    });
    $('#wifi_edit_network_settings_config_save_button').click(function(){
        if (!$(this).hasClass('ui-state-disabled')) {
            var updateRequired = true;
            var validateRequired = true;
            var displayNetworkModeChangeMsg = true;
            var currentNetworkMode = $('#NetworkModeEditValue').val();
    
            if ($('#wifi_edit_settings_network_mode_dhcp_button').hasClass('button-selected') && currentNetworkMode == 'dhcp_client') {
                // DHCP to DHCP - no changes
                updateRequired = false;
                validateRequired = false;
            }
            else if ($('#wifi_edit_settings_network_mode_static_button').hasClass('button-selected') && currentNetworkMode == 'static') {
                // Static to Static - some change, no warning message, but must validate
                displayNetworkModeChangeMsg = false;
            }
            else if ($('#wifi_edit_settings_network_mode_dhcp_button').hasClass('button-selected')) {
                // Static to DHCP - change and warning msg, but not validation
                validateRequired = false;
            }
            //else DHCP to Static - change, validate, and warning msg
                
            if (updateRequired) {
                // validate form first so error message is displayed before warning message
                if (validateRequired) {
                    if (validate('#wifi_edit_network_settings_config_form')) {
                        if (displayNetworkModeChangeMsg) {
                            $('#wifi_network_mode_confirmation').dialog('open');
                        }
                        else {
                            changeNetworkSettings();
                        }
                    }
                }
                else if (updateRequired) {
                    $('#wifi_network_mode_confirmation').dialog('open');
                }
            }
            $('#wifi_edit_network_settings_config_overlay').dialog('close');
        }
    });
    	
	$("#wifi_signin_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: "auto",
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_signin_overlay_title" class="wizard_dialog_title">'+$('#wifi_signin_overlay').attr('title')+'</div>',
        open: function(){
        	//$('#wifi_signin_form').restForm('reset');
            enableIdTag('#wifi_signin_form_password');
            enableIdTag('#wifi_signin_form_password_show');
            $('#wifi_signin_form_password_container').show();
            $('#wifi_signin_form_password_show_container').hide();

            disableIdTag('#wifi_signin_wps_pin');
            $('#wifi_signin_wps_pin_container').hide();
            $('#wifi_signin_use_password_button').addClass("button-selected");
            $('#wifi_signin_use_wps_button').removeClass("button-selected");

            if (wifi_signin_ap_trusted) {
                $('#wifi_signin_form_trusted_checkbox').attr('checked',true);
                $('#wifi_signin_form_trusted').val('true');
                $('.settings_mac_clone').hide();
            }
            else {
                $('#wifi_signin_form_trusted_checkbox').attr('checked',false);
                $('#wifi_signin_form_trusted').val('false');
                $('.settings_mac_clone').show();
            }

            $('.wifi_network_settings_mac_address').html(gMacAddress);
            $('.wifi_network_settings_device_name').html(gDeviceName);

            $('.show_advanced_options').show();
            $('.hide_advanced_options').hide();
            $('.advanced_options_container').hide();

            if (wifi_signin_ap_remembered) {
                disableIdTag('#wifi_signin_form_default_remember_network');
                enableIdTag('#wifi_signin_form_remember_network');
                $('#wifi_signin_form_forget_network_container').show();
                $('#wifi_signin_form_remember_network').val('true');
            }
            else {
                enableIdTag('#wifi_signin_form_default_remember_network');
                disableIdTag('#wifi_signin_form_remember_network');
                $('#wifi_signin_form_forget_network_container').hide();
                $('#wifi_signin_form_remember_network').val('false');
            }

            $('.remember_network_show_all').show();
        }
    });

    $("#wifi_modify_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: "auto",
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_modify_overlay_title" class="wizard_dialog_title">'+$('#wifi_modify_overlay').attr('title')+'</div>',
        open: function(){
        	//$('#wifi_modify_form').restForm('reset');
            $('#wifi_modify_form_mac_address').val( $('#wifi_signin_form_mac_address').val() );

            if (gTrustedNetwork) {
                $('#wifi_modify_form_trusted_checkbox').attr('checked',true);
                $('#wifi_modify_form_trusted').val('true');
                $('.settings_mac_clone').hide();
            }
            else {
                $('#wifi_modify_form_trusted_checkbox').attr('checked',false);
                $('#wifi_modify_form_trusted').val('false');
                $('.settings_mac_clone').show();
            }

            $('#wifi_modify_form_forget_network_checkbox').attr('checked',false);
            $('#wifi_modify_form_remember_network').val('true');

            $('.wifi_network_settings_mac_address').html(gMacAddress);
            $('.wifi_network_settings_device_name').html(gDeviceName);

            $('.show_advanced_options').show();
            $('.hide_advanced_options').hide();
            $('.advanced_options_container').hide();

            $('.remember_network_show_all').show();
        }
    });
	
    $("#wifi_signin_to_other_network_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: "auto",
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_signin_to_other_network_overlay_title" class="wizard_dialog_title">'+$('#wifi_signin_to_other_network_overlay').attr('title')+'</div>',
        open: function(){
        	//$('#wifi_signin_to_other_network_form').restForm('reset');
            enableIdTag('#wifi_signin_to_other_network_form_password');
            enableIdTag('#wifi_signin_to_other_network_form_password_show');
            $('#wifi_signin_to_other_network_form').find('.display_ssid_password').hide();
            $('#wifi_signin_to_other_network_form').find('.display_wifi_encryption').hide();
            wifi_signin_other_password_required = false;
            $('#wifi_signin_to_other_network_form_password_container').show();
            $('#wifi_signin_to_other_network_form_password_show_container').hide();

            $('#wifi_signin_to_other_network_form_trusted').val('false');
            $('.settings_mac_clone').show();

            $('.wifi_network_settings_mac_address').html(gMacAddress);
            $('.wifi_network_settings_device_name').html(gDeviceName);

            $('.show_advanced_options').show();
            $('.hide_advanced_options').hide();
            $('.advanced_options_container').hide();
        }
    });

    $("#wifi_signin_confirmation_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_signin_confirmation_overlay_title" class="wizard_dialog_title">'+$('#wifi_signin_confirmation_overlay').attr('title')+'</div>',
        open: function(){
            $('#wifi_signin_confirmation_overlay_save_button').focus();
            
            var waname = '<b><i>'+gWANSSIDName+'</i></b>';
            msg = dictionaryList['wifi_signin_network_changing_msg'].replace('{0}', waname);
            $('#wifi_signin_network_changing_msg').html(msg);
        }
    });

    $('#wifi_signin_confirmation_overlay_cancel_button').click(function(){
        $('.wifi_ap_list_item').removeClass('selected');
        $('#wifi_signin_confirmation_overlay').dialog('close');
    }); 

    $('#wifi_signin_confirmation_overlay_save_button').click(function(){
        $('#wifi_signin_confirmation_overlay').dialog('close');
        if (signInToOtherNetwork) {
            before_wifi_signin_to_other_network_form_submit();
            $('#wifi_signin_to_other_network_form').submit();
        }
        else {
            before_wifi_signin_form_submit();
            $('#wifi_signin_form').submit();
        }
    });

    $("#wifi_modify_confirmation_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_modify_confirmation_overlay_title" class="wizard_dialog_title">'+$('#wifi_modify_confirmation_overlay').attr('title')+'</div>',
        open: function(){
            var waname = '<b><i>'+gWANSSIDName+'</i></b>';
            msg = dictionaryList['wifi_modify_network_changing_msg'].replace('{0}', waname);
            $('#wifi_modify_network_changing_msg').html(msg);
        }
    }); 

    $('#wifi_modify_confirmation_overlay_cancel_button').click(function(e){
        e.preventDefault();
        $('.wifi_ap_list_item').removeClass('selected');

        $('#wifi_modify_confirmation_overlay').dialog('close');
    }); 

    $('#wifi_modify_confirmation_overlay_save_button').click(function(){
        $('#wifi_modify_confirmation_overlay').dialog('close');
        $('#wifi_modify_form').submit();
    }); 

    $("#wifi_signin_complete_message_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        closeOnEscape:false,
        title: '<div id="wifi_signin_complete_message_overlay_title" class="wizard_dialog_title">'+$('#wifi_signin_complete_message_overlay').attr('title')+'</div>'
    });

    $("#wifi_disable_confirmation_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_disable_confirmation_overlay_title" class="wizard_dialog_title">'+$('#wifi_disable_confirmation_overlay').attr('title')+'</div>',
        open: function(){
            var waname = '<b><i>'+gWANSSIDName+'</i></b>';
            msg = dictionaryList['wifi_disable_confirmation'].replace('{0}', waname);
            $('#wifi_disable_confirmation').html(msg);
        }
    });

    $('#wifi_disable_confirmation_overlay').bind('dialogclose', function(e) {
        if(e.keyCode == 27){
            $('#WifiEnableToggle').attr('checked',true);
            $('#WifiEnableValue').val('false');
        }
    });

    $('#wifi_disable_confirmation_overlay_cancel_button').click(function(){
    	$('#WifiEnableToggle').attr('checked',true);
        $('#WifiEnableValue').val('false');
        $('#wifi_disable_confirmation_overlay').dialog('close');
    });

    $('#wifi_disable_confirmation_overlay_save_button').click(function(){
        $('#wifi_enabled_form').submit();
        $('#wifi_disable_confirmation_overlay').dialog('close');
    });

    $("#wifi_disconnect_confirmation_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="wifi_disconnect_confirmation_overlay_title" class="wizard_dialog_title">'+$('#wifi_disconnect_confirmation_overlay').attr('title')+'</div>',
        open: function(){
            var waname = '<b><i>'+gWANSSIDName+'</i></b>';
            msg = dictionaryList['wifi_disconnect_network_changing_msg'].replace('{0}', waname);
            $('#wifi_disconnect_network_changing_msg').html(msg);
        }
    });

    $('#wifi_disconnect_confirmation_overlay_cancel_button').click(function(){
        $('#wifi_disconnect_confirmation_overlay').dialog('close');
    });

    $('#wifi_disconnect_confirmation_overlay_save_button').click(function(){
        $('#wifi_disconnect_confirmation_overlay').dialog('close');

        var mac_address = $('#wifi_modify_form_mac_address').val();
        forgetThisCurrentConnection(mac_address);
    });
    
    	
    $("#wifi_disable_disconnect_complete_message_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 700,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        closeOnEscape:false,
        title: '<div id="wifi_disable_disconnect_complete_message_overlay_title" class="wizard_dialog_title">'+$('#wifi_disable_disconnect_complete_message_overlay').attr('title')+'</div>'
    });
    
    $('#wifi_modify_form').restForm({
        'dialogName': 'wifi_modify_overlay',
        'processFormSuccessCallback':function(data, textStatus, jqXHR){
            $('#wifi_modify_overlay').dialog('close');

            modifyCurrentNetwork = true;
            if (connectToNewNetwork && !gFoundMe) {
                verifyCurrentWifiClientConnectionFromHomeRouter();
            }
            else {
                verifyCurrentWifiClientConnection();
            }
		}
    });

	$('#wifi_signin_form').restForm({
    	'dialogName': 'wifi_signin_overlay',
        'processFormSuccessCallback':function(data, textStatus, jqXHR){
            $('#wifi_signin_overlay').dialog('close');

            modifyCurrentNetwork = false;
            if (connectToNewNetwork && !gFoundMe) {
                verifyCurrentWifiClientConnectionFromHomeRouter();
            }
            else {
                verifyCurrentWifiClientConnection();
            }

            disableIdTag('#wifi_signin_wps_pin');
            $('#wifi_signin_use_password_button').addClass("button-selected");
            $('#wifi_signin_use_wps_button').removeClass("button-selected");

            //$('#wifi_signin_form_type_untrusted_button').addClass("button-selected");
            //$('#wifi_signin_form_type_trusted_button').removeClass("button-selected");

            enableIdTag('#wifi_signin_form_password');
            enableIdTag('#wifi_signin_form_password_show');
		},
		'processFormCompleteCallback': function(jqXHR, textStatus){
			$('#wifi_signin_form').restForm('processFormComplete', jqXHR, textStatus);
			//$('#wifi_signin_overlay').dialog('close');

            /* will handle in beforeProcessForm
            $('#wifi_signin_form_password_show').removeClass('NOTEMPTY');
            $('#wifi_signin_form_password').removeClass('NOTEMPTY'); 
            */ 
		}
    });
    
	$('#wifi_signin_to_other_network_form').restForm({
    	'dialogName': 'wifi_signin_to_other_network_overlay',
    	'beforeProcessForm': function(){
            
            var security_mode = $("#wifi_signin_to_other_network_form_security_mode_select option:selected").val();
            if (security_mode.toLowerCase() == 'none') {
                $('#wifi_signin_to_other_network_form_security_mode').val('NONE');
            }
            else if (security_mode.toLowerCase() == 'wep') {
                $('#wifi_signin_to_other_network_form_security_mode').val('WEP');
            }
            else {
                var encryption = $("#wifi_signin_to_other_network_form_encryption_select option:selected").val();
                $('#wifi_signin_to_other_network_form_security_mode').val(security_mode+'/'+encryption);
            }

            /*
            if ($('#wifi_signin_to_other_network_auto_join_toggle').is(':checked')) {
                $('#wifi_signin_to_other_network_join_value').val('true');
            }
            else {
                $('#wifi_signin_to_other_network_join_value').val('false');
            }
            */
    	},
        'setDefaultFormDataCallback': function (data) {
        },
        'processFormSuccessCallback':function(data, textStatus, jqXHR){

            modifyCurrentNetwork = false;
            if (connectToNewNetwork && !gFoundMe) {
                verifyCurrentWifiClientConnectionFromHomeRouter();
            }
            else {
                verifyCurrentWifiClientConnection();
            }

            //$('#wifi_signin_to_other_network_form_type_untrusted_button').addClass("button-selected");
            //$('#wifi_signin_to_other_network_form_type_trusted_button').removeClass("button-selected");
		},
		'processFormCompleteCallback': function(jqXHR, textStatus){
			$('#wifi_signin_to_other_network_form').restForm('processFormComplete', jqXHR, textStatus);
			$('#wifi_signin_to_other_network_overlay').dialog('close');

            /* will handle in beforeProcessForm
            $('#wifi_signin_to_other_network_form_password_show').removeClass('NOTEMPTY');
            $('#wifi_signin_to_other_network_form_password').removeClass('NOTEMPTY'); 
            */ 
		}
    });
    
    $("#verify_wifi_signin_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div id="verify_wifi_signin_overlay_title" class="wizard_dialog_title">'+$('#verify_wifi_signin_overlay').attr('title')+'</div>',
        open: function(){
            $('#verify_wifi_signin_overlay').find('.verify_wifi_signin_status').hide();
            $('#verify_wifi_signin_overlay').find('.dialog_form_controls').hide();
            $('#verify_wifi_signin_overlay').find('.connecting').show();
        }
    });

    $('#verify_wifi_signin_overlay_close_button').live('click', function(){
        $('#verify_wifi_signin_overlay').dialog('close');
    });

    $('#wifi_edit_config_form').restForm({
		'refreshDataCallback': function(data){
            $('#wifi_edit_config_form').restForm("_refreshData", data);

            if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {                
               
                //$('#wifi_edit_config_form_ssid').attr("value", data.wifi_ap.ssid); 

                $('#wifi_edit_config_form_mac_address').text(data.wifi_ap.mac_address); 
                $('#wifi_edit_config_form_original_ipaddress').text(data.wifi_ap.ip); 
                //$('#wifi_edit_config_form_original_netmask').text(data.wifi_ap.netmask); 
                $('#wifi_edit_config_form_netmask').text(data.wifi_ap.netmask); 
                $('#wifi_edit_config_form_original_security').text(data.wifi_ap.security_mode); 

                var broadcast = data.wifi_ap.broadcast.toLowerCase();
                $('#wifi_edit_config_form_original_broadcast').text(broadcast); 
                if (broadcast == 'true') {                
                    $('#wifi_edit_config_form_broadcast_toggle').attr('checked',true);
                    gSSIDBroadcasting = true;
                }
                else {
                    $('#wifi_edit_config_form_broadcast_toggle').attr('checked',false);
                    gSSIDBroadcasting = false;
                }  
                
                var enable_dhcp = data.wifi_ap.enable_dhcp.toLowerCase();
                $('#wifi_edit_config_form_original_enable_dhcp').text(enable_dhcp); 
                if (enable_dhcp == 'true') {                
                    $('#wifi_edit_config_form_enable_dhcp_toggle').attr('checked',true);
                }
                else {
                    $('#wifi_edit_config_form_enable_dhcp_toggle').attr('checked',false);
                }  

                /* will handle in beforeProcessForm
                $("#wifi_edit_config_form_password").removeClass("NOTEMPTY");
                $("#wifi_edit_config_form_password").removeClass("WPA_NETWORK_PASSWORD");
                $("#wifi_edit_config_form_password").removeClass("WEP_NETWORK_PASSWORD"); 
                */ 

                /* will handle in beforeProcessForm
                $("#wifi_edit_config_form_password_confirm").removeClass("CONFIRM_PASSWORD"); 
                */ 

                /* will handle in beforeProcessForm
                enableIdTag('#wifi_edit_config_form_password');
                enableIdTag('#wifi_edit_config_form_password_confirm'); 
                */ 

                //$('#wifi_edit_config_form_ipaddress').text(data.wifi_ap.ip);
                //$('#wifi_edit_config_form_netmask').text(data.wifi_ap.netmask);

                var maxWifiChannel = 11;
                if (data.wifi_ap.max_available_channel != null) {
                    maxWifiChannel = data.wifi_ap.max_available_channel;
                }
                // delete all available items except 1st which will be use as template
                $("#wifi_edit_config_form_channel_select").find("option:first").siblings().remove();

                for (var i = 1; i <= maxWifiChannel; i++) {
                    var newOption = $('#wifi_edit_config_form_channel_select').find("option:first").clone();
                    newOption.val(i);
                    newOption.html(i);
                    newOption.appendTo('#wifi_edit_config_form_channel_select');
                }
                $("#wifi_edit_config_form_channel_select").selectmenu();

                if (data.wifi_ap.channel_mode.toLowerCase() == 'auto') {
                    $('#wifi_edit_config_form_channel_select option').each(function(){
                        $(this)[0].defaultSelected = false;
                    });
                    $('#wifi_edit_config_form_channel_select option[value=0]').each(function(){
                        $(this)[0].defaultSelected = true;
                        $('#wifi_edit_config_form_channel_select').selectmenu("value", $(this).val());
                    });
                }
                else {
                    $('#wifi_edit_config_form_channel_select option[value='+data.wifi_ap.channel+']').each(function(){
                        $(this)[0].defaultSelected = true;
                        $('#wifi_edit_config_form_channel_select').selectmenu("value", $(this).val());
                    });
                }

                $('#wifi_edit_config_form').find('.display_ssid_password').show();
                wifi_edit_config_password_required = true;

                if (data.wifi_ap.security_mode.toLowerCase() == "none") {
                    /* will handle in beforeProcessForm
                    disableIdTag('#wifi_edit_config_form_password');
                    disableIdTag('#wifi_edit_config_form_password_confirm'); 
                    */ 
                    $('#wifi_edit_config_form').find('.display_ssid_password').hide();
                    wifi_edit_config_password_required = false;
                }
                /* WEP not supported in AP mode
                else if (data.wifi_ap.security_mode.toLowerCase() == "wep") {
                    $("#wifi_edit_config_form_password").addClass("WEP_NETWORK_PASSWORD");
                    $("#wifi_edit_config_form_password").addClass("NOTEMPTY");
                    $("#wifi_edit_config_form_password_confirm").addClass("CONFIRM_PASSWORD");
                }
                */
                /* will handle in beforeProcessForm
                else {
                    / * will handle in beforeProcessForm
                    $("#wifi_edit_config_form_password").addClass("WPA_NETWORK_PASSWORD");
                    $("#wifi_edit_config_form_password").addClass("NOTEMPTY"); 
                    * /
                     
                    / * will handle in beforeProcessForm
                    $("#wifi_edit_config_form_password_confirm").addClass("CONFIRM_PASSWORD"); 
                    * / 
                }
                */
            }
        },
        'processFormSuccessCallback':function(data){
            gSSIDName = $('#wifi_edit_config_form_ssid').val();

            var broadcast_setting = $('#wifi_edit_config_form_broadcast_value').val();
            if (broadcast_setting == 'true') {
                gSSIDBroadcasting = true;
            }
            else {
                gSSIDBroadcasting = false;
            }

            $('#wifi_edit_config_overlay').dialog('close');
            doReconnectWirelessNetwork();
        },
        'processFormCompleteCallback': function(jqXHR, textStatus){
            $('#wifi_edit_config_form').restForm('processFormComplete', jqXHR, textStatus);
            enableIdTag('#wifi_edit_config_form_password');
            enableIdTag('#wifi_edit_config_form_password_confirm');
            disableIdTag('#wifi_edit_config_form_password_show');
            $('#wifi_edit_config_form_password_show_container').hide();
		},
        'beforeProcessForm': function(){
            var channel = $("#wifi_edit_config_form_channel_select option:selected").val();
            if (channel == '0') {
                $('#wifi_edit_config_form_channel_mode').val('auto');
                disableIdTag('#wifi_edit_config_form_channel_select');
            }
            else {
                $('#wifi_edit_config_form_channel_mode').val('manual');
            }
        }
	});

    $('#wifi_edit_network_settings_config_form').restForm({
        'beforeProcessForm': function(){
            $('#wifi_edit_network_settings_config_form').attr('action', $('#wifi_edit_network_settings_config_default_form').attr('action'));
        },
		'refreshDataCallback': function(data){
            $('#wifi_edit_network_settings_config_form').restForm("_refreshData", data);
            if (data != null && data.network_configuration != null && data.network_configuration.ip != null) {

                if (data.network_configuration.proto.toLowerCase() == 'static') {
                    networkModeIsStatic = true;
                    $('#wifi_edit_settings_network_mode_static_button').addClass("button-selected");
                    $('#wifi_network_settings_static_container').show();
                    $('#wifi_network_settings_dhcp_container').hide();
                }                   
                else {
                    networkModeIsStatic = false;
                    $("#wifi_edit_settings_network_mode_dhcp_button").addClass("button-selected");
                    $('#wifi_network_settings_dhcp_ip_address').html(data.network_configuration.ip); 
                    $('#wifi_network_settings_dhcp_container').show();
                } 
            }
            $('#wifi_edit_network_settings_mac_address').html(gMacAddress);
            $('#wifi_edit_network_settings_device_name').html(gDeviceName);
            $('#wifi_edit_network_settings_ssid_name').html(gSSIDName);
            
        }
	});

    $("#wifi_edit_config_form_security_mode_select").change(function() {
        var security_mode = $("#wifi_edit_config_form_security_mode_select option:selected").val();

        /* will handle in beforeProcessForm
        $("#wifi_edit_config_form_password").removeClass("NOTEMPTY");
        $("#wifi_edit_config_form_password").removeClass("WPA_NETWORK_PASSWORD");
        //$("#wifi_edit_config_form_password").removeClass("WEP_NETWORK_PASSWORD"); // WEP not supported in AP mode
        */

        /* will handle in beforeProcessForm
        $("#wifi_edit_config_form_password_confirm").removeClass("CONFIRM_PASSWORD"); 
        */ 

        $('#wifi_edit_config_form').find('.display_ssid_password').show();
        wifi_edit_config_password_required = true;

        /* will handle in beforeProcessForm
        enableIdTag('#wifi_edit_config_form_password');
        enableIdTag('#wifi_edit_config_form_password_confirm'); 
        */ 

        if (security_mode.toLowerCase() == 'none') {
            /* will handle in beforeProcessForm
            disableIdTag('#wifi_edit_config_form_password');
            disableIdTag('#wifi_edit_config_form_password_confirm'); 
            */ 
            $('#wifi_edit_config_form').find('.display_ssid_password').hide();
            wifi_edit_config_password_required = false;
        }
        /* WEP not supported in AP mode
        else if (security_mode.toLowerCase() == 'wep') {
            $("#wifi_edit_config_form_password").addClass("WEP_NETWORK_PASSWORD");
            $("#wifi_edit_config_form_password").addClass("NOTEMPTY");
            $("#wifi_edit_config_form_password_confirm").addClass("CONFIRM_PASSWORD");
        }
        */
        /* will handle in beforeProcessForm
        else {
            / * will handle in beforeProcessForm
            $("#wifi_edit_config_form_password").addClass("WPA_NETWORK_PASSWORD");
            $("#wifi_edit_config_form_password").addClass("NOTEMPTY"); 
            * / 

            / * will handle in beforeProcessForm
            $("#wifi_edit_config_form_password_confirm").addClass("CONFIRM_PASSWORD"); 
            * / 
        }
        */
    }); 
    
    $("#wifi_signin_to_other_network_form_security_mode_select").change(function() {
        var security_mode = $("#wifi_signin_to_other_network_form_security_mode_select option:selected").val();

        //$("#wifi_signin_to_other_network_form_password").removeClass("NOTEMPTY"); // will handle in beforeProcessForm

        /* will handle in beforeProcessForm
        $("#wifi_signin_to_other_network_form_password").removeClass("WPA_NETWORK_PASSWORD").removeClass("WEP_NETWORK_PASSWORD"); 
        $("#wifi_signin_to_other_network_form_password_show").removeClass("WPA_NETWORK_PASSWORD").removeClass("WEP_NETWORK_PASSWORD"); 
        */

        $('#wifi_signin_to_other_network_form').find('.display_ssid_password').hide();
        $('#wifi_signin_to_other_network_form').find('.display_wifi_encryption').hide();
        wifi_signin_other_password_required = false;

        //enableIdTag('#wifi_signin_to_other_network_form_password');   // will handle in beforeProcessForm

        if (security_mode.toLowerCase() == 'none') {
            //disableIdTag('#wifi_signin_to_other_network_form_password');  // will handle in beforeProcessForm
        }
        else if (security_mode.toLowerCase() == 'wep') {
            $('#wifi_signin_to_other_network_form').find('.display_ssid_password').show();
            wifi_signin_other_password_required = true;

            /* will handle in beforeProcessForm
            $("#wifi_signin_to_other_network_form_password").addClass("WEP_NETWORK_PASSWORD");
            $("#wifi_signin_to_other_network_form_password_show").addClass("WEP_NETWORK_PASSWORD"); 
            */ 

            //$("#wifi_signin_to_other_network_form_password").addClass("NOTEMPTY");    // will handle in beforeProcessForm
        }
        else {
            $('#wifi_signin_to_other_network_form').find('.display_ssid_password').show();
            $('#wifi_signin_to_other_network_form').find('.display_wifi_encryption').show();
            wifi_signin_other_password_required = true;

            /* will handle in beforeProcessForm
            $("#wifi_signin_to_other_network_form_password").addClass("WPA_NETWORK_PASSWORD");
            $("#wifi_signin_to_other_network_form_password_show").addClass("WPA_NETWORK_PASSWORD"); 
            */ 

            //$("#wifi_signin_to_other_network_form_password").addClass("NOTEMPTY");    // will handle in beforeProcessForm
        }
    }); 

    $('#reconnect_network_form').restForm({
        'timeout': ajaxTimeoutPolling,
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
        },
        'setDefaultFormDataCallback': function (data) {
          
            reconnectWirelessInProgress = false;

	        if (data.system_state.status == "ready") {

                $("#reconnect_network_dialog").dialog('close');
                $('#wifi_access_point_name').text( $('#wifi_edit_config_form_ssid').val() );
                
                return;
	        }

            // avoid infinitely calling reconnectWirelessNetwork() by checking timeout
            var reconnectWirelessCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((reconnectWirelessCurrentTimeStamp - reconnectWirelessStartTimeStamp) > reconnectWirelessTimeOutMax) {
                // if system is "ready", then just continue
                if (status == "ready") {
                    $("#reconnect_network_dialog").dialog('close');
                    $('#wifi_access_point_name').text( $('#wifi_edit_config_form_ssid').val() );
                }
                else {
                    showReconnectWirelessTimeout();
                }
                return;
            }
	        setTimeout("reconnectWirelessNetwork();", pingInterval);
	    },
        'processFormErrorCallback': function(){
            reconnectWirelessInProgress = false;

            // avoid infinitely calling reconnectWirelessNetwork() by checking timeout
            var reconnectWirelessCurrentTimeStamp = new Date().getTime(); // in milliseconds
	        if ((reconnectWirelessCurrentTimeStamp - reconnectWirelessStartTimeStamp) > reconnectWirelessTimeOutMax) {
                showReconnectWirelessTimeout();
	            return;
	        }
	        setTimeout("reconnectWirelessNetwork();", pingInterval);
        }              
    });

    $('#wifi_access_point_edit').live('click', function(){
        if (!$(this).hasClass('ui-state-disabled') && !$(this).parent().parent().hasClass('ui-state-disabled')) {
            $('#wifi_edit_config_overlay').dialog('open');
        }
    });
    
    $('#wifi_network_settings_edit').live('click', function(){
        if (!$(this).hasClass('ui-state-disabled') && !$(this).parent().parent().hasClass('ui-state-disabled')) {
            $('#wifi_edit_network_settings_config_form').attr('action', $('#wifi_edit_network_settings_config_default_form').attr('action')); 
            $('#wifi_edit_network_settings_config_overlay').dialog('open');
        }
    });
    
    $('#wifi_edit_settings_network_mode_static_button').click(function () {
        if (!$('#wifi_edit_settings_network_mode_static_button').hasClass("button-selected")) {
            $("#wifi_edit_settings_network_mode_dhcp_button").removeClass("button-selected");
            $(this).addClass("button-selected");
            enableIdTag('#wifi_edit_network_settings_config_save_button');

            $('#wifi_network_settings_dhcp_container').hide();
            $('#wifi_network_settings_static_container').show();
        }
    });

    $('#wifi_edit_settings_network_mode_dhcp_button').click(function () {
        if (!$('#wifi_edit_settings_network_mode_dhcp_button').hasClass("button-selected")) {
            $("#wifi_edit_settings_network_mode_static_button").removeClass("button-selected");
            $(this).addClass("button-selected");
            enableIdTag('#wifi_edit_network_settings_config_save_button');

            $('#wifi_network_settings_dhcp_container').show();
            $('#wifi_network_settings_static_container').hide();
        }
    });

    $("#wifi_network_mode_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#wifi_network_mode_confirmation').attr('title')+'</div>'
    });

    $('#wifi_network_mode_confirmation_close_button').click(function(){
        $('#wifi_network_mode_confirmation').dialog('close');
    }); 

    $('#wifi_network_mode_confirmation_ok_button').click(function(){
        $('#wifi_network_mode_confirmation').dialog('close');
        changeNetworkSettings();
    });    

    $('#wifi_signin_form_show_password_checkbox').click(function() {
        if ($('#wifi_signin_form_show_password_checkbox').is(":checked")) {
            $('#wifi_signin_form_password').val( $('#wifi_signin_form_password_show').val() );
            $('#wifi_signin_form_password_container').show();
            $('#wifi_signin_form_password_show_container').hide();
            enableIdTag('#wifi_signin_form_password');
            disableIdTag('#wifi_signin_form_password_show');
        }
        else {
            $('#wifi_signin_form_password_show').val( $('#wifi_signin_form_password').val() );
            $('#wifi_signin_form_password_container').hide();
            $('#wifi_signin_form_password_show_container').show();
            disableIdTag('#wifi_signin_form_password');
            enableIdTag('#wifi_signin_form_password_show');

            if ($('#wifi_signin_form_password_show').val() != '') {
                $('#wifi_signin_form_password_show_container').find('.deletebutton').show();
            }
            else {
                $('#wifi_signin_form_password_show_container').find('.deletebutton').hide();
            }
        }
    });
    
    $('#wifi_edit_config_form_show_password_checkbox').click(function() {
        if ($('#wifi_edit_config_form_show_password_checkbox').is(":checked")) {
            $('#wifi_edit_config_form_password').val( $('#wifi_edit_config_form_password_show').val() );
            $('#wifi_edit_config_form_password_container').show();
            $('#wifi_edit_config_form_password_show_container').hide();
            $('#wifi_edit_config_form_password_confirm_container').show();
            enableIdTag('#wifi_edit_config_form_password');
            disableIdTag('#wifi_edit_config_form_password_show');
        }
        else {
            $('#wifi_edit_config_form_password_show').val( $('#wifi_edit_config_form_password').val() );
            $('#wifi_edit_config_form_password_container').hide();
            $('#wifi_edit_config_form_password_show_container').show();
            $('#wifi_edit_config_form_password_confirm_container').hide();
            disableIdTag('#wifi_edit_config_form_password');
            enableIdTag('#wifi_edit_config_form_password_show');

            if ($('#wifi_edit_config_form_password_show').val() != '') {
                $('#wifi_edit_config_form_password_show_container').find('.deletebutton').show();
            }
            else {
                $('#wifi_edit_config_form_password_show_container').find('.deletebutton').hide();
            }
        }
    });    
    
    

    $('#wifi_signin_to_other_network_form_show_password_checkbox').click(function() {
        if ($('#wifi_signin_to_other_network_form_show_password_checkbox').is(":checked")) {
            $('#wifi_signin_to_other_network_form_password').val( $('#wifi_signin_to_other_network_form_password_show').val() );
            $('#wifi_signin_to_other_network_form_password_container').show();
            $('#wifi_signin_to_other_network_form_password_show_container').hide();
            enableIdTag('#wifi_signin_to_other_network_form_password');
            disableIdTag('#wifi_signin_to_other_network_form_password_show');
        }
        else {
            $('#wifi_signin_to_other_network_form_password_show').val( $('#wifi_signin_to_other_network_form_password').val() );
            $('#wifi_signin_to_other_network_form_password_container').hide();
            $('#wifi_signin_to_other_network_form_password_show_container').show();
            disableIdTag('#wifi_signin_to_other_network_form_password');
            enableIdTag('#wifi_signin_to_other_network_form_password_show'); 

            if ($('#wifi_signin_to_other_network_form_password_show').val() != '') {
                $('#wifi_signin_to_other_network_form_password_show_container').find('.deletebutton').show();
            }
            else {
                $('#wifi_signin_to_other_network_form_password_show_container').find('.deletebutton').hide();
            }
        }
    });

    $('.wifi_ap_list_item').live('click', function(e) {
        e.preventDefault();

        var ssid = $(this).find('.wireless_ap_ssid').text();
        var mac = $(this).find('.wireless_ap_mac').text();
        var security_mode = $(this).find('.wireless_ap_security_mode').text();
        var wps_enabled = $(this).find('.wireless_info').hasClass('ap_wps');
        var dhcp_disabled = $(this).find('.wireless_info').hasClass('dhcp_disabled');
        var ap_remembered = $(this).find('.wireless_info').hasClass('ap_remembered');
        var ap_trusted = $(this).find('.wireless_info').hasClass('ap_trusted');
        var secured = $(this).find('.wireless_info').hasClass('ap_secured');
        //var wifi_not_in_range = $(this).find('.wireless_strength').hasClass('not_in_range');
        var wifi_connected = $(this).find('.wireless_label_text').hasClass('ap_connected');
        var mac_cloned = $(this).find('.wireless_info').hasClass('mac_cloned');
 
        $(this).addClass('selected');
        $(this).siblings().removeClass('selected');

        // modifying current connected Wi-Fi network is also a "connectToNewNetwork"
        if (gConnectedNetwork) {
            connectToNewNetwork = true;
        }
        else {
            connectToNewNetwork = false;
        }

        if (ssid == '' && mac == '') {
            signInToOtherNetwork = true;
            
            $('#wifi_signin_to_other_network_form').restForm('reset');
        }
        else {
            signInToOtherNetwork = false;
            $('#wifi_signin_form').restForm('reset');
        }

        $('#wifi_signin_form_ssid').text(ssid);
        $('#wifi_signin_form_mac_address').val(mac);
        $('#wifi_signin_form_security_mode').val(security_mode);

        wifi_signin_with_wps_pin = false;

        //disableIdTag('#wifi_signin_form_password');   // will handle in beforeProcessForm
        $('#wifi_signin_form').find('.display_ssid_password').hide();

        wifi_signin_ap_remembered = ap_remembered;
        wifi_signin_ap_trusted = ap_trusted;

        if (signInToOtherNetwork) {
            //enableIdTag('#wifi_client_ap_submit_btn');

            // default security mode is 1st item on list (which is currently NONE)
            //disableIdTag('#wifi_signin_to_other_network_form_password');  // will handle in beforeProcessForm
            $('#wifi_signin_to_other_network_form').find('.display_ssid_password').hide();
            $('#wifi_signin_to_other_network_form').find('.display_wifi_encryption').hide();
            wifi_signin_other_password_required = false;
            //$("#wifi_signin_to_other_network_form_password").removeClass("NOTEMPTY"); // will handle in beforeProcessForm
        }
        else {

            //if (/*wifi_not_in_range ||*/ (wifi_connected && !connectToNewNetwork)) {
            //    disableIdTag('#wifi_client_ap_submit_btn');
            //}
            //else {
            //    enableIdTag('#wifi_client_ap_submit_btn');
            //}
    
            if (wifi_connected || ap_remembered) {
                $('#wifi_signin_wps_toggle_container').hide();
            }
            else if (wps_enabled) {
                $('#wifi_signin_wps_toggle_container').show();
            }
            else {
                $('#wifi_signin_wps_toggle_container').hide();
            }

            if (ap_remembered) {
                wifi_signin_password_required = false;
                $('.show_checkbox_separator').hide();
            }
            else if (secured == false) {
                wifi_signin_password_required = false;
                $('.show_checkbox_separator').hide();
            }
            else {
                //enableIdTag('#wifi_signin_form_password');    // will handle in beforeProcessForm
                $('#wifi_signin_form').find('.display_ssid_password').show();
                wifi_signin_password_required = true;
                $('.show_checkbox_separator').show();
        
                // will handle in beforeProcessForm
                //$("#wifi_signin_form_password").removeClass("NOTEMPTY");
                //$("#wifi_signin_form_password").removeClass("WPA_NETWORK_PASSWORD");
                //$("#wifi_signin_form_password").removeClass("WEP_NETWORK_PASSWORD");
    
                /* see disable section above
                if (security_mode.toLowerCase() == 'none') {
                    //disableIdTag('#wifi_signin_form_password');   // will handle in beforeProcessForm
                    $('#wifi_signin_form').find('.display_ssid_password').hide();
                    wifi_signin_password_required = false;
                }
                */ 
                /* WEP not supported on AP mode
                else if (security_mode.toLowerCase() == 'wep') {
                    //$("#wifi_signin_form_password").addClass("WEP_NETWORK_PASSWORD");
                    //$("#wifi_signin_form_password").addClass("NOTEMPTY");
                }
                */
                /* SLEE - comment out since doing nothing
                else {
                    //$("#wifi_signin_form_password").addClass("WPA_NETWORK_PASSWORD");
                    //$("#wifi_signin_form_password").addClass("NOTEMPTY"); // will handle in beforeProcessForm
                }
                */
            }
        }

        if (wifiApListAutoClickFlag) {
            $('#wifi_client_ap_submit_btn').click();
        }
        /*
        else {
            wifiApListAutoClickFlag = true;
        }
        */

        $('.wifi_settings_ip').val( $(this).find('.wireless_client_ip').text() );
        $('.wifi_settings_netmask').val( $(this).find('.wireless_client_netmask').text() );
        $('.wifi_settings_gateway').val( $(this).find('.wireless_client_gateway').text() );
        $('.wifi_settings_dns0').val( $(this).find('.wireless_client_dns0').text() );
        $('.wifi_settings_dns1').val( $(this).find('.wireless_client_dns1').text() );
        $('.wifi_settings_dns2').val( $(this).find('.wireless_client_dns2').text() );

        if (dhcp_disabled) {
            $('.wifi_settings_network_mode_static_button').addClass("button-selected");
            $('.wifi_settings_network_mode_dhcp_button').removeClass("button-selected");

            $('.wifi_settings_dhcp_enabled').val("false");

            $('.wifi_client_network_settings_dhcp_container').hide();
            $('.wifi_client_network_settings_static_container').show();
        }                   
        else {
            $('.wifi_settings_network_mode_static_button').removeClass("button-selected");
            $('.wifi_settings_network_mode_dhcp_button').addClass("button-selected");

            $('.wifi_settings_dhcp_enabled').val("true");

            var client_ip = $(this).find('.wireless_client_ip').text();
            if (client_ip == '') {
                client_ip = $('.wifi_avatar_device_ip_address').text();
            }
            $('.wifi_network_settings_dhcp_ip_address').text(client_ip);

            $('.wifi_client_network_settings_dhcp_container').show();
            $('.wifi_client_network_settings_static_container').hide();
        } 

        if (mac_cloned) {
            $('.mac_clone_value').val("true");
            $('.mac_clone_toggle').attr('checked', true);
        }
        else {
            $('.mac_clone_value').val("false");
            $('.mac_clone_toggle').attr('checked', false);
        }
    });

    $('#wifi_signin_use_password_button').click(function () {
        $('#wifi_signin_wps_pin_container').hide();
        disableIdTag('#wifi_signin_wps_pin');

        wifi_signin_with_wps_pin = false;

        $('#wifi_signin_use_password_button').addClass("button-selected");
        $('#wifi_signin_use_wps_button').removeClass("button-selected");

        if (wifi_signin_password_required) {
            $('#wifi_signin_form').find('.display_ssid_password').show();
        }
    });

    $('#wifi_signin_use_wps_button').click(function () {
        $('#wifi_signin_wps_pin_container').show();
        enableIdTag('#wifi_signin_wps_pin');

        wifi_signin_with_wps_pin = true;

        $('#wifi_signin_use_password_button').removeClass("button-selected");
        $('#wifi_signin_use_wps_button').addClass("button-selected");

        if (wifi_signin_password_required) {
            $('#wifi_signin_form').find('.display_ssid_password').hide();
        }
    });
   
    /*
    $('#wifi_signin_form_type_untrusted_button').click(function () {
        //$('#wifi_signin_form_type_untrusted_button').addClass("button-selected");
        //$('#wifi_signin_form_type_trusted_button').removeClass("button-selected");
        $('#wifi_signin_form_trusted').val('false');
        $('.settings_mac_clone').show();
    });
    */

    /*
    $('#wifi_signin_form_type_trusted_button').click(function () {
        //$('#wifi_signin_form_type_untrusted_button').removeClass("button-selected");
        //$('#wifi_signin_form_type_trusted_button').addClass("button-selected");
        $('#wifi_signin_form_trusted').val('true');
        $('.settings_mac_clone').hide();
    });
    */

    $('#wifi_signin_form_trusted_checkbox').click(function() {
        // checked means previously trusted
        if ($('#wifi_signin_form_trusted_checkbox').is(":checked")) {
            $('#wifi_signin_form_trusted').val('false');
            $('.settings_mac_clone').show();
        }
        else {
            $('#wifi_signin_form_trusted').val('true');
            $('.settings_mac_clone').hide();
        }
    });

    $('#wifi_modify_form_trusted_checkbox').click(function() {
        // checked means previously trusted
        if ($('#wifi_modify_form_trusted_checkbox').is(":checked")) {
            $('#wifi_modify_form_trusted').val('false');
            $('.settings_mac_clone').show();
        }
        else {
            $('#wifi_modify_form_trusted').val('true');
            $('.settings_mac_clone').hide();
        }
    });

    $('#wifi_signin_to_other_network_form_trusted_checkbox').click(function() {
        // checked means previously trusted
        if ($('#wifi_signin_to_other_network_form_trusted_checkbox').is(":checked")) {
            $('#wifi_signin_to_other_network_form_trusted').val('false');
            $('.settings_mac_clone').show();
        }
        else {
            $('#wifi_signin_to_other_network_form_trusted').val('true');
            $('.settings_mac_clone').hide();
        }
    });

    $('#wifi_modify_form_forget_network_checkbox').click(function() {
        // checked means previously not remembered
        if ($('#wifi_modify_form_forget_network_checkbox').is(":checked")) {
            $('#wifi_modify_form_remember_network').val('true');
            $('.remember_network_show_all').show();
        }
        else {
            $('#wifi_modify_form_remember_network').val('false');
            $('.remember_network_show_all').hide();
        }
    });

    $('#wifi_signin_form_forget_network_checkbox').click(function() {
        // checked means previously not remembered
        if ($('#wifi_signin_form_forget_network_checkbox').is(":checked")) {
            $('#wifi_signin_form_remember_network').val('true');
            $('.remember_network_show_all').show();
        }
        else {
            $('#wifi_signin_form_remember_network').val('false');
            
            $('.remember_network_show_all').hide();
        }
    });

    $('.show_advanced_options').live('click', function(e) {
        e.preventDefault();

        $('.advanced_options_container').show();

        $('.show_advanced_options').hide();
        $('.hide_advanced_options').show();
    });

    $('.hide_advanced_options').live('click', function(e) {
        e.preventDefault();

        $('.advanced_options_container').hide();

        $('.show_advanced_options').show();
        $('.hide_advanced_options').hide();
    });

    $('#wifi_edit_config_form_broadcast_toggle').bind('toggle', function (event) {
        if ($(this).is(':checked')) {
            $('#wifi_edit_config_form_broadcast_value').val('true');
        }
        else {
            $('#wifi_edit_config_form_broadcast_value').val('false');
        }
    });

    $('#wifi_edit_config_form_enable_dhcp_toggle').bind('toggle', function (event) {
        if ($(this).is(':checked')) {
            $('#wifi_edit_config_form_enable_dhcp_value').val('true');
        }
        else {
            $('#wifi_edit_config_form_enable_dhcp_value').val('false');
        }
    });

    $("#reconnect_network_dialog").dialog({
        autoOpen: false,
        resizable: false,
        closeOnEscape: false,
        position: 'center',
        width: 710,
        minHeight: dialogMinHeight,
        zIndex: 2000,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#reconnect_network_dialog').attr('title')+'</div>',
        open: function(){
            var msg;
            var ssidname = '<b><i>'+gSSIDName+'</i></b>';
            msg = dictionaryList['find_wifi'].replace('{0}', ssidname);
            $('#connect_msg_find_wifi_network').find('.connect_network_msg_title').html(msg);

            msg = dictionaryList['connect_wifi'].replace('{0}', ssidname);
            $('#connect_msg_select_wifi_network').find('.connect_network_msg_title').html(msg);

            // browser is on Mac or iOS
            if ((navigator.appVersion.indexOf("Mac") != -1) || (navigator.platform.toLowerCase() == "ipad") || (navigator.platform.toLowerCase() == "iphone")) {
        		$('#connect_msg_find_wifi_network').find('.icon').removeClass('pc_icon');
                $('#connect_msg_select_wifi_network').find('.icon').removeClass('pc_icon');
        	} else {
        		$('#connect_msg_find_wifi_network').find('.icon').addClass('pc_icon');
                $('#connect_msg_select_wifi_network').find('.icon').addClass('pc_icon');
        	}

            if (gSSIDBroadcasting) {
                $('#ssid_broadcasting').show();
                $('#ssid_not_broadcasting').hide();
                msg = dictionaryList['select_avatar_wifi'].replace('{0}', ssidname);
                $('#connect_msg_select_wifi_network').find('.connect_network_msg_details').html(msg);
            }
            else {
                $('#ssid_broadcasting').hide();
                $('#ssid_not_broadcasting').show();
                msg = dictionaryList['select_other_network'].replace('{0}', ssidname);
                $('#connect_msg_select_other_network').find('.connect_network_msg_details').html(msg);
            }

            var deviceNameURL = getDeviceNameURL(gDeviceName);
            msg = dictionaryList['devicename_url'].replace('{0}', '<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
            $('#connect_network_msg_refresh_browser').find('.connect_network_msg_details').html(msg);
        }
    });

    $("#reconnect_network_timeout_dialog").dialog({
        autoOpen: false,
        resizable: false,
        closeOnEscape: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        zIndex: 2000,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#reconnect_network_timeout_dialog').attr('title')+'</div>'
    });    

    $('#wifi_settings_network_dhcp_renew_button').click(function (e) {
        e.preventDefault();

        displayLoading();
        $.ajaxAPI({
            "url": "network_configuration", 
            "type": "PUT",
            "data": {'proto': 'dhcp_client', 'dhcp_mode': 'renew'},
            "timeout": ajaxTimeoutNetwork,
    		"success": function(data, textStatus, jqXHR) {
    		},
            "error": function (request, status, error) {
            },
            "complete": function (jqXHR, textStatus) {
                hideLoading();
            }
    	});
    });
    
    $('.mac_clone_toggle').bind('toggle', function (event) {
        if ($(this).is(':checked')) {
            $('.mac_clone_value').val('true');
        }
        else {
            $('.mac_clone_value').val('false');
        }
    });

    $('#wifi_enabled_form').restForm({
        'refreshDataCallback' : function(data) {

            if (data != null && data.wifi_client_configuration != null) {                
                if (data.wifi_client_configuration.enabled.toLowerCase() == 'true') {                
                    $('#wifi_enabled_form').find('#WifiEnableToggle').attr('checked',true);
                    $('#WifiEnableValue').val('true');
                    $('#wifi_ap_list_content').show();
                    $('#wifi_ap_list_off').hide();
                    gWiFiEnabled = true;
    
                    showWifiClientAccessPointListContainer();
                }
                else {
                    $('#wifi_enabled_form').find('#WifiEnableToggle').attr('checked',false);
                    $('#WifiEnableValue').val('false');
                    $('#wifi_ap_list_content').hide();
                    $('#wifi_ap_list_off').show();
                    gWiFiEnabled = false;
                }  
                checkCurrentWifiClientConnection();
            }
        },
        'beforeProcessForm': function(){
             if (gTrustedNetwork && !gFoundMe) {
                
                $('#wifi_ap_list_off').show();
                $('#wifi_ap_list_content').hide();

                $('.wifi_ap_list_item.default').siblings().remove();

                disableIdTag('.network_separator2');
            }
        },
        'processFormSuccessCallback':function(data){

            if ($('#WifiEnableValue').val() == 'true') {
                gWiFiEnabled = true;
                checkCurrentWifiClientConnection();
                showWifiClientAccessPointListContainer();

                $('#wifi_ap_list_off').hide();
                $('#wifi_ap_list_content').show();
            }
            else {
                gWiFiEnabled = false;
                $('#wifi_ap_list_off').show();
                $('#wifi_ap_list_content').hide();

                $('.wifi_ap_list_item.default').siblings().remove();

                disableIdTag('.network_separator2');
            }
        },
        'processFormErrorCallback': function(){
            if (gTrustedNetwork && !gFoundMe) {
                gWiFiEnabled = false;

                displayDisableDisconnectCompleteMessage();
            }
        }

    });

    $('#WifiEnableToggle').live('toggle', function (e) {

        if ($(this).is(':checked')) {
            $('#WifiEnableValue').val('true');
            $('#wifi_enabled_form').submit();
        }
        else {
            $('#WifiEnableValue').val('false');

            if (!gFoundMe && gTrustedNetwork) {
                $('#wifi_disable_confirmation_overlay').dialog('open');
            }
            else {
                $('#wifi_enabled_form').submit();
            }
        }
    });

});

function before_wifi_edit_config_form_submit() {

    $('#wifi_edit_config_form_password').removeClass('NOTEMPTY');
    $('#wifi_edit_config_form_password').removeClass('WPA_NETWORK_PASSWORD');
    disableIdTag('#wifi_edit_config_form_password');

    $('#wifi_edit_config_form_password_confirm').removeClass('NOTEMPTY');
    $('#wifi_edit_config_form_password_confirm').removeClass('CONFIRM_PASSWORD');
    disableIdTag('#wifi_edit_config_form_password_confirm');

    $('#wifi_edit_config_form_password_show').removeClass('NOTEMPTY');
    $('#wifi_edit_config_form_password_show').removeClass('WPA_NETWORK_PASSWORD');
    disableIdTag('#wifi_edit_config_form_password_show');

    var security_mode = $("#wifi_edit_config_form_security_mode_select option:selected").val();

    if (wifi_edit_config_password_required) {
        if ($('#wifi_edit_config_form_show_password_checkbox').is(":checked")) {
            enableIdTag('#wifi_edit_config_form_password_show');
            $('#wifi_edit_config_form_password_show').addClass('NOTEMPTY');

            if (security_mode.toLowerCase() == 'none') {
                // do nothing, can't have security mode=none and password required
            }
            /* WEP not supported in AP mode
            else if (security_mode.toLowerCase() == 'wep') {
                $('#wifi_edit_config_form_password_show').addClass('WEP_NETWORK_PASSWORD');
            } 
            */ 
            else {
                $('#wifi_edit_config_form_password_show').addClass('WPA_NETWORK_PASSWORD');
            }
        }
        else {
            enableIdTag('#wifi_edit_config_form_password');
            $('#wifi_edit_config_form_password').addClass('NOTEMPTY');

            enableIdTag('#wifi_edit_config_form_password_confirm');
            $('#wifi_edit_config_form_password_confirm').addClass('CONFIRM_PASSWORD');

            if (security_mode.toLowerCase() == 'none') {
                // do nothing, can't have security mode=none and password required
            }
            /* WEP not supported in AP mode
            else if (security_mode.toLowerCase() == 'wep') {
                $('#wifi_edit_config_form_password').addClass('WEP_NETWORK_PASSWORD');
            } 
            */ 
            else {
                $('#wifi_edit_config_form_password').addClass('WPA_NETWORK_PASSWORD');
            }
        }
    }
}

function before_wifi_signin_to_other_network_form_submit() {
    
    disableIdTag('#wifi_signin_to_other_network_form_password');
    $('#wifi_signin_to_other_network_form_password').removeClass('NOTEMPTY').removeClass('WPA_NETWORK_PASSWORD').removeClass('WEP_NETWORK_PASSWORD');

    disableIdTag('#wifi_signin_to_other_network_form_password_show');
    $('#wifi_signin_to_other_network_form_password_show').removeClass('NOTEMPTY').removeClass('WPA_NETWORK_PASSWORD').removeClass('WEP_NETWORK_PASSWORD');

    var security_mode = $("#wifi_signin_to_other_network_form_security_mode_select option:selected").val();

    if (wifi_signin_other_password_required) {  // Password required
        if ($('#wifi_signin_to_other_network_form_show_password_checkbox').is(":checked")) {    // "Show Password" checkbox checked
            enableIdTag('#wifi_signin_to_other_network_form_password_show');
            $('#wifi_signin_to_other_network_form_password_show').addClass('NOTEMPTY');
            
            if (security_mode.toLowerCase() == 'none') {
                // do nothing, can't have security mode=none and password required
            }
            else if (security_mode.toLowerCase() == 'wep') {
                $('#wifi_signin_to_other_network_form_password_show').addClass('WEP_NETWORK_PASSWORD');
            }
            else {
                $('#wifi_signin_to_other_network_form_password_show').addClass('WPA_NETWORK_PASSWORD');
            }
        }
        else {  // "Show Password" checkbox NOT checked

            enableIdTag('#wifi_signin_to_other_network_form_password');
            $('#wifi_signin_to_other_network_form_password').addClass('NOTEMPTY');

            if (security_mode.toLowerCase() == 'none') {
                // do nothing, can't have security mode=none and password required
            }
            else if (security_mode.toLowerCase() == 'wep') {
                $('#wifi_signin_to_other_network_form_password').addClass('WEP_NETWORK_PASSWORD');
            }
            else {
                $('#wifi_signin_to_other_network_form_password').addClass('WPA_NETWORK_PASSWORD');
            }
        }
    }

    if ($('.wifi_settings_network_mode_dhcp_button').hasClass('button-selected')) {
        $('#wifi_signin_to_other_SettingIp').removeClass('IPADDRESS');
        $('#wifi_signin_to_other_SettingNetmask').removeClass('NETMASK');

        $('.wifi_settings_dhcp_enabled').val('true');

        disableIdTag('.wifi_static_network_settings');
    }
    else {
        $('#wifi_signin_to_other_SettingIp').addClass('IPADDRESS');
        $('#wifi_signin_to_other_SettingNetmask').addClass('NETMASK');

        $('.wifi_settings_dhcp_enabled').val('false');

        enableIdTag('.wifi_static_network_settings');
    }

    /*
    if ($('#wifi_signin_to_other_network_form_type_untrusted_button').hasClass('button-selected')) {
        enableIdTag('.mac_clone_value');

        var clone_mac_enable = $('.mac_clone_value').val();
        if (clone_mac_enable == 'true') {
            $('.cloned_mac_address').val(gMacAddress);
            enableIdTag('.cloned_mac_address');
        }
        else {
            disableIdTag('.cloned_mac_address');
        }
        
    }
    else {
        disableIdTag('.mac_clone_value');
        disableIdTag('.cloned_mac_address');
    }
    */

    if ($('#wifi_signin_to_other_network_form_trusted').val() == 'false') {
        enableIdTag('.mac_clone_value');

        var clone_mac_enable = $('.mac_clone_value').val();
        if (clone_mac_enable == 'true') {
            $('.cloned_mac_address').val(gMacAddress);
            enableIdTag('.cloned_mac_address');
        }
        else {
            disableIdTag('.cloned_mac_address');
        }
    }
    else {
        disableIdTag('.mac_clone_value');
        disableIdTag('.cloned_mac_address');
    }
}

function before_wifi_signin_form_submit() {

    disableIdTag('#wifi_signin_form_password');
    $('#wifi_signin_form_password').removeClass('NOTEMPTY').removeClass('WPA_NETWORK_PASSWORD').removeClass('WEP_NETWORK_PASSWORD');

    disableIdTag('#wifi_signin_form_password_show');
    $('#wifi_signin_form_password_show').removeClass('NOTEMPTY').removeClass('WPA_NETWORK_PASSWORD').removeClass('WEP_NETWORK_PASSWORD');

    disableIdTag('#wifi_signin_wps_pin');
    $('#wifi_signin_wps_pin').removeClass('NOTEMPTY').removeClass('WPS_PIN');

    disableIdTag('#wifi_signin_form_security_mode');

    var security_mode = $("#wifi_signin_form_security_mode").val();

    if (wifi_signin_ap_remembered) {
        //disableIdTag('#wifi_signin_form_security_mode');
    }
    else if (wifi_signin_with_wps_pin) {
        enableIdTag('#wifi_signin_wps_pin');
        $('#wifi_signin_wps_pin').addClass('NOTEMPTY').addClass('WPS_PIN');
    }
    else {
        enableIdTag('#wifi_signin_form_security_mode');
        if (wifi_signin_password_required) {
            if ($('#wifi_signin_form_show_password_checkbox').is(":checked")) {
                enableIdTag('#wifi_signin_form_password_show');
                $('#wifi_signin_form_password_show').addClass('NOTEMPTY');
                
                if (security_mode.toLowerCase() == 'none') {
                    // do nothing, can't have security mode=none and password required
                }
                else if (security_mode.toLowerCase() == 'wep') {
                    $('#wifi_signin_form_password_show').addClass('WEP_NETWORK_PASSWORD');
                } 
                else {
                    $('#wifi_signin_form_password_show').addClass('WPA_NETWORK_PASSWORD');
                }
            }
            else {
                enableIdTag('#wifi_signin_form_password');
                $('#wifi_signin_form_password').addClass('NOTEMPTY');
                
                if (security_mode.toLowerCase() == 'none') {
                    // do nothing, can't have security mode=none and password required
                }
                else if (security_mode.toLowerCase() == 'wep') {
                    $('#wifi_signin_form_password').addClass('WEP_NETWORK_PASSWORD');
                }
                else {
                    $('#wifi_signin_form_password').addClass('WPA_NETWORK_PASSWORD');
                }
            }
        }
    }

    if ($('.wifi_settings_network_mode_dhcp_button').hasClass('button-selected')) {
        $('#wifi_signin_SettingIp').removeClass('IPADDRESS');
        $('#wifi_signin_SettingNetmask').removeClass('NETMASK');

        $('.wifi_settings_dhcp_enabled').val('true');

        disableIdTag('.wifi_static_network_settings');
    }
    else {
        $('#wifi_signin_SettingIp').addClass('IPADDRESS');
        $('#wifi_signin_SettingNetmask').addClass('NETMASK');

        $('.wifi_settings_dhcp_enabled').val('false');

        enableIdTag('.wifi_static_network_settings');
    }

    /*
    if ($('#wifi_signin_form_type_untrusted_button').hasClass('button-selected')) {
        enableIdTag('.mac_clone_value');

        var clone_mac_enable = $('.mac_clone_value').val();
        if (clone_mac_enable == 'true') {
            $('.cloned_mac_address').val(gMacAddress);
            enableIdTag('.cloned_mac_address');
        }
        else {
            disableIdTag('.cloned_mac_address');
        }
        
    }
    else {
        disableIdTag('.mac_clone_value');
        disableIdTag('.cloned_mac_address');
    }
    */
    if ($('#wifi_signin_form_trusted').val() == 'false') {
        enableIdTag('.mac_clone_value');

        var clone_mac_enable = $('.mac_clone_value').val();
        if (clone_mac_enable == 'true') {
            $('.cloned_mac_address').val(gMacAddress);
            enableIdTag('.cloned_mac_address');
        }
        else {
            disableIdTag('.cloned_mac_address');
        }
    }
    else {
        disableIdTag('.mac_clone_value');
        disableIdTag('.cloned_mac_address');
    }
}

function showWifiClientAccessPointListContainer() {

    var wifi_ap_count = 0;
    $('#wifi_ap_list_content ul li').each(function (i) {
        wifi_ap_count++;
    });
    if (wifi_ap_count > 1) {
        $('.wifi_list_please_wait').hide();
    }
    else {
        $('.wifi_list_please_wait').show();
    }
}

function updateWifiClientAccessPointList(){

    var wifi_ap_found_count = 0;
    var wifi_ap_list = {};
    var empty_flag = true;

    // Don't delete list, just update it
    //$('.wifi_ap_list_item.default').siblings().remove();
    //$('.wifi_list_please_wait').show();

    $('#wifi_ap_list_content ul li').each(function (i) {
        if (!$(this).hasClass('.default')) {
            var mac = $(this).find('.wireless_ap_mac').text();
            var ssid = $(this).find('.wireless_label_text').text();
            if (mac != '') {
                wifi_ap_list[mac] = ssid;
                empty_flag = false;
            }
        }
    });

    //disableIdTag('#wifi_client_ap_submit_btn');

    if (wifi_client_access_points_inprogress) {
        return;
    }
    wifi_client_access_points_inprogress = true;

	$.ajaxAPI({
		"url": "wifi_client_access_points",
        "timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
			if (data != null && data.wifi_client_access_points != null && data.wifi_client_access_points.wifi_ap_client_access_point != null) {
                // only 1 ap client
				if( Object.prototype.toString.call( data.wifi_client_access_points.wifi_ap_client_access_point ) != '[object Array]' ){
					data.wifi_client_access_points.wifi_ap_client_access_point = $.makeArray(data.wifi_client_access_points.wifi_ap_client_access_point);
				}
                $.each(data.wifi_client_access_points.wifi_ap_client_access_point, function (index, value){
                    // skip non-broadcasting SSID
                    if (value.ssid != '') {
                        var newItem = $('.wifi_ap_list_item.default').clone();
                        var ssidName = value.ssid;
                        var ap_connected = false;
                        //var not_in_range = false;
                        var newItemIdName = value.ssid;
                        var signal_strength = parseInt(value.signal_strength);

                        if (value.connected.toLowerCase() == 'true') {
                            ap_connected = true;
                            newItem.find('.wireless_label_text').addClass('ap_connected');
                            newItem.find('.wifi_ap_list_item_icon').addClass('icon_ap_connected');
                            newItem.addClass('connected');
                        }

                        if ((value.wps_enabled != null) && (value.wps_enabled.toLowerCase() == 'true')) {
                            //newItem.find('.wireless_wps').addClass('wireless_wps_available').removeClass('wireless_wps');
                            newItem.find('.wireless_info').addClass('ap_wps');
                        }

                        if ((value.remembered != null) && (value.remembered.toLowerCase() == 'true')) {
                            newItem.find('.wireless_info').addClass('ap_remembered');

                            if ((value.trusted != null) && (value.trusted.toLowerCase() == 'true')) {
                                newItem.find('.wireless_info').addClass('ap_trusted');
                            }
                        }

                        if (value.dhcp_enabled.toLowerCase() == 'false') {
                            newItem.find('.wireless_info').addClass('dhcp_disabled');
                        }

                        if (value.mac_clone_enable.toLowerCase() == 'true') {
                            newItem.find('.wireless_info').addClass('mac_cloned');
                        }

                        // workaround firmware bug
                        if (value.dns0 == '--dns1') {
                            value.dns0 = '';
                        }
                        if (value.dns1 == '--dns2') {
                            value.dns1 = '';
                        }
                        if (value.dns2 == '--dns3') {
                            value.dns2 = '';
                        }

                        newItem.find('.wireless_client_ip').text(value.ip);
                        newItem.find('.wireless_client_netmask').text(value.netmask);
                        newItem.find('.wireless_client_gateway').text(value.gateway);
                        newItem.find('.wireless_client_dns0').text(value.dns0);
                        newItem.find('.wireless_client_dns1').text(value.dns1);
                        newItem.find('.wireless_client_dns2').text(value.dns2);

                        newItem.find('.wireless_label_text').text(ssidName);
                        newItem.removeClass('default');

                        newItem.find('.wireless_ap_ssid').text(value.ssid);
                        newItem.find('.wireless_ap_mac').text(value.mac);
                        newItem.find('.wireless_ap_security_mode').text(value.security_mode);

                        if ((value.secured != null) && (value.secured.toLowerCase() == 'true')) {
                            newItem.find('.wireless_info').addClass('ap_secured');
                        }
                        else {
                            newItem.find('.wireless_lock').addClass('wireless_unlock').removeClass('wireless_lock');
                        }

                        if (signal_strength > 90) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_5bars');
                        }
                        else if (signal_strength > 70) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_4bars');
                        }
                        else if (signal_strength > 50) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_3bars');
                        }
                        else if (signal_strength > 30) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_2bars');
                        }
                        else if (signal_strength > 10) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_1bars');
                        }
                        else if (signal_strength > 0) {
                            newItem.find('.wireless_strength').addClass('wireless_strength_0bars');
                        }
                        else {
                            //newItem.find('.wireless_strength').addClass('not_in_range');
                            //not_in_range = true;

                            // don't show WiFi not in range
                            return;
                        }

                        if (ap_connected) {
                            newItemIdName = 'connected_' + newItemIdName;
                        }
                        /*
                        else if (not_in_range) {
                            newItemIdName = 'out_of_range_' + newItemIdName;
                        }
                        */
                        else {
                            newItemIdName = 'new_' + newItemIdName;
                        }

                        newItemIdName = newItemIdName.replace(/[.]/g,'_').replace(/\s/g,'_');
                        newItem.attr('id', newItemIdName);

                        if (wifi_ap_list[value.mac] != null) {
                            // if found old ssid setting, just delete it and will append next
                            $('#wifi_ap_list_content ul li').each(function (i) {
                                if ( $(this).find('.wireless_ap_mac').text() == value.mac) {
                                    $(this).remove();
                                    delete wifi_ap_list[value.mac];
                                    return;
                                }
                            });
                        }
                        $('#wifi_ap_list').append(newItem);

                        wifi_ap_found_count++;
                    }
                });

                for (var mac in wifi_ap_list){
                    if (wifi_ap_list[mac] != null) {

                        // delete item from page
                        $('#wifi_ap_list_content ul li').each(function (i) {
                            if ( $(this).find('.wireless_ap_mac').text() == mac) {
                                $(this).remove();
                                delete wifi_ap_list[mac];
                                wifi_ap_found_count--;
                                return;
                            }
                        });
                    }
                }

                /* -- AP list --- */
                // sort by wifi name (with priority on Connected and lowest on Out of Range APs
                $('#wifi_ap_list_content ul li').tsort({attr:'id',order:'asc'});

			}
		},
        "error": function (request, status, error) {
        },
        "complete": function (jqXHR, textStatus) {

            if (empty_flag) {
                wifi_ap_found_count++;
                var newItem = $('.wifi_ap_list_item.default').clone();
    
                newItem.find('.wireless_label_text').text( dictionaryList['other_network'] );
                newItem.find('.wireless_ap_mac').text('');
                newItem.find('.wireless_ap_security_mode').text('');
    
                newItem.removeClass('default');
                newItem.attr('id', 'other_network');
        
                newItem.find('.wireless_lock').addClass('wireless_unlock').removeClass('wireless_lock');
        
                $('#wifi_ap_list').append(newItem);
            }

            $('.wifi_ap_list_item').each(function (i) {
                if (i == 0) { return; }
                if (i % 2 === 0) {
                    $(this).addClass('alt_row_bg');
                }
                else {
                    $(this).removeClass('alt_row_bg');
                }
            });

            if (wifi_ap_found_count > 4) {
                $('#wifi_ap_list_content').addClass('wifi_ap_content_scroll_width');
            }
            else {
                $('#wifi_ap_list_content').removeClass('wifi_ap_content_scroll_width');
            }

            wifi_client_access_points_inprogress = false;
            $('.wifi_list_please_wait').hide();

            $('#wifi_ap_list_content').scrollTop(0);
        }
	});
}

function checkCurrentWifiClientConnection(){

	$.ajaxAPI({
		"url": "current_wifi_client_connection",
        "timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
            gConnectedNetwork = false;

			//get wifi details to replace list if already connected to wifi
			if (data != null && data.current_wifi_client_connection != null && data.current_wifi_client_connection != null && data.current_wifi_client_connection.ssid != null && data.current_wifi_client_connection.ssid != '' ) {
                gWANSSIDName = data.current_wifi_client_connection.ssid;
                gConnectedNetwork = true;

                if (data.current_wifi_client_connection.trusted.toLowerCase() == 'true') {
                    gTrustedNetwork = true;
                }
                else {
                    gTrustedNetwork = false;
                }

                enableIdTag('.network_separator2');
			}
            
            updateWifiClientConnection(false);
		},
        "error": function (request, status, error) {
        }
	});
}

function updateWifiClientConnection(firstTime) {

    resetNetworkPage();
    
    // direct connect
    if (!gConnectedNetwork) {
        updateAvatarDevice_with_SSID(false);
    }
    else {

        if (firstTime) {
            setTimeout("getNetworkSettings();", 5000);
        }
        else {
            getNetworkSettings();
        }
    }

    if (gWiFiEnabled) {
        updateWifiClientAccessPointList();
    }
}

function resetNetworkPage() {

    // reset network mode
    $('.network_mode').hide();
    $('.wifi_buttons').hide();

    // direct connection (Ad Hoc) to Avatar
    if (!gConnectedNetwork) {
        // show direct network mode
        $('.mode_direct_connection').show();
        $('.wifi_access_point_setting_up_buttons').show();
        $('.wifi_access_point_profile_list_buttons').show();
    }
    else {
        $('.wifi_access_point_setting_up_buttons').show();
        $('.wifi_access_point_profile_list_buttons').show();

        $('#selected_wireless_network_image').removeClass('home_network_image');

        // Home mode
        if (gTrustedNetwork) {

            // in Home mode, first check for Bridge connection
            if (gConnectedDevices) {
                // Bridged mode

                $('.mode_trusted_network').show();
                $('#selected_wireless_network_image').addClass('home_network_image');

                // Me connected to Avatar
                if (gFoundMe) {
                    updateAvatarDevice_with_SSID(false);
                }
                // Me connected through home router (don't show Me anymore)
                else {
                    updateAvatarDevice_with_DeviceName();
                }
            }
            // Just home mode
            else {
                $('.mode_trusted_network').show();
                updateAvatarDevice_with_DeviceName();

                $('#selected_wireless_network_image').addClass('home_network_image');
            }
        }
        else {
            // hotspot mode
            updateAvatarDevice_with_SSID(false);

            $('.mode_network_hotspot').show();
        }
    }
}

function doReconnectWirelessNetwork() {

    var msg;
    var advanced_settings_changed = false;
    var new_dhcp_setting = $('#wifi_edit_config_form_enable_dhcp_value').val();
    var old_dhcp_setting = $('#wifi_edit_config_form_original_enable_dhcp').text();
    var new_broadcast_setting = $('#wifi_edit_config_form_broadcast_value').val();
    var old_broadcast_setting = $('#wifi_edit_config_form_original_broadcast').text();
    var new_ip_setting = $('#wifi_edit_config_form_ipaddress').val();
    var old_ip_setting = $('#wifi_edit_config_form_original_ipaddress').text();
    //var new_netmask_setting = $('#wifi_edit_config_form_netmask').val();
    //var old_netmask_setting = $('#wifi_edit_config_form_original_netmask').text();
    var new_security_setting = $("#wifi_edit_config_form_security_mode_select option:selected").val();
    var old_security_setting = $('#wifi_edit_config_form_original_security').text();

    $('#reconnect_wireless_network_msg_container').hide();
    $('#reconnect_wireless_network_ipaddress_msg').hide();
    $('#reconnect_wireless_network_dhcp_msg').hide();
    $('#reconnect_wireless_network_ssid_broadcast_msg').hide();
    $('#reconnect_wireless_network_security_msg').hide();

    if (new_security_setting != old_security_setting) {
        advanced_settings_changed = true;
        // changing from secured to secured
        if (new_security_setting == 'NONE') {
            msg = dictionaryList['ap_security_off'];
        }
        else {
            msg = dictionaryList['ap_security_on'];
        }
        $('#reconnect_wireless_network_security_msg').text(msg);
        $('#reconnect_wireless_network_security_msg').show();
    }
    else if (new_security_setting != 'NONE') {
        advanced_settings_changed = true;
        msg = dictionaryList['ap_security_password_changed'];
        $('#reconnect_wireless_network_security_msg').text(msg);
        $('#reconnect_wireless_network_security_msg').show();
    }

    if (new_dhcp_setting != old_dhcp_setting) {
        advanced_settings_changed = true;
        if (new_dhcp_setting == 'true') {
            msg = dictionaryList['ap_dhcp_on_msg'];
        }
        else {
            msg = dictionaryList['ap_dhcp_off_msg'];
        }
        $('#reconnect_wireless_network_dhcp_msg').text(msg);
        $('#reconnect_wireless_network_dhcp_msg').show();
    }

    if (new_broadcast_setting != old_broadcast_setting) {
        if (new_broadcast_setting == 'false') {
            advanced_settings_changed = true;
            msg = dictionaryList['ap_ssid_broadcast_off_msg'].replace('{0}', '<b><i>'+gSSIDName+'</i></b>');
            $('#reconnect_wireless_network_ssid_broadcast_msg').text(msg);
            $('#reconnect_wireless_network_ssid_broadcast_msg').show();
        }
    }
    
    if (new_ip_setting != old_ip_setting) {
        advanced_settings_changed = true;
        msg = dictionaryList['ap_ipaddress_changed_msg'].replace('{0}', '<b>'+$('#wifi_edit_config_form_ipaddress').val()+'</b>');

        $('#reconnect_wireless_network_ipaddress_msg').html(msg);
        $('#reconnect_wireless_network_ipaddress_msg').show();
    }

    if (advanced_settings_changed) {
        $('#reconnect_wireless_network_msg_container').show();
    }

    reconnectWirelessStartTimeStamp = new Date().getTime(); // in milliseconds
    $("#reconnect_network_dialog").dialog("open"); 

    setTimeout("reconnectWirelessNetwork();", startReconnectWirelessDelay);
}

function reconnectWirelessNetwork(){

    if(reconnectWirelessInProgress) {
        return;
    }
    reconnectWirelessInProgress = true;

    $('#reconnect_network_form').submit();
}

// show the reconnect timeout message
function showReconnectWirelessTimeout() {

    $("#reconnect_network_dialog").dialog('close');
    $("#reconnect_network_timeout_dialog").dialog('open');
}

function updateAvatarDevice_with_DeviceName() {

    if (gDeviceName == '') {
        setTimeout('updateAvatarDevice_with_DeviceName();', 1500); 
    }
    else {
        doUpdateAvatarDevice_with_DeviceName(gDeviceName);
    }
}

function doUpdateAvatarDevice_with_DeviceName(DeviceName) {

    $('#wifi_access_point_name').text(DeviceName);
    $('#wifi_access_point_tooltip').show();
    $('#wifi_connected_tooltip').hide();
    $('#avatar_icon_tooltip').show();
    
    $('#wifi_access_point_ssid_lock').hide();
    $('#wifi_avatar_access_point_name_container').show();
    $('#wifi_access_point_edit').hide();
    $('#wifi_network_settings_edit').show();
    $('#wifi_access_point_edit_container').show();
}

function updateAvatarDevice_with_SSID(showTooltip) {

    if (gSSIDName == '') {
        // get SSID Name of Avatar
        $.ajaxAPI({
            "url": "wifi_ap",
            "timeout": ajaxTimeout,
            "success": function(data, textStatus, jqXHR) {
                if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
                    gSSIDName = data.wifi_ap.ssid;
                    if (data.wifi_ap.secured.toLowerCase() == "true") {
                        gSSIDSecured = true;
                    }
                    else {
                        gSSIDSecured = false;
                    }
                    if (data.wifi_ap.broadcast.toLowerCase() == "true") {
                        gSSIDBroadcasting = true;
                    }
                    else {
                        gSSIDBroadcasting = false;
                    }
                }
                $('.device_text').text(gSSIDName);
            },
            "error": function (request, status, error) {
            },
            "complete": function (jqXHR, textStatus) {
                doUpdateAvatarDevice_with_SSID(gSSIDName, gSSIDSecured, showTooltip);
            }
        });
    }
    else {
        doUpdateAvatarDevice_with_SSID(gSSIDName, gSSIDSecured, showTooltip);
    }
}

function doUpdateAvatarDevice_with_SSID(SSIDName, SSIDSecured, showTooltip) {

    $('#wifi_access_point_name').text(SSIDName);

    if (showTooltip) {
        $('#wifi_access_point_tooltip').show();
        $('#wifi_connected_tooltip').hide();
    }
    else {
        $('#wifi_access_point_tooltip').hide();
        $('#wifi_connected_tooltip').show();
    }
    $('#avatar_icon_tooltip').show();

    if (SSIDSecured) {
        $('#wifi_access_point_ssid_lock').show();
    }
    else {
        $('#wifi_access_point_ssid_lock').hide();
    }
    $('#wifi_avatar_access_point_name_container').show();
    $('#wifi_access_point_edit').show();
    $('#wifi_network_settings_edit').hide();
    $('#wifi_access_point_edit_container').show();
}

function getNetworkSettings() {

    var ipaddress;

    $.ajaxAPI({
        "url": "network_configuration", 
        "timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
            if (data != null && data.network_configuration != null && data.network_configuration.ip != null) {
                ipaddress = data.network_configuration.ip;

                //$('.selected_wireless_network_ip_address').text(data.network_configuration.ip);
                $('.selected_wireless_network_gateway').text(data.network_configuration.gateway);
                //$('.selected_wireless_network_dns').text(data.network_configuration.dns0);

                $('.wifi_avatar_device_name').text(gDeviceName);
                $('.wifi_avatar_device_ip_address').text(data.network_configuration.ip);
                $('.wifi_avatar_device_netmask').text(data.network_configuration.netmask);
                $('.wifi_avatar_device_gateway').text(data.network_configuration.gateway);
                $('.wifi_avatar_device_dns').text(data.network_configuration.dns0);
            }
		},
        "error": function (request, status, error) {
        },
        "complete": function (jqXHR, textStatus) {
            if (ipaddress == '') {
                setTimeout("getNetworkSettings();", 5000);
            }
            else {
                checkInternetConnectivityCount = 0;
                getInternetConnectivity();
            }
        }
	});
}

function changeNetworkSettings() {

    displayLoading();

    // make sure we can ping the server before executing a save network configuration
    $.ajaxAPI({
        "url": "system_state",
        "timeout": ajaxTimeoutNetwork,
        "error": function (request, status, error) {
            showError('edit_network_lan_configuration_form_internal_error');
        },
        "success": function (data) {
            if ($('#wifi_edit_settings_network_mode_dhcp_button').hasClass('button-selected')) {
                changeNetworkSettingsToDHCP();
            }
            else {
                changeNetworkSettingsToStatic();
            }
        },
        "complete": function (jqXHR, textStatus) {
            // don't remove if redirecting after a network change
            //hideLoading();
        }
    });
}

function changeNetworkSettingsToDHCP() {

    var gateway_mac_address = $('#wifi_network_settings_gateway_mac_address').val();
    $.ajaxAPI({
        "url": "network_configuration", 
        "type": "PUT",
        "data": {'proto': 'dhcp_client', 'gateway_mac_address': gateway_mac_address},
        "timeout": ajaxTimeoutNetwork,
        "success": function(data, textStatus, jqXHR) {
            hideLoading();
            updateWifiClientAccessPointList();
        },
        "error": function (request, status, error) {
            // workaround to redirect after timeout (until API can returns response)
            if (error == 'timeout') {
                var hostname = $('#wifi_edit_network_settings_device_name').text();
                stopPolling();
                window.location = 'http://'+hostname;
            }
            else {
                processAndDisplayError(request.responseText, 'put_network_configuration', request.status);
                hideLoading();
            }
        }
    });
}

function changeNetworkSettingsToStatic() {

    // first change workgroup then change ip settings

    var workname = $("#SettingWorkgroupName").val();
    $.ajaxAPI({
        "url": "network_workgroup",
        "type": "PUT",
        "data": {'workname': workname},
        "timeout": ajaxTimeoutNetwork,
        "complete": function (jqXHR, textStatus) {
            updateStaticNetworkSettings();
        }
    });
}

function updateStaticNetworkSettings() {

    var ip = $("#SettingIp").val();
    var netmask = $("#SettingNetmask").val();
    var gateway = $("#SettingGateway").val();
    var dns0 = $("#SettingDns0").val();
    var dns1 = $("#SettingDns1").val();
    var dns2 = $("#SettingDns2").val();
    var gateway_mac_address = $("#wifi_network_settings_gateway_mac_address").val();
    
    $.ajaxAPI({
        "url": "network_configuration", 
        "type": "PUT",
        "data": {'proto': 'static', 'ip': ip, 'netmask': netmask, 'gateway': gateway, 'dns0': dns0, 'dns1': dns1, 'dns2': dns2, 'gateway_mac_address': gateway_mac_address},
        "timeout": ajaxTimeoutNetwork,
        "success": function(data, textStatus, jqXHR) {
            if (ip != gIPAddress) {
                stopPolling();
                window.location = 'http://'+ip;
            }
            else {
                hideLoading();
                updateWifiClientAccessPointList();
            }
        },
        "error": function (request, status, error) {
            // workaround to redirect after timeout (until API can returns response)
            if (error == 'timeout') {
                stopPolling();
                window.location = 'http://'+ip;
            }
            else {
                processAndDisplayError(request.responseText, 'put_network_configuration', request.status);
                hideLoading();
            }
        }
    });
}

function verifyCurrentWifiClientConnection(){

    signInWifiStartTimeStamp = new Date().getTime(); // in milliseconds

    var dialogTitle = dictionaryList['connecting_to_title'];
    if (signInToOtherNetwork) {
        dialogTitle = dialogTitle.replace('{0}',$('#wifi_signin_to_other_network_form_ssid').val());
    }
    else {
        var ssidName = $('#wifi_signin_form_ssid').text();
        if ((connectToNewNetwork) && (ssidName == gWANSSIDName)) {
            dialogTitle = dictionaryList['modifying_wifi_network_title'];
        }
        dialogTitle = dialogTitle.replace('{0}', ssidName);
    }

    $('#verify_wifi_signin_overlay_title').text(dialogTitle);
    $("#verify_wifi_signin_overlay").dialog("open"); 

    setTimeout("doVerifyCurrentWifiClientConnection();", signInWifiDelay);
}

function doVerifyCurrentWifiClientConnection() {

    if (signInWifiInProgress) {
        return;
    }
    signInWifiInProgress = true;

    var router_ssid = $('#wifi_signin_form_ssid').text();
    var mac_address = $('#wifi_signin_form_mac_address').val();
    var new_trusted = ($('#wifi_signin_form_trusted').val());

    if (modifyCurrentNetwork) {
        router_ssid = gWANSSIDName;
        new_trusted = ($('#wifi_modify_form_trusted').val());
        mac_address = $('#wifi_modify_form_mac_address').val();
    }
    else if (signInToOtherNetwork) {
        router_ssid = $('#wifi_signin_to_other_network_form_ssid').val();
        new_trusted = ($('#wifi_signin_to_other_network_form_trusted').val());
        mac_address = '';
    }

    $.ajaxAPI({
        "url": "current_wifi_client_connection",
        "timeout": ajaxTimeoutFast,
        "success": function(data, textStatus, jqXHR) {

            gConnectedNetwork = false;
			if (data != null && data.current_wifi_client_connection != null && data.current_wifi_client_connection.connected != null) {
                if (data.current_wifi_client_connection.ssid != null && data.current_wifi_client_connection.ssid != '') {
    
                    if ((router_ssid == data.current_wifi_client_connection.ssid) && 
                        (new_trusted == data.current_wifi_client_connection.trusted) && 
                        ((signInToOtherNetwork) || (mac_address == data.current_wifi_client_connection.mac))) 
                    {
                        gWANSSIDName = data.current_wifi_client_connection.ssid;
                        gConnectedNetwork = true;

                        if (data.current_wifi_client_connection.trusted.toLowerCase() == 'true') {
                            gTrustedNetwork = true;
                        }
                        else {
                            gTrustedNetwork = false;
                        }
        
                        //if (!gFoundMe) {
                        //    $('#verify_wifi_signin_overlay').dialog('close');
                        //    processSignInTrustedCompletefromHomeRouter(gWANSSIDName, gDeviceName);
                        //} 
                        //else {
                            signinCompletfromDirectConnect(router_ssid);
                        //}

                        return;
                    }
                }
                else if (data.current_wifi_client_connection.code != null && data.current_wifi_client_connection.code != '') {
                    var code = data.current_wifi_client_connection.code;
                    if (code != 5) {    // code=5 is Success
                        $("#verify_wifi_signin_overlay").dialog("close"); 
                        if (code == 10 && wifi_signin_with_wps_pin) {
                            showError('current_wifi_client_connection_'+code+'_wps_pin');
                        }
                        else {
                            showError('current_wifi_client_connection_'+code);
                        }

                        wifiApListAutoClickFlag = false;
                        $('.wifi_ap_list_item.selected').click();
                        wifiApListAutoClickFlag = true;

                        $('.wifi_ap_list_item').removeClass('selected');
                        return;
                    }
                }
            }

            // avoid infinitely calling doVerifyCurrentWifiClientConnection() by checking timeout
            var signInWifiCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((signInWifiCurrentTimeStamp - signInWifiStartTimeStamp) > signInWifiTimeOutMax) {
                showVerifyCurrentWifiClientConnectionTimeout();
                return;
            }
            setTimeout('doVerifyCurrentWifiClientConnection();', signInWifiDelay);
        },
        "error": function (request, status, error) {

            // avoid infinitely calling doVerifyCurrentWifiClientConnection() by checking timeout
            var signInWifiCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((signInWifiCurrentTimeStamp - signInWifiStartTimeStamp) > signInWifiTimeOutMax) {
                showVerifyCurrentWifiClientConnectionTimeout();
                return;
            }
            setTimeout("doVerifyCurrentWifiClientConnection();", signInWifiDelay);
        },
        "complete": function (jqXHR, textStatus) {
            signInWifiInProgress = false;
        }
    });
}

function verifyCurrentWifiClientConnectionFromHomeRouter(){

    signInWifiStartTimeStamp = new Date().getTime(); // in milliseconds

    var dialogTitle = dictionaryList['connecting_to_title'];
    if (signInToOtherNetwork) {
        dialogTitle = dialogTitle.replace('{0}',$('#wifi_signin_to_other_network_form_ssid').val());
    }
    else {
        var ssidName = $('#wifi_signin_form_ssid').text();
        if ((connectToNewNetwork) && (ssidName == gWANSSIDName)) {
            dialogTitle = dictionaryList['modifying_wifi_network_title'];
        }
        dialogTitle = dialogTitle.replace('{0}', ssidName);
    }

    $('#verify_wifi_signin_overlay_title').text(dialogTitle);
    $("#verify_wifi_signin_overlay").dialog("open"); 

    setTimeout("doVerifyCurrentWifiClientConnectionFromHomeRouter();", signInWifiDelay);
}

function doVerifyCurrentWifiClientConnectionFromHomeRouter() {

    if (signInWifiInProgress) {
        return;
    }
    signInWifiInProgress = true;

    var router_ssid = $('#wifi_signin_form_ssid').text();
    var mac_address = $('#wifi_signin_form_mac_address').val();
    var new_trusted = ($('#wifi_signin_form_trusted').val());

    if (modifyCurrentNetwork) {
        router_ssid = gWANSSIDName;
        new_trusted = ($('#wifi_modify_form_trusted').val());
        mac_address = $('#wifi_modify_form_mac_address').val();
    }
    else if (signInToOtherNetwork) {
        router_ssid = $('#wifi_signin_to_other_network_form_ssid').val();
        new_trusted = ($('#wifi_signin_to_other_network_form_trusted').val());
        mac_address = '';
    }
    gConnectedNetwork = false;

    $.ajaxAPI({
        "url": "current_wifi_client_connection",
        "timeout": ajaxTimeoutFast,
        "success": function(data, textStatus, jqXHR) {

            if (data != null && data.current_wifi_client_connection != null && data.current_wifi_client_connection.connected != null) {
                if (data.current_wifi_client_connection.ssid != null && data.current_wifi_client_connection.ssid != '') {
                
                    // if ssid, mac, and trusted matched then we have modified
                    if ((router_ssid == data.current_wifi_client_connection.ssid) && 
                        (mac_address == data.current_wifi_client_connection.mac) &&
                        (new_trusted == data.current_wifi_client_connection.trusted)) 
                    {
                        gConnectedNetwork = true;
                        gWANSSIDName = data.current_wifi_client_connection.ssid;

                        if (data.current_wifi_client_connection.trusted.toLowerCase() == 'true') {
                            gTrustedNetwork = true;
                        }
                        else {
                            gTrustedNetwork = false;
                        }

                    }
                }
                else if (data.current_wifi_client_connection.code != null && data.current_wifi_client_connection.code != '') {
                    var code = data.current_wifi_client_connection.code;
                    if (code != 5) {    // code=5 is Success
                        $("#verify_wifi_signin_overlay").dialog("close"); 
                        if (code == 10 && wifi_signin_with_wps_pin) {
                            showError('current_wifi_client_connection_'+code+'_wps_pin');
                        }
                        else {
                            showError('current_wifi_client_connection_'+code);
                        }

                        wifiApListAutoClickFlag = false;
                        $('.wifi_ap_list_item.selected').click();
                        wifiApListAutoClickFlag = true;

                        $('.wifi_ap_list_item').removeClass('selected');
                        return;
                    }
                }
            }

            // avoid infinitely calling doVerifyCurrentWifiClientConnectionFromHomeRouter() by checking timeout
            var signInWifiCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((signInWifiCurrentTimeStamp - signInWifiStartTimeStamp) > signInWifiTimeOutMax) {
                showVerifyCurrentWifiClientConnectionTimeout();
                return;
            }
            setTimeout('doVerifyCurrentWifiClientConnectionFromHomeRouter();', signInWifiDelay);
        },
        "error": function (request, status, error) {

            if (!gFoundMe) {
                $('#verify_wifi_signin_overlay').dialog('close');
                if (new_trusted == 'true') {
                    processSignInTrustedCompletefromHomeRouter(router_ssid, gDeviceName);
                }
                else {
                    processSignInUnTrustedCompletefromHomeRouter(router_ssid, gDeviceName, gSSIDName);
                }
                return;
            }
          // avoid infinitely calling doVerifyCurrentWifiClientConnectionFromHomeRouter() by checking timeout
            var signInWifiCurrentTimeStamp = new Date().getTime(); // in milliseconds
            if ((signInWifiCurrentTimeStamp - signInWifiStartTimeStamp) > signInWifiTimeOutMax) {
                showVerifyCurrentWifiClientConnectionTimeout();
                return;
            }
            setTimeout('doVerifyCurrentWifiClientConnectionFromHomeRouter();', signInWifiDelay);
        },
        "complete": function (jqXHR, textStatus) {
            signInWifiInProgress = false;
        }
    });
}

function signinCompletfromDirectConnect(router_ssid) {

    $('.wifi_ap_list_item').removeClass('selected');

    $("#verify_wifi_signin_overlay").dialog("close"); 

    enableIdTag('.network_separator2');

    // remove old connected info
    removeOldWiFiConnectedInfo();

    // add connected info
    var connected_wifi_mac = $('#wifi_signin_form_mac_address').val();
    $('#wifi_ap_list_content ul li').each(function (i) {
        if ( $(this).find('.wireless_ap_mac').text() == connected_wifi_mac) {
            $(this).addClass('connected').find('.wifi_ap_list_item_icon').addClass('icon_ap_connected');
            return;
        }
    });
            
    updateWifiClientConnection(true);
    updateWifiClientAccessPointList();
}

function processSignInTrustedCompletefromHomeRouter(router_ssid, devicename) {

    var deviceNameURL = getDeviceNameURL(devicename);
    var router_ssid_bold = '<b><i>'+router_ssid+'</i></b>';

    var msg = dictionaryList['home_mode_reconnect_intro'].replace('{0}',router_ssid_bold);
    $('#home_network_reconnect_intro').html(msg);

    msg = dictionaryList['home_network_reconnect_tip_1'].replace('{0}',router_ssid_bold);
    $('#home_network_reconnect_tip_1').html(msg);

    msg = dictionaryList['home_network_reconnect_tip_2'].replace('{0}',router_ssid_bold);
    msg = msg.replace('{1}','<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
    $('#home_network_reconnect_tip_2').html(msg);

    $('#signin_complete_message_to_home_mode').show();
    $('#signin_complete_message_to_hotspot').hide();

    resetNetworkConnectionDiagram('mode_trusted_network');
    $('.connection_text').text(router_ssid);
    $('.device_text').text(devicename);	

    $('#wifi_signin_complete_message_overlay').dialog('open');
}

function processSignInUnTrustedCompletefromHomeRouter(router_ssid, devicename, avatar_ssid) {

    var deviceNameURL = getDeviceNameURL(devicename);
    var router_ssid_bold = '<b><i>'+router_ssid+'</i></b>';
    var avatar_ssid_bold = '<b><i>'+avatar_ssid+'</i></b>';

    var msg = dictionaryList['hotspot_direct_connection_reconnect_tip_1'].replace('{0}',avatar_ssid_bold);
    $('#hotspot_connection_reconnect_tip_1').html(msg);

    msg = dictionaryList['hotspot_direct_connection_reconnect_tip_2'].replace('{0}', '<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
    $('#hotspot_connection_reconnect_tip_2').html(msg);

    $('#signin_complete_message_to_home_mode').hide();
    $('#signin_complete_message_to_hotspot').show();

    resetNetworkConnectionDiagram('mode_network_hotspot');
    $('.connection_text').text(avatar_ssid);
    $('.device_text').text(router_ssid);

    $('#wifi_signin_complete_message_overlay').dialog('open');
}

// show the verify wifi_sigin_connection timeout message
function showVerifyCurrentWifiClientConnectionTimeout() {

    var dialogTitle = dictionaryList['unable_to_connect_title'];
    if (signInToOtherNetwork) {
        dialogTitle = dialogTitle.replace('{0}',$('#wifi_signin_to_other_network_form_ssid').val());
    }
    else {
        dialogTitle = dialogTitle.replace('{0}',$('#wifi_signin_form_ssid').text());
    }
    $('#verify_wifi_signin_overlay_title').text(dialogTitle);

    $('#verify_wifi_signin_overlay').find('.verify_wifi_signin_status').hide();

    if (wifi_signin_with_wps_pin) {
        $('#verify_wifi_signin_overlay').find('.wps_failed').show();
    }
    else {
        $('#verify_wifi_signin_overlay').find('.password_failed').show();
    }

    $('#verify_wifi_signin_overlay').find('.dialog_form_controls').show();
}

function getInternetConnectivity() {

    checkInternetConnectivityCount++;

    $.ajaxAPI({
        "url": 'internet_access',
        "success": function(data){
            if (data != null && data.internet_access != null) {
                if (data.internet_access.connectivity.toLowerCase() == 'true') {
                    $('#no_internet_access').hide();
                    gInternetAccess = true;
                }
                else {
                    //$('#no_internet_access').show();
                    gInternetAccess = false;
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            if (!gInternetAccess) {
                if (checkInternetConnectivityCount < maxCheckInternetConnectivityCount) {
                    setTimeout("getInternetConnectivity();", 2000);
                }
                else if (gConnectedNetwork) {
                    $('#no_internet_access').show();
                }
            }
        }
    });
}

function getSSIDName() {

    // get SSID Name of Avatar
    $.ajaxAPI({
        "url": "wifi_ap",
        "timeout": ajaxTimeout,
        "success": function(data, textStatus, jqXHR) {
            if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
                gSSIDName = data.wifi_ap.ssid;
            }
        },
        "error": function (request, status, error) {
        }
    });
}

function forgetThisCurrentConnection(mac_address) {

    displayLoading();
    $.ajaxAPI({
        "url": "current_wifi_client_connection"+"/"+mac_address, 
        "type": "DELETE",
        "success": function(data, textStatus, jqXHR) {
            hideLoading();
            gTrustedNetwork = false;
            gConnectedNetwork = false;

            $('.wifi_ap_list_item').removeClass('selected');

            disableIdTag('.network_separator2');

            // remove old connected info
            removeOldWiFiConnectedInfo();

            if (gTrustedNetwork && !gFoundMe) {
                displayDisableDisconnectCompleteMessage();
            }
            else {
                updateWifiClientConnection();
                updateWifiClientAccessPointList();
            }
        },
        "error": function (request, status, error) {
            hideLoading();
            if (gTrustedNetwork && !gFoundMe) {
                displayDisableDisconnectCompleteMessage();
            }
        }
    });
}

function forgetThisRememberedNetwork(mac_address) {

    displayLoading();
    $.ajaxAPI({
        "url": "wifi_client_access_points"+"/"+mac_address, 
        "type": "PUT",
        "data": {"remember_network":"false"},
        "success": function(data, textStatus, jqXHR) {
            $('#wifi_enabled_form').restForm("refreshForm");
        },
        "error": function (request, status, error) {
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });
}

function displayDisableDisconnectCompleteMessage() {

    var deviceNameURL = getDeviceNameURL(gDeviceName);
    var ssidname = '<b><i>'+gSSIDName+'</i></b>';
    var msg = dictionaryList['hotspot_direct_connection_reconnect_tip_1'].replace('{0}',ssidname);
    $('#direct_connection_reconnect_tip_1').html(msg);

    msg = dictionaryList['hotspot_direct_connection_reconnect_tip_2'].replace('{0}', '<a href="'+deviceNameURL+'">'+deviceNameURL+'</a>');
    $('#direct_connection_reconnect_tip_2').html(msg);

    resetNetworkConnectionDiagram('mode_direct_connection');
    $('.connection_text').text('');
    $('.device_text').text(gSSIDName);

    $('#wifi_disable_disconnect_complete_message_overlay').dialog('open');

    gTrustedNetwork = false;
    gConnectedNetwork = false;
}

function removeOldWiFiConnectedInfo() {
    $('.wifi_ap_list_item.connected').find('.wifi_ap_list_item_icon').removeClass('icon_ap_connected');
    $('.wifi_ap_list_item.connected').find('.wireless_label_text').removeClass('ap_connected');
    $('.wifi_ap_list_item.connected').find('.wireless_info').removeClass('ap_remembered').removeClass('ap_trusted');
    $('.wifi_ap_list_item').removeClass('connected');
}

function checkWiFiEnabled() {
    // disable the 2nd network separator
    disableIdTag('.network_separator2');

    $('#wifi_enabled_form').restForm("refreshForm");
}
