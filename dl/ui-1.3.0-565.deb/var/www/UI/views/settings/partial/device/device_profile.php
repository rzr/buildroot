<?php
    // NOTE: deprecated
?>
<div class="content_row">
    <form id="settings_device_name_form" action="device_description" method="PUT">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?></label>
        <input id="settings_device_name_form_machine_name" maxlength="15" class="DEVICE_NAME" type="text" name="machine_name" value=""/>
        <input id="settings_device_name_form_machine_desc" type="hidden" name="machine_desc" value=""/>
        <span class="form_controls">
            <input type="submit" value="<?php echo _("BUTTON_SAVE");?>" />
        </span>
    </form>
</div>