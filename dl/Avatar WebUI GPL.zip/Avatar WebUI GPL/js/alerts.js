var alertsViewed = false;
var isIE6 = false;
var checkForNewAlertsFailCount = 0;
var alertsSeverityArray = new Array();
var alertIdArray = new Array();
var alertCodeArray = new Array();
var maxAlertInDropDown = 3;
var uiNotificationLevel = 0;
var alertDeleteInitiated = false;


$(document).ready(function(){

// #########################################################
//                forms 
// #########################################################
	
	
    /* Legacy Sequoia
	$('#alert_level_form').restForm({
	    'refreshDataCallback' : function(data) {
	    
	        uiNotificationLevel = "10";
	        if (typeof data.alert_configuration.min_level_rss != 'undefined'){
                uiNotificationLevel = data.alert_configuration.min_level_rss;
            }
        }

	});
    */
	
	$('#alert_events_form').restForm({
	    'useStubs': false,	     
        'showProcessingCallback': function () {},
        'hideProcessingCallback': function () {},
        'processFormErrorCallback':function(){},

        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
         
            for (i = 0; i < data.alert_events.alerts.alert.length; i++) {
   
                code = data.alert_events.alerts.alert[i].code;
                severity = data.alert_events.alerts.alert[i].severity;
                
                alertsSeverityArray[code] = severity;

            }
            
        	$('#alerts_form').restForm("refreshForm");
        }

	});
	
	$('#alerts_dismiss_all_form').restForm({
	    'useStubs': false,	     

        'processFormSuccessCallback':function(data){
            
            if (data.alerts.status.toLowerCase() == "success"){
                $("#view_all_alerts_dialog").dialog('close');
                
            }
            setNoAlertsInfo();

        }
	});
	
	
	
	$('#alerts_form').restForm({
	    'useStubs': false,	     

        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
            
            // clear out all the notification list
            $('.notification_list_item:first').siblings().remove();
            $('.view_all_notification_list_item:first').siblings().remove();
            alertIdArray.length = 0;
            alertCodeArray.length = 0;
            
            // if there are no alerts then jump out
            if (data.rss.channel.item == undefined) {  
            
                setNoAlertsInfo();                       
                
                return;
            }
            else {
                $('#notification_link_icon').removeClass('noAlerts');
                $('#notification_link_icon').addClass('withAlerts');
                $('#notification_link').removeClass('noAlerts');
                $('#notification_link').addClass('withAlerts');
                $('#no_notifications').css("display", "none");
                $('#notification_display_levels').css("display", "block");            
            }

                   
            if( Object.prototype.toString.call( data.rss.channel.item ) != '[object Array]' ){
                data.rss.channel.item = $.makeArray(data.rss.channel.item);
            }
            
            
            for (i = 0; i < data.rss.channel.item.length; i++) {
                link = data.rss.channel.item[i].link;
                
                // parse the link element to get the code and the timestamp
                alertLinkArray = link.split('?');                
                array2 = alertLinkArray[1];             
                codeArray = array2.split('&');                
                codeTextElement = codeArray[0];
                code = codeTextElement.split("=")[1];                
                timeStampArray = codeArray[1];                
                timeStamp = timeStampArray.split("=")[1];
                alertId =  code + timeStamp;   
                
                if (codeArray.length > 2) {
                    alertIdString = codeArray[2];
                    alertId = alertIdString.split("=")[1];
                
                }
                alertIdFound = false;
                
                for (j=0; j< alertIdArray.length; j++){
                    if (alertId == alertIdArray[j]) {
                        alertIdFound = true;
                    }                    
                }
                
                alertCodeFound = false;
                for (j=0; j< alertCodeArray.length; j++){
                    if (code == alertCodeArray[j]) {
                        alertCodeFound = true;
                    }                    
                }
                
                // if the alert was not found in the id list then add it to the list
                if (!alertIdFound) {
                    alertSeverity = "info";
                    if (alertsSeverityArray.length >= code) {
                        if (alertsSeverityArray[code] != undefined) {
                            alertSeverity = alertsSeverityArray[code].toLowerCase();
                        }
                    }
                     
                    index = alertIdArray.length;
                    alertIdArray[index] = alertId;
                    if (alertCodeFound && alertSeverity == "info") {
                    
                        // loop over the notification drop down list
                        $('#notification_list ul li').each(function (j) {
                            
                            liCode = $(this).find('.notification_code').html();

                            // skip the first list element, it is the template
                            if (j != 0 && code == liCode) {            
                                // #######################################################
                                // add the additional alert id on here!!!!
                                // #######################################################
                                liCount = $(this).find('.notification_count').html();                                
                                liCount ++;
                                alertIDs = $(this).find('.notification_id_list').html(); 
                                alertIDs += ','+ alertId;
                                $(this).find('.notification_id_list').html(alertIDs);
                                $(this).find('.notification_count').html(liCount);
                                
                                liId = $(this).attr('id');
                                $('#alert_view_all_'+liId).find('.notification_count').html(liCount);
                                $('#alert_view_all_'+liId).find('.notification_id_list').html(alertIDs);
                                

                            }
                        });
                    }
                    else {

                        codeIndex = alertCodeArray.length;
                        alertCodeArray[codeIndex] = code;
                                                    
                        cloneLi = $('#notification_list').find('ul.notification_ul li:first').clone();
                        cloneLiDialog = $('#dialog_notification_list').find('ul.dialog_notification_ul li:first').clone();
                        cloneLi.attr('id', alertId);
                        cloneLiDialog.attr('id', 'alert_view_all_'+alertId);
                        cloneLi.find('.notification_title').html(data.rss.channel.item[i].title);

                        cloneLi.find('.notification_id_list').html(alertId);
                        cloneLiDialog.find('.notification_id_list').html(alertId);
                       
                        cloneLi.find('.notification_code').html(code);

                        switch (alertSeverity) {
                        case "info":
                            cloneLi.addClass('notification_sev3');
                            cloneLiDialog.addClass('notification_sev3');
                            cloneLi.find('.notification_title').addClass('notification_info_icon');
                            cloneLiDialog.find('.notification_title').addClass('notification_info_icon');
                            cloneLi.addClass('alert_info');
                            cloneLiDialog.addClass('alert_info');
                            break;
                        case "warning":
                            cloneLi.addClass('notification_sev2');
                            cloneLiDialog.addClass('notification_sev2');
                        	cloneLi.find('.notification_title').addClass('notification_warning_icon');
                        	cloneLiDialog.find('.notification_title').addClass('notification_warning_icon');
                            cloneLi.addClass('alert_warning');
                            cloneLiDialog.addClass('alert_warning');
                            break;
                        case "critical":
                            cloneLi.addClass('notification_sev1');
                            cloneLiDialog.addClass('notification_sev1');
                        	cloneLi.find('.notification_title').addClass('notification_critical_icon');
                        	cloneLiDialog.find('.notification_title').addClass('notification_critical_icon');
                            cloneLi.addClass('alert_critical');
                            cloneLiDialog.addClass('alert_critical');
                            break;
                        default:
                            break;
                        }
                        
                        cloneLiDialog.find('.notitication_code').html(code);
                        cloneLiDialog.find('.dialog_notification_description').html(data.rss.channel.item[i].description);
                        cloneLiDialog.find('.notification_title').html(data.rss.channel.item[i].title);
                        cloneLiDialog.find('.notification_more_info').attr('id', 'alerts_more_info_'+alertId);
                        cloneLiDialog.find('.notitication_code').attr('id', 'alerts_dialog_notification_code_'+alertId);
                        dialogDeleteItem =  cloneLiDialog.find('.notification_dialog_ignore_alert');
                        dialogDeleteItem.attr('id', 'delete_dialog_'+alertId);

                        if (code == 2001) {
                            cloneLiDialog.find('.all_alert_speciality_link').attr("id","code_"+code);
                            cloneLiDialog.find('.all_alert_speciality_link').text(dictionaryList["begin_update"]);
                            cloneLiDialog.find('.all_alert_speciality_container').show();
                        }
                        else if (code == 2002) {
                            cloneLiDialog.find('.all_alert_speciality_link').attr("id","code_"+code);
                            cloneLiDialog.find('.all_alert_speciality_link').text(dictionaryList["install_update"]);
                            cloneLiDialog.find('.all_alert_speciality_container').show();
                        }
                        /* Legacy - product improvement special code
                        else if (code == 2035) {
                            cloneLiDialog.find('.all_alert_speciality_link').attr("id","code_"+code);
                            cloneLiDialog.find('.all_alert_speciality_link').text(dictionaryList["learnMoreTxt"]);
                            cloneLiDialog.find('.all_alert_speciality_container').show();
                        }
                        */
                        else {
                            cloneLiDialog.find('.all_alert_speciality_container').remove();
                        }
                                    
                        alert_time_string = getTimeStamp(timeStamp);

                        cloneLi.find('.notification_time').html(alert_time_string);
                        cloneLi.find('.notification_time').attr('id','list_notification_time_'+alertId);

                        cloneLiDialog.find('.notification_time').html(alert_time_string);
                        cloneLiDialog.find('.notification_time').attr('id','dialog_notification_time_'+alertId);

                        deleteItem = cloneLi.find('.notification_ignore');
                        deleteItem.attr('id', 'delete_'+alertId);
                        detailsItem = cloneLi.find('.notification_see_details');
                        detailsItem.attr('id', 'alert_details_'+alertId);
                        cloneLiDialog.css('display', 'block');

                        cloneLi.appendTo($('#notification_list').find('ul.notification_ul'));
                        cloneLiDialog.appendTo($('#dialog_notification_list').find('ul.dialog_notification_ul')); 

                        localizeTimeStamp('#list_notification_time_'+alertId);
                        localizeTimeStamp('#dialog_notification_time_'+alertId);

                    }              
                }
               
            }            
            $('#view_all_alerts_button').css("display", "none");
            $('#notification_see_all').removeClass("view_all");
            $('#notification_see_all').removeClass("no_alerts");
            $('#notification_see_all').addClass("no_view_all");            
        

            updateNotificationToolbar();

            // loop over the notification drop down list
            $('#notification_list ul li').each(function (j) {                
                if (j != 0 && j <(maxAlertInDropDown+1)) {
                    $(this).css("display", "block");                    
                }
                else if (j == (maxAlertInDropDown+1)){
                    $('#view_all_alerts_button').css("display", "block");            
                    $('#notification_see_all').removeClass("no_view_all");
                    $('#notification_see_all').removeClass("no_alerts");
                    $('#notification_see_all').addClass("view_all");

                }
            });

        },
        'processFormErrorCallback': function(){ // temporarily disable error popups for alerts returning Internal Server Error
        }

	});
	
// #########################################################
//                dialogs 
// #########################################################

    $("#view_all_alerts_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_notifications',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#view_all_alerts_dialog').attr('title')+'</div>',
        open: function(){
            $('#alerts_view_all_cancel_button').focus();
        }
    });
    
    $("#view_single_alert_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: 500,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#view_single_alert_dialog').attr('title')+'</div>'
    });

    // Russian legend text takes the entire line
    if (gLanguage == 'ru_RU') {
        $('.notification_legend_table').addClass('padding_left_none');
    }

});	

// ###############################################################
//
//              functions
//
// ###############################################################

function initAlerts(useQueue) {
	if (typeof useQueue == 'undefined'){
		useQueue = false;
	}
	$('#alert_events_form').restForm("refreshForm", useQueue);
    $('#alert_level_form').restForm("refreshForm", useQueue);

    if (updateCountHandler != null) {
        updateCountHandler.subscribe("alert_update_count", function () {
            // if the update count change was not due to a delete initiated from this UI
            if (!alertDeleteInitiated) {
                //make an ajax call to retrieve a new list of alerts
            	$('#alerts_form').restForm("refreshForm");
            }
            else {
                alertDeleteInitiated = false;
            }
        });
    }
}

$(function(){
 
    $('#alert_begin_update_link').live('click', function() { 
        $("#view_single_alert_dialog").dialog('close');
        var alertID = $(this).attr('rel');

        if (alertID == 2001) {
            // 2001 is firmware available
            checkForFirmwareAvailable();
        }
        else if (alertID == 2002) {
            // 2002 is firmware downloaded
            checkForFirmwareInstall();
        }
    });

    $('.all_alert_speciality_link').live('click', function(e) { 
        e.preventDefault();

        $("#view_all_alerts_dialog").dialog('close');
        var ID = $(this).attr('id');

        if (ID == 'code_2001') {
            // 2001 is firmware available
            checkForFirmwareAvailable();
        }
        else if (ID == 'code_2002') {
            // 2002 is firmware downloaded
            checkForFirmwareInstall();
        }
        /* Legacy - product improvement special code
        else if (ID == 'code_2035') {
            $("#product_improvement_dialog").dialog('open');
        }
        */
        return false;
    });
    
     
 $('#view_all_alerts_button').live('click', function(event) {
    //$(".all_alert_speciality_link").text(dictionaryList["begin_update"]);
    $("#view_all_alerts_dialog").dialog('open');
    $('#notification_list_container').toggle();
    $('#notification_link').removeClass('selected');
 });

 $('.notification_see_details').live('click', function(event) {
    
    detailsDivID = $(event.target).attr('id');
    alertId = detailsDivID.split("_")[2];
    
    alertLi = $('#'+alertId);
    
    $("#view_single_alert_dialog").parent().removeClass('mochi_dialog_info');
    $("#view_single_alert_dialog").parent().removeClass('mochi_dialog_warning');
    $("#view_single_alert_dialog").parent().removeClass('mochi_dialog_critical'); 

    if (alertLi.hasClass('alert_info')) {
         $("#view_single_alert_dialog").parent().addClass('mochi_dialog_notifications_info');

//	    $("#alert_details_info_icon").css("display", "inline-block"); 
//	    $("#alert_details_warning_icon").css("display", "none");  
//	    $("#alert_details_critical_icon").css("display", "none"); 													
    }
    else if (alertLi.hasClass('alert_warning')) {
        $("#view_single_alert_dialog").parent().addClass('mochi_dialog_warning');
//	    $("#alert_details_info_icon").css("display", "none"); 
//	    $("#alert_details_warning_icon").css("display", "inline-block");  
//	    $("#alert_details_critical_icon").css("display", "none"); 													    
    }
    else{
        $("#view_single_alert_dialog").parent().addClass('mochi_dialog_critical');
//	    $("#alert_details_info_icon").css("display", "none"); 
//	    $("#alert_details_warning_icon").css("display", "none");  
//	    $("#alert_details_critical_icon").css("display", "inline-block"); 													    
    } 
   
    alertViewAllLi = $('#alert_view_all_'+alertId); 

    //titleText = alertViewAllLi.find('.notification_title').html();
    //alertTitle = '<div class="wizard_dialog_title">'+titleText+'</div>';
    alertCode = alertViewAllLi.find('.notitication_code').html();

    if (alertCode == 2001) {
        $("#alert_begin_update_link").text(dictionaryList["begin_update"]);
        $("#alert_begin_update_link").attr('rel',alertCode);
        $("#single_alert_begin_update").show();
    }
    else if (alertCode == 2002) {
        $("#alert_begin_update_link").text(dictionaryList["install_update"]);
        $("#alert_begin_update_link").attr('rel',alertCode);
        $("#single_alert_begin_update").show();
    }
    /* Legacy - product improvement special code
    else if (alertCode == 2035) {
        $("#product_improvement_dialog").dialog('open');
        return;
    }
    */
    else {
        $("#single_alert_begin_update").hide();
    }
    
    //$('#view_single_alert_dialog').dialog("option", "title", alertTitle);


    
    $('#alert_details_title').html(alertViewAllLi.find('.notification_title').html());
    $('#alert_details_description').html(alertViewAllLi.find('.dialog_notification_description').html());
    $('#alert_details_time').html(alertViewAllLi.find('.notification_time').html()); 
    $('#single_alert_details_code').html(alertCode);        
    
    $("#view_single_alert_dialog").dialog('open');
    $('#notification_list_container').toggle();
    $('#notification_link').removeClass('selected');    
 });
 
  $('#alerts_view_single_alert_cancel_button').live('click', function(event) {
    
    $("#view_single_alert_dialog").dialog('close');    
 });
 
 
 $('#alerts_view_all_cancel_button').live('click', function(event) {
    $("#view_all_alerts_dialog").dialog('close');
 }); 
 
 $('#alerts_view_dismiss_all_button').live('click', function(event) {
    $('#alerts_dismiss_all_form').submit();
    alertDeleteInitiated = true;

 });


$('.notification_dialog_ignore_alert').live('click', function(event) {
    deleteDivID = $(event.target).attr('id');
    alertId = deleteDivID.split("_")[2];
    delete_alert(deleteDivID, alertId);
});

 $('.notification_ignore').live('click', function(event) { 
    
    deleteDivID = $(event.target).attr('id');
    alertId = deleteDivID.split("_")[1];
    delete_alert(deleteDivID, alertId);

 });
 
 }); 
 	
 function delete_alert(deleteDivID, alertId) {
	    
        
        
        alertIDs = $('#'+alertId).find('.notification_id_list').html(); 
        alertIDs_list = alertIDs.split(',');

        // loop through all alert ids for this alert code and remove them
        for(var idx=0; idx < alertIDs_list.length; idx++) {            
            $('#alerts_form').find('#alerts_acknowledge_alert_id').val(alertIDs_list[idx]);
            $('#alerts_form').submit();
        }

        alertDeleteInitiated = true;
        nextLi = $('#'+alertId).next();

        $('#'+alertId).remove();
        $('#alert_view_all_'+alertId).remove();
                     
        keepGoing = true;
        
        // look to see if there is an alert that is not visible in the alert pulldown and
        // make it visible
        while (nextLi.length > 0 && keepGoing){      
        
//            // if the next div is not visible then make it visible and stop looping
            if (!nextLi.is(":visible")){ 
                nextLi.css('display', 'block');
                keepGoing = false;
            }
            else {
                nextLi = nextLi.next();
            }

        }
	    
        // if the list length > max (+1 since there is a template in the list) then display view all button
        if ($('#notification_list_container ul li').length <= (maxAlertInDropDown+1)){
            $('#view_all_alerts_button').css("display", "none");
        }
        else {
            $('#view_all_alerts_button').css("display", "block");            
        }           
        
        // if there are no alerts (only the template) then show no alerts 
        if ($('#notification_list_container ul li').length <= 1){
            setNoAlertsInfo();
        }   

        updateNotificationToolbar();
}


function setNoAlertsInfo() {                       
    
    $('.notification_list_item:first').siblings().remove();
    $('.view_all_notification_list_item:first').siblings().remove();
            
    $('#notification_link_icon').removeClass('withAlerts');
    $('#notification_link_icon').addClass('noAlerts');
    $('#notification_link').removeClass('withAlerts');
    $('#notification_link').addClass('noAlerts');
//    switch (uiNotificationLevel) {
//    case "1":   // critical only
//        $('#no_alerts_message').html(dictionaryList['NoCritAlertsTxt']);
//        break;
//    case "5":  // critical and warning
//        $('#no_alerts_message').html(dictionaryList['NoCritWarnAlertsTxt']);
//        break;
//    case "10":  // all
        $('#no_alerts_message').html(dictionaryList['NoAlertsTxt']); 

//        break;
//    default:
//        break;

//    }                        
   // $('#no_notifications').css("display", "block");
    $('#notification_see_all').removeClass("no_view_all");
    $('#notification_see_all').addClass("no_alerts");
    $('#notification_see_all').removeClass("view_all");
    $('#notification_display_levels').css("display", "none");
    $('#view_all_alerts_button').css("display", "none");

    updateNotificationToolbar();
 }
 
 function toggleNotificationListContainer() {
    
    // if the notification list will be displayed then apply the alert filter
    if (!$('#notification_list_container').is(":visible")){

        dropDownCount = 0;

        // loop over the notification drop down list
        $('#notification_list_container ul li').each(function (i) {
            
            $(this).css('display', 'none');
            // skip the first list element, it is the template
            if (i != 0 && dropDownCount < maxAlertInDropDown) {            
                $(this).css('display', 'block');
                dropDownCount++;
            }
        });
            
    }
    
 //   if (dropDownCount != 0 || $('#notification_list_container').is(":visible")) {
        $('#notification_list_container').toggle();
 //   }
 }

// $('.notification_more_info').live('click', function(event) { 
//    moreInfoLinkID = $(event.target).attr('id');
//    alertId = moreInfoLinkID.split("_")[3];
//    notificationCode = $('#alerts_dialog_notification_code_'+alertId).html();
//    alert('This will display more information for alert code '+notificationCode);

// });


// $('.notification_single_alert_more_info').live('click', function(event) { 
////    moreInfoLinkID = $(event.target).attr('id');
////    alertId = moreInfoLinkID.split("_")[3];
////    notificationCode = $('#alerts_dialog_notification_code_'+alertId).html();
//    alert('This will display more inforation for this alert');
//   // $("#alerts_more_info_dialog").dialog('open');    

// });

function updateNotificationToolbar() {

    // loop over the notification drop down list
    var severity = 0;
    $('#notification_list_container ul li').each(function (i) {

        // skip the first list element, it is the template
        if (i != 0) {
            if ($(this).hasClass('alert_info')) {
                if (severity < 1) {
                    severity = 1;
                }
            }
            else if ($(this).hasClass('alert_warning')) {
                if (severity < 2) {
                    severity = 2;
                }
            }
            else if ($(this).hasClass('alert_critical')) {
                if (severity < 3) {
                    severity = 3;
                }
            }

            var liCount = $(this).find('.notification_count').html();
            if (liCount > 1) {
                $(this).find('.totalcount').remove();
                alertMsg = $(this).find('.notification_title').html() + '<span class="totalcount">&nbsp;('+liCount+')</span>';
                $(this).find('.notification_title').html(alertMsg);
            }
        }
    });

    $('#dialog_notification_list ul li').each(function (i) {
        if (i != 0) {
            var liCount = $(this).find('.notification_count').html();
            if (liCount > 1) {
                $(this).find('.totalcount').remove();
                alertMsg = $(this).find('.notification_title').html() + '<span class="totalcount">&nbsp;('+liCount+')</span>';
                $(this).find('.notification_title').html(alertMsg);
            }
        }
    });

    $('#notification_list ul li').tsort({attr:'class'});
    $('#dialog_notification_list ul li').tsort({attr:'class'});

    $('#notification_link').removeClass('notification_critical');
    $('#notification_link').removeClass('notification_none');
    $('#notification_link').removeClass('notification_warn'); 
    /* TBD - support additional icons if required
    $('#notification_link').removeClass('notification_info'); 
    */ 

    $('#notification_link').find('.icon').removeClass('icon_notification_critical');
    $('#notification_link').find('.icon').removeClass('icon_notification_warning'); 
    /* TBD - support additional icons if required
    $('#notification_link').find('.icon').removeClass('icon_notification_info');  
    */ 

    if (severity == 0) {
        $('#notification_link').addClass('notification_none');
    }
    /* TBD - support additional icons if required
    else if (severity == 1) {
        $('#notification_link').addClass('notification_info');
        $('#notification_link').find('.icon').addClass('icon_notification_info');
    }
    */
    else if (severity == 2) {
        $('#notification_link').addClass('notification_warn');
        $('#notification_link').find('.icon').addClass('icon_notification_warning');
    }
    else if (severity == 3) {
        $('#notification_link').addClass('notification_critical');
        $('#notification_link').find('.icon').addClass('icon_notification_critical');
    }

}
