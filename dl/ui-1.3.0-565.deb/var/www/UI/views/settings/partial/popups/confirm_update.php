<div id="confirm_update" title="<?php echo _('PAGE_HEADER_UPDATE_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
		<?php echo _('LABEL_DESCR_AVATAR_UPDATE_FROM_FILE_REBOOT'); ?>
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="confirm_update_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="confirm_update_ok_button" class="mochi_dialog_save_button"><?php echo _('CONTENT_SETTINGS_DIALOG_BUTTON_INSTALL_AND_REBOOT')?></button>
	</div>
</div>
