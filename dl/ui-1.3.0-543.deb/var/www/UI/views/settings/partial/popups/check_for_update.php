<div id="firmware_up_to_date_dialog" title="<?php echo _('PAGE_HEADER_UPDATE_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container dialog_content_length_firmware_up_to_date">
		<div class="mochi_dialog_content">
            <?php echo _('LABEL_DESCR_FIRMWARE_UP_TO_DATE'); ?>
		</div>
	</div>
	<div class="dialog_form_controls">
        <button type="button" id="firmware_up_to_date_dialog_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

<div id="new_firmware_available_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_STRING_NEW_FIRMWARE_AVAILABLE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            
            <p><strong><?php echo _('LABEL_DESCR_FIRMWARE_UPDATE_FOUND'); ?></strong></p>
            
            <!-- used to iterate and display all available firmware packages -->
            <form id="firmware_update_list_form">
                <div id="firmware_update_list">
                    <div class="firmware_update_item">
                        <input type="radio" class="firmware_selection_input" name="firmware_selection" value="" />
                        <span class="firmware_update_name"></span>
                        <span class="firmware_update_version"></span>
                        <span class="firmware_releasenotes"><a href="#" target="_blank"><?php echo _('CONTENT_SETTINGS_LINK_RELEASE_NOTES'); ?></a></span>
                        <span class="firmware_confirmation" rel=""></span>
                    </div>
                </div>
            </form>

            <!-- firmware EULA message -->
            <div id="firmware_update_message">
                <br />
                <iframe id="message_iframe" frameborder="0" height="297px" width="100%"></iframe>  
            </div>

            <!-- checkbox for firmware EULA message -->
            <div id="firmware_update_message_acceptance">
                <br />
                <form id="message_acceptance_form">
                    <input type="checkbox" class="normal_checkbox" id="message_acceptance_input" name="message_acceptance" value=""/>
                    <label class="fw_eula_checkbox_label" for="message_acceptance_input"><?php echo _('LABEL_FW_UPGRADE_EULA_ACCEPTANCE')?></label>
                </form>
            </div>

            <!-- generic upgrade and reboot message -->
            <div id="install_and_reboot_button">
                <ul>
                    <li><?php echo _('LABEL_DESCR_AVATAR_UPDATE_FROM_FILE_REBOOT'); ?></li>
                </ul>
            </div>
            
		</div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="new_firmware_available_dialog_cancel_button" class="cancel"><?php echo _('BUTTON_CANCEL')?></button>
		<button type="button" id="new_firmware_available_dialog_save_button" class="mochi_dialog_save_button"><?php echo _('CONTENT_SETTINGS_DIALOG_BUTTON_INSTALL_AND_REBOOT')?></button>
        <button type="button" id="new_firmware_available_dialog_next_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_NEXT')?></button>
	</div>
</div>
