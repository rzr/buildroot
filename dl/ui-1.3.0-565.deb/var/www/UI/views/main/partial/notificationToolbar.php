<div id="notification_toolbar" class="toolbar_item">
	<div class="toolbar_button_container">
		<a href="#" class="toolbar_button notification_none" id="notification_link">
            <span class="icon"></span>
            <span class="down_arrow"></span>
        </a>
	</div>
	<form id="alert_events_form" method="GET" action="alert_events"></form>
    
	<!--<form id="alert_level_form" method="GET" action="alert_configuration"></form>-->
    
	<form id="alerts_form" method="PUT" action="alerts?simple=true">
		<input type="hidden" id="alerts_acknowledge_alert_id" name="alert_id" value="" /> 
		<input type="hidden" id="alerts_acknowledge_flag" name="ack" value="true" />  
	</form>
    
	<div id="notification_list_container" class="toolbar_button_list_container">
		
		<div id="notification_list">	
			<div id="no_notifications" style="display:none">
				<div class="notification_information">						
					<p class="notification_title" id="no_alerts_message" style="display:inline-block;"></p>				
				</div>
			</div>	
			<ul class="notification_ul">				
				<li style="display:none" class="notification_list_item">
					<div class="notification_information">
                        <div class="notification_title_container">
                            <span class="notification_title notification_info_icon overflow_hidden_nowrap_ellipsis" style="display:inline-block;"></span>
                            <span class="notification_code" style="display:none;"></span>
                            <span class="notification_count" style="display:none;">1</span>
                            <span class="notification_id_list" style="display:none;"></span>
                        </div>
                        <div id="notification_time_container">
                            <div class="notification_time notification_time_indented" style="display:inline-block"></div>
                        </div>
						<div class="notification_functions_container">
							<span class="notification_ignore"></span>
							<span class="notification_see_details"></span>
						</div>
					</div>
				</li>
			</ul>
		</div>
		<div id="notification_display_levels">
            <table class="notification_legend_table">
                <tr>
                    <td class="notification_legend_td" align="middle">
                        <table>
                            <tr>
                                <td nowrap class="notification_level_display notification_level_info"></td>
                                <td><?php echo _('GLOB_NAV_NOTIFICATIONS_LABEL_INFO')?></td>
                            </tr>
                        </table>
                    </td>
                    <td class="notification_legend_td" align="middle">
                        <table>
                            <tr>
                                <td nowrap class="notification_level_display notification_level_warning"></td>
                                <td><?php echo _('GLOB_NAV_NOTIFICATIONS_LABEL_WARNING')?></td>
                            </tr>
                        </table>
                    </td>
                    <td class="notification_legend_td" align="middle">
                        <table>
                            <tr>
                                <td nowrap class="notification_level_display notification_level_critical"></td>
                                <td><?php echo _('GLOB_NAV_NOTIFICATIONS_LABEL_CRITICAL')?></td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
    	</div>
    	
		<div id="notification_see_all" class="view_all">
    		<button id="view_all_alerts_button" style="display:none"><?php echo _('GLOB_NAV_NOTIFICATIONS_BUTTON_VIEW_ALL')?></button>
    	</div>
        
	</div>
</div>