<?php
class PageLoader{
    private $views = array();
    
    function __construct(){
        //read xml files in child folders
        $this->LoadBase();
        $this->LoadComponents();
    }
    
    public function LoadBase(){
        if ($handle = opendir(realpath(dirname(__FILE__)).'/../views'))
        {
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != "..") {
                    $viewsRoot = realpath(dirname(__FILE__)).'/../views';
                    $viewItemRoot = realpath(dirname(__FILE__)).'/../views/'.$entry;
                    
                    $scriptRoot = realpath(dirname(__FILE__)).'/../js/';
                    $scriptLinkRoot = 'js/';

                    $styleRoot = realpath(dirname(__FILE__)).'/../css/';
                    $styleLinkRoot = 'css/';
                    
                    if (is_dir($viewItemRoot))
                    {
                        if (is_file($viewItemRoot.'/config.xml'))
                        {
                            $xml = simplexml_load_file($viewItemRoot.'/config.xml');
                            //$this->views = $this->GetViewFromConfig($xml, $this->views, $viewItemRoot, $viewsRoot);
                             
                            if (isset($xml->views))
                            {
                                foreach ($xml->views->children() as $viewInformation){
                                    if (isset($this->views[$viewInformation->getName()])){
                                        $view = $this->views[$viewInformation->getName()];
                                    }
                                    else{
                                        $view = new View();
                                    }
                                    $view->GetViewFromConfig($viewInformation, $viewItemRoot, $viewsRoot, $scriptRoot, $scriptLinkRoot, $styleRoot, $styleLinkRoot, 'main');
                                    $this->views[$view->identifier] = $view;
                                }
                            }
                        }
                    }
                }
            }
            closedir($handle);
        }
    }
    
    public function LoadComponents(){
        if ($handle = opendir(realpath(dirname(__FILE__)).'/../components'))
        {
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != "..") {
                    if (is_dir(realpath(dirname(__FILE__)).'/../components/'.$entry))
                    {
                        if ($innerHandle = opendir(realpath(dirname(__FILE__).'/../components/'.$entry)))
                        {
                            $viewsRoot = realpath(dirname(__FILE__)).'/../views';
                            $componentRoot = realpath(dirname(__FILE__).'/../components/'.$entry);
                            
                            $scriptRoot = realpath(dirname(__FILE__)).'/../components/'.$entry.'/js';
                            $scriptLinkRoot = 'components/'.$entry.'/js/';
                            
                            $styleRoot = realpath(dirname(__FILE__)).'/../components/'.$entry.'/css';
                            $styleLinkRoot = 'components/'.$entry.'/css/';
                            
                            if (is_file($componentRoot.'/config.xml'))
                            {
                                $xml = simplexml_load_file($componentRoot.'/config.xml');
                                
                                if (isset($xml->views))
                                {
                                    foreach ($xml->views->children() as $viewInformation){
                                        if (isset($this->views[$viewInformation->getName()])){
                                            $view = $this->views[$viewInformation->getName()];
                                        }
                                        else{
                                            $view = new View();
                                        }
                                        $view->GetViewFromConfig($viewInformation, $componentRoot.'/views', $viewsRoot, $scriptRoot, $scriptLinkRoot, $styleRoot, $styleLinkRoot, 'main');
                                        $this->views[$view->identifier] = $view;
                                    }
                                }
                            }
                            closedir($innerHandle);
                        }                
                    }
                }
            }
            closedir($handle);
        }
    }
    
    public function LoadPage(){
        foreach ($this->views as $view){
            $this->LoadView($view);
        }
    }
    
    public function LoadView($view){
        include($view->layout);
    }
}

class View{
    public $layout;
    public $title;
    public $subtitle;
    public $identifier;
    public $navigation;
    public $head;
    public $scripts = array();
    public $styles = array();
    public $views = array();
    public $contents = array();
    
    public function GetViewFromConfig($viewInformation, $viewItemRoot, $viewsRoot, $scriptRoot, $scriptLinkRoot, $styleRoot, $styleLinkRoot, $contentFolder = 'content'){
        if (isset($viewInformation->navigation)){
            foreach ($viewInformation->navigation->navigation_item as $navigationItemXml){
                $navigationItem = new NavigationItem();
                $navigationItem->id = (string)$navigationItemXml->attributes()->id;
                $navigationItem->order = (string)$navigationItemXml->attributes()->order;
                $navigationItem->title = (string)$navigationItemXml;
                $navigationItem->subtitle = (string)$navigationItemXml;
                $navigationItem->group = "0";
                if (isset($navigationItemXml->attributes()->group)){
                    $navigationItem->group = (string)$navigationItemXml->attributes()->group;
                }
                if (isset($navigationItemXml->attributes()->link)){
                    $navigationItem->link = (string)$navigationItemXml->attributes()->link;
                }
                if (!isset($this->navigation->navigationItems[$navigationItem->group][$navigationItem->order])){
                    $this->navigation->navigationItems[$navigationItem->group][$navigationItem->order] = array();
                }
                if (isset($navigationItemXml->attributes()->default)){
                    $navigationItem->default = true;
                }
                $this->navigation->navigationItems[$navigationItem->group][$navigationItem->order][] = $navigationItem;
            }
        }
        
        if (isset($viewInformation->contents)){
            foreach ($viewInformation->contents->content as $contentInformation){
                $contentFile = (string)$contentInformation;
                if (isset($contentFile) && !empty($contentFile) && is_file($viewItemRoot.'/'.$contentFile)){
                    $content = new Content();
                    $content->order = (int)$contentInformation->attributes()->order;
                    $content->file = $viewItemRoot.'/'.$contentFile;
                    $content->column = 0;
                    if (isset($contentInformation->attributes()->column)){
                        $content->column = (int)$contentInformation->attributes()->column;    
                    }
                    if (!isset($this->contents[$content->column])){
                        $this->contents[$content->column] = array();
                    }
                    
                    if (!isset($this->contents[$content->column][$content->order])){
                        $this->contents[$content->column][$content->order] = array();
                    }
                    
                    $this->contents[$content->column][$content->order][] = $content;
                }
            }
        }
        
        if (isset($viewInformation->navigation->layout)){
            if (is_file($viewItemRoot.'/layouts/navigation/'.$viewInformation->layout)){
                $this->navigation->layout = $viewItemRoot.'/layouts/navigation/'.$viewInformation->navigation->layout;
            }
            else{
                $this->navigation->layout = $viewsRoot.'/layouts/navigation/'.$viewInformation->navigation->layout;
            }
        }
        
        $this->identifier = $viewInformation->getName();
        
        $viewInformationTitle = (string)$viewInformation->title;
        if (isset($viewInformation->title) && !empty($viewInformationTitle)){
            $this->title = $viewInformationTitle;
        }
        
        $viewInformationSubTitle = (string)$viewInformation->subtitle;
        if (isset($viewInformation->subtitle) && !empty($viewInformationSubTitle)){
            $this->subtitle = $viewInformationSubTitle;
        }
                
        if (isset($viewInformation->layout)){
            if (is_file($viewItemRoot.'/layouts/content'.$viewInformation->layout)){
                $this->layout = $viewItemRoot.'/layouts/'.$contentFolder.'/'.$viewInformation->layout;
            }
            else{
                $this->layout = $viewsRoot.'/layouts/'.$contentFolder.'/'.$viewInformation->layout;
            }
        }
        
        if (isset($viewInformation->head)){
            if (!isset($this->head)){
                $this->head = new View();
            }
            $this->head->GetViewFromConfig($viewInformation->head, $viewItemRoot, $viewsRoot, $scriptRoot, $scriptLinkRoot, $styleRoot, $styleLinkRoot);
        }
        
        if (isset($viewInformation->views)){
            foreach ($viewInformation->views->children() as $innerViewInformation){
                $viewIdentifier = $innerViewInformation->getName();
                if (!isset($this->views[$viewIdentifier])){
                    $view = new View();
                    $view->order = 0;
                    if (isset($innerViewInformation->attributes()->order)){
                        $view->order = (int)$innerViewInformation->attributes()->order;
                    }
                }
                else{
                    $view = $this->views[$viewIdentifier];
                }
                $view->GetViewFromConfig($innerViewInformation, $viewItemRoot, $viewsRoot, $scriptRoot, $scriptLinkRoot, $styleRoot, $styleLinkRoot);
                $this->views[$viewIdentifier] = $view;
            }
        }
        
        if (isset($viewInformation->scripts)){
            foreach ($viewInformation->scripts->script as $scriptInformation){
                $scriptFile = (string)$scriptInformation;
                if (isset($scriptFile) && !empty($scriptFile) && is_file($scriptRoot.'/'.$scriptFile)){
                    $script = new Script();
                    $script->order = 0;
                    if (isset($scriptInformation->attributes()->order)){
                        $script->order = (int)$scriptInformation->attributes()->order;
                    }
                    $script->file = $scriptLinkRoot.$scriptFile;
                    if (!isset($this->scripts[$script->order])){
                        $this->scripts[$script->order] = array();
                    }

                    $this->scripts[$script->order][] = $script;
                }
            }
        }
            
        if (isset($viewInformation->styles)){
            foreach ($viewInformation->styles->style as $styleInformation){
                $styleFile = (string)$styleInformation;
                if (isset($styleFile) && !empty($styleFile) && is_file($styleRoot.'/'.$styleFile)){
                    $style = new Style();
                    $style->order = 0;
                    if (isset($styleInformation->attributes()->order)){
                        $style->order = (int)$styleInformation->attributes()->order;
                    }
                    $style->file = $styleLinkRoot.$styleFile;
                    if (!isset($this->styles[$style->order])){
                        $this->styles[$style->order] = array();
                    }

                    $this->styles[$style->order][] = $style;
                }
            }
        }
    }
    
    public function LoadNavigation(){
        $identifier = $this->identifier;
        if (isset($this->navigation) && !empty($this->navigation)){
            $navigationItems = $this->navigation->navigationItems;
            if (isset($navigationItems) && !empty($navigationItems)){
                ksort($navigationItems);
                foreach($navigationItems as $index => $innerNavigationItems){
                    ksort($innerNavigationItems);
                    $navigationItems[$index] = $innerNavigationItems;
                }
                if (isset($this->navigation) && !empty($this->navigation->layout)){
                    include($this->navigation->layout);
                }
            }
        }
    }
    
    public function LoadViews(){
        $orderedViews = array();
        foreach ($this->views as $view){
            $orderedViews[$view->order][] = $view;
        }
        ksort($orderedViews);

        foreach ($orderedViews as $viewItems){
            ksort($viewItems);
            foreach ($viewItems as $view){
                $identifier = $view->identifier;
                $title = $view->title;
                if (isset($view->subtitle)){
                    $subtitle = $view->subtitle;
                }
                if (isset($view) && !empty($view->layout)){
                    include ($view->layout);
                }
            }
        }
    }
    
    public function LoadContents($column = null){
        ksort($this->contents);
        if (isset($column)){
            if (isset($this->contents[$column])){
                foreach ($this->contents[$column] as $contentItems){
                    ksort($contentItems);
                    foreach ($contentItems as $content){
                        if (isset($content) && !empty($content->file)){
                            include ($content->file);
                        }
                    }
                }
            }
        }
        else{
            foreach ($this->contents as $columnContents){
                ksort($columnContents);
                foreach ($columnContents as $contentItems){
                    foreach ($contentItems as $content){
                        if (isset($content) && !empty($content->file)){
                            include ($content->file);
                        }
                    }
                }
            }
        }
    }
    
    public function LoadHead(){
        $view = $this->head;
        if (isset($view->contents) && !empty($view->contents)){
            ksort($view->contents[0]);
        }
        if (isset($view) && !empty($view->layout)){
            include($view->layout);
        }
    }

    public function LoadScripts(){
        if (isset($this->scripts) && !empty($this->scripts)){
            ksort($this->scripts);
        }
        if (isset($this->scripts) && !empty($this->scripts)){
            foreach($this->scripts as $scriptOrderArray){
                foreach ($scriptOrderArray as $script){
                    echo '<script src="'.$script->file.'" type="text/javascript"></script>';
                }
            }
        }
    }

    public function LoadStyles(){
        if (isset($this->styles) && !empty($this->styles)){
            ksort($this->styles);
        }
        if (isset($this->styles) && !empty($this->styles)){
            foreach($this->styles as $styleOrderArray){
                foreach ($styleOrderArray as $style){
                    echo '<link href="'.$style->file.'" rel="stylesheet" type="text/css" />';
                }
            }
        }
    }

}

class Navigation{
    public $layout;
    public $navigationItems = array();
}

class NavigationItem{
    public $id;
    public $title;
    public $subtitle;
    public $order;
    public $link = '#';
    public $group;
    public $default = false;
}

class Content{
    public $order;
    public $file;
    public $column;
}

class Script{
    public $order;
    public $file;
}

class Style{
    public $order;
    public $file;
}