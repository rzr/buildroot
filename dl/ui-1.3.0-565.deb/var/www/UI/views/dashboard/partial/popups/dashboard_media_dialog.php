<div id="dashboard_media_dialog" title="<?php echo _('CONTENT_HOME_DIALOG_TITLE_MEDIA_SCAN')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">						
            <p><?php echo _('CONTENT_HOME_DIALOG_STRING_MEDIA_SNAPSHOT_DESC')?></p>
			<div class="dashboard_media_list_container">
				<ul class="dashboard_media_list">
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_videos"></span>
                        <span class="dashboard_media_list_item_label" id="dashboard_media_videos"><?php echo _('LABEL_DESCR_MEDIA_SERVING_VIDEOS')?></span>
                        <span class="dashboard_media_list_scan_type" id="dashboard_media_videos_scan_txt"></span>

                        <div class="iconTooltip_container" id="dashboard_media_videos_scan_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_media_videos_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_VIDEOS_SCANNED')?></div>
			                </div>
                        </div>

                        <span class="dashboard_media_list_item_count">
                            <span id="dashboard_media_videos_count" style="width:0%"></span>
                        </span>
                        <span class="dashboard_media_list_item_percent" id="dashboard_media_videos_percent"></span>
                    </li>
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_music"></span>
                        <span class="dashboard_media_list_item_label" id="dashboard_media_music"><?php echo _('CONTENT_HOME_DIALOG_LABEL_MUSIC')?></span>
                        <span class="dashboard_media_list_scan_type" id="dashboard_media_music_scan_txt"></span>
                        
                        <div class="iconTooltip_container" id="dashboard_media_music_scan_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_media_music_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_MUSIC_SCANNED')?></div>
			                </div>
                        </div>

                        <span class="dashboard_media_list_item_count">
                            <span id="dashboard_media_music_count" style="width:0%"></span>
                        </span>
                        <span class="dashboard_media_list_item_percent" id="dashboard_media_music_percent"></span>

                    </li>
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_photos"></span>
                        <span class="dashboard_media_list_item_label" id="dashboard_media_photo"><?php echo _('LABEL_DESCR_MEDIA_SERVING_PHOTOS')?></span>
                        <span class="dashboard_media_list_scan_type" id="dashboard_media_photos_scan_txt"></span>

                        <div class="iconTooltip_container" id="dashboard_media_photos_scan_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_media_photos_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_PHOTOS_SCANNED')?></div>
			                </div>
                        </div>

                        <span class="dashboard_media_list_item_count">
                            <span id="dashboard_media_photos_count" style="width:0%"></span>
                        </span>
                        <span class="dashboard_media_list_item_percent" id="dashboard_media_photos_percent"></span>
                    </li>
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_other"></span>
                        <span class="dashboard_media_list_item_label" id="dashboard_media_other"><?php echo _('CONTENT_HOME_DIALOG_LABEL_OTHER')?></span>
                        <span class="dashboard_media_list_scan_type" id="dashboard_media_other_scan_txt"></span>
                        
                        <div class="iconTooltip_container" id="dashboard_media_other_scan_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_media_other_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_OTHERS_SCANNED')?></div>
			                </div>
                        </div>

                        <span class="dashboard_media_list_item_count">
                            <span id="dashboard_media_other_count" style="width:0%"></span>
                        </span>
                        <span class="dashboard_media_list_item_percent" id="dashboard_media_other_percent"></span>
                    </li>
				</ul>
			</div>

            <hr />

            <p><?php echo _('CONTENT_SETTINGS_HEAD2_DLNA_MEDIA_SERVER')?><span id="dlna_media_server_scan_in_progress"></span></p>
			<div class="dashboard_dlna_list_container">
				<ul class="dashboard_dlna_list">
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_videos"></span>
                        <span class="dashboard_dlna_list_item_label" id="dashboard_dlna_videos"><?php echo _('LABEL_DESCR_MEDIA_SERVING_VIDEOS')?></span>
					    <span class="dashboard_dlna_list_item_count" id="dashboard_dlna_videos_count"></span>

                        <div class="iconTooltip_container dashboard_dlna_list_item_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_dlna_videos_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_VIDEOS_SCANNED')?></div>
			                </div>
                        </div>

                    </li>
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_music"></span>
                        <span class="dashboard_dlna_list_item_label" id="dashboard_dlna_music"><?php echo _('CONTENT_HOME_DIALOG_LABEL_MUSIC')?></span>
					    <span class="dashboard_dlna_list_item_count" id="dashboard_dlna_music_count"></span>

                        <div class="iconTooltip_container dashboard_dlna_list_item_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_dlna_music_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_MUSIC_SCANNED')?></div>
			                </div>
                        </div>

                    </li>
					<li>
                        <span class="dashboard_media_icon dashboard_media_icon_photos"></span>
                        <span class="dashboard_dlna_list_item_label" id="dashboard_dlna_photo"><?php echo _('LABEL_DESCR_MEDIA_SERVING_PHOTOS')?></span>
					    <span class="dashboard_dlna_list_item_count" id="dashboard_dlna_photos_count"></span>

                        <div class="iconTooltip_container dashboard_dlna_list_item_done">
                            <div class="tooltip_icon"><span class="dashboard_media_list_scan_done mediaScanIconDone"></span></div>
                            <div class="tooltip_inner_container">
				            <div class="tooltip" id="dashboard_dlna_photos_tooltip"><?php echo _('CONTENT_HOME_DIALOG_TOOLTIP_PHOTOS_SCANNED')?></div>
			                </div>
                        </div>

                    </li>
				</ul>
			</div>

		</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="dashboard_media_close_button" class="close mochi_dialog_save_button"><?php echo _("BUTTON_OK")?></button>
	</div>

</div>

