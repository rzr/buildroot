<div id="manual_update_uploading" title="<?php echo _('PAGE_HEADER_UPDATING_FIRMWARE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
			<p><?php echo _('AVATAR_LABEL_DESCR_IMPORTING_FILE'); ?></p>
		</div>
	</div>
</div>
