<div id="<?php echo $identifier?>_container">
    <div id="<?php echo $identifier?>_header" class="main_content_header">
        <h1><?php echo _($title)?></h1>
        <?php if (isset($subtitle)):?>
        <a href="#" id="<?php echo $identifier?>_help"><?php echo _($subtitle)?></a>
        <?php endif?>
    </div>
    <div class="content_full_container">
    	<div id="<?php echo $identifier?>_content" class="content_container">

            <?php $view->LoadContents(0)?>

            <div class="column0 three_column_column"><?php $view->LoadContents(1)?></div>
            <div class="network_separator network_separator1"></div>
            <div class="column1 three_column_column"><?php $view->LoadContents(2)?></div>
            <div class="network_separator network_separator2"></div>
            <div class="column2 three_column_column"><?php $view->LoadContents(3)?></div>

            <!--
            <div class="network_separator network_separator3"></div>
            <div class="column3 three_column_column"></div>
            -->

            <?php $view->LoadViews();?>
		</div>
	</div>
</div>