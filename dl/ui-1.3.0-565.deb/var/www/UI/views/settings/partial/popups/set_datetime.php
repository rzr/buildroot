<?
  include(realpath(dirname(__FILE__))."/../../../common/dates.php");
?>

<div id="set_datetime_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_DATE_AND_TIME_SETTINGS')?>" class="mochi_dialog_container">
	<form method="PUT" id="settings_dateTime_date_form" action="date_time_configuration">
		<div class="mochi_dialog_content_container">
			<div class="mochi_dialog_content">
				<p><?php echo _('CONTENT_SETTINGS_DIALOG_STRING_DATE_AND_TIME_SETTINGS_INTRO')?></p>
				<br />

				<div class="edit_container_box">

					<div class="content_row">
						<label><?php echo _('CONTENT_SETTINGS_DIALOG_LABEL_DATE')?></label> <span> <input id="dateTime_calender" type="text" value="" /> </span>
                        <span id="dateTime_calender_datestamp" style="display:none;"></span>
                        <span id="dateTime_calender_timestamp" style="display:none;"></span>
					</div>
					<div class="content_row">
						<label><?php echo _('CONTENT_SETTINGS_DIALOG_LABEL_TIME')?></label> <span class="selectBox defaultfont"> <select id="SettingsLanguageClockHour" name="dateTime_hour">
						<?php foreach($hours as $index=>$hour):?>
								<option value="<?php echo $index?>">
								<?php echo $hour?>
								</option>
								<?php endforeach;?>
						</select> </span> <span>:</span> <span class="selectBox defaultfont"> <select id="SettingsLanguageClockMinute" name="dateTime_minute">
						<?php foreach($minutes as $index=>$minute):?>
								<option value="<?php echo $index?>">
								<?php echo $minute?>
								</option>
								<?php endforeach;?>
						</select> </span> <span class="selectBox defaultfont"> <select id="SettingsLanguageClockAMPM" name="dateTime_ampm">
						<?php foreach($ampm as $index=>$value):?>
								<option value="<?php echo $index?>">
								<?php echo $value?>
								</option>
								<?php endforeach;?>
						</select> </span>
					</div>
				</div>
			</div>
		</div>
		<div class="dialog_form_controls">
			<button type="button" id="settings_dateTime_date_cancel_form"><?php echo _('BUTTON_CANCEL')?></button>
			<button type="button" id="settings_dateTime_date_submit_form" class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
		</div>

	</form>
</div>
