$(document).ready(function(){
	var wifiDashboardHandler = {
		updateInProgress:false,
		update: function(useQueue){
			var $this = this;
	    	if ($this.updateInProgress) {
	            return;
	        }

			gConnectedNetwork = false;
			gTrustedNetwork = false;
			gWANSSIDName = dictionaryList['_unknown'];

	    	var ajaxAPIOptions = {
				"url": "current_wifi_client_connection",
	            "timeout": ajaxTimeout,
				"success": function(data, textStatus, jqXHR) {
					if (data != null && data.current_wifi_client_connection != null && data.current_wifi_client_connection.ssid != null) {
	                    if (data.current_wifi_client_connection.ssid != '') {
							gWANSSIDName = data.current_wifi_client_connection.ssid;
							gConnectedNetwork = true;

							if (data.current_wifi_client_connection.trusted == 'true'){
								gTrustedNetwork = true;
							}
	                    }
	                }
					
					// in Home mode, first check for Bridge connection
					if (gConnectedNetwork && gTrustedNetwork) {
						var connected_device_count = 0;
						gFoundMe = false;
						$.ajaxAPI({
							"url": "wifi_ap_clients",
							"timeout": ajaxTimeout,
							"success": function(data, textStatus, jqXHR) {
								if (data != null && data.wifi_ap_clients != null && data.wifi_ap_clients.wifi_ap_client != null) {
									// only 1 ap client
									if( Object.prototype.toString.call( data.wifi_ap_clients.wifi_ap_client ) != '[object Array]' ){
										data.wifi_ap_clients.wifi_ap_client = $.makeArray(data.wifi_ap_clients.wifi_ap_client);
									}
									for(var i in data.wifi_ap_clients.wifi_ap_client){
										connected_device_count++;
										if (data.wifi_ap_clients.wifi_ap_client[i].ip == gRemoteAddr) {
											gFoundMe = true;
										}
									}
								}
							},
							"error": function (request, status, error) {
							},
							"complete": function(){
								if (connected_device_count) {
									gConnectedDevices = true;
								}
								else {
									gConnectedDevices = false;
								}
	
								// Bridge mode
								if (gConnectedDevices) {
									updateDashboard_BridgedConnection();
								}
								// Home mode
								else {
									updateDashboard_HomeMode();
								}
							}
						});
					}
					// Hotspot mode
					else if (gConnectedNetwork) {
						updateDashboard_HotSpot();
					}
					// Direct connection
					else {
						updateDashboard_DirectConnection();
					}
				},
	            "error": function (request, status, error) {
	            },
				"complete": function(){
					$this.updateInProgress = false;
	        	    if ($this.updateCompleteHandler != null){
	        	    	$this.updateCompleteHandler();
	        	    }
				}
			};
	    	if (typeof useQueue != 'undefined' && useQueue == true){
	    		ajaxQueue.add(ajaxAPIOptions);	
	    	}
	    	else{
	    		$.ajaxAPI(ajaxAPIOptions);
	    	}
	    }
	};
	
	dashboardHandler.addUpdateHandle(wifiDashboardHandler, 'wifiNameAndSignal');
});

function updateDashboard_DirectConnection() {

	resetNetworkConnectionDiagram('mode_direct_connection');

	$('.mode_direct_connection').css("display", "inline-block");

	// get SSID Name of Avatar
	$.ajaxAPI({
		"url": "wifi_ap",
		"timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
			if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
				gSSIDName = data.wifi_ap.ssid;
				gAvatarApIpAddress = data.wifi_ap.ip;
				//gAvatarApSecurity = data.wifi_ap.security_mode;

				if (data.wifi_ap.secured.toLowerCase() == "true") {
					gSSIDSecured = true;
				}
				else {
					gSSIDSecured = false;
				}
				if (data.wifi_ap.broadcast.toLowerCase() == "true") {
					gSSIDBroadcasting = true;
				}
				else {
					gSSIDBroadcasting = false;
				}
			}
		},
		"error": function (request, status, error) {
		},
		"complete": function() {
			$('.me_text').text(dictionaryList['Me']);
			$('.connection_text').text('');
			$('.device_text').text(gSSIDName);

			$('.wifi_avatar_ssid_name').text(gSSIDName);
			$('.wifi_avatar_ip_address').text(gAvatarApIpAddress);
			//$('.wifi_avatar_security').text(dictionaryList['security_'+gAvatarApSecurity.toLowerCase()]);
		}
	});
}

function updateDashboard_BridgedConnection() {

	resetNetworkConnectionDiagram();

	$('.mode_trusted_network').css("display", "inline-block");

	// Me connected to Avatar
	if (gFoundMe) {
		$('.connection_diagram').addClass('mode_bridged_direct_connection')

		$.ajaxAPI({
			"url": "wifi_ap",
			"timeout": ajaxTimeout,
			"success": function(data, textStatus, jqXHR) {
				if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
					gSSIDName = data.wifi_ap.ssid;
					gAvatarApIpAddress = data.wifi_ap.ip;
					//gAvatarApSecurity = data.wifi_ap.security_mode;
	
					if (data.wifi_ap.secured.toLowerCase() == "true") {
						gSSIDSecured = true;
					}
					else {
						gSSIDSecured = false;
					}
					if (data.wifi_ap.broadcast.toLowerCase() == "true") {
						gSSIDBroadcasting = true;
					}
					else {
						gSSIDBroadcasting = false;
					}
				}
			},
			"error": function (request, status, error) {
			},
			"complete": function() {
				$('.me_text').text(dictionaryList['Me']);
				$('.connection_text').text(gSSIDName);
				$('.device_text').text(gWANSSIDName);

				$('.wifi_avatar_ssid_name').text(gSSIDName);
				$('.wifi_avatar_ip_address').text(gAvatarApIpAddress);
				//$('.wifi_avatar_security').text(dictionaryList['security_'+gAvatarApSecurity.toLowerCase()]);
			}
		});	
	}
	// Me connected from Home router
	else {
		$('.connection_diagram').addClass('mode_bridged_home_connection');

		$('.me_text').text(dictionaryList['Me']);
		$('.connection_text').text(gWANSSIDName);
		$('.device_text').text(gDeviceName);
	}
}

function updateDashboard_HotSpot() {

	resetNetworkConnectionDiagram('mode_network_hotspot');

	$('.mode_network_hotspot').css("display", "inline-block");

	$.ajaxAPI({
		"url": "wifi_ap",
		"timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
			if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
				gSSIDName = data.wifi_ap.ssid;
				gAvatarApIpAddress = data.wifi_ap.ip;
				//gAvatarApSecurity = data.wifi_ap.security_mode;

				if (data.wifi_ap.secured.toLowerCase() == "true") {
					gSSIDSecured = true;
				}
				else {
					gSSIDSecured = false;
				}
				if (data.wifi_ap.broadcast.toLowerCase() == "true") {
					gSSIDBroadcasting = true;
				}
				else {
					gSSIDBroadcasting = false;
				}
			}
		},
		"error": function (request, status, error) {
		},
		"complete": function() {
			$('.me_text').text(dictionaryList['Me']);
			$('.connection_text').text(gSSIDName);
			$('.device_text').text(gWANSSIDName);

			$('.wifi_avatar_ssid_name').text(gSSIDName);
			$('.wifi_avatar_ip_address').text(gAvatarApIpAddress);
			//$('.wifi_avatar_security').text(dictionaryList['security_'+gAvatarApSecurity.toLowerCase()]);
		}
	});
}

function updateDashboard_HomeMode() {
	resetNetworkConnectionDiagram('mode_trusted_network');

	$('.mode_trusted_network').css("display", "inline-block");

	$('.me_text').text(dictionaryList['Me']);
	$('.connection_text').text(gWANSSIDName);
	$('.device_text').text(gDeviceName);

	$.ajaxAPI({
		"url": "wifi_ap",
		"timeout": ajaxTimeout,
		"success": function(data, textStatus, jqXHR) {
			if (data != null && data.wifi_ap != null && data.wifi_ap.ssid != null) {
				gSSIDName = data.wifi_ap.ssid;
				gAvatarApIpAddress = data.wifi_ap.ip;
				//gAvatarApSecurity = data.wifi_ap.security_mode;

				if (data.wifi_ap.secured.toLowerCase() == "true") {
					gSSIDSecured = true;
				}
				if (data.wifi_ap.broadcast.toLowerCase() == "true") {
					gSSIDBroadcasting = true;
				}
			}
		},
		"error": function (request, status, error) {
		},
		"complete": function() {
			$('.wifi_avatar_ssid_name').text(gSSIDName);
			$('.wifi_avatar_ip_address').text(gAvatarApIpAddress);
			//$('.wifi_avatar_security').text(dictionaryList['security_'+gAvatarApSecurity.toLowerCase()]);
		}
	});
}

function resetNetworkConnectionDiagram(newDiagram) {

	$('.network_mode').hide();
	$('.connection_diagram').removeClass('mode_direct_connection');
	$('.connection_diagram').removeClass('mode_network_hotspot');
	$('.connection_diagram').removeClass('mode_trusted_network');
	$('.connection_diagram').removeClass('mode_bridged_home_connection');
	$('.connection_diagram').removeClass('mode_bridged_direct_connection');

	if (newDiagram != undefined) {
		$('.connection_diagram').addClass(newDiagram);
	}
}
