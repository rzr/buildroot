<div id="dashboard_battery_dialog" title="<?php echo _('Battery Details')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
            <p><?php echo _('View remaining battery power and adjust priority.')?></p>
            <div id="dashboard_battery_chart"><div id="dashboard_battery_chart_graphic"></div><div id="dashboard_battery_chart_text">100%</div></div>
            <div id="dashboard_battery_settings">
            	<h3><?php echo _('Battery Settings')?></h3>
            	<form id="power_profile_form" action="power_profile" method="PUT">
                	<div><label id="battery_setting_label">Priority</label><input type="radio" name="battery_setting" id="battery_setting_life"/><label class="battery_radio_label" for="battery_setting_life"><?php echo _('Battery life')?></label><input type="radio" id="battery_setting_media" name="battery_setting"/><label class="battery_radio_label" for="battery_setting_media"><?php echo _('Media scanning')?></label></div>
                	<div id="battery_setting_description">Scan media/generate thumbnails/etc. only when connected to a power source</div>
            	</form>
            </div>
		</div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="dashboard_battery_close_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>

</div>