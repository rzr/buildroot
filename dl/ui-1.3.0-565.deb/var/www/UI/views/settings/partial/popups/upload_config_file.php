<div id="upload_config_file" title="<?php echo _('PAGE_HEADER_IMPORT_CONFIGURATION_FILE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
       	<div class="mochi_dialog_content">
        	<br /><?php echo _('AVATAR_LABEL_DESCR_IMPORTING_FILE'); ?>
        </div>
    </div>
</div>