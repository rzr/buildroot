<div class="content_row manual_update_container">
    <label><?php echo _('CONTENT_SETTINGS_LABEL_FIRMWARE_IMAGE')?></label>
    <button id="manual_update_btn"><?php echo _('BUTTON_UPDATE_FROM_FILE')?></button>
</div>
<div class="content_row">
    <label>&nbsp;</label>
    <a href="http://support.wdc.com/product/download.asp" target="_blank" id="online_firmware_link" class="internet_required"><?php echo _('CONTENT_SETTINGS_FIRMWARE_LINK_ONLINE_LOCATION_OF_FIRWMARE')?></a>
</div>