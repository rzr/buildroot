 <div id="settings_admin_user_container" class="edit_container_box">
 
 <h2><?php echo _('CONTENT_SETTINGS_HEAD2_SMB_AND_SETTINGS_USER')?></h2>

 <form id="settings_admin_user_form_default" action="users"></form>
 
<form id="settings_admin_user_form" action="users" method="PUT">
    <div class="content_row">
    	<label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_USERNAME')?></label>
        <span id="settings_admin_user_username"></span>
    </div>

    <div class="content_row">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_SETTING_PASSWORD");?>
            <div class="tooltip_container">
                <span class="tooltip_icon"></span>
                <div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_TOOLTIP_ADMIN_USER_UN_PW");?></div></div></div></label>
        <input type="checkbox" id="user_detail_password_checkbox" name="" value="" />
        <span id="user_detail_password_edit_section"><a id="user_detail_password_edit_link" href="#"><?php echo _('CONTENT_SETTINGS_LINK_EDIT')?><span class="details_link_marker">&nbsp;&raquo;</span></a></span>
    </div>

</form>

<form id="settings_device_name_form" action="device_description" method="PUT">
    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_TOOLTIP_ADMIN_USER_DEVICE_NAME");?><ul><li> <?php echo _("CONTENT_SETTINGS_TOOLTIP_ADMIN_USER_DEVICE_NAME_1");?></li><li> <?php echo _("CONTENT_SETTINGS_TOOLTIP_ADMIN_USER_DEVICE_NAME_2");?></li></ul></div></div></div></label>
        <input id="settings_device_name_form_machine_name" maxlength="15" class="DEVICE_NAME" type="text" name="machine_name" value=""/>
        <input id="settings_device_name_form_machine_desc" type="hidden" name="machine_desc" value=""/>
        <span class="form_controls">
            <input type="submit" value="<?php echo _("BUTTON_SAVE");?>" />
        </span>
    </div>
</form>

</div>
