var updateUploader;
var updateUploaderKeepGoing;
var updateUnexpectedErrorMax = 5;
var updateUnexpectedErrorCounter = 0;
var updateProgressPoll = 5000;
var processUpdatePollTimeout = 60000; // 60 seconds
var firmwareUpgradeStartTime = 0;
var firmwareUpgradeUnknownStartTime = 0;
var firmwareUpgradeTimeout = 600000; // 10 minutes
var minFreeSpaceForUpdate_MB = 256; // MB
var minBatteryPercentForUpgrade = 50; // percent

var useStubUpdates = false;

$(document).ready(function(){

    initUpdates();

    $('#head_settings_nav_update_link').navItem({
        'contentId': 'firmware_container',
        'refreshDataCall': function(){

        	// Set Selection
        	resetNavigationSelection('#head_settings_nav_update_link');
        
          //  pollingHandler.poll();
            if(gIsMobile) {
                disableIdTag('#manual_update_btn');
            }
            $('#battery_status_form').restForm("refreshForm");
            $('#firmware_info_form').restForm("refreshForm");

            /* Legacy Sequoia
            $('#auto_system_updates_form').restForm("refreshForm"); 
            $('#settings_nav_updates').parent('li').addClass('selected').siblings().removeClass('selected'); 
            */
            
        }
    });

    $('#head_settings_nav_update_link').click(function(){
        $('#head_nav').hide();
        $('#head_nav_link').removeClass('selected');
        //$('#nav_settings').css('display','inline-block');
    });

    /* Legacy Sequoia
	$('#settings_nav_updates').navItem({
	    'containerId': 'settings_content',
	    'contentId': 'firmware_container',
	    'selectedClass': 'selected',
        'refreshDataCall': function(){
        
            if(gIsMobile) {
                $('#manual_update_btn').attr('disabled', true);
                $('#manual_update_btn').addClass('ui-state-disabled');
            }
            $('#auto_system_updates_form').restForm("refreshForm");
            $('#firmware_info_form').restForm("refreshForm");
        }
    });
    */
	
    /* Legacy Sequoia
	$('#auto_system_updates_form').restForm({
        'refreshDataCallback': function(data){
        	$('#auto_system_updates_form').restForm("_refreshData", data);
        	var hour = data.firmware_update_configuration.auto_install_hour;

            var ampm = "AM";
            if (hour >= 12) {
                ampm = "PM";
                hour -= 12;
            }
			$('#SettingUpdateHour option').each(function(){
				$(this)[0].defaultSelected = false;
			});
			$('#SettingUpdateHour option[value='+hour+']').each(function(){
				$(this)[0].defaultSelected = true;
				$('#SettingUpdateHour').selectmenu("value", $(this).val());
			});
			
			$('#SettingUpdateAmPm option').each(function(){
				$(this)[0].defaultSelected = false;
			});
			$('#SettingUpdateAmPm option[value='+ampm+']').each(function(){
				$(this)[0].defaultSelected = true;
				$('#SettingUpdateAmPm').selectmenu("value", $(this).val());
			});
        },
        'beforeProcessForm': function(){
        	var hour = parseInt($('#SettingUpdateHour').val());
        	if ($('#SettingUpdateAmPm').val() == "PM"){
				hour +=12;
        	}
        	
        	$('#SettingUpdateHourHidden').val(hour);
        },
        'resetCallback': function(){
        	$('#auto_system_updates_form').restForm("_reset");
        	var autoUpdateEnabled = $('#chk_enable_auto_update').is(":checked");
			if (autoUpdateEnabled){
				$('#hide_update_schedule').show();
			}
			else{
				$('#hide_update_schedule').hide();
			}
        }
    }); 
    */ 

    $('#firmware_info_form').restForm({
        'useStubs': useStubUpdates,
        'refreshDataCallback': function(data){
            $('#firmware_info_form').restForm("_refreshData", data);

            if (data != null && data.firmware_info != null) {

                var currentFirmwareName = data.firmware_info.current_firmware['package'].name;
                //var currentFirmwareDescription = data.firmware_info.current_firmware['package'].description;
                var currentFirmwareVersion = data.firmware_info.current_firmware['package'].version;
                $('#settingUpdateCurrentFirmwareVersion').html(currentFirmwareName + ' v' + currentFirmwareVersion);
    
                if (data.firmware_info.current_firmware['package'].last_upgrade_time != '') {
                    $('#settingUpdateLastUpdateTime').html(getTimeStamp(data.firmware_info.current_firmware['package'].last_upgrade_time));
                    localizeTimeStamp('#settingUpdateLastUpdateTime');
                }
                else {
                    $('#settingUpdateLastUpdateTime').html( dictionaryList['nonetxt'] );
                }
    
                if (data.firmware_info.upgrades.available.toLowerCase() == "true") {

                    /*
                    $('#available_update_container').find('.update_now_container').each(function(i){
                        if (i>0) {
                            $(this).remove();
                        }
                    }); 
                    */
                     
                    // if there is only 1 available upgrade
                    if (data.firmware_info.upgrades.upgrade.version != null) {
                        addFirmwareAvailable(data.firmware_info.upgrades.upgrade, currentFirmwareName, 0);
                    }
                    else {
                        for(var i in data.firmware_info.upgrades.upgrade){
                            addFirmwareAvailable(data.firmware_info.upgrades.upgrade[i], currentFirmwareName, i);
                        }
                    }

                    if (data.firmware_info.upgrades.upgrade.version != null) {
                        updateFirmwareAvailable(data.firmware_info.upgrades.upgrade, currentFirmwareName);
                    }

                    $('.check_for_update_container').hide();
                    $('.update_now_container').show();
                    //$('.no_firmware_update_container').hide();
                }
                else {
                    $('.check_for_update_container').show();
                    $('.update_now_container').hide();
                    //$('.no_firmware_update_container').show();
                }
            }
        }
        /*
        ,
        'beforeProcessForm': function(){
            if (useStubUpdates) {
                $('#firmware_info_form').attr('action', 'firmware_info.php');
            }
            else {
                $('#firmware_info_form').attr('action', $('#firmware_info_default_form').attr('action'));
            }
    	}
        */

    });

    $('#message_acceptance_form').restForm();
    $('#confirm_upgrade_firmware_message_acceptance_form').restForm();
    $('#firmware_update_list_form').restForm();

    /* Legacy Sequoia
    $('#chk_enable_auto_update').live('toggle', function(e){
		  $('#hide_update_schedule').toggle();      

          // checked means firmware_update_configuration's auto_install=enable
          if( $(this).is(":checked") ){
              // do nothing since there is a Submit / Cancel button
              //$(this).submit();
          }
          else {
              $(this).submit();
          }
    });
    */

    $("#confirm_update").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#confirm_update').attr('title')+'</div>'
    });
    
    $('#confirm_update_cancel_button').click(function(){
    	$('#confirm_update').dialog('close');
    });
    
    $('#confirm_update_ok_button').click(function(){
        // require at least 256MB to upgrade firmware
        var capacity_MB = 0;
        var usage_MB = 0;

        if (gCapacity > 0) {
            capacity_MB = parseInt(gCapacity / BYTE_DIVISOR / BYTE_DIVISOR);
            usage_MB = parseInt(gUsage / BYTE_DIVISOR / BYTE_DIVISOR);
        }

        if (capacity_MB - usage_MB >= minFreeSpaceForUpdate_MB) { 
            rebootInitHere = true;
            updateUploader.submit();
        }
        else {
            showError('space_issue_for_file');
        }
        $('#confirm_update').dialog('close');
    });

    $("#manual_update_uploading").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        closeOnEscape:false,
        title: '<div class="wizard_dialog_title">'+$('#manual_update_uploading').attr('title')+'</div>'
    });

    $("#update_progress").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        closeOnEscape:false,
        title: '<div class="wizard_dialog_title">'+$('#update_progress').attr('title')+'</div>'
    });

    $("#confirm_upgrade_firmware_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#confirm_upgrade_firmware_dialog').attr('title')+'</div>'
    });
    
    $('#confirm_upgrade_firmware_cancel_button').click(function(){
    	$('#confirm_upgrade_firmware_dialog').dialog('close');
    });
    
    $('#confirm_upgrade_firmware_ok_button').click(function(){

        $('#confirm_upgrade_firmware_dialog').dialog('close'); 
        checkUpgradeRequirements();
    	
    });

    $("#confirm_upgrade_firmware_message_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#confirm_upgrade_firmware_message_dialog').attr('title')+'</div>'
    });
    
    $('#confirm_upgrade_firmware_message_dialog_cancel_button').click(function(){
    	$('#confirm_upgrade_firmware_message_dialog').dialog('close');
    });
    
    $('#confirm_upgrade_firmware_message_dialog_next_button').click(function(){
        $('#confirm_upgrade_firmware_message_dialog').dialog('close');
        $('#confirm_upgrade_firmware_dialog').dialog('open');
    });
    

    $("#firmware_up_to_date_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: 'auto',
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#firmware_up_to_date_dialog').attr('title')+'</div>'
    });

    $('#firmware_up_to_date_dialog_ok_button').click(function(){
        $('#firmware_up_to_date_dialog').dialog('close');
    });

    $("#new_firmware_available_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_firmware',
        modal: true,
        stack: true,
        title: '<div class="wizard_dialog_title">'+$('#new_firmware_available_dialog').attr('title')+'</div>'
    });

    $('#new_firmware_available_dialog_save_button').click(function(){

        $('#new_firmware_available_dialog').dialog('close');
        checkUpgradeRequirements();
    });

    $('#new_firmware_available_dialog_next_button').click(function(){
        $('#new_firmware_available_dialog').dialog('close');
        $('#confirm_upgrade_firmware_dialog').dialog('open');
    });

    $('#new_firmware_available_dialog_cancel_button').click(function(){
        $('#new_firmware_available_dialog').dialog('close');
    });

});

$(function() {

    $('.begin_update_available_btn').live('click', function() {
        if (!$(this).hasClass('ui-state-disabled')) {
            var firmwareMessage =  $(this).parent().find('.settingUpdateFirmwareNewMessage').html();
            if (firmwareMessage != '') {
    
                var firmwareName = $(this).parent().find('.settingUpdateFirmwareNewVersion').html();
                var firmwareImage = $(this).parent().find('.settingUpdateFirmwareNewImage').html();
                var firmwareReleaseNotes = $(this).parent().find('.settingUpdateFirmwareNewReleaseNotes').attr('href');
    
                updateConfirmFirmwareDialogMessage(firmwareName, firmwareMessage, firmwareReleaseNotes);
    
                $('#firmware_image').val(firmwareImage);
    
                if($('#confirm_upgrade_firmware_message_acceptance_input').is(":checked")){
                    $('#confirm_upgrade_firmware_message_acceptance_input').attr('checked', false);
                    disableIdTag('#confirm_upgrade_firmware_message_dialog_next_button');
                }
    
                $('#confirm_upgrade_firmware_message_dialog').dialog('open');
            }
            else {
                $('#confirm_upgrade_firmware_dialog').dialog('open');
            }
        }
    });

    $('.check_for_update_btn').live('click', function() { 
        checkForFirmwareAvailable();
    }); 

	$('.firmware_selection_input').live('click', function(e){
        var upgradeImage = $(e.target).val();
        var upgradeMessage = $(e.target).attr('rel');

        $('#firmware_image').val(upgradeImage);
        $('.firmware_selection_input').attr('checked', false);

        $(e.target).attr('checked', true);
        updateFirmwareDialogMessage(upgradeMessage);
    });

    $('#message_acceptance_input').click(function(){
        if($('#message_acceptance_input').is(":checked")){
            disableIdTag('#new_firmware_available_dialog_next_button');
        }
        else {
            enableIdTag('#new_firmware_available_dialog_next_button');
        }
    });
    
    $('#confirm_upgrade_firmware_message_acceptance_input').click(function(){
        if($('#confirm_upgrade_firmware_message_acceptance_input').is(":checked")){
            disableIdTag('#confirm_upgrade_firmware_message_dialog_next_button');
        }
        else {
            enableIdTag('#confirm_upgrade_firmware_message_dialog_next_button');
        }
    });

});

function initUpdates() {
    //checkForFirmwareUpdate();

    if (useStubUpdates) {
        $('#firmware_info_form').attr('action', 'firmware_info.php');
    }
    else {
        $('#firmware_info_form').attr('action', $('#firmware_info_default_form').attr('action'));
    }

    disableIdTag('#disabled_update_btn');
}

function addFirmwareAvailable(data, firmwareName, idx) {
    /*
    var firmwareVersion = data.version;
    var firmwareReleaseNotes = data.releasenotes;
    var firmwareMessage = data.message;
    var firmwareImage = data.image;

    bar = $('#available_update_container').find('.update_now_container:first').clone();
    if (idx > 0) {
        bar.find('.update_now_label').text('');
    }
    bar.find('.settingUpdateFirmwareNewVersion').html(firmwareName + 'v' + firmwareVersion);
    bar.find('.settingUpdateFirmwareNewReleaseNotes').attr("href", firmwareReleaseNotes);
    bar.find('.settingUpdateFirmwareNewMessage').text(firmwareMessage);
    bar.find('.settingUpdateFirmwareNewimage').text(firmwareImage);

    / *
    var tooltip = bar.find('.tooltip').html();
    bar.find('.tooltip').html(tooltip + ' ' + firmwareName + 'v' + firmwareVersion);
    * /

    bar.show();
    bar.insertBefore('#firmware_info_form');
    */
}

function updateFirmwareAvailable(data, firmwareName) {
    var firmwareVersion = data.version;
    var firmwareReleaseNotes = data.releasenotes;
    var firmwareMessage = data.message;
    var firmwareImage = data.image;

    $('.settingUpdateFirmwareNewVersion').html(firmwareName + '&nbsp;v' + firmwareVersion);
    $('.settingUpdateFirmwareNewReleaseNotes').attr("href", firmwareReleaseNotes);
    $('.settingUpdateFirmwareNewMessage').text(firmwareMessage);
    $('.settingUpdateFirmwareNewimage').text(firmwareImage);
}

function resetFirmwareDialog() {
    // restore original button and dialog size
    $('#new_firmware_available_dialog_next_button').hide();
    $('#new_firmware_available_dialog_save_button').show();

    // reset firmware available dialog size
    $('#new_firmware_available_dialog').dialog( "option", "width", 500 );
    $('#new_firmware_available_dialog').dialog( "option", "height", 'auto' );
    //$('#new_firmware_available_dialog').dialog( "option", "resizable", false );

    // reset EULA message iframe 
    $('#message_iframe').attr( "height", "297px" );

    // reset firmware confirmation diaglog size
    $('#confirm_upgrade_firmware_dialog').dialog( "option", "width", 500 );
    $('#confirm_upgrade_firmware_dialog').dialog( "option", "height", 'auto' );

    $('#install_and_reboot_button').show();
    $('#firmware_update_message').hide();

    $('#firmware_update_message_acceptance').hide();

    if($('#message_acceptance_input').is(":checked")){
        $('#message_acceptance_input').attr('checked', false);
        disableIdTag('#new_firmware_available_dialog_next_button');
    }
}

function updateFirmwareDialogMessage(upgradeMessage) {

    if (upgradeMessage !== '') {

        disableIdTag('#new_firmware_available_dialog_next_button');

        $('#new_firmware_available_dialog_next_button').show();
        $('#new_firmware_available_dialog_save_button').hide();

        browserWidth = getBrowserWidth();
        browserHeight = getBrowserHeight();

        // dynamically adjust the FW Eula height and width depending on browse size
        if (browserWidth > 720) {   // 715px is the page width of the update server's upgrade message
            FWEulaWidth = 720;
        } 
        else {
            FWEulaWidth = browserWidth;
        }
        
        if (browserHeight > 700) {
            FWEulaHeight = 'auto';
        }
        else {
            FWEulaHeight = browserHeight - 15;          // 15px account for the browser header and footer
            if (FWEulaHeight > 250) {                   // only adjust iframe height if window height is greater than 250px
                iframeHeight = FWEulaHeight - 240;      // 240px is height of Firmware EULA without the iframe height
                $('#message_iframe').attr( "height", iframeHeight.toString() + "px" );
            }
        }

        $('#new_firmware_available_dialog').dialog( "option", "width", FWEulaWidth );
        $('#new_firmware_available_dialog').dialog( "option", "height", FWEulaHeight );
        //$('#new_firmware_available_dialog').dialog( "option", "resizable", true );

        $('#message_iframe').attr('src', upgradeMessage);
        $('#install_and_reboot_button').hide();
        $('#firmware_update_message').show();

        $('#firmware_update_message_acceptance').show();

    }
    else {
        resetFirmwareDialog();
    }
}

function updateConfirmFirmwareDialogMessage(firmwareName, firmwareMessage, firmwareReleaseNotes) {

    disableIdTag('#confirm_upgrade_firmware_message_dialog_next_button');

    $('#confirm_upgrade_firmware_message_dialog_cancel_button').show();
    $('#confirm_upgrade_firmware_message_dialog_save_button').hide();

    $('#confirm_upgrade_firmware_message_name').html(firmwareName);
    $('#confirm_upgrade_firmware_message_releasenotes').attr("href", firmwareReleaseNotes);

    $('#confirm_upgrade_firmware_message_iframe').attr('src', firmwareMessage);
    $('#firmware_update_message').show();

    $('#firmware_update_message_acceptance').show();
}

function updateFirmwareAvailableDialog(data) {

    // delete all available items except for template
    $('#firmware_update_list .firmware_update_item:first').siblings().each(function(){
        $(this).remove();
    });

    if (data.upgrades != null && data.upgrades.upgrade != null){

        resetFirmwareDialog();

        var firmwareName = data.current_firmware['package'].name;

        // if there is only 1 available upgrade
        if (data.upgrades.upgrade.version != null) {
            populateFirmwareList(data.upgrades.upgrade, firmwareName, 0, false);
        }
        else {
            for (var i in data.upgrades.upgrade) {
                populateFirmwareList(data.upgrades.upgrade[i], firmwareName, i, true);
            }
        }
    }
    $('#new_firmware_available_dialog').dialog('open');
    
}

function populateFirmwareList(data, firmwareName, idx, multipleFirmware) {

    var releasenotesTxt = dictionaryList['releasenotestxt'];

    bar = $('#firmware_update_list').find('.firmware_update_item:first').clone();
    bar.show();
    bar.find('.firmware_selection_input').attr('value', data.image);
    bar.find('.firmware_selection_input').attr('rel', data.message);
    bar.find('.firmware_update_name').html(firmwareName);
    bar.find('.firmware_update_version').html(data.version);

    // default check the first upgrade package
    if (idx == 0) {
        bar.find('.firmware_selection_input').attr('checked','checked');
        $('#firmware_image').val(data.image);

        if (data.message.toString() !== '') {
            updateFirmwareDialogMessage(data.message);
        }
    }

    // if only one upgrade package, don't display radio button and display release notes on 2nd line
    brTxt = '<br>';
    if (multipleFirmware == true) {
        bar.find('.firmware_selection_input').show();
        brTxt = '';
    }
    bar.find('.firmware_releasenotes').html(brTxt+'<a href="'+ data.releasenotes +'" target="_blank" class="internet_required">'+releasenotesTxt+'</a>');
    if (data.confirmation != null) {
        bar.find('.firmware_confirmation').html(data.confirmation);
    }
    bar.find('.firmware_confirmation').attr('rel', data.message);

    bar.appendTo('#firmware_update_list');
}

function checkForFirmwareInstall() {
    displayLoading();
    $.ajaxAPI({
        "url": 'battery_status',
        "success": function(data){
            if (data != null && data.battery_status != null) {
                if ((data.battery_status.state == 'charging') || (parseInt(data.battery_status.percent_remaining) >= minBatteryPercentForUpgrade)) {
                    $('.begin_update_available_btn').click();
                }
                else {
                    showError("low_battery_for_upgrade");
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });
}

function checkForFirmwareAvailable() {

    displayLoading( dictionaryList['retrievingtxt'] );
    $.ajaxAPI({
        "url": 'internet_access',
        "type": "GET",
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'get_internet_access', request.status);
        },
        "success": function(data){

            if ((data != null) && (data.internet_access != null)) {
                if (data.internet_access.connectivity.toLowerCase() != 'true') {
                    //showError("internet_access_error");
                    $('#no_internet_access_dialog').dialog("open");
                    return;
                }
            }
            checkForFirmwareAvailableOnServer();
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });

}

function checkForFirmwareAvailableOnServer() {

    var urlPrefix = apiUrlPrefix;
    var url = "firmware_info";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    $.ajaxAPI({
        "urlPrefix": urlPrefix,
        "url": url,
        "type": "PUT",
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'put_firmware_info', request.status);
        },
        "success": function(data){
            get_firmware_info_and_popup();
        }
    });
}

function checkUpgradeRequirements() {

    // require at least 256MB to upgrade firmware
    var capacity_MB = 0;
    var usage_MB = 0;
    if (gCapacity > 0) {
        capacity_MB = parseInt(gCapacity / BYTE_DIVISOR / BYTE_DIVISOR);
        usage_MB = parseInt(gUsage / BYTE_DIVISOR / BYTE_DIVISOR);
    }
    if (capacity_MB - usage_MB < minFreeSpaceForUpdate_MB) { 
        showError('space_issue_for_file');
        return;
    }

    // make sure there's enough power if on battery
    var low_battery_for_upgrade = false;
    $.ajaxAPI({
        "url": 'battery_status',
        "success": function(data){
            if (data != null && data.battery_status != null) {
                if (data.battery_status.state.toLowerCase() == 'discharging' && parseInt(data.battery_status.percent_remaining) < minBatteryPercentForUpgrade) {
                    low_battery_for_upgrade = true;
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            if (low_battery_for_upgrade) {
                showError("low_battery_for_upgrade");
            }
            else {
                doUpdateAvailable();
            }
        }
    });
}

function doUpdateAvailable(){

    var urlPrefix = apiUrlPrefix;
    var url = "firmware_update";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    firmwareUpgradeStartTime = new Date().getTime();

    var image_url = $("#firmware_image").val();
    displayLoading();
    $.ajaxAPI({
        "urlPrefix": urlPrefix,
        "url": url,
        "type": "PUT",
        "data": {'image': image_url},
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'put_firmware_update', request.status);
        },
        "success": function(data){
            $("#update_progressbar").progressbar({value: 0});
            $('.update_progress_percentage').html('');
            $('#update_progress').dialog('open');
            updateUnexpectedErrorCounter = 0;
            processUpdate();
        },
        "complete": function (jqXHR, textStatus) {
            hideLoading();
        }
    });
}

function doManualUpdate() {
    $("#update_progressbar").progressbar({ value: 0 });
    $('.update_progress_percentage').html('');
    $('#update_progress').dialog('open');
    updateUnexpectedErrorCounter = 0;
    firmwareUpgradeStartTime = new Date().getTime();
    setTimeout("processUpdate();", updateProgressPoll);
}

function processUpdate(){

    var urlPrefix = apiUrlPrefix;
    var url = "firmware_update";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    //displayLoading();
    $.ajaxAPI({
        "urlPrefix": urlPrefix,
        "url": url,
        "type": "GET",
        "timeout": processUpdatePollTimeout,
        "error": function (request, status, error) {
            //showError('firmware_update ' + status + ': ' + request.status + ' ' + error);

            // continue processing if the unexpected error (http_code=500) count hasn't been met
            updateUnexpectedErrorCounter++;           
            if (updateUnexpectedErrorCounter <= updateUnexpectedErrorMax){
                setTimeout("processUpdate();", updateProgressPoll);
            }
            else if (request.status == 500) {

                updateUnexpectedErrorCounter = 0;
                $('#update_progress').dialog('close');
                //disabledPolling = false;

                var xotree = new XML.ObjTree();
                var data = xotree.parseXML( request.responseText );
                var error_code = parseDataForErrors(data, 'error_code');
                if (error_code) {
                    showError("update_"+error_code);
                }
                else {
                    //showError("update_failed");
                    firmwareUpgradeUnknownProgress();
                }
            }
            else {
                //showError("update_failed");
                //$('#update_progress').dialog('close');
                //disabledPolling = false;
                firmwareUpgradeUnknownProgress();
            }
        },
        "success": function (data) {
            if ((data != null) && (data.firmware_update != null)) {

                var status = data.firmware_update.status.toLowerCase();
                var completion_percent = data.firmware_update.completion_percent;
                var error_code = data.firmware_update.error_code;

                if (completion_percent != '') {
                    completion_percent = parseInt(completion_percent);
                }
                else {
                    completion_percent = 0;
                }

                /*
                // SLEE - workaround percent returned in data.firmware_update.status
                if ((completion_percent == 0) && (data.firmware_update.status != '')) {
                    var status_percent = parseInt(data.firmware_update.status);
                    if (status_percent > 0) {
                        completion_percent = status_percent;
                        status = 'upgrading';
                    }
                }
                */

                if (status == "idle") {
                    // Should never be idle since we are in the middle of an update, 
                    // so continue processing if the unexpected error (idle) count hasn't been met
                    updateUnexpectedErrorCounter++;
    				if (updateUnexpectedErrorCounter <= updateUnexpectedErrorMax){
                        setTimeout("processUpdate();", updateProgressPoll);
    				}
                    else {
                        showError("update_failed");
                        $('#update_progress').dialog('close');
                        //disabledPolling = false;
                    }
                }
                else if (status == "failed") {
                    $('#update_progress').dialog('close');
                    updateUnexpectedErrorCounter = 0;
                    if (error_code !== ''){
                        showError("update_"+error_code);
                    }
                    else {
                        showError("update_failed");
                    }
                    //disabledPolling = false;
                }
                else {
                    updateUnexpectedErrorCounter=0;
                    $("#update_progressbar").progressbar('value', completion_percent);
                    $('.update_progress_label').css('display','none');
                    $('#update_progress_'+status).css('display','block');
                    $('#update_progress_percentage_'+status).html('(' + completion_percent + '%)');

                    if(status == 'upgrading' && completion_percent >= 100){
                        $('#update_progress').dialog('close');
                        doReboot('update');
                    }
                    else {
                        setTimeout("processUpdate();", updateProgressPoll);
                    }
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            //hideLoading();
        }
    });
}

function init_updateUploadFromFile() {
    updateUploadInit();
}

function updateUploadInit() {

    var button = $("#manual_update_btn");

    var url = apiUrlPrefix + "firmware_update?format=json";
    updateUploaderKeepGoing = "true";
    updateUploader = new AjaxUpload(button, {
        action: url,
        name: 'file',
        responseType: 'json',
        autoSubmit: false,
        onSubmit: function(file, ext) {

            // if the user cancels out
            if (updateUploaderKeepGoing == "false") {
                updateUploaderKeepGoing = "true";
                return false;
            }

            var regex = /^(bin)$/i;
            if (!(ext && regex.test(ext))) {
                showError('invalid_firmware_file_type');
                return false;
            }

            $("#manual_update_uploading").dialog('open');
            this.disable();
        },
        onChange: function(file, ext) {

            // make sure there's enough power if on battery
            var low_battery_for_upgrade = false;
            $.ajaxAPI({
                "url": 'battery_status',
                "success": function(data){
                    if (data != null && data.battery_status != null) {
                        if (data.battery_status.state.toLowerCase() == 'discharging' && parseInt(data.battery_status.percent_remaining) < minBatteryPercentForUpgrade) {
                            low_battery_for_upgrade = true;
                        }
                    }
                },
                "complete": function (jqXHR, textStatus) {
                    if (low_battery_for_upgrade) {
                        showError("low_battery_for_upgrade");
                    }
                    else {
                        $("#confirm_update").dialog('open');
                    }
                }
            });
        },
        onComplete: function(file, response) {
            //alert(debug(response));

            // add in checks for 200 http_code stuff and make it JSON
            $("#manual_update_uploading").dialog('close');
            this.enable();

            if (response != null && response.firmware_update != null) {
                if (response.firmware_update.status != null && response.firmware_update.status.toLowerCase() == "success") {
                    doManualUpdate();
                }
                else if (response.firmware_update.error_code != null) {
                    showError(response.firmware_update.error_code + " " + response.firmware_update.error_message);
                }
                else {
                    showError("firmware update failed");
                }
            }
            else {
                showError("firmware update failed");
            }
        }
    });
    $("#manual_update_btn").hover(
        function(){
            $(this).css('cursor','pointer !important');
        },
        function(){
            $(this).css('cursor','default');
        }
    );
}

function checkForFirmwareUpdate(useQueue) {

    var urlPrefix = apiUrlPrefix;
    var url = "firmware_update";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    var ajaxAPIOptions = {
        "urlPrefix": urlPrefix,
        "url": url,
        "type": "GET",
        "success": function (data) {
            if ((data != null) && (data.firmware_update != null)) {

                var status = data.firmware_update.status.toLowerCase();

                // status could be "failed" if system hasn't been reboot since a failed attempt
                if ((status != "idle") && (status != "failed")) {    
                    $("#update_progressbar").progressbar({ value: 0 });
                    $('.update_progress_percentage').html('');
                    $('#update_progress').dialog('open');
                    updateUnexpectedErrorCounter = 0;
                    processUpdate();
                }
            }
        }
    };
    if (typeof useQueue != 'undefined' && useQueue == true){
    	ajaxQueue.add(ajaxAPIOptions);
    }
    else{
    	$.ajaxAPI(ajaxAPIOptions);
    }
}

function get_firmware_info_and_popup() {

    var urlPrefix = apiUrlPrefix;
    var url = "firmware_info";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    $.ajaxAPI({
        "urlPrefix": urlPrefix,
        "url": url,
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'get_firmware_info', request.status);
        },
        "success": function(data){
            if (data != null && data.firmware_info != null && data.firmware_info.upgrades != null) {

                if (data.firmware_info.upgrades.available == 'true') {
                    updateFirmwareAvailableDialog(data.firmware_info);

                    /*
                    $('#available_update_container').find('.update_now_container').each(function(i){
                        if (i>0) {
                            $(this).remove();
                        }
                    });
                    */

                    var currentFirmwareName = data.firmware_info.current_firmware['package'].name;

                    // if there is only 1 available upgrade
                    if (data.firmware_info.upgrades.upgrade.version != null) {
                        addFirmwareAvailable(data.firmware_info.upgrades.upgrade, currentFirmwareName, 0);
                    }
                    else {
                        for(var i in data.firmware_info.upgrades.upgrade){
                            addFirmwareAvailable(data.firmware_info.upgrades.upgrade[i], currentFirmwareName, i);
                        }
                    } 

                    if (data.firmware_info.upgrades.upgrade.version != null) {
                        updateFirmwareAvailable(data.firmware_info.upgrades.upgrade, currentFirmwareName);
                    }

                    // update the Firmware Update page
                    $('.check_for_update_container').hide();
                    $('.update_now_container').show();
                }
    			else if (data.firmware_info.upgrades.available == "false") {
    				$('#firmware_up_to_date_dialog').dialog('open');
    			}
                else if (data.firmware_info.upgrades.available == "error") {
                    showError('get_firmware_info_error');
                }
    			else {
    				showError('get_firmware_info_unk');
    			}
            }
            else {
                showError('get_firmware_info_int_error');
            }
        }
    });            
}

function firmwareUpgradeUnknownProgress() {
    $('.update_progress_label').hide();
    $('#update_progress_inprogress').show();
    $('#update_progressbar').hide();

    updateUnexpectedErrorCounter = 0;
    firmwareUpgradePingServerStartTime = new Date().getTime(); 

    tickElapsedTime('#firmware_upgrade_elapsed_time', firmwareUpgradeStartTime);
    firmwareUpgradePingServer();
}

function firmwareUpgradePingServer() {

    var urlPrefix = apiUrlPrefix;
    var url = "system_state";
    if (useStubUpdates) {
        urlPrefix = 'http://'+window.location.host+'/'+SITE_BASE_URL+'/stubs/';
        url += ".php";
    }

    var currentTime = new Date().getTime(); // in milliseconds
    if ((currentTime - firmwareUpgradePingServerStartTime) > firmwareUpgradeTimeout) {
        $("#update_progress").dialog('close');
        showError('avatar_update_no_return');
        return;
    }

    $.ajaxAPI({
        "urlPrefix": urlPrefix,
        "url": url,
        "timeout": ajaxTimeoutPolling,
        "error": function (request, status, error) {
            if (status == 'timeout' || status == 'error' || status == 'abort') {
                previous_reboot_state = 'rebooting';    // error means the device is rebooting
                setTimeout("firmwareUpgradePingServer();", updateProgressPoll);
            }
            else {
                processAndDisplayError(request.responseText, 'get_system_state', request.status);
            }
        },
        "success": function (data) {
            if (data != null && data.system_state != null) {
                if ((data.system_state.status == 'initializing') || (data.system_state.status == 'ready')) {
                    $("#update_progress").dialog('close');
                    doReboot('update');
                }
                /*
                else {
                    $('#update_progressbar').show();
                    $("#update_progressbar").progressbar({ value: 0 });
                    $('.update_progress_percentage').html('');
                    $('#update_progress').dialog('open');
                    processUpdate();
                }
                */
                else {
                    setTimeout("firmwareUpgradePingServer();", updateProgressPoll);
                }
            }
        },
        "complete": function (jqXHR, textStatus) {
            //hideLoading();
        }
    });
}

