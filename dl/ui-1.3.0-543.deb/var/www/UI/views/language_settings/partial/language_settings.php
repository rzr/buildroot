<?php
    include(realpath(dirname(__FILE__))."/../../../views/common/languages.php");

?>
<div class="content_row">
    <form method="PUT" id="settings_device_language_form" action="language_configuration">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_LANGUAGE_SELECTION')?></label>
        <div class="selectBox defaultfont">
            <select id="languageSelect" name="language">
                <?php foreach($languages as $index=>$language):?>
            	    <option value="<?php echo $index?>"><?php echo $language?></option>
           	    <?php endforeach;?>
            </select>
        </div>
        <span class="form_controls">
            <input type="submit" value="<?php echo _("BUTTON_SAVE");?>" />
            <input type="button" class="reset_form" value="<?php echo _("BUTTON_CANCEL");?>" />     
        </span>
    </form>
</div>
