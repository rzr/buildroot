var suppressErrors = false;

$(document).ready(function(){
	$("#error_dialog").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_critical',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#error_dialog').attr('title')+'</div>'
	});

    $('#error_dialog_close_button').click(function(){
        $('#error_dialog').dialog('close');

        // redirect if applicable
        if (gRedirect) {
            window.location = redirectURL;
        }
    });

});

function showError(ids, msg){

    if(suppressErrors){
        return;
    }

    var errormsgs = '';
    var unknownIDs = '';

    // check for the error code first
    if (ids == undefined) {ids = 'unk';}
    if (typeof(ids) === typeof(200)) {ids = ids.toString();}
    if(!$.isArray(ids) && typeof(ids) === typeof('')){
        // it's a string. or, at least, it had better be
        tmp = ids;
        ids = new Array(tmp);
    }

    // clear out old error messages / unknown if necessary
    if ($('#error_dialog').dialog('isOpen') == false) {
        $("#error_dialog_message ul li").each(function(){
            $(this).remove();
        });
        $("#unknown_ids_message ul li").each(function(){
            $(this).remove();
        });
    }

    if (msg != undefined && msg != '') {
        $("#unknown_ids_message_list").append('<li>' + msg + '</li>');
    }

    var errorDialogTitle = '';
    var ssidNameError = false;
    var passwordError = false;
    var passwordNotMatchError = false;
    var useGenericErrorTitle = false;

    for (var i = 0; i < ids.length; i++) {
        var currentID = ids[i];
        if (currentID == '') {
            continue;   // do nothing
        }
        else if (currentID == 'timeout') {
            /*
            var skip_this_timeout = false;
            $('#error_dialog_message ul li').each(function () {
                var timeoutMsgAlreadyShown = $(this).text();
                // error 200001 is the timeout error
                if ( timeoutMsgAlreadyShown.indexOf( "(200001)" ) > -1 ) {
                    skip_this_timeout = true;
                }
            });
            if (!skip_this_timeout) {
                errormsgs += '<li>' + errorsList[currentID] + '</li>';
            }
            */

            if (checkDuplicateErrorMsg('200001') == false) {
                errormsgs += '<li>' + errorsList[currentID] + '</li>';
            }
        }
        else if (errorsList[currentID] != undefined) {
            errormsgs += '<li>' + errorsList[currentID] + '</li>';
        }
        else {
            // if currentID is undefined and contains "_error", then just display generic error message
            if ((currentID.indexOf('_error') > -1) && (checkDuplicateErrorMsg('200005') == false)) {
                errormsgs += '<li>' + errorsList['get_error'] + '</li>';
            }
            else {
                unknownIDs += '<li>' + currentID + '</li>';
            }
        }

        // Customized title for SSID Name and Password errors
        /*
        if ((currentID == 'wifi_edit_config_form_ssid') || (currentID == 'wifi_signin_to_other_network_form_ssid') || 
            (currentID == 'create_network_ssid') || (currentID == 'ssidname_begin_end_space')) 
        {
            ssidNameError = true;
        }
        else if ((currentID == 'wpa_password_error') || (currentID == 'wep_password_error') || 
                 (currentID == 'create_network_password') || (currentID == 'create_login_password') ||
                 (currentID == 'edit_user_password')) 
        {
            passwordError = true;
        }
        else if (currentID == 'password_not_match') {
            passwordNotMatchError = true;
        }
        else {
            useGenericErrorTitle = true;
        }
        */
    }

    // determine custom error title
    /*
    if (useGenericErrorTitle) {
        errorDialogTitle = '';
    }
    else if (ssidNameError) {
        if (passwordError || passwordNotMatchError) {
            errorDialogTitle = dictionaryList['title_invalid_ssid_and_password'];
        }
        else {
            errorDialogTitle = dictionaryList['title_invalid_ssid_name'];
        }
    }
    else if (passwordError) {
        errorDialogTitle = dictionaryList['title_invalid_password'];
    }
    else if (passwordNotMatchError) {
        errorDialogTitle = dictionaryList['title_mismatch_password'];
    }
    */

    // display custom error title
    if (errorDialogTitle != '') {
        $("#ui-dialog-title-error_dialog").find(".wizard_dialog_title").text(errorDialogTitle);
    }
    else {
        $("#ui-dialog-title-error_dialog").find(".wizard_dialog_title").text(dictionaryList['title_error']);
    }

    // display any unknown ids
    if (unknownIDs.length) {

        // always display the unknownIDs (unless _error or _undefined)
        if ((unknownIDs.indexOf( "_undefined" ) > -1) || (unknownIDs.indexOf( "_error" ) > -1)){
            // do nothing
        }
        else {
            $("#unknown_ids_message_list").append(unknownIDs);
        }

        // but don't display duplicate message (200000)
        var skip_this_unknown_msg = false;
        $('#error_dialog_message ul li').each(function () {
            var errorMsgAlreadyShown = $(this).text();
            // error 200000 is the unknown error
            if ( errorMsgAlreadyShown.indexOf( "(200000)" ) > -1 ) {
                skip_this_unknown_msg = true;
            }
        });

        if (!skip_this_unknown_msg) {
            errormsgs += '<li>' + errorsList["unk"] + '</li>';
        }

        $("#unknown_ids_message").show();
    }

    // display the error messages
    $("#error_dialog_message_list").append(errormsgs);

    $('#error_dialog').dialog('open');
}

function checkDuplicateErrorMsg(id_key) {
    var skip_this_msg = false;
    $('#error_dialog_message ul li').each(function () {
        var timeoutMsgAlreadyShown = $(this).text();
        if ( timeoutMsgAlreadyShown.indexOf( id_key ) > -1 ) {
            skip_this_msg = true;
        }
    });
    return skip_this_msg;
}

function processAndDisplayError(xmlData, method_action, request_status) {

    var xotree = new XML.ObjTree();
    var data = xotree.parseXML( xmlData );
    var error_id = parseDataForErrors(data);
    var errorKey;
    if (error_id) {
        errorKey = method_action + '_error_id_' + error_id;
        if (errorsList[errorKey] != undefined) {
            showError(errorKey);
        }
        else {
            showError('error_id_' + error_id);
        }
    }
    else {
        // if error_id is not found check for error_code
        var msg = '';
        var error_code = parseDataForErrors(data, 'error_code');
        if (error_code) {
            errorKey = method_action + '_http_'+ error_code;
            if (errorsList[errorKey] == undefined) {
                msg = errorKey;
                errorKey = 'http_'+ error_code;
            }
        }
        else {
            if (request_status != 0) {
                errorKey = method_action + '_'+ request_status;
            }
            else {
                errorKey = method_action + '_timeout';
            }

            if (errorsList[errorKey] == undefined) {
                msg = errorKey;
                errorKey = 'timeout';
            }
        }

        showError(errorKey, msg);
    }
}

function parseDataForErrors(data, errorkey){
	var errorFound = false;
    if (errorkey == null) {
        errorkey = "error_id";
    }
	for (var key in data){
        if (key == "#text") {   // skip whitespaces
            continue;
        }
		if (data[key] instanceof Object){
			return parseDataForErrors(data[key], errorkey);
		}
		else if (key == errorkey){
			return data[key];
		}
	}
	return false;
}

function processAjaxError(ID, status) {
    hideLoading();
    if (status == 'parsererror' || status == 'error' || status == 'abort') {
        showError(ID + '_' + status);
    }
    else if (status == 'timeout') {
        showError('timeout');
    }
    else {
        showError(ID + '_unk_error ('+status+')');
    }
}

