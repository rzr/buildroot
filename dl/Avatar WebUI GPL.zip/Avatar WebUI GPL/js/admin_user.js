$(document).ready(function(){

    $('#head_settings_nav_admin_link').navItem({
        'contentId': 'admin_user_container',
        'refreshDataCall': function(){

            // Set Selection
            resetNavigationSelection('#head_settings_nav_admin_link');

            // before retrieve data
            $('#user_detail_password_checkbox').removeAttr('checked');
            $('#user_detail_password_checkbox').attr('disabled', 'disabled');
            $('#user_detail_password_edit_section').hide();

            $('#settings_device_name_form').restForm("refreshForm");
            $('#settings_device_language_form').restForm("refreshForm");
            $('#ssh_form').restForm("refreshForm");
            $('#network_ftp_form').restForm("refreshForm");

        //    pollingHandler.poll();
            $.ajaxAPI({
                "url": "users",
                "timeout": ajaxTimeout,
                "success": function(data, textStatus, jqXHR) {
                    if (data != null && data.users != null && data.users.user != null) {
                        // only 1 user
                        if( Object.prototype.toString.call( data.users.user ) != '[object Array]' ){
                            data.users.user = $.makeArray(data.users.user);
                        }
                        for(var i in data.users.user){
                            if (data.users.user[i].is_admin.toLowerCase() == "true") {
                                $('#settings_admin_user_username').text(data.users.user[i].username);
                                $('#settings_admin_user_form').attr('action', $('#settings_admin_user_form_default').attr('action')+'/'+data.users.user[i].username);

                               	if (data.users.user[i].is_password.toLowerCase() == 'true'){
                            		$('#user_detail_password_checkbox').attr('checked', 'checked');
                            	}
                            	else{
                            		$('#user_detail_password_checkbox').removeAttr('checked');
                            	}

                                $('#edit_admin_user_password_form').attr('action', $('#edit_admin_user_password_form').attr('action')+'/'+data.users.user[i].username);

                                /* workaround IE8 issue with form reset*/
                                $('#edit_admin_user_password_form').find('.username').text( data.users.user[i].username );
                                $('#edit_admin_user_password_form').find('.user_id').text( data.users.user[i].user_id );
                                $('#edit_admin_user_password_form').find('.is_admin').text( data.users.user[i].is_admin );
                                $('#edit_admin_user_password_form').find('.fullname').text( data.users.user[i].fullname );
                                break;
                            }
                        }
                    }
                },
                "error": function (request, status, error) {

                },
                "complete": function (jqXHR, textStatus) {
                    // after retrieve data
                    $('#user_detail_password_checkbox').removeAttr('disabled');

        			if ($('#user_detail_password_checkbox').is(':checked')){
        				$('#user_detail_password_edit_section').show();
        			}
        			else{
        				$('#user_detail_password_edit_section').hide();
        			}

                }
            });
        }
    });

	$('#settings_admin_user_form').restForm({
		'refreshDataCallback': function(data) {
            $('#settings_admin_user_form').restForm("_refreshData", data);
		},
		'refreshDataComplete':function(){
			$('#settings_admin_user_form').restForm("reset");
		},
		'processFormCompleteCallback': function(jqXHR, textStatus){
			$('#settings_admin_user_form').restForm("reset");
			$('#settings_admin_user_form').restForm('processFormComplete', jqXHR, textStatus);
		},
    	'beforeProcessForm': function(){
    		var password = $('#settings_admin_user_form_password').val();
    		$('#settings_admin_user_password_encoded').val($.base64.encode(password));
    	},
		'validateFormCallback': function(){
            $('#settings_admin_user_form').restForm('_validateForm');
            /* CONFIRM validation already done as part of class CONFIRM
            if ($('#settings_admin_user_form').data('validForm') == true){
                if ($('#settings_admin_user_form_password').val() != $('#settings_admin_user_form_password_confirm').val()){
                    $('#settings_admin_user_form').data('validForm', false);
                }
            }
            */
    	}
	});

    $('#edit_admin_user_password_form').restForm({
    	'validateFormCallback': function(){

            if ($("#user_detail_password_checkbox").is(':checked')){
                $('#edit_admin_user_password_form').restForm('_validateForm');
                /* CONFIRM validation already done as part of class CONFIRM
                if ($('#edit_admin_user_password_form').data('validForm') == true){
                    if ($('#edit_user_password').val() != $('#edit_user_password_confirm').val()){
                        $('#edit_admin_user_password_form').data('validForm', false);
                    }
                }
                */
            }
            else {
                $('#edit_admin_user_password_form').data('validForm', true);
            }

    	},
		'processFormSuccessCallback':function(data){
			//reset form and close it
			$('#edit_admin_user_password_form').restForm('reset');
			$('#user_password_overlay').dialog('close');
			if ($('#user_detail_password_checkbox').is(':checked')){
				$('#user_detail_password_edit_section').show();
			}
			else{
				$('#user_detail_password_edit_section').hide();
			}

            /* Avatar - always show Logout button
            if ($("#user_password_overlay").find(".is_admin").val() == 'true') {
                if ($('#user_detail_password_checkbox').is(':checked')){
                    $("#logout_toolbar").show();
                }
                else {
                    $("#logout_toolbar").hide();
                }
            }
            */
		},
    	'beforeProcessForm': function(){
    		var password;
            if ($('#edit_user_password_form_show_password_checkbox').is(":checked")) {
                password = $('#edit_user_password_show').val();
            }
            else {
                password = $('#edit_user_password').val();
            }


    		$('#edit_admin_user_password_encoded').val($.base64.encode(password));

            /* workaround IE8 issue with form reset*/
            $('#edit_admin_user_password_form').find('input[name="username"]').val( $('#edit_admin_user_password_form').find('.username').text() );
            $('#edit_admin_user_password_form').find('input[name="user_id"]').val( $('#edit_admin_user_password_form').find('.user_id').text() );
            $('#edit_admin_user_password_form').find('input[name="is_admin"]').val( $('#edit_admin_user_password_form').find('.is_admin').text() );
            $('#edit_admin_user_password_form').find('input[name="fullname"]').val( $('#edit_admin_user_password_form').find('.fullname').text() );

            /* old password - TBD
            var oldpassword = $('#edit_old_user_password').val();
            $('#edit_old_password_encoded').val($.base64.encode(oldpassword));
            */
    	}
	});

    $("#user_detail_password_checkbox").live("toggle", function (e) {
        e.preventDefault();

        if ($("#user_detail_password_checkbox").is(':checked')){
            $('#user_password_overlay').dialog('option', 'title', '<div class="wizard_dialog_title">'+dictionaryList['create_admin_password']+'</div>');
        	$('#user_password_overlay').dialog("open");
        }
        else{
        	//remove password
        	$('#edit_admin_user_password_form').restForm("reset");
            //$('#edit_old_password_encoded').attr('disabled',true);   // old password - TBD
        	$('#edit_admin_user_password_form').submit();
        }
    });
    
    $('#user_detail_password_edit_link').click(function(e){
    	e.preventDefault();
        $('#user_password_overlay').dialog('option', 'title', '<div class="wizard_dialog_title">'+dictionaryList['edit_admin_password']+'</div>');
    	$('#user_password_overlay').dialog("open");
    });

    $("#user_password_overlay").dialog({
        autoOpen: false,
        resizable: false,
        width: 'auto',
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_user',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#user_password_overlay').attr('title')+'</div>',
        open: function(event, ui){
            /* old password - TBD
            if ($("#user_password_overlay").find(".is_admin").val() == 'true') {
                $('#old_password_container').show();
                $('#edit_old_password_encoded').attr('disabled',false);
            }
            else {
                $('#old_password_container').hide();
                $('#edit_old_password_encoded').attr('disabled',true);
            }
            */
        	$('#edit_admin_user_password_form')[0].reset();

            resetEditUserPasswordForm();
        }
    });
    
    $('#user_password_overlay').bind('dialogclose', function(e) {
        if(e.keyCode == 27){
            if (!$('#user_detail_password_edit_link').is(':visible')){
                $('#user_detail_password_checkbox').removeAttr('checked');	
            }
        }
    });

    $('#edit_user_password_close_button').click(function () {
        $('#user_password_overlay').dialog('close');
        if (!$('#user_detail_password_edit_link').is(':visible')){
        	$('#user_detail_password_checkbox').removeAttr('checked');	
        }
    });

    $('#user_detail_password_checkbox').checkbox(); 

    $('#edit_user_password_form_show_password_checkbox_container > .jquery-checkbox2').live('keydown', function(event) {
        if (event.keyCode == 13) {
            $('#edit_user_password_form_show_password_checkbox').toggle();
            event.preventDefault();
            event.stopPropagation();
        }
    });

    $('#edit_user_password_form_show_password_checkbox').click(function() {
        if ($('#edit_user_password_form_show_password_checkbox').is(":checked")) {
            $('#edit_user_password').val( $('#edit_user_password_show').val() );
            resetEditUserPasswordForm();
        }
        else {
            $('#edit_user_password_show').val( $('#edit_user_password').val() );
            $('#edit_user_password_form_password_container').hide();
            $('#edit_user_password_form_password_show_container').show();
            $('#edit_user_password_form_password_confirm_container').hide();

            $('#edit_user_password').removeClass('PASSWORD').removeClass('NOTEMPTY');
            $('#edit_user_password_confirm').removeClass('CONFIRM_PASSWORD');
            $('#edit_user_password_show').addClass('PASSWORD').addClass('NOTEMPTY');

            if ($('#edit_user_password_show').val() != '') {
                $('#edit_user_password_form_password_show_container').find('.deletebutton').show();
            }
            else {
                $('#edit_user_password_form_password_show_container').find('.deletebutton').hide();
            }

            disableIdTag('#edit_user_password');
            enableIdTag('#edit_user_password_show');
        }
    });    
});

function resetEditUserPasswordForm() {
    $('#edit_user_password_form_password_container').show();
    $('#edit_user_password_form_password_show_container').hide();
    $('#edit_user_password_form_password_confirm_container').show();

    $('#edit_user_password').addClass('PASSWORD').addClass('NOTEMPTY');
    $('#edit_user_password_confirm').addClass('CONFIRM_PASSWORD');
    $('#edit_user_password_show').removeClass('PASSWORD').removeClass('NOTEMPTY');

    enableIdTag('#edit_user_password');
    disableIdTag('#edit_user_password_show');
}
