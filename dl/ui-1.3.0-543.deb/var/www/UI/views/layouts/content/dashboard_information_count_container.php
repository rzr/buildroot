<div id="dashboard_information_count_container">
    <?php $view->LoadContents();$view->LoadViews();?>
</div>