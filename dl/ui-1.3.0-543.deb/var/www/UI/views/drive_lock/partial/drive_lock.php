<div id="drive_lock" class="edit_container_box">
    <h2><?php echo _("CONTENT_SETTINGS_HEAD2_DRIVE_LOCK");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("TOOLTIP_SETTINGS_DRIVE_LOCK");?></div></div></div></h2>
    <div class="content_row">
        <form id="settings_drive_lock_form" action="device_security" method="PUT">
            <!--<label><?php echo _("CONTENT_SETTINGS_LABEL_LOCK");?></label>-->
 
			<input type="checkbox" id="DriveLockToggle" class="onoffswitch"/>		
            <input id="DriveLockValue" name="locked" value="true" type="hidden"/>

        </form>
    </div>
</div>
