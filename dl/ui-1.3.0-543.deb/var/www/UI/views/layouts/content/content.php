<div id="<?php echo $identifier?>_content" class="content_container">
	<?php $view->LoadViews();$view->LoadContents();?>
</div>