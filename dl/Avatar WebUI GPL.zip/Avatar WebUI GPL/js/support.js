
$(document).ready(function(){

    if(gIsMobile) {
        disableIdTag('#create_and_save_btn');
    }

    $('#head_settings_nav_support_link').navItem({
        'contentId': 'support_container',
        'refreshDataCall': function(){

        	// Set Selection
            resetNavigationSelection('#head_settings_nav_support_link');
            
            $('#diagnostics_tests_form').restForm("refreshForm");
            $('#product_improvement_form').restForm("refreshForm");

        }
    });

    $('#no_internet_access_dialog').dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#no_internet_access_dialog').attr('title')+'</div>',
        open: function(){
            $('#no_internet_access_ok_button').focus();
        }
    });
    
    $('#popup_blocked_dialog').dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#popup_blocked_dialog').attr('title')+'</div>'
    });
    
    $('#popup_blocked_ok_button').click(function () {	
        $('#popup_blocked_dialog').dialog("close");
    });
        
    $("#support_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass: 'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#support_dialog').attr('title')+'</div>'
    });

    $('#support_dialog_close_button').click(function () { 
        $("#support_dialog").dialog("close");
    });

    $('#request_automated_support_form').restForm();

    $('#create_and_save_btn').click(function (e) {
        e.preventDefault();	
        createAndSaveSystemLog();
    });

    $('#support_run_request_support_button').click(function (e) {
        e.preventDefault();	
        //check to verify we have internet access
        requestAutomatedSupport();                  
        
        $('#support_dialog').dialog("close");
    });

    $('#request_support_btn').click(function (e) { 
        e.preventDefault();

        // check to verify that the device has internet access
        $.ajaxAPI({
            "url": 'internet_access',
            "type": "GET",
            "success": function(data){
    			if (data != null && data.internet_access != null && data.internet_access.connectivity != null){
    				if (data.internet_access.connectivity == "true") {    	                
    	                $("#request_automated_support_form")[0].reset();
        		        disableIdTag("#support_run_request_support_button");
        		
        		        if(gIsMobile) {
        		            $('#support_run_report_button').attr('disabled', true);
        		            $('#support_run_report_button').addClass('ui-state-disabled');
        		        }
        		        $("#support_dialog").dialog("open");
    	            }
    	            else {    	                
    	                $('#no_internet_access_dialog').dialog("open");
    	            }    		    				    				
    			}
            },
            "complete": function (jqXHR, textStatus) {
            }
        });
       
        
    });

    $('#no_internet_access_ok_button').click(function () {	
    	$('#no_internet_access_dialog').dialog("close");
    });

    $('#product_improvement_dialog_form').restForm({
        'processFormSuccessCallback': function(){
            $('#product_improvement_form').find('#PrivacyOptionToggle').attr('checked', true);
            $('#PrivacyOptionValue').val('true');
        },
        'processFormCompleteCallback': function(jqXHR, textStatus){
            $('#product_improvement_dialog_form').restForm('processFormComplete', jqXHR, textStatus);
            updatePIPDialogs();
        }
    });

    $('#request_automated_support').click(function () {	
        if ($(this).is(':checked')){
            disableIdTag('#support_run_request_support_button');
        }
        else {
            enableIdTag('#support_run_request_support_button');
        }
    });
    
    $("#product_improvement_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width:600,
        minHeight:240,
        dialogClass:'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#product_improvement_dialog').attr('title')+'</div>',
        open: function(){
            $('#product_improvement_dialog_ok_button').focus();
        }

    });

    $('#product_improvement_dialog_cancel_button').click(function () { 
        $("#product_improvement_dialog").dialog("close");
    });

    $('#product_improvement_dialog_ok_button').click(function () { 
        $("#product_improvement_dialog").dialog("close");
        $('#product_improvement_dialog_form').submit();
    });

    $('#product_improvement_dialog_close_button').click(function () { 
        $("#product_improvement_dialog").dialog("close");
    });

    $('#product_improvement_form').restForm({
        'refreshDataCallback' : function(data) {
            if (data != null && data.privacy_options != null) {
                if (data.privacy_options.send_serial_number.toLowerCase() == 'true') {
                    $('#product_improvement_form').find('#PrivacyOptionToggle').attr('checked', true);
                    $('#PrivacyOptionValue').val('true');
                }                   
                else {
                    $('#product_improvement_form').find('#PrivacyOptionToggle').attr('checked', false);
                    $('#PrivacyOptionValue').val('false');
                } 
            }
            else {
            }
        },
        'processFormCompleteCallback': function(jqXHR, textStatus){
            $('#product_improvement_form').restForm('processFormComplete', jqXHR, textStatus);
            updatePIPDialogs();
        }
    });
	
    $('#PrivacyOptionToggle').live('toggle', function (e) {
    	if ($(this).is(':checked')) {
    		$('#PrivacyOptionValue').val('true');           
        }
        else {
            $('#PrivacyOptionValue').val('false');
        }
        $('#product_improvement_form').submit();
    });

    $('#product_improvement_more_info').click(function(e){
    	e.preventDefault();
    	$('#product_improvement_dialog').dialog("open");
    });

});




function requestAutomatedSupport() {
    displayLoading();
    $.ajaxAPI({
        "url": "system_log",
        "type": "POST",
        "error": function (request, status, error) {
            processAndDisplayError(request.responseText, 'post_system_log', request.status);
        },
        "success": function (data) {

            var logfilename = data.system_log.logfilename;
            var nastype = gModelNumber;

            $("#quick_support_form").find("#devlang").val(gLanguage3Letter);
            $("#quick_support_form").find("#devsn").val(gSerialNumber);
            $("#quick_support_form").find("#devmodel").val(gModelNumber);
            $("#quick_support_form").find("#devnastype").val(nastype);
            $("#quick_support_form").find("#devfw").val(VERSION);
            $("#quick_support_form").find("#devhash").val(logfilename);

            $("#quick_support_form").submit();
        },
        "complete": function (jqXHR, textStatus) {
           // $("#support_dialog").dialog('close');
            hideLoading();
        }
    });
}

function createAndSaveSystemLog() {

   	var url = apiUrlPrefix + "system_log?attach_file=true";
    displayLoading();
    downloadInIframe(url);
}

function updatePIPDialogs() {
    if ($('#PrivacyOptionToggle').is(':checked')) {
        $('#product_improvement_dialog_cancel_button').hide();
        $('#product_improvement_dialog_ok_button').hide();
        $('#product_improvement_dialog_close_button').show();
        $('#product_improvement_dialog_participate').hide();
    }
    else {
        $('#product_improvement_dialog_close_button').hide();
        $('#product_improvement_dialog_cancel_button').show();
        $('#product_improvement_dialog_ok_button').show();
        $('#product_improvement_dialog_participate').show();
    }
}
