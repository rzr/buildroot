<div id="dashboard_firmware_box" class="dashboard_medium_box dashboard_box">
	<div class="header"><h3><span id="dashboard_device_status_firmware_header"><?php echo _('CONTENT_HOME_SMALL_BOX_TITLE_FIRMWARE')?></span></h3></div>
    <div id="dashboard_device_status_firmware_version" class="dashboard_count dashboard_content_status_text overflow_hidden_nowrap_ellipsis"><span id="dashboard_device_status_firmware_version_text"></span></div>
    <div class="footer"><a href="#" id="dashboard_firmware_link"></a></div>
</div>