
<div id="wifi_edit_config_overlay" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_ACCESS_POINT_SETTINGS')?>" class="mochi_dialog_container">
	<form id="wifi_edit_config_form" action="wifi_ap" method="PUT">
    	<div class="mochi_dialog_content_container">
        	<div class="mochi_dialog_content">

                <div class="content_row">
        			<label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_NAME')?></label>
                	<input id="wifi_edit_config_form_ssid" type="text" name="ssid" class="NETWORK_SSID NOTEMPTY" maxlength="32" />
                </div>        	

                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_SECURITY_TYPE')?></label>
                    <div class="selectBox defaultfont">
                        <select id="wifi_edit_config_form_security_mode_select" name="security_mode"><?php foreach($ap_security_modes as $index=>$security_mode):?>
                            <option value="<?php echo $index?>"><?php echo $security_mode?></option>
                        <?php endforeach;?></select>
                        <span id="wifi_edit_config_form_original_security" class="original_settings"></span>
                    </div>
                </div>

                <div class="content_row display_ssid_password">
        			<label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_PASSWORD')?></label>
        			<span id="wifi_edit_config_form_password_container"><input type="password" id="wifi_edit_config_form_password" name="security_key" class="NETWORK_PASSWORD WPA_NETWORK_PASSWORD NOTEMPTY" maxlength="63" autocomplete="off" /></span>
                    <span id="wifi_edit_config_form_password_show_container"><input type="text" id="wifi_edit_config_form_password_show" name="security_key" maxlength="63" /></span>
                </div>

                <div class="content_row display_ssid_password" id="wifi_edit_config_form_password_confirm_container" style="display:block">        			
        			<label><?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_CONFIRM_PASSWORD')?></label>
                    <input type="password" id="wifi_edit_config_form_password_confirm" class="CONFIRM_PASSWORD" maxlength="63" autocomplete="off" />
                </div>

                <div class="content_row display_ssid_password">
                    <label>&nbsp;</label>
                    <input type="checkbox" class="normal_checkbox" id="wifi_edit_config_form_show_password_checkbox" /> <?php echo _('CONTENT_SETTINGS_STRING_SHOW_PASSWORD')?>
                </div>

                <div class="content_row advanced_options_row">
                    <label class="show_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="right_arrow"></span>
                    </label>
                    <label class="hide_advanced_options">
                        <span class="advanced_details_text"><?php echo _('CONTENT_SETTINGS_LABEL_ADVANCED_OPTIONS')?></span>
                        <span class="down_arrow"></span>
                    </label>
                </div>

                <div class="advanced_options_container">

                    <div class="content_row">
                        <label><?php echo _('CONTENT_SETTINGS_LABEL_SSID_BROADCAST')?></label>
		                <input type="hidden" id="wifi_edit_config_form_broadcast_value" name="broadcast" value="true"/>
		                <input type="checkbox" id="wifi_edit_config_form_broadcast_toggle" class="onoffswitch"/>
                        <span id="wifi_edit_config_form_original_broadcast" class="original_settings"></span>
                    </div>
    
                    <div class="content_row">
                        <label><?php echo _('CONTENT_SETTINGS_DIALOG_LABEL_WIFI_CHANNEL')?></label>
                        <div class="selectBox defaultfont">
                            <select id="wifi_edit_config_form_channel_select" name="channel">
                                <?php foreach($wifi_channels as $index=>$wifi_channel):?>
                                    <option value="<?php echo $index?>"><?php echo $wifi_channel?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div> 

                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_MAC_ADDRESS')?></label>
                        <span id="wifi_edit_config_form_mac_address"></span>
                    </div>        	
    
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?></label>
            				<input type="text" id="wifi_edit_config_form_ipaddress" class="IPADDRESS" name="ip" value=""/>
                            <span id="wifi_edit_config_form_original_ipaddress" class="original_settings"></span>
            			</div>
            		</div>
            		<div class="content_row" id="wifi_edit_config_form_netmask_container">
            			<div class="input text">
            				<label><?php echo _('LABEL_HEADER_NETMASK')?></label>
                            <!--
            				<input type="text" id="wifi_edit_config_form_netmask" class="NETMASK" name="netmask" value=""/>
                            <span id="wifi_edit_config_form_original_netmask" class="original_settings"></span>
                            -->
                            <span id="wifi_edit_config_form_netmask"></span>
            			</div>
            		</div>
    
                    <div class="content_row">
                        <label><?php echo _('LABEL_HEADER_DHCP_SERVER')?></label>
		                <input type="hidden" id="wifi_edit_config_form_enable_dhcp_value" name="enable_dhcp" value="true"/>
		                <input type="checkbox" id="wifi_edit_config_form_enable_dhcp_toggle" class="onoffswitch"/>
                        <span id="wifi_edit_config_form_original_enable_dhcp" class="original_settings"></span>
                    </div>
    
                    <input type="hidden" name="enabled" />
                    <input type="hidden" name="channel_mode" id="wifi_edit_config_form_channel_mode" />

                </div>
            </div>
        </div>
    	<div class="dialog_form_controls">
        	<button type="button" id="wifi_edit_config_cancel_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
            <button type="button" id="wifi_edit_config_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
		</div>
	</form>
</div>

<div id="wifi_edit_network_settings_config_overlay" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_NETWORK_SETTINGS')?>" class="mochi_dialog_container">

    <form id="wifi_edit_network_settings_config_default_form" action="network_configuration"></form>
	<form id="wifi_edit_network_settings_config_form" action="network_configuration" method="PUT">
    	<div class="mochi_dialog_content_container">
        	<div class="mochi_dialog_content">
                <div class="content_row">
                	<label><?php echo _('LABEL_HEADER_MAC_ADDRESS')?></label>
                    <span id="wifi_edit_network_settings_mac_address"></span>
                </div>
                <input type="hidden" id="wifi_network_settings_gateway_mac_address" name="gateway_mac_address" />
                <div class="content_row">
                	<label><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?></label>
                    <span id="wifi_edit_network_settings_device_name"></span>
                </div>        	
                <!--
                <div class="content_row">
                	<label><?php echo _('GLOB_NAV_LOGIN_LABEL_NETWORK_NAME')?></label>
                    <span id="wifi_edit_network_settings_ssid_name"></span>
                </div>
                -->
                <div class="content_row">
                	<label><?php echo _('LABEL_HEADER_NETWORK_MODE')?></label>
                    <button type="button" id="wifi_edit_settings_network_mode_dhcp_button" class="left-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_DHCP')?></button><button type="button" id="wifi_edit_settings_network_mode_static_button" class="right-button"><?php echo _('CONTENT_SETTINGS_NETWORK_BUTTON_STATIC')?></button>
                </div>
                
                <div id="wifi_network_settings_dhcp_container">
                    <div class="content_row">
                    	<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?></label>
                        <span id="wifi_network_settings_dhcp_ip_address"></span>
                    </div>
                    <div class="content_row">
                    	<label><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_ACTIONS')?></label>
                        <button type="button" id="wifi_settings_network_dhcp_renew_button"><?php echo _('CONTENT_SETTINGS_WIFI_STRING_RENEW')?></button>
                        <!--<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('TOOLTIP_SETTINGS_DHCP_REVIEW')?></div></div></div>-->
                    </div>
                </div>
                <div id="wifi_network_settings_static_container">

                    <input type="hidden" id="NetworkModeEditValue" name="proto" value="static"/>
            
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?><span class="required">&nbsp;*</span></label>
            				<input type="text" id="SettingIp" class="IPADDRESS" name="ip" />
            			</div>
            		</div>
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _("LABEL_HEADER_NETMASK")?><span class="required">&nbsp;*</span></label>
            				<input type="text" id="SettingNetmask" class="NETMASK" name="netmask" />
            			</div>
            		</div>
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _("LABEL_HEADER_GATEWAY")?></label>
            				<input type="text" id="SettingGateway" class="GATEWAY" name="gateway" />
            			</div>
            		</div>
                    <!--
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('CONTENT_SETTINGS_WIFI_LABEL_DNS')?></label>
            				<input type="text" class="dns_server_input DNS" id="SettingDns0" name="dns0" />
                            <input type="hidden" id="SettingDns1" name="dns1" />
                            <input type="hidden" id="SettingDns2" name="dns2" />
            			</div>
            		</div>
                    -->
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_1')?></label>
            				<input type="text" class="dns_server_input DNS" id="SettingDns0" name="dns0" />
            			</div>
            		</div>
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_2')?></label>
            				<input type="text" class="dns_server_input DNS" id="SettingDns1" name="dns1" />
            			</div>
            		</div>
                    <!--
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_3')?></label>
            				<input type="text" id="SettingDns2" class="dns_server_input DNS" name="dns2" />
            			</div>
            		</div>
                    -->
                    <input type="hidden" id="SettingDns2" name="dns2" />
            		<div class="content_row">
            			<div class="input text">
            				<label><?php echo _('LABEL_HEADER_WORKGROUP_NAME')?></label>
            				<input type="text" id="SettingWorkgroupName" class="WORKGROUP" name="workname" maxlength="16"/>
                            <!--<div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_SETTINGS_NETWORK_TOOLTIP_WORKGROUP')?></div></div></div>-->
            			</div>
            		</div>
                    <div class="content_row">
                        <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
                    </div>
                </div>

            </div>
        </div>
    	<div class="dialog_form_controls">
        	<button type="button" id="wifi_edit_network_settings_config_cancel_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
            <button type="button" id="wifi_edit_network_settings_config_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
		</div>
	</form>
    <form id="network_workgroup_form" method="PUT" action="network_workgroup"></form>

</div>

<div id="wifi_network_mode_confirmation" title="<?php echo _('CONTENT_DIALOG_SETTINGS_NETWORK_TITLE_NETWORK_MODE_CONFIRMATION')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
        	<p><?php echo _('CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_MODE_CONFIRMATION_MESSAGE')?> </p>        
        	<br/>
        	<p><?php echo _('CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_MODE_CONTINUE_MESSAGE')?></p>
        </div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="wifi_network_mode_confirmation_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="wifi_network_mode_confirmation_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>

