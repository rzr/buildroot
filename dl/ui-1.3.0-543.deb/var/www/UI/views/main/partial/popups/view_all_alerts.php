<div id="view_all_alerts_dialog" title="<?php echo _('GLOB_NAV_NOTIFICATIONS_TITLE_NOTIFICATIONS')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
        	<div id="dialog_notification_list">
        
        		<ul class="dialog_notification_ul">
        
        			<li style="display:none" class="view_all_notification_list_item"> 
        
        						<span class="notification_title" style="display:inline-block"></span>
        						<!--<span class="notification_count_shown" style="display:inline-block;padding-left:5px"></span>-->
        						<p class="notification_count" style="display:none;"></p>
        						<p class="notification_id_list" style="display:none;"></p>

        						<div>
        							<p class="dialog_notification_description"></p> 
                                    <p class="all_alert_speciality_container"><a href="#"><span class="all_alert_speciality_link"><?php echo _('CONTENT_DIALOG_ALERTS_STRING_BEGIN_UPDATE')?></span></a></p>
        						</div>
        						
        						<span class="dialog_notification_time">
        						    <span class="notification_time notification_time_indented"></span>
                                </span>

                                <span class="dialog_notification_ignore">
        						    <span class="notification_dialog_ignore_alert"> </span>
                                </span>

                                <span class="dialog_notification_code">
        						    <span class="notitication_code_text" style="display:inline-block"><?php echo _('GLOB_NAV_NOTIFICATIONS_LABEL_CODE')?></span>
        						    <span class="notitication_code" style="display:inline-block"></span>
                                </span>
        						
        						<!-- <a class="notification_more_info" style="display:inline-block" href="#" >More Information</a> -->
        
        			</li>
        
        		</ul>
        	</div>
        </div>
    	<form id="alerts_dismiss_all_form" method="DELETE" action="alerts">
		</form>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="alerts_view_dismiss_all_button" class="close"><?php echo _('GLOB_NAV_NOTIFICATIONS_BUTTON_DISMISS_ALL')?></button>
    	<button type="button" id="alerts_view_all_cancel_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>