<div id="factory_restore_quick_wait_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_FACTORY_RESTORE'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container no_dialog_form_controls">
		<div class="mochi_dialog_content">
			<div>
                <table>
                    <tr>
                        <td><span class="spinnerSunIcon"></span></td>
                        <td><?php echo _('CONTENT_SETTINGS_STRING_FACTORY_RESTORE_IN_PROGRESS'); ?></td>
                    </tr>
                </table>
			</div>
		</div>
	</div>
</div>
