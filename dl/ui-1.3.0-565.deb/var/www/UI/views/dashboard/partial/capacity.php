<div class="dashboard_box dashboard_big_box" id="dashboard_device_capacity">
	<div class="header"><h2><?php echo _('CONTENT_HOME_BIG_BOX_TITLE_CAPACITY')?></h2></div>
	<div id="dashboard_storage_information_space_available_container"><span id="dashboard_storage_information_space_available_total_text"></span>
		<div id="dashboard_storage_information_text">
			<div id="dashboard_storage_information_space_type"></div>
			<div id="dashboard_storage_information_text_free"><?php echo _('CONTENT_HOME_BIG_BOX_STRING_FREE')?></div>
		</div>
	</div>
    <div class="footer"><a href="#" id="dashboard_capacity_link"></a></div>
</div>