<form id="battery_status_form" method="PUT" action="battery_status">
    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_CURRENT_LEVEL')?></label>
        <span id="battery_settings_current_level_text"></span>
    </div>
    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_LABEL_POWER_STATE')?></label>
        <span id="battery_settings_current_state_text"></span>
    </div>
</form>
<div class="content_row">
	<form id="battery_settings_power_profile" method="PUT" action="power_profile">
    	<label><?php echo _('CONTENT_SETTINGS_LABEL_PRIORITY')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('TOOLTIP_SETTINGS_BATTERY_PRIORITY')?></div></div></div></label>
        <button type="button" id="settings_battery_media_performance_button" class="left-button"><?php echo _('LABEL_MEDIA_PERFORMANCE')?></button><button type="button" id="settings_battery_max_life_button" class="right-button"><?php echo _('LABEL_BATTERY_LIFE')?></button>
    	<input type="hidden" id="settings_battery_profile" name="profile" value=""/>
    </form>
</div>
