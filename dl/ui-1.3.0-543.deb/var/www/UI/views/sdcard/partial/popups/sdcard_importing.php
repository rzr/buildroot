<div id="importing_sdcard_content_dialog" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_SD_CARD_IMPORT'); ?>">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
			<?php echo _('CONTENT_DIALOG_SETTINGS_STRING_COPY_MOVE_NOW_SUCCESS_ME')?>
        </div>
	</div>
	<div class="dialog_form_controls">
		<button type="button" id="importing_sdcard_content_dialog_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>
