function isIpOrHostname(val){
    h = new RegExp("^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$");
    ip = new RegExp("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$");
    return ip.test(val) || h.test(val);
}

function isHostname(val){
    h = new RegExp("^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$");
    return h.test(val);
}

function validateHostNameOrIP(val, iptype) {

    //check if it is IP address or hostname

	var validCharStr1 = "1234567890.";
	var validCharStr2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.";
	var isHostName = true;
	var isNumber = true;

	for ( var i = 0 ; i < val.length; i++ ) {
		//check if it is a valid character
		if ( validCharStr1.indexOf (val.charAt(i)) == -1 ) {
			isNumber = false;
			break;
		}
	}
	for ( var j = 0 ; j < val.length; j++ ) {
		//check if it is a number
		if ( validCharStr2.indexOf (val.charAt(j)) == -1 ) {
			isHostName = false;
			break;
		}
	}

	if ((isHostName === false) && (isNumber === false)) {
		return 1000;
	}

	if (isNumber === true) {
		return validateIP(val, iptype);
	}
	else if (isHostName === true) {
		h = new RegExp("^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$");
		if (h.test(val) === true) {
			return 0;
		}
		else {
			return 1000;
		}
	}
	return 0;
}

function validateIP(strIP, iptype) {

	//check if the text filed is blank
	if (trimString(strIP).length === 0) {
		return 1001;
	}

	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var ipArray = strIP.match(ipPattern);

	if (ipArray === null) {
		return 1000;
	} 
	else if ((strIP == "0.0.0.0") ||
			 (strIP == "255.255.255.255"))
	{
		// special IP and cannot be used
		return 1002;
	}
	else if (iptype == 'NETMASK') {
		// futher netmask validation will be done in function validateNetMask()
		return 0; 
	}
	else if (ipArray[1] === '0') {
		// 0.x.x.x are reserved for self-identification
		return 1003;
	}
	else if (ipArray[1] == 127) {
		// 127.x.x.x are reserved for loopback
		return 1004;
	}
	else if (ipArray[1] == 169 && ipArray[2] == 254) {
		// 169.254.x.x are reserved for LINKLOCAL (DHCP client auto-config space)
		return 1005;
	}
	else if (ipArray[1] == 192 && ipArray[2] == 88 && ipArray[3] == 99) {
		// 192.88.99.x are reserved for 6to4 Relay Anycast address
		return 1006;
	}
	else if (ipArray[1] >= 224 && ipArray[1] <= 239) {
		// 224.0.0.0 through 239.255.255.255 are reserved for Multicast
		return 1007;
	}
	else if (ipArray[1] >= 240 && ipArray[1] <= 255) {
		// 240.0.0.0 through 255.255.255.254 are reserved; 255.255.255.255 reserved for "limited broadcast" destination address
		return 1008;
	}
	else {
		for (i = 1; i < 5; i++) {
			ipSegment = ipArray[i];
			if (ipSegment > 255) {
				// IP octet range 0-255
				return 1000;
			}
		}
	}
	return 0;
}
