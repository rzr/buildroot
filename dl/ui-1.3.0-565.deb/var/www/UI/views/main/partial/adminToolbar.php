<div id="admin_toolbar" class="toolbar_item">
	<div class="toolbar_button_container">
		<a href="#" class="toolbar_button" id="admin_link"></a>
	</div>
</div>