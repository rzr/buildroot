<div id="configure_alerts_overlay" title="<?php echo _('CONTENT_DIALOG_SETTINGS_NOTIFICATIONS_TITLE_NOTIFICATIONS_CONFIG')?>"  class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
    <p><?php echo _('CONTENT_DIALOG_SETTINGS_NOTIFICATIONS_HEAD2_SETUP_NOTIFICATIONS')?></p>
	
	<p><?php echo _('CONTENT_DIALOG_SETTINGS_NOTIFICATIONS_LABEL_SETUP_NOTIFICATIONS_MESSAGE')?></p>
	
	<div class="content_row" style="padding-left: 40px;">
		<label style="width:220px"><?php echo _('CONTENT_SETTINGS_NOTIFICATION_LABEL_CRITICAL_ONLY')?></label>
		<label style="width:320px"><?php echo _('CONTENT_SETTINGS_NOTIFICATION_LABEL_CRITICAL_AND_WARNING')?></label>
		<label style="width:150px"><?php echo _('CONTENT_SETTINGS_NOTIFICATION_LABEL_ALL_NOTIFICATIONS')?></label>        
		<div id="alert_config_email_slider"></div>
    </div>
    
	<form id="users_for_alert_settings_form" action="users" method="PUT">			
	</form>
		
	<br/>
	
	<form id="edit_alert_configuration_form" action="alert_configuration" method="PUT">	
		
		
		<div class="wizard_users_for_alerts_list_control">			

			<div class="wizard_add_email_container">            	
				<ul class="wizard_list" id="wizard_add_email_list" style="max-height:200px">
					<li class="add_email_list_item" style="display:none">
   						<input type="hidden" class="alert_email_value" value=""/>
            			<span style="display:inline-block" class="wizard_list_email"></span>
            			<span class="notification_delete_emails alert_email_delete"></span>
            			
            			
					</li>		
					<li id="alert_input_email_li" class="alert_input_email_class" style="display:none">
            			<input type="text" placeholder="<?php echo _('CONTENT_GENERIC_TEXTBOX_LABEL_EMAIL_ADDRESS')?>" class="EMAIL alert_input_email" />
            			<span class="edit_dialog_form_controls form_controls email_save_button" style="float:right"><input type="submit" value="<?php echo _("BUTTON_SAVE");?>" /></span>            			
					</li>					
				</ul>
			</div>
	   	</div>

		<input type="hidden"  name="email_enabled" id="edit_alert_email_enabled" value=""/>
		<input type="hidden"  name="min_level_email" id="edit_alert_email_min_level_email" value=""/>
		<input type="hidden"  name="min_level_rss" id="edit_alert_email_min_level_rss" value=""/>
		<input type="hidden" id="edit_alert_configuration_email_0" name="email_recipient_0" value=""/>
		<input type="hidden" id="edit_alert_configuration_email_1" name="email_recipient_1" value="" />
		<input type="hidden" id="edit_alert_configuration_email_2" name="email_recipient_2" value="" />
		<input type="hidden" id="edit_alert_configuration_email_3" name="email_recipient_3" value="" />
		<input type="hidden" id="edit_alert_configuration_email_4" name="email_recipient_4" value="" />
		
	</form>
	<div class="wizard_users_for_alerts_btn_container content_row">
		<input type="button" id="alert_configuration_add_email" class="wizard_add_email_btn" value="<?php echo _('CONTENT_DIALOG_SETTINGS_NOTIFICATIONS_BUTTON_NEW_EMAIL')?>"/>	        
	</div>
		
		
	<form id="alert_test_email_form" action="alert_test_email" method="POST">
			
	</form>
	</div>
	</div>
	<div class="dialog_form_controls">

    	<button type="button" id="alert_configuration_ok_button" class="close mochi_dialog_save_button"><?php echo _('BUTTON_OK'); ?></button>
       <button type="button" id="alert_configuration_send_button" class="mochi_dialog_save_button"><?php echo _('CONTENT_DIALOG_SETTINGS_NOTIFICATIONS_BUTTON_SEND_TEST_EMAIL')?></button>
	</div>

</div>