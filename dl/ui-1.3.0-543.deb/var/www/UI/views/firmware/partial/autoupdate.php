<?php include(realpath(dirname(__FILE__))."/../../common/dates.php")?>
<form id="auto_system_updates_form" method="PUT" action="firmware_update_configuration">
    <div class="content_row">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_ENABLE_AUTO_UPDATE");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_UPDATE_TOOLTIP_ENABLE_AUTO");?></div></div></div></label>
	    <input type="hidden" name="auto_install" value="false" />
        <input type="checkbox" id="chk_enable_auto_update" class="onoffswitch" name="auto_install" value="true"/>
    </div>

    <div id="hide_update_schedule" class="content_row content_row_wrappable" style="display: none;">
        <table>
            <tr>
                <td><label><?php echo _('LABEL_UPDATE_SCHEDULE')?></label></td>
                <td class="settings_values_container">
                    <div class="selectBox">
                        <select id="SettingUpdateDay" name="auto_install_day">
                            <?php foreach($daysOfWeek as $index=>$dayOfWeek):?>
                                <option value="<?php echo $index?>"><?php echo $dayOfWeek?></option>
                            <?php endforeach?>
                        </select>
                    </div>
                    <div class="selectBox">
                        <select id="SettingUpdateHour">
                            <?php foreach($hours_00 as $index=>$hour):?>
                                <option value="<?php echo $index?>"><?php echo $hour?></option>
                            <?php endforeach?>
                        </select>
                        <input type="hidden" id="SettingUpdateHourHidden" name="auto_install_hour" />
                    </div>
                    <div class="selectBox">
                        <select id="SettingUpdateAmPm">
                            <?php foreach($ampm as $index=>$value):?>
                                <option value="<?php echo $index?>"><?php echo $value?></option>
                            <?php endforeach?>
                        </select>
                    </div>
                    <span class="form_controls">
                        <input type="submit" value="<?php echo _('BUTTON_SAVE')?>" />
                        <input type="button" class="reset_form" value="<?php echo _('BUTTON_CANCEL')?>" />     
                    </span>
                </td>
            </tr>
        </table>
    </div>
</form>