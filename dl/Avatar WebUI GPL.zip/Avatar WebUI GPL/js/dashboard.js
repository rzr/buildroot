var dashboardHandler = null; 

var deviceTemperature = dictionaryList['_unknown'];
var deviceSmartStatus = dictionaryList['_unknown'];
var deviceVolumeStatus = dictionaryList['_unknown'];
var deviceFreeSpace = dictionaryList['_unknown'];
var gFreeSpaceBad = false;
var gCapacity = 0;
var gUsage = 0;
var gDLNAScanningState = 'idle';            // idle, scanning, error, unknown
var gMediaCrawlerScanningState = 'idle';    // idle, scanning, error, unknown
var gMediaCrawlerScanningStateMsg = dictionaryList['idle'];

$(document).ready(function(){
	dashboardHandler = $.updateDashboardHandler({
		updateFinishCallback: function(){
			hideLoading();
		}
	});
    subscribeDashboardPolls();

    /* Legacy Sequoia
    $('#dashboard_create_user_link').click(function(){
        $('#create_user_wizard').dialog("open");
    }); 
    */ 

    //pollingHandler.addPoll("device_user", ["dashboard_container"], dashboardDeviceUserPollSuccess, dashboardPollError);
    //pollingHandler.addPoll("mediacrawler_status", ["dashboard_container"], dashboardMediacrawlerPollSuccess, dashboardMediacrawlerPollError, pollingFrequency, false, true);
    //pollingHandler.addPoll("media_server_database", ["dashboard_container"], dashboardDLNAPollSuccess, dashboardDLNAPollError, pollingFrequency, false, true);

    $('#footer_device_version').text('v'+VERSION);

    $('#dashboard_battery').click(function(){
        $('#head_settings_nav_hardware_link').click();
    }); 

    $('#dashboard_wifi_box').click(function(){
        $('#head_settings_nav_network_link').click();
    }); 

    $('#footer_device_timestamp_form').restForm({
        'showProcessingCallback': function () {
        },
        'hideProcessingCallback': function () {
        },
        'refreshDataCallback': function(data) {
            $('#footer_device_timestamp_form').restForm("_refreshData", data);

            if (data != null && data.date_time_configuration != null && data.date_time_configuration.datetime != null) {

                var dateStamp = new Date();
                var seconds = Math.round(dateStamp.getTime() / 1000);
                gDateTime = seconds;

                // if Avatar RTC is out of sync by 60 seconds, set the RTC
                if (Math.abs(seconds - data.date_time_configuration.datetime) > 120) {
                    $('#footer_device_timestamp_datetime').val(seconds);
                    $('#footer_device_timestamp_ntpservice').val('false');
                    $('#footer_device_timestamp_form').submit();
                }
            }
        }
    });

    $('.internet_required').live('click', function(e) {
        e.preventDefault();
        var external_link = $(this).attr('href');
        var target_window = $(this).attr('id');
        if (target_window == '') {
            target_window = $(this).attr('target');
        }

        // check to verify that the device has internet access
        $.ajaxAPI({
            "url": 'internet_access',
            "type": "GET",
            "success": function(data){
    			if (data != null && data.internet_access != null && data.internet_access.connectivity != null){
                    if (data.internet_access.connectivity == "true") {

                        if (gPopupBlocker) {
                            if (isPopupBlockerEnabled()) {
                                gPopupBlocker = true;
                                $('#popup_blocked_dialog').dialog("open");
                            }
                            else {
                                gPopupBlocker = false;
                            }
                        }

                        window.open(external_link, target_window);
                        $('#no_internet_access').hide();
                    }
                    else {
                        $('#no_internet_access_dialog').dialog("open");
                        if (gConnectedNetwork) {
                            $('#no_internet_access').show();
                        }
                    }
    			}
            }
        });
    });

    $('#shortcut_link').live('click', function(e) {
        e.preventDefault();
        $("#create_shortcut_dialog").dialog("open");
    });

    $("#create_shortcut_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width:530,
        minHeight:240,
        dialogClass:'mochi_dialog mochi_dialog_support',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#create_shortcut_dialog').attr('title')+'</div>',
        open: function () { $('#create_shortcut_dialog_ok_button').focus(); }
    });

    $('#create_shortcut_dialog_cancel_button').click(function () { 
        $("#create_shortcut_dialog").dialog("close");
    });

    $('#create_shortcut_dialog_ok_button').click(function () { 
        $("#create_shortcut_dialog").dialog("close");
        window.location = "/UI/shortcut";
    });
});

function initDashboard() {

    $('#footer_device_timestamp_form').restForm("refreshForm");
    updateTimeTick(0);

    if (gIsMobile) {
        $('#shortcut_toolbar').hide();
    }
}

function updateTimeTick(incrementTime) {
    if (incrementTime) {
        gDateTime = gDateTime + 60;
    }

    var timestamp = getTimeStamp(gDateTime);
    $('#footer_device_date_value').html( timestamp );
    $('#footer_device_time_value').html( timestamp );
    localizeTimeStamp('#footer_device_date_value', 'd');
    localizeTimeStamp('#footer_device_time_value', 't');

    setTimeout("updateTimeTick(1);", 60000); // 60 seconds
}

/* Legacy Sequoia only, no diagnose section on dashboard
function dashboardDeviceUserPollSuccess(data) {
    if (data != null && data.device_users != null && data.device_users.device_user != null){
        updateDashboardCloudDeviceCount(data.device_users);
    }
}

function dashboardMediacrawlerPollSuccess(data) {
    updateDashboardMediaCrawler(data);
}

function dashboardDLNAPollSuccess(data) {
    var videos = dictionaryList['_unknown'];
    var music_tracks = dictionaryList['_unknown'];
    var pictures = dictionaryList['_unknown'];

    if (data != null && data.media_server_database != null) {

        if (data.media_server_database.videos != null && data.media_server_database.videos != '') {
            videos = data.media_server_database.videos;
        }
        if (data.media_server_database.music_tracks != null && data.media_server_database.music_tracks != '') {
            music_tracks = data.media_server_database.music_tracks;
        }
        if (data.media_server_database.pictures != null && data.media_server_database.pictures != '') {
            pictures = data.media_server_database.pictures;
        }

        if (data.media_server_database.scan_in_progress == 'true') {
            gDLNAScanningState = 'scanning';
            $("#dlna_media_server_scan_in_progress").html("&nbsp;"+ dictionaryList['mediaScanInProgress']);

            $(".dashboard_dlna_list_item_count").show();
            $(".dashboard_dlna_list_item_done").hide();
            $("#dlna_media_server_scan_in_progress").show();

            $("#dashboard_dlna_videos_count").text(videos);
            $("#dashboard_dlna_music_count").text(music_tracks);
            $("#dashboard_dlna_photos_count").text(pictures);
        }
        else {
            var dashboard_dlna_tooltip;

            $(".dashboard_dlna_list_item_count").hide();
            $(".dashboard_dlna_list_item_done").attr('style', 'display:inline-block;');
            $("#dlna_media_server_scan_in_progress").hide();

            if (videos == dictionaryList['_unknown'] || music_tracks == dictionaryList['_unknown'] || pictures == dictionaryList['_unknown']) {
                gDLNAScanningState = 'unknown';
            }
            else {
                gDLNAScanningState = 'idle';

                dashboard_dlna_tooltip = dictionaryList['videos_scanned'];
                $('#dashboard_dlna_videos_tooltip').html( dashboard_dlna_tooltip.replace('{0}', videos) );

                dashboard_dlna_tooltip = dictionaryList['music_scanned'];
                $('#dashboard_dlna_music_tooltip').html( dashboard_dlna_tooltip.replace('{0}', music_tracks) );

                dashboard_dlna_tooltip = dictionaryList['photos_scanned'];
                $('#dashboard_dlna_photos_tooltip').html( dashboard_dlna_tooltip.replace('{0}', pictures) );
            }
        }
    }
    else {
        gDLNAScanningState = 'unknown';
    }

    if (gDLNAScanningState == 'unknown') {
        $(".dashboard_dlna_list_item_done").hide();
        $(".dashboard_dlna_list_item_count").show();

        $("#dashboard_dlna_videos_count").text(videos);
        $("#dashboard_dlna_music_count").text(music_tracks);
        $("#dashboard_dlna_photos_count").text(pictures);

        $('#dashboard_dlna_list_item_count').siblings('.iconTooltip_container').hide();
    }

    updateDashboardContentScan();
}


function dashboardPollError() {
    // do nothing
}

function dashboardDLNAPollError(request, status, error) {
    $('.dashboard_dlna_list').find('.dashboard_media_list_scan_done').removeClass('mediaScanIconDone');
    $('.dashboard_dlna_list').find('.dashboard_media_list_scan_done').removeClass('mediaScanIconError');

    if (status == 'error') {
        gDLNAScanningState = 'error';
        $('.dashboard_dlna_list_item_count').hide();

        $('.dashboard_dlna_list_item_done').attr('style', 'display:inline-block;');
        $('.dashboard_dlna_list').find('.dashboard_media_list_scan_done').addClass('mediaScanIconError');

        var errorMsg = getPollingErrorMessage(request);
        
        $('.dashboard_dlna_list').find('.tooltip').text(errorMsg);
    }
    else {
        gDLNAScanningState = 'unknown';
        $(".dashboard_dlna_list_item_done").hide();

        $(".dashboard_dlna_list_item_count").show();
        $("#dashboard_dlna_videos_count").text(dictionaryList['_unknown']);
        $("#dashboard_dlna_music_count").text(dictionaryList['_unknown']);
        $("#dashboard_dlna_photos_count").text(dictionaryList['_unknown']);
    }

    updateDashboardContentScan();
}

function dashboardMediacrawlerPollError(request, status, error) {
    updateDashboardMediaCrawlerError(request, status);
    updateDashboardContentScan();
}
*/

function subscribeDashboardPolls() {
    if (updateCountHandler != null) {
    	
        updateCountHandler.subscribe("data_volume_write_update_count", function () {
        	dashboardHandler.callHandler('updateStorage');
        },
        "dashboard_container"
        );
        updateCountHandler.subscribe("battery_update_count", function () {
        	$('#battery_status_form').restForm("refreshForm");
        },
        "dashboard_container"
        );
    	updateCountHandler.subscribe("battery_update_count", function () {
        	$('#battery_status_form').restForm("refreshForm");
        },
        "hardware_container"
        );       

        /* Legacy Sequoia only, no diagnose section on dashboard
        updateCountHandler.subscribe("system_state_update_count", function () {
        	dashboardHandler.callHandler('updateHealth');
        },
        "dashboard_container"
        );
        */

        /* Legacy Sequoia only, no shares section on dashboard
        updateCountHandler.subscribe("share_update_count", function () {
        	dashboardHandler.callHandler('updateShareCount', useQueue);
        },
        "dashboard_container"
        );
        */

        /* Legacy Sequoia only, no firmware section on dashboard
        updateCountHandler.subscribe("firmware_update_update_count", function () {
        	dashboardHandler.callHandler('updateFirmware', useQueue);
        },
        "dashboard_container"        
        );
        */
    }
}

/* Legacy Sequoia only, no diagnose section on dashboard
function updateDashboardContentScan() {
    if (gMediaCrawlerScanningState == 'error' || gDLNAScanningState == 'error') {
        $('#dashboard_content_scan').text(dictionaryList['error']);
    }
    else if (gMediaCrawlerScanningState == 'unknown' || gDLNAScanningState == 'unknown') {
        $('#dashboard_content_scan').text(dictionaryList['_unknown']);
    }
    else if (gMediaCrawlerScanningState == 'scanning' || gDLNAScanningState == 'scanning') {
        $('#dashboard_content_scan').text(dictionaryList['scanning']);
    }
    else {
        $('#dashboard_content_scan').text(dictionaryList['idle']);
    }
}

function updateMediaScanDialog(mediaType, count, total) {

    var mediaPercent = 100;
    if (total > 0) {
        mediaPercent = Math.round(count / total * 100);

        // due to side-effect of ITR 65787, media transcoded can exceed total media
        if (mediaPercent > 100) {
            mediaPercent = 100;
        }
    }
    $('#dashboard_media_' + mediaType + '_count').attr("style", "width:"+mediaPercent+"%");
    $('#dashboard_media_' + mediaType + '_percent').text( mediaPercent + '%' );
    if (mediaPercent == 100) {
        $('#dashboard_media_' + mediaType + '_scan_txt').hide();
        $('#dashboard_media_' + mediaType + '_scan_done').show();

        $('#dashboard_media_' + mediaType + '_count').parent().hide();
        $('#dashboard_media_' + mediaType + '_percent').hide();

        //var dashboard_media_tooltip = $('#dashboard_media_' + mediaType + '_tooltip').html();
        var dashboard_media_tooltip = dictionaryList[mediaType+'_scanned'];
        $('#dashboard_media_' + mediaType + '_tooltip').html( dashboard_media_tooltip.replace('{0}', total) );
    }
    else {
        $('#dashboard_media_' + mediaType + '_scan_done').hide();
        $('#dashboard_media_' + mediaType + '_scan_txt').show();

        $('#dashboard_media_' + mediaType + '_scan_txt').html(count + ' / ' + total);
        $('#dashboard_media_' + mediaType + '_count').parent().attr('style', 'display:inline-block;');
        $('#dashboard_media_' + mediaType + '_percent').attr('style', 'display:inline-block;');
    }
}
*/

(function ($) {
    $.extend({
        updateDashboardHandler: function (options){
            var $this = this;
            var settings = {
                updateFinishedList: {},
                updateHandles: {},
                updateFinishCallback: null,
                byteDivisor: 1000
            };
            var handler = {
                init: function(options){
                	$.extend(settings, options);
                    return this;
                },
                addUpdateHandle: function(handle, id){
                	settings.updateFinishedList[id] = false;
                	handle.updateCompleteHandler = function(){
                		settings.updateFinishedList[id] = true;
                		handler.updateFinished();
                	};
                	settings.updateHandles[id] = handle;
                },
                updateAll: function(){
                	for (var i in settings.updateHandles){
                		settings.updateHandles[i].update();
                	}
                },
                callHandler: function(handleId, parameters){
                	if(settings.updateHandles[handleId] != null){
                		settings.updateHandles[handleId].update.apply(settings.updateHandles[handleId], parameters);
                	}
                },
                updateFinished: function(){
                	var isFinished = true;
                	for (var i in settings.updateFinishedList){
                		if (settings.updateFinishedList[i] == false){
                			isFinished = false;
                			break;
                		}
                	}
                	if (isFinished){
                		settings.updateFinishCallback();
                	}
                }
            };
            return handler.init(options);
		}
    });
    
    
// #########################################################
//                dialogs 
// #########################################################
    
    /* Legacy Sequoia
    $("#dashboard_diagnostics_dialog").dialog({
            autoOpen: false,
            resizable: false,
            width: 600,
            minHeight: 400,
            dialogClass: 'mochi_dialog mochi_dialog_diagnosis',
            modal: true,
            stack: false,
            title: '<div class="wizard_dialog_title">'+$('#dashboard_diagnostics_dialog').attr('title')+'</div>'
      });
      
    $("#dashboard_media_dialog").dialog({
            autoOpen: false,
            resizable: false,
            width: 500,
            minHeight: 400,
            dialogClass: 'mochi_dialog mochi_dialog_media',
            modal: true,
            stack: false,
            title: '<div class="wizard_dialog_title">'+$('#dashboard_media_dialog').attr('title')+'</div>'
      });
          
    $("#dashboard_capacity_dialog").dialog({
            autoOpen: false,
            resizable: false,
            width: 600,
            minHeight: 400,
            dialogClass: 'mochi_dialog mochi_dialog_capacity',
            modal: true,
            stack: false,
            title: '<div class="wizard_dialog_title">'+$('#dashboard_capacity_dialog').attr('title')+'</div>'
      });
    */
              
// ###############################################################
//
//              click events
//
// ###############################################################         
           
    /* Legacy Sequoia
    $('#dashboard_create_user_link').click(function(e){
    	e.preventDefault();
    	//$('#nav_users_link').click();
    	$('#create_user_btn').click();

        //hideUsersBumper();
    });
    
    $('#dashboard_create_share_link').click(function(e){
    	e.preventDefault();
    	//$('#nav_shares_link').click();
    	$('#create_share_btn').click();

        //hideSharesBumper();
    });
    
    $('#dashboard_firmware_link').click(function(e){
        e.preventDefault();
        checkForFirmwareAvailable();

    });

    $('#dashboard_diagnostics_link').click(function(e){
        e.preventDefault();
		$('#dashboard_diagnostics_temperature').html(deviceTemperature);
		$('#dashboard_diagnostics_smart_status').html(deviceSmartStatus);
		$('#dashboard_diagnostics_volume_status').html(deviceVolumeStatus);
		$('#dashboard_diagnostics_free_space').html(deviceFreeSpace);
				
    	$('#dashboard_diagnostics_dialog').dialog('open');
    });
	
    $('#dashboard_diagnostics_close_button').click(function(e){
    	$('#dashboard_diagnostics_dialog').dialog('close');
    });


    $('#dashboard_create_mobile_device_link').click(function(e){
        e.preventDefault();
        $("#create_cloud_device_dialog").dialog("open");
    });

    $('#dashboard_media_close_button').click(function(e){
        $('#dashboard_media_dialog').dialog('close');
    });

    $('#dashboard_media_info_link').click(function(e){
        e.preventDefault();
        $('#dashboard_media_dialog').dialog('open');
    });

    $('#dashboard_capacity_close_button').click(function(e){
        $('#dashboard_capacity_dialog').dialog('close');
    });
    */

})(jQuery);