
<div id="settings_dlna_database_container">
    <div class="content_row">
        <label><?php echo _('CONTENT_SETTINGS_STRING_MEDIA')?></label>
        <span id="dlnaMediaDB_count" style="display:none;">
            <?php echo _('LABEL_HEADER_MUSIC')?>&nbsp;<span id="settings_media_dlna_music_tracks"></span>&nbsp;&nbsp;&nbsp;
            <?php echo _('LABEL_HEADER_PICTURES')?>&nbsp;<span id="settings_media_dlna_pictures"></span>&nbsp;&nbsp;&nbsp;
            <?php echo _('LABEL_HEADER_VIDEOS')?>&nbsp;<span id="settings_media_dlna_videos"></span>
        </span>
    </div>

    <div class="content_row">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_DLNA_DATABASE");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("AVATAR_CONTENT_SETTINGS_MEDIA_TOOLTIP_DLNA_DATABASE_RESCAN");?>&nbsp;<?php echo _("CONTENT_SETTINGS_MEDIA_TOOLTIP_DLNA_DATABASE_REBUILD");?></div></div></div></label>
        <span id="dlna_mediadb_button_container">
            <button id="dlna_mediadb_rescan_button"><?php echo _('AVATAR_BUTTON_RESCAN_MEDIA')?></button>
            <span class="extra_space_left"></span><button id="dlna_mediadb_rebuild_button"><?php echo _('BUTTON_REBUILD')?></button>
        </span>
        <!--<span id="dlnaMediaDBProcessContainer" style="display:none;"><?php echo _("CONTENT_SETTINGS_STRING_UPDATING_DATABASE");?></span>-->
    </div>

    <div class="content_row">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_SCAN_ACTIVITY");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_MEDIA_TOOLTIP_DLNA_SCAN_ACTIVITY");?></div></div></div></label>
        <span id="settings_media_dlna_last_update_string"><?php echo _("CONTENT_AVATAR_MEDIA_UPDATED");?></span>
        <span id="settings_media_dlna_update">&nbsp;</span>
        <span id="dlnaMediaDBProcessContainer" style="display:none;"><?php echo _("CONTENT_SETTINGS_STRING_UPDATING_DATABASE");?></span>
    </div>
</div>

