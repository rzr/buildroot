<div class="content_row">
    <form id="settings_media_toggle_dlna_service_form" action="media_server_configuration" method="PUT">
        <label><?php echo _("CONTENT_SETTINGS_LABEL_MEDIA_STREAMING");?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _("CONTENT_SETTINGS_MEDIA_TOOLTIP_STREAMING");?></div></div></div></label>
        <input class="false" name="enable_media_server" value="false" type="hidden"/>
        <input id="dlna_enabled" class="onoffswitch" name="enable_media_server" value="true" type="checkbox"/>
        <!--
        <span id="settings_dlna_form_advanced_options" style="display:none;">
            <a id="settings_dlna_form_advanced_options_link" href="#"><?php echo _("CONTENT_SETTINGS_LINK_VIEW_MEDIA_PLAYERS");?><span class="details_link_marker">&nbsp;&raquo;</span></a>
        </span>
        -->
    </form>
</div>