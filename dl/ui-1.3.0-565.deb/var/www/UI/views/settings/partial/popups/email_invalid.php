<div id="alert_email_invalid_email" title="<?php echo _('CONTENT_SETTINGS_DIALOG_TITLE_INVALID_EMAIL')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
			<p><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_INVALID_EMAIL')?></p>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="alert_email_invalid_email_close_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>