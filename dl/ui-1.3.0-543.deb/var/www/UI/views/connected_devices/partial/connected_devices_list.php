
<form id="wifi_ap_client_default_form" action="wifi_ap_clients"></form>
<form method="DELETE" id="wifi_ap_client_delete_form" action="wifi_ap_clients"></form>

<div id="connected_devices_container" class="wifi_network_outer_box">
    <a href="#" id="connected_devices_list_refresh"></a>
    <div class="content_row wifi_box_title overflow_hidden_nowrap_ellipsis">
        <?php echo _('CONTENT_SETTINGS_LABEL_CONNECTED_DEVICES')?>
    </div>
    <div class="wifi_network_inner_box">
        <ul id="connected_devices_list" class="mochi_list">
            <li class="connected_devices_item default">
                <span class="connected_device_image"></span>
                <div class="iconTooltip_container connected_device_label_container">
                    <div class="tooltip_icon">
                        <label class="connected_device_label overflow_hidden_nowrap_ellipsis">
                            <span class="wireless_label_text"></span>
                        </label>
                    </div>
                    <div class="tooltip_inner_container">
		                <div class="tooltip">
                            <ul>
                                <li><?php echo _('CONTENT_SETTINGS_LABEL_DEVICE_NAME')?>: <span class="connected_device_name"></span></li>
                                <li><?php echo _('LABEL_HEADER_MAC_ADDRESS')?>: <span class="connected_device_macaddress"></span></li>
                                <li><?php echo _('LABEL_HEADER_IP_ADDRESS')?>: <span class="connected_device_ipaddress"></span></li>
                                <li><?php echo _('CONTENT_SETTINGS_LABEL_CONNECTION_UPTIME')?>: <span class="connected_device_uptime"></span></li>
                            </ul>
                        </div>
	                </div>
                </div>
                <div class="iconTooltip_container connected_device_delete_container">
                    <div class="tooltip_icon">
                        <a href="#" class="connected_device_delete"></a>
                    </div>
                    <div class="tooltip_inner_container">
		                <div class="tooltip"><?php echo _('TOOLTIP_REMOVE_THIS_CONNECTED_DEVICE')?></div>
	                </div>
                </div>
            </li>
        </ul>
    </div>
</div>

<div id="router_connected_devices_container" class="wifi_network_outer_box">
    <div class="content_row wifi_box_title overflow_hidden_nowrap_ellipsis"><?php echo _('CONTENT_SETTINGS_LABEL_HOME_CONNECTED_DEVICES')?></div>
    <div class="wifi_network_inner_box">
        <ul id="router_connected_devices_list" class="mochi_list">
            <li class="router_connected_devices_item">
                <span class="connected_device_image connected_device_me_image"></span>
                <div class="iconTooltip_container connected_device_label_container">
                    <div class="tooltip_icon">
                        <label class="connected_device_label overflow_hidden_nowrap_ellipsis">
                            <span><?php echo _('CONTENT_SETTINGS_STRING_ME')?></span>
                        </label>
                    </div>
                    <div class="tooltip_inner_container">
		                <div class="tooltip">
                            <ul>
                                <li><?php echo _('LABEL_HEADER_IP_ADDRESS')?>: <span id="home_connected_device_ipaddress"></span></li>
                            </ul>
                        </div>
	                </div>
                </div>
            </li>
        </ul>
    </div>
</div>
