
<div id="authentication_container">
    <div id="authentication_content">
        <h2><?php echo _('CONTENT_LOGIN_TITLE')?></h2>
        <form id="login_form" action="users" method="get">
            <div class="white_bg">
    
                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_USERNAME'); ?></label>
                    <input type="hidden" id="login_username" name="username" value="admin" />
                    <span id="login_user_id"></span>
                </div>
        
                <div class="content_row">
                    <label><?php echo _('GLOB_NAV_LOGIN_LABEL_PASSWORD'); ?></label>
                    <input type="password" id="login_password" name="password" value="" autocomplete="off" />
                </div>
        
                <!--
                <div class="content_row" id="password_hint_container">
                    <label><?php echo _('LABEL_DESCR_SHOW_PASSWORD_HINT'); ?></label>
                    <span id="password_hint"></span>
                </div>
                -->
    
                <div>
                    <span id="invalid_unauthorized"><?php echo _('GLOB_NAV_LOGIN_STRING_UNAUTHORIZED'); ?></span>
                </div>
                
            </div>
            
            <div class="content_row">
                <button type="button" id="login_ok_button" class="mochi_dialog_save_button wizard_action"><?php echo _('GLOB_NAV_LINK_LOGIN_AVATAR')?></button>
            </div>
            
        </form>
    </div>
    <div class="pass_city"></div>
</div>
