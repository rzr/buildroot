<?php
    include(realpath(dirname(__FILE__))."/../../../views/common/languages.php");

?>
<div id="language_toolbar" class="toolbar_item" style="display:none">
    <div id="language_container" class="toolbar_button_container">
        <form method="PUT" id="eula_language_form" action="language_configuration">
            <div class="selectBox defaultfont">
                <select id="eula_language_select" name="language"><?php foreach($languages as $index=>$language):?>
                    <option value="<?php echo $index?>"><?php echo $language?></option>
                <?php endforeach;?></select>
            </div>
        </form>
    </div>
</div>

