<div id="<?php echo $identifier?>_container">
    <div id="<?php echo $identifier?>_content" class="content_container">
    	<?php $view->LoadContents();$view->LoadViews();?>
	</div>
</div>