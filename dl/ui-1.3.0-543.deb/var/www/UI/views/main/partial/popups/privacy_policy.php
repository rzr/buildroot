<?php

$privacyPolicy = 'Privacy%20Policy/'.LANGUAGE_STR.'.html';
if (!file_exists($privacyPolicy)) {
    $privacyPolicy = 'Privacy%20Policy/en_US.html';
}

?>

<div id="privacy_policy_overlay" title="<?php echo _('CONTENT_SETTINGS_LINK_PRIVACY_POLICY'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <div id="privacyPolicyTextWrap">
                <div id="privacyPolicyText">
                    <iframe src="<?php echo $privacyPolicy; ?>" id="privacyPolicy_iframe"></iframe>
                </div>
            </div>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="privacy_policy_overlay_close" class="mochi_dialog_save_button"><?php echo _('BUTTON_CLOSE')?></button>
	</div>
</div>
