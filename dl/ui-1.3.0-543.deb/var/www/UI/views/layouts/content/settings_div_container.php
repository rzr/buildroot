<div id="settings_<?php echo $identifier?>_container" style="display:none;">
    <?php $view->LoadContents();$view->LoadViews();?>
</div>