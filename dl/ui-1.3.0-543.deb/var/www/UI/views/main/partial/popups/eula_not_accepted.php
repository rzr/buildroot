<div id="eula_not_accepted" title="<?php echo _('GLOB_NAV_DIALOG_TITLE_EULA_NOT_ACCEPTED'); ?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
		<div class="mochi_dialog_content">
            <div><?php echo _('EULA_ACCEPTANCE_DESC_NOT_ACCEPTED'); ?></div>
		</div>
	</div>
	<div class="dialog_form_controls">
    	<button type="button" id="eula_go_back_button" class="sshOkButton mochi_dialog_save_button"><?php echo _('GLOB_NAV_EULA_BUTTON_GO_BACK')?></button>
    	<!-- <button type="button" id="eula_exit_application_button" class="sshOkButton mochi_dialog_save_button"><?php echo _('GLOB_NAV_EULA_BUTTON_EXIT')?></button>  -->
	</div>
</div>
