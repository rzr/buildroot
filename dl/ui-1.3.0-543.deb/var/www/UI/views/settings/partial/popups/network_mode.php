<div id="network_mode_overlay" title="<?php echo _('CONTENT_DIALOG_SETTINGS_NETWORK_TITLE_NETWORK_MODE')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
        	<p><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_NETWORK_MODE_MESSAGE')?></p>
        
        	<form id="edit_network_lan_configuration_form" method="PUT" action="network_configuration">
        
        		<input type="hidden" id="NetworkModeEditValue" name="proto" value="static"/>
        
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _('LABEL_HEADER_IP_ADDRESS')?><span class="required">&nbsp;*</span><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_IP')?></div></div></div></label>
        				<input type="text" id="SettingIp" class="IPADDRESS" name="ip" value=""/>
        			</div>
        		</div>
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _("LABEL_HEADER_NETMASK")?><span class="required">&nbsp;*</span><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_NETMASK')?></div></div></div></label>
        				<input type="text" id="SettingNetmask" class="NETMASK" name="netmask" value=""/>
        			</div>
        		</div>
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _("LABEL_HEADER_GATEWAY")?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_GATEWAY')?></div></div></div></label>
        				<input type="text" id="SettingGateway" class="GATEWAY" name="gateway" value=""/>
        			</div>
        		</div>
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_1')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_DNS')?></div></div></div></label>
        				<input type="text" class="dns_server_input DNS" id="SettingDns0" name="dns0" value=""/>
        			</div>
        		</div>
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_2')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_DNS')?></div></div></div></label>
        				<input type="text" id="SettingDns1" class="dns_server_input DNS" name="dns1" value=""/>
        			</div>
        		</div>
        		<div class="content_row">
        			<div class="input text">
        				<label><?php echo _('CONTENT_DIALOG_SETTINGS_STRING_DNS_SERVER_3')?><div class="tooltip_container"><span class="tooltip_icon"></span><div class="tooltip_inner_container"><div class="tooltip"><?php echo _('CONTENT_DIALOG_SETTINGS_TOOLTIP_NETWORK_MODE_DNS')?></div></div></div></label>
        				<input type="text" id="SettingDns2" class="dns_server_input DNS" name="dns2" value=""/>
        			</div>
        		</div>
        		<br />     

                <div class="required_text required required_dialog_text require_settings">*&nbsp;<?php echo _("LABEL_DESCR_REQUIRED")?></div>
        
        	</form>
      	</div>
	</div>
	<div class="dialog_form_controls">

    	<button type="button" id="network_mode_cancel_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
        <button type="button" id="network_mode_save_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
	</div>

</div>