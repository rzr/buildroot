<div id="network_mode_confirmation" title="<?php echo _('CONTENT_DIALOG_SETTINGS_NETWORK_TITLE_NETWORK_MODE_CONFIRMATION')?>" class="mochi_dialog_container">
	<div class="mochi_dialog_content_container">
       	<div class="mochi_dialog_content">
        	<p><?php echo _('CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_MODE_CONFIRMATION_MESSAGE')?> </p>        
        	<br/>
        	<p><?php echo _('CONTENT_DIALOG_SETTINGS_LABEL_NETWORK_MODE_CONTINUE_MESSAGE')?></p>
        </div>
    </div>
    <div class="dialog_form_controls">
    	<button type="button" id="network_mode_confirmation_close_button" class="close"><?php echo _('BUTTON_CANCEL')?></button>
    	<button type="button" id="network_mode_confirmation_ok_button" class="mochi_dialog_save_button"><?php echo _('BUTTON_OK')?></button>
	</div>
</div>