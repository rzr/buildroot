$(document).ready(function () {

    /*
	$('#help_iframe').load(function() 
    {
    	$('#help_iframe_message').hide();
		$('#help_iframe_container').show();
    });

    $('.bumper_help_link').click(function (event) {
        event.preventDefault();
        
        $('#help_iframe_message').show();
		$('#help_iframe_container').hide();
		
        url_beginning = "/UI/help/" + gLanguage + "/index.htm#";
        help_link_url = "";
        
        if ($(this).hasClass('about_users')) {
            help_link_url = url_beginning + "user_about.htm";
        }
        else if ($(this).hasClass('adding_users')) {
            help_link_url = url_beginning + "user_add.htm";        
        }
        else if ($(this).hasClass('user_change_access')) {
            help_link_url = url_beginning + "user_change_access.htm";                
        }  
        
        else if ($(this).hasClass('about_shares')) {
            help_link_url = url_beginning + "shares_about.htm";                
        }  
        else if ($(this).hasClass('share_add')) {
            help_link_url = url_beginning + "share_add.htm";                
        }
        else if ($(this).hasClass('about_cloud_access')) {
            help_link_url = url_beginning + "cloud_access_about.htm";                
        }  
        else if ($(this).hasClass('cloud_access_basics')) {
            help_link_url = url_beginning + "remote_basics.htm";                
        }  
        else if ($(this).hasClass('setting_up_cloud_access')) {
            help_link_url = url_beginning + "remote_access_setup_general.htm";                
        }  
        else if ($(this).hasClass('setting_up_cloud_access')) {
            help_link_url = url_beginning + "remote_access_setup_general.htm";                
        } 
        else if ($(this).hasClass('about_safepoints')) {
            help_link_url = url_beginning + "safepoints_about.htm";                
        }  
        else if ($(this).hasClass('creating_a_safepoint')) {
            help_link_url = url_beginning + "safepoint_create.htm";                
        }
        else if ($(this).hasClass('safepoint_restore')) {
            help_link_url = url_beginning + "safepoint_restore.htm";                
        }    
        
        $('#help_iframe').attr("src", help_link_url);

        $("#help_dialog").dialog("open");      


    });
    */
    
    /*
    $('#help_dialog_link').click(function (event) {
        event.preventDefault();
        $('#help_iframe_message').show();
		$('#help_iframe_container').hide();
		
        $('#help_list_container').hide();
        help_link_url = "/UI/help/" + gLanguage + "/index.htm";

        if ($('#help_link').hasClass('selected')){
        	$('#help_link').removeClass('selected');
        }
        $('#help_iframe').attr("src", help_link_url);

        $("#help_dialog").dialog("open");
    });
    */
    

    /*
    $('#help_support_link').navItem({
        'contentId': 'support_container',
        'refreshDataCall': function(){

            // Hide help container
            $('#help_list_container').toggle();
            if ($('#help_link').hasClass('selected')){
            	$('#help_link').removeClass('selected');
            }
            else{
            	$('#help_link').addClass('selected');
            }

            // Set Selection
            resetNavigationSelection('#head_settings_nav_support_link');

        }
    });
    */

    $('#help_about_link').click(function (e) { 
        e.preventDefault();

        $("#about_firmware_version").text(VERSION);
        $("#about_dialog").dialog("open");
    });
    
    $('#help_topic_help').click(function (e) { 
        e.preventDefault();

        $("#help_dialog").dialog("open");
    });

    $("#about_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: dialogWidth,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_logo',
        modal: true,
        stack: false,
		title: '<div class="wizard_dialog_title">'+$('#about_dialog').attr('title')+'</div>',
        open: function(){
            $('#about_dialog_close_button').focus();
        }
    });
    
    $('#about_dialog_close_button').click(function () { 
        $("#about_dialog").dialog("close");
    });
    
    $("#help_dialog").dialog({
        autoOpen: false,
        resizable: false,
        width: 620,
        minHeight: dialogMinHeight,
        dialogClass:'mochi_dialog mochi_dialog_logo',
        modal: true,
        stack: false,
		title: '<div class="wizard_dialog_title">'+$('#help_dialog').attr('title')+'</div>'
    });
    
    $('#help_close_button').click(function (event) {

        $("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
        
        $("#help_dialog").dialog("close");
    });

    $('.help_load_content').click(function (event) { 
    	 $("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();    	 
    	 $("#help_load_content > .disclosureTitle").click(); 
    	 $('#help_container').scrollTop(0);
    });
    
    $('.help_connect_with_usb').click(function (event) {    
   	 	$("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
   	 	$("#help_connect_with_usb > .disclosureTitle").click();
   	 	$('#help_container').scrollTop(0);
   });
    $('.help_get_led_meaning').click(function (event) {    
   	 	$("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
   	 	$("#help_get_led_meaning > .disclosureTitle").click();
   	 	$('#help_container').scrollTop(0);
   });

    $('.help_first_connect_status').click(function (event) {    
   	 	$("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
   	 	$("#help_first_connect_status > .disclosureTitle").click();
   	 	$('#help_container').scrollTop(0);
   });
    
    $('.help_connect_to_internet').click(function (event) {    
        $("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
        $("#help_connect_to_internet > .disclosureTitle").click();
        $('#help_container').scrollTop(0);
   });
    
    $('.help_copy_with_usb').click(function (event) {    
   	 	$("#help_container > div.toggleLeftArrow.down > .disclosureTitle").click();
   	 	$("#help_copy_with_usb > .disclosureTitle").click();
   	 	$('#help_container').scrollTop(0);
   });
    
    
    $('.toggleLeftArrow').each(
        /* The below scripts control the disclosure triangles used for the Tasks and FAQ sections.
        * A set of functions is required for EACH disclosure triangle
        */
        //Generic toggler for collpsable arrows
        function() {
            var disclosureId = $(this).attr('id');  // get the #id of the entire disclosure div

            $('#'+disclosureId +' > .disclosureTitle').toggle(  // add a toggle to the disclosure title
                function() {
                    
               	 	$('#'+disclosureId).removeClass('up').addClass('down'); // change the style of the entire disclosure div
               	 	$('#'+disclosureId +' > .disclosureContent').css({display:'block'}); // display the disclosure content div
               	 	$(this).parent().siblings('.up').css({display:'none'});
                    //console.log('test' +disclosureId);

                    $('#help_container').scrollTop(0);
                },
                function() {
                    //console.log('second toggle:' + disclosureId);   // debug
                    $('#'+disclosureId).removeClass('down').addClass('up'); // change the style of the entire disclosure div
                    $('#'+disclosureId +' > .disclosureContent').css({display:'none'}); // hide the disclosure content div
                    $(this).parent().siblings('.up').css({display:'block'});

                }
            );
        }
    );

    var helpmsg = dictionaryList['help_first_connect_status_for_pc'].replace('{0}', '<a href="http://mypassport" target="_blank">http://mypassport</a>');
    $('#help_first_connect_status_for_pc').html(helpmsg);

    helpmsg = dictionaryList['help_first_connect_status_for_mac'].replace('{0}', '<a href="http://mypassport.local" target="_blank">http://mypassport.local</a>');
    $('#help_first_connect_status_for_mac').html(helpmsg);

    helpmsg = dictionaryList['help_getting_started_more_info'].replace('{0}', '<a href="http://wd.com/setup/mypassportwireless" target="_blank">http://wd.com/setup/mypassportwireless</a>');
    $('#help_getting_started_more_info').html(helpmsg);

    helpmsg = dictionaryList['help_connect_with_usb_more_info'].replace('{0}', '<a href="http://wd.com/setup/mypassportwireless" target="_blank">http://wd.com/setup/mypassportwireless</a>');
    $('#help_connect_with_usb_more_info').html(helpmsg);

});

