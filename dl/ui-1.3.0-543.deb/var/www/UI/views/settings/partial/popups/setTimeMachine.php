<div id="set_time_machine_dialog" title="<?php echo _("CONTENT_SETTINGS_DIALOG_TITLE_TIME_MACHINE_SETTINGS");?>" class="mochi_dialog_container">

	<form id="update_time_machine_form" method="PUT" action="time_machine">
		<div class="mochi_dialog_content_container">
			<div class="mochi_dialog_content">
				<p><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_TIME_MACHINE_INTRO");?></p>
				<br />

				<div class="edit_container_box">


					<div class="content_row">
						<label><?php echo _("CONTENT_SETTINGS_DIALOG_LABEL_SELECT_A_SHARE");?></label>
						<div class="selectBox defaultfont">
							<select id="SettingsTimeMachineShareSelect">
								<option value="" rel=""></option>
							</select>
						</div>

					</div>

					<div id="SettingsTimeMachineShareCurrent">
						<table>
							<tr>
								<td><label></label></td>
								<td class="time_machine_warning"><?php echo _("CONTENT_SETTINGS_DIALOG_LABEL_ENABLED_ON_SHARE");?>&nbsp;<span id="SettingsTimeMachineShareCurrentName"></span></td>
							</tr>
						</table>
					</div>

					<div class="content_row">
						<label><?php echo _("CONTENT_SETTINGS_DIALOG_LABEL_MAXIMUM_SIZE");?></label>
						<div id="time_machine_slider"></div>
						<span id="time_machine_slider_value"></span>
					</div>

					<div class="content_row">
						<table>
							<tr>
								<td><label></label></td>
								<td class="time_machine_warning"><?php echo _("CONTENT_SETTINGS_DIALOG_STRING_MAXIMUM_SIZE_WARNING");?></td>
							</tr>
						</table>
					</div>

					<input type="hidden" id="time_machine_backup_enabled" name="backup_enabled" value="" /> <input type="hidden" id="time_machine_backup_size_limit" name="backup_size_limit" value="" />

				</div>
			</div>
		</div>
		<div class="dialog_form_controls">
			<button type="button" id="update_time_machine_form_cancel_button"><?php echo _('BUTTON_CANCEL')?></button>
			<button type="button" id="update_time_machine_form_save_button"  class="mochi_dialog_save_button"><?php echo _('BUTTON_SAVE')?></button>
		</div>
	</form>
</div>
