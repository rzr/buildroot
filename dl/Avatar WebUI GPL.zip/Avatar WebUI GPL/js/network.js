var networkModeIsStatic = false;
var savingNetworkModeData = false;

$(document).ready(function(){

// #########################################################
//                nav Items 
// #########################################################    

    $('#settings_nav_network_settings').navItem({
	    'containerId': 'settings_content',
	    'contentId': 'network_container',
	    'selectedClass': 'selected',
	    'refreshDataCall': function(){
	    	$('#network_ftp_form').restForm("refreshForm");
	    	$('#network_lan_configuration_form').restForm("refreshForm");
	    	$('#network_workgroup_form').restForm("refreshForm");
	        $('#ssh_form').restForm("refreshForm");
	        //$('#internet_connectivity_form').restForm("refreshForm");
            $('#network_config_mac_address').text(gMacAddress);
            $('#network_config_ip_address').text(gIPAddress);
            /*
    		$.ajaxAPI({
				"url": "system_information",
				"success": function(data) {

            	    $('#network_config_mac_address').text(data.system_information.mac_address);
				}
			});
            */
	    }
    });
    
// #########################################################
//                forms 
// #########################################################
	
    /* Legacy Sequoia
    $('#network_lan_configuration_form').restForm({
        'useStubs': false,
        'onOffCheckboxOptions': {
            checkedLabel: dictionaryList['Static'],
            uncheckedLabel: dictionaryList['DHCP']
        },
        'timeout': ajaxTimeoutNetwork,
        'refreshDataCallback' : function(data) {
            
            if (data.network_configuration.proto.toLowerCase() == 'static') {
                networkModeIsStatic = true;
                $("#settings_network_mode_dhcp_button").removeClass("button-selected");
                $('#settings_network_mode_static_button').addClass("button-selected");
                
                $('#network_mode_details').css('display', 'inline-block');               
                $('#network_config_ip_address').html(data.network_configuration.ip); 
            }                   
            else {
                networkModeIsStatic = false;
                $('#network_mode_details').css('display', 'none');
                $("#settings_network_mode_dhcp_button").addClass("button-selected");
                $('#settings_network_mode_static_button').removeClass("button-selected");

                $('#network_config_ip_address').html(data.network_configuration.ip);             

            } 

        },
        'processFormSuccessCallback': function () {

            $('#network_lan_configuration_form').restForm("processFormSuccess");

        },
        'processFormErrorCallback': function(request, status, error) {
            $('#network_mode_confirmation').dialog('close');

            // workaround to redirect after timeout (until API can returns response)
            if (error == 'timeout') {
                var hostname = $('#settings_device_name_form_machine_name').val();
                stopPolling();
                window.location = 'http://'+hostname;
            }
            else {
                $('#network_lan_configuration_form').restForm('processFormError', request, status, error);
            }
        }             

    });
    */
    
    /* Legacy Sequoia
    $('#edit_network_lan_configuration_form').restFormDialog({
        'dialogName': 'network_mode_overlay',
    	'useStubs': false,
        'timeout': ajaxTimeoutNetwork,
        'refreshDataCallback' : function(data) {
            if (data.network_configuration.proto.toLowerCase() == 'static') {
                networkModeIsStatic = true;
                //$('#edit_network_lan_configuration_form').find('#NetworkModeEditValue').val('static');
                $('#SettingIp').val("");
                $('#SettingIp')[0].defaultValue = "";
                if (data.network_configuration.ip != undefined) {                
                    $('#SettingIp').val(data.network_configuration.ip);
                    $('#SettingIp')[0].defaultValue = data.network_configuration.ip;
                }
                
                $('#SettingNetmask').val("");
                $('#SettingNetmask')[0].defaultValue = "";                
                if (data.network_configuration.netmask != undefined) {                
                    $('#SettingNetmask').val(data.network_configuration.netmask);
                    $('#SettingNetmask')[0].defaultValue = data.network_configuration.netmask;
                }

                $('#SettingGateway').val("");
                $('#SettingGateway')[0].defaultValue = "";                
                if (data.network_configuration.gateway != undefined) {                
                    $('#SettingGateway').val(data.network_configuration.gateway);
                    $('#SettingGateway')[0].defaultValue = data.network_configuration.gateway;
                }
                
                $('#SettingDns0').val("");
                $('#SettingDns0')[0].defaultValue = "";
                if (data.network_configuration.dns0 != undefined) {                
                    $('#SettingDns0').val(data.network_configuration.dns0);
                    $('#SettingDns0')[0].defaultValue = data.network_configuration.dns0;
                }
                
                $('#SettingDns1').val("");
                $('#SettingDns1')[0].defaultValue = "";
                if (data.network_configuration.dns1 != undefined) {                
                    $('#SettingDns1').val(data.network_configuration.dns1);
                    $('#SettingDns1')[0].defaultValue = data.network_configuration.dns1;
                }
                                
                $('#SettingDns2').val("");
                $('#SettingDns2')[0].defaultValue = "";
                if (data.network_configuration.dns2 != undefined) {                
                    $('#SettingDns2').val(data.network_configuration.dns2);
                    $('#SettingDns2')[0].defaultValue = data.network_configuration.dns2;
                }               
            }                   
            else
            {
                networkModeIsStatic = false;
                //$('#edit_network_lan_configuration_form').find('#NetworkModeEditValue').val('dhcp_client');
                $('#SettingIp').val("");
                $('#SettingIp')[0].defaultValue = "";
                $('#SettingNetmask').val("");
                $('#SettingNetmask')[0].defaultValue = "";
                $('#SettingGateway').val("");
                $('#SettingGateway')[0].defaultValue = "";
                $('#SettingDns0').val("");
                $('#SettingDns0')[0].defaultValue = "";
                $('#SettingDns1').val("");
                $('#SettingDns1')[0].defaultValue = "";
                $('#SettingDns2').val("");
                $('#SettingDns2')[0].defaultValue = "";
            } 

        },
        'validateFormCallback': function () {

            $('#edit_network_lan_configuration_form').restForm("_validateForm");
            return $('#edit_network_lan_configuration_form').data('validForm');
        },
        'processFormSuccessCallback': function () {
            $('#network_mode_overlay').dialog('close');
            $('#edit_network_lan_configuration_form').restForm("processFormSuccess");

            var newip = $('#SettingIp').val();
            var oldip = $("#network_config_ip_address").text();
            if (newip != oldip) {
                stopPolling();
                window.location = 'http://'+newip;
            }
        },
        'processFormErrorCallback': function(request, status, error) {
            $('#network_mode_overlay').dialog('close');

            // workaround to redirect after timeout (until API can returns response)
            if (error == 'timeout') {
                var newip = $('#SettingIp').val();
                stopPolling();
                window.location = 'http://'+newip;
            }
            else {
                $('#edit_network_lan_configuration_form').restForm('processFormError', request, status, error);
            }
        }             
        
    });
    */
    	
    $('#network_workgroup_form').restForm({
        'refreshDataCallback' : function(data) {
            if (data != null && data.network_workgroup != null) {
                $('#SettingWorkgroupName').val(data.network_workgroup.workname);
                $('#SettingWorkgroupName')[0].defaultValue = data.network_workgroup.workname;
            }
        },
        'validateFormCallback': function () {

            $('#network_workgroup_form').restForm("_validateForm");
            return $('#network_workgroup_form').data('validForm');

        }	
	});
	
    $('#ssh_confirmation_form').restForm();
    $('#SettingsSshIAgreeToggle_form').restForm();

    $('#SettingsSshIAgreeToggle').click(function () {	
        if ($(this).is(':checked')){
            $('.sshOkButton').attr('disabled', true);
            $('.sshOkButton').addClass('ui-state-disabled');
        }
        else {
            $('.sshOkButton').attr('disabled', false);
            $('.sshOkButton').removeClass('ui-state-disabled');
        }
    });

    $('#network_ftp_form').restForm({
        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
            
            // if there is a smart test in progress, process the data
            if (data.network_services_configuration.enable_ftp.toLowerCase() == 'true') {                
                $('#network_ftp_form').find('#SettingNetworkFtpToggle').attr('checked',true);
            }
            else
            {
                $('#network_ftp_form').find('#SettingNetworkFtpToggle').attr('checked',false);
                
            }  
        }
    });
	
    /* Legacy Sequoia    
	$('#internet_connectivity_form').restForm({
        'useStubs': false,
        
        // #############################################################################################
        //
        // To do - will have to do some sort of polling for internet connectivity when in network screen
        //
        // #############################################################################################
        // this is called when a refresh (get) is requested
        'refreshDataCallback' : function(data) {
            if (data.internet_access.connectivity == "true") {
                $('#internet_connectivity_good').css("display", "inline-block");
                $('#internet_connectivity_bad').css("display", "none");
                gInternetAccess = true;
                
            }
            else {
                $('#internet_connectivity_good').css("display", "none");
                $('#internet_connectivity_bad').css("display", "inline-block");
                gInternetAccess = false;
            
            }
        }
    }); 
    */ 

});

// #########################################################
//                dialogs 
// #########################################################

    /* Legacy Sequoia    
    $("#network_mode_confirmation").dialog({
        autoOpen: false,
        resizable: false,
        position: 'center',
        width:500,
        minHeight:300,
        dialogClass:'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#network_mode_confirmation').attr('title')+'</div>'
    });
    */
    
    /* Legacy Sequoia    
    $('#network_mode_confirmation_close_button').click(function(){
    	$('#network_mode_confirmation').dialog('close');
        cancelEditStaticNetworkMode();
    }); 
    */ 
    
    /* Legacy Sequoia    
    $('#network_mode_confirmation_ok_button').click(function(){
    	$('#network_mode_confirmation').dialog('close');
        if ($('#settings_network_mode_static_button').hasClass("button-selected")) {
            $('#network_mode_overlay').dialog('open');
            $('#network_mode_details').css('display', 'inline-block');
        }
        else {
            // make sure we can ping the server before executing a save network configuration
            $.ajaxAPI({
                "url": "system_state",
                "timeout": ajaxTimeoutNetwork,
                "error": function (request, status, error) {
                    showError('edit_network_lan_configuration_form_internal_error');
                },
                "success": function (data) {
                    $('#network_lan_configuration_form').submit();
                    $('#network_lan_configuration_form').restForm("refreshForm");
                }
            });
        }
    }); 
    */ 
    
    /* Legacy Sequoia
    $("#network_mode_overlay").mochiDialog({
        autoOpen: false,
        resizable: false,
        width: 600,
        minHeight: 500,
        dialogClass: 'mochi_dialog mochi_dialog_network',
        modal: true,
        stack: false,
        title: '<div class="wizard_dialog_title">'+$('#network_mode_overlay').attr('title')+'</div>',
        open: function(event, ui){
            $('#edit_network_lan_configuration_form').restForm("refreshForm");
            $("#network_mode_overlay").mochiDialog('_open', event, ui);
        },
        close: function(event, ui){
            if (!savingNetworkModeData){
                cancelEditStaticNetworkMode();
                savingNetworkModeData = false;
            }        
       }            
    });
    */

// #########################################################
//                functions 
// #########################################################

$(function(){	

    $('#SettingNetworkFtpToggle').bind('toggle', function (event) {
    
        if ($(this).is(':checked')) {
            $('#network_enable_ftp_value').val('true');
        }
        else {
            $('#network_enable_ftp_value').val('false');
        }
        $('#network_ftp_form').submit();
    });
    
//    $("#NetworkModeToggle").live('toggle',
//        function(e){
//            $("#network_mode_confirmation").dialog('open');
//        }
//    );
	
    /* Legacy Sequoia	
	$('#settings_network_mode_static_button').click(function () {
        if (!$('#settings_network_mode_static_button').hasClass("button-selected")) {
            $("#network_mode_confirmation").dialog('open'); 
            $("#settings_network_mode_dhcp_button").removeClass("button-selected");
            $(this).addClass("button-selected");
        }
    });

    $('#settings_network_mode_dhcp_button').click(function () {
        if (!$('#settings_network_mode_dhcp_button').hasClass("button-selected")) {
            $("#network_mode_confirmation").dialog('open'); 
            $("#settings_network_mode_static_button").removeClass("button-selected");
            $(this).addClass("button-selected");
        }
    });
    */
    
    /* Legacy Sequoia	
    $('#network_mode_details').click(function (e) {
    	e.preventDefault();
        $("#network_mode_overlay").dialog('open');        
    });	
    */
    
    /* Legacy Sequoia		
    $('#network_mode_cancel_button').click(function () {
        savingNetworkModeData = false;
        $('#network_mode_overlay').dialog('close');
        
    });	
    */
    
    /* Legacy Sequoia
    $('#network_mode_save_button').click(function () {

        // make sure we can ping the server before executing a save network configuration
        $.ajaxAPI({
            "url": "system_state",
            "error": function (request, status, error) {
                showError('edit_network_lan_configuration_form_internal_error');
            },
            "success": function (data) {
                savingNetworkModeData = true;
                $('#edit_network_lan_configuration_form').submit();
                //$('#network_mode_overlay').dialog('close');
            }
        });

    });	
    */
    	
});

/* Legacy Sequoia	
function cancelEditStaticNetworkMode() {
    if (networkModeIsStatic) {
        $("#settings_network_mode_dhcp_button").removeClass("button-selected");
        $("#settings_network_mode_static_button").addClass("button-selected");
        $('#network_mode_details').css('display', 'inline-block');
    }                   
    else
    {
        $("#settings_network_mode_dhcp_button").addClass("button-selected");
        $("#settings_network_mode_static_button").removeClass("button-selected");
        $('#network_mode_details').css('display', 'none');
    } 
}
*/

/* Legacy Sequoia	
function updateInternetAccess(data) {

    if (data.connectivity == "true") {
        $('#internet_connectivity_good').css("display", "inline-block");
        $('#internet_connectivity_bad').css("display", "none");
        gInternetAccess = true;
    }
    else {
        $('#internet_connectivity_good').css("display", "none");
        $('#internet_connectivity_bad').css("display", "inline-block");
        gInternetAccess = false;
    }
}
*/
